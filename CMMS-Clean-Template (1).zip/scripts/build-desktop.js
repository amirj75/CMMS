import fs from 'fs';
import path from 'path';

function bundleSingleHtml() {
  const distHtmlPath = path.resolve('dist', 'index.html');
  if (!fs.existsSync(distHtmlPath)) {
    console.error('dist/index.html not found. Run npm run build first.');
    process.exit(1);
  }

  const distHtml = fs.readFileSync(distHtmlPath, 'utf8');
  const assetsDir = path.resolve('dist', 'assets');
  const files = fs.readdirSync(assetsDir);
  const cssFile = files.find(f => f.endsWith('.css'));
  const jsFile = files.find(f => f.endsWith('.js'));

  if (!cssFile || !jsFile) {
    console.error('Missing css or js file in dist/assets');
    process.exit(1);
  }

  const css = fs.readFileSync(path.join(assetsDir, cssFile), 'utf8');
  const js = fs.readFileSync(path.join(assetsDir, jsFile), 'utf8');

  // Pre-script shims for desktop offline & file:/// execution
  const preScriptShims = `
    // 1. Safe localStorage fallback in case of strict file:/// sandbox
    try {
      var testKey = '__cmms_test__';
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
    } catch (e) {
      console.warn('localStorage restricted, using in-memory store:', e);
      var mem = {};
      try {
        Object.defineProperty(window, 'localStorage', {
          value: {
            getItem: function(k) { return mem.hasOwnProperty(k) ? mem[k] : null; },
            setItem: function(k, v) { mem[k] = String(v); },
            removeItem: function(k) { delete mem[k]; },
            clear: function() { mem = {}; }
          },
          writable: true,
          configurable: true
        });
      } catch (err) {}
    }

    // 1.5. Apply preloaded central cloud database if injected during download
    if (window.__PRELOADED_CENTRAL_STORAGE__ && typeof window.__PRELOADED_CENTRAL_STORAGE__ === 'object') {
      try {
        var pre = window.__PRELOADED_CENTRAL_STORAGE__;
        if (pre.oilTanks) {
          window.localStorage.setItem('portal_oil_tanks', JSON.stringify(pre.oilTanks));
          window.localStorage.setItem('portal_oil_tanks_version_v12', '12');
        }
        if (pre.oilTransactions) {
          window.localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(pre.oilTransactions));
          window.localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(pre.oilTransactions));
          window.localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(pre.oilTransactions));
          window.localStorage.setItem('portal_oil_tx_version_v12', '12');
        }
        if (pre.workRequests) window.localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(pre.workRequests));
        if (pre.equipments) window.localStorage.setItem('portal_equipments_v9', JSON.stringify(pre.equipments));
        if (pre.checklistCategories && Array.isArray(pre.checklistCategories)) {
          window.localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(pre.checklistCategories));
          window.localStorage.setItem('portal_exact9_categories_v9_clean', '9');
          var photoStore = {};
          try {
            var existing = JSON.parse(window.localStorage.getItem('portal_category_persistent_photos_v1') || '{}');
            Object.assign(photoStore, existing);
          } catch(e) {}
          pre.checklistCategories.forEach(function(c) {
            if (c.image) {
              photoStore[c.name] = c.image;
              photoStore[c.id] = c.image;
            }
          });
          window.localStorage.setItem('portal_category_persistent_photos_v1', JSON.stringify(photoStore));
        }
      } catch (err) {}
    }

    // 2. Multi-device sync router for file:/// and content:// protocols (connect to central cloud datacenter)
    var CENTRAL_CLOUD_HOST = '';
    if (CENTRAL_CLOUD_HOST && (window.location.protocol === 'file:' || window.location.protocol === 'content:' || !window.location.protocol.startsWith('http'))) {
      var originalFetch = window.fetch;
      window.fetch = function(url, options) {
        if (typeof url === 'string') {
          if (url.startsWith('/api/')) {
            url = CENTRAL_CLOUD_HOST + url;
          } else if (url.startsWith('./api/')) {
            url = CENTRAL_CLOUD_HOST + url.slice(1);
          } else if (url.indexOf('CMMS-Factory-Desktop.html') !== -1 || url.indexOf('download-desktop') !== -1) {
            url = CENTRAL_CLOUD_HOST + '/api/portal/download-desktop';
          }
        }
        return originalFetch ? originalFetch.apply(this, [url, options]) : Promise.reject(new Error('Fetch not available'));
      };
    }

    // 3. Error listener to inform user in case of any runtime problem
    window.addEventListener('error', function(e) {
      if (e.message && (e.message.indexOf('WebSocket') !== -1 || e.message.indexOf('resize') !== -1)) return;
      var el = document.getElementById('desktop-runtime-error');
      if (!el && document.body) {
        el = document.createElement('div');
        el.id = 'desktop-runtime-error';
        el.style = 'position:fixed;top:10px;left:10px;right:10px;background:#991b1b;color:#fff;padding:12px;border-radius:12px;z-index:999999;font-family:Tahoma,sans-serif;direction:rtl;font-size:13px;box-shadow:0 10px 25px rgba(0,0,0,0.5);';
        document.body.appendChild(el);
      }
      if (el) {
        el.innerHTML = '⚠️ پیام سیستم: ' + (e.message || 'خطای اجرا رخ داد.');
      }
    });
  `;

  // Safely escape </script> inside JS
  const safeJs = js.replace(/<\/script/gi, '<\\/script');

  // Convert key visual assets (animated logo video, poster, dark & light backgrounds) to Base64 data URIs
  // so the downloaded standalone desktop file is 100% self-contained and never shows blank logos or missing backgrounds
  const toDataUri = (relPath, mimeType) => {
    const fullPath = path.resolve('public', relPath);
    if (fs.existsSync(fullPath)) {
      const b64 = fs.readFileSync(fullPath).toString('base64');
      return `data:${mimeType};base64,${b64}`;
    }
    const distPath = path.resolve('dist', relPath);
    if (fs.existsSync(distPath)) {
      const b64 = fs.readFileSync(distPath).toString('base64');
      return `data:${mimeType};base64,${b64}`;
    }
    return null;
  };
  const darkBgWebpB64 = toDataUri('assets/aistudio/bg-silver-dark.webp', 'image/webp');
  const lightBgWebpB64 = toDataUri('assets/aistudio/bg-silver-light.webp', 'image/webp');

  const assetReplacements = [
        { target: '/assets/aistudio/bg-silver-dark.webp', uri: darkBgWebpB64 },
    { target: '/assets/aistudio/bg-silver-light.webp', uri: lightBgWebpB64 }
  ];

  let inlinedJs = safeJs;
  let inlinedCss = css;
  let inlinedHtml = distHtml;

  for (const item of assetReplacements) {
    if (item.uri) {
      inlinedJs = inlinedJs.replaceAll(item.target, item.uri);
      inlinedCss = inlinedCss.replaceAll(item.target, item.uri);
      inlinedHtml = inlinedHtml.replaceAll(item.target, item.uri);
    }
  }

  // Strip external css, js, sw, manifest from distHtml
  let cleanHtml = inlinedHtml;
  cleanHtml = cleanHtml.replace(new RegExp(`<link[^>]*href=["'][^"']*${cssFile}["'][^>]*>`, 'gi'), '');
  cleanHtml = cleanHtml.replace(new RegExp(`<script[^>]*src=["'][^"']*${jsFile}["'][^>]*>\\s*</script>`, 'gi'), '');
  cleanHtml = cleanHtml.replace(/<script[^>]*registerSW\.js[^>]*><\/script>/gi, '');
  cleanHtml = cleanHtml.replace(/<link[^>]*manifest\.webmanifest[^>]*>/gi, '');

  // Make Google Fonts non-blocking so offline without VPN NEVER hangs
  cleanHtml = cleanHtml.replace(
    /<link[^>]*fonts\.googleapis\.com[^>]*rel=["']stylesheet["'][^>]*>/gi,
    '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" media="print" onload="this.media=\'all\'">'
  );

  // Inject CSS inside <head>
  const styleBlock = `<style id="cmms-bundle-style">\n${inlinedCss}\nbody { font-family: Vazirmatn, 'Segoe UI', Tahoma, -apple-system, sans-serif !important; }\n</style>`;
  if (cleanHtml.includes('</head>')) {
    const headSplit = cleanHtml.split('</head>');
    cleanHtml = headSplit[0] + '\n' + styleBlock + '\n</head>' + headSplit.slice(1).join('</head>');
  }

  // Inject JS AFTER <div id="root"></div> using pure string concatenation (NEVER String.replace!)
  const rootTarget = '<div id="root"></div>';
  if (!cleanHtml.includes(rootTarget)) {
    console.error('Target <div id="root"></div> not found in template HTML!');
    process.exit(1);
  }

  const scriptBlock = `\n<script>\n${preScriptShims}\n</script>\n<script>\n${inlinedJs}\n</script>\n`;

  const parts = cleanHtml.split(rootTarget);
  const finalHtml = parts[0] + rootTarget + scriptBlock + parts.slice(1).join(rootTarget);

  const outPath = path.resolve('public', 'CMMS-Factory-Desktop.html');
  fs.writeFileSync(outPath, finalHtml, 'utf8');

  const distOutPath = path.resolve('dist', 'CMMS-Factory-Desktop.html');
  fs.writeFileSync(distOutPath, finalHtml, 'utf8');

  console.log(`[OK] Successfully bundled standalone app via pure concatenation: ${(finalHtml.length / 1024).toFixed(1)} KB`);
  console.log(`[OK] Inlined all visual assets (video, poster, dark & light backgrounds) as Base64 data URIs.`);
  console.log(`[OK] Verified NO dollar-sign corruption and script runs AFTER <div id="root"></div>.`);
}

bundleSingleHtml();
