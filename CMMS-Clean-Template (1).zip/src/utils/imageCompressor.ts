/**
 * یوتیلیتی فشرده‌سازی خودکار تصاویر قبل از ذخیره در localStorage و ارسال به سرور
 * جلوگیری قطعی از خطای QuotaExceededError و حفظ سرعت لود برنامه
 */
export const compressImageDataUrl = (
  dataUrl: string,
  maxWidth = 640,
  quality = 0.75
): Promise<string> => {
  return new Promise((resolve) => {
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image')) {
      resolve(dataUrl);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      try {
        const origWidth = img.naturalWidth || img.width;
        const origHeight = img.naturalHeight || img.height;

        let targetWidth = origWidth;
        let targetHeight = origHeight;

        if (origWidth > maxWidth) {
          targetWidth = maxWidth;
          targetHeight = Math.round((origHeight * maxWidth) / origWidth);
        }

        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          resolve(dataUrl);
          return;
        }

        // رسم تصویر با کیفیت بالا و اندازه کنترل‌شده
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

        let compressed = '';
        try {
          compressed = canvas.toDataURL('image/webp', quality);
          if (!compressed.startsWith('data:image/webp')) {
            compressed = canvas.toDataURL('image/jpeg', quality);
          }
        } catch {
          compressed = canvas.toDataURL('image/jpeg', quality);
        }

        // اگر خروجی کوچک‌تر بود، خروجی جدید را بازگردان
        if (compressed && compressed.length < dataUrl.length) {
          resolve(compressed);
        } else {
          resolve(dataUrl);
        }
      } catch {
        resolve(dataUrl);
      }
    };

    img.onerror = () => {
      resolve(dataUrl);
    };

    img.src = dataUrl;
  });
};
