import { createClient, SupabaseClient } from '@supabase/supabase-js';

// آدرس پروژه و کلید عمومی تأییدشده کاربر
export const DEFAULT_SUPABASE_URL = '';
export const DEFAULT_SUPABASE_ANON_KEY = '';

export const SQL_SCHEMA_SCRIPT = `-- گام اول: ساخت جدول درخواست‌ها و دستورکارها در سوپابیس
create table if not exists work_requests (
  id uuid default gen_random_uuid() primary key,
  code text unique not null,
  work_order_code text,
  place text not null,
  created text not null,
  title text not null,
  priority text not null,
  description text default '—',
  status text not null default 'در حال اقدام',
  technician text,
  operation_type text,
  action_details text,
  wo_date text,
  wo_start_time text,
  wo_end_time text,
  duration_minutes integer,
  completed_at text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- گام دوم: فعال‌سازی دسترسی امن (Row Level Security)
alter table work_requests enable row level security;

-- ایجاد مجوزهای خواندن و نوشتن
create policy "Allow all select" on work_requests for select using (true);
create policy "Allow all insert" on work_requests for insert with check (true);
create policy "Allow all update" on work_requests for update using (true);
create policy "Allow all delete" on work_requests for delete using (true);

-- گام سوم: جدول مخازن انبار روغن و تراکنش‌ها
create table if not exists tanks (
  id integer primary key,
  name text not null,
  sub_name text,
  type text,
  capacity_liters numeric not null,
  current_liters numeric not null,
  min_alert_liters numeric not null,
  last_refill text,
  color_class text,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

create table if not exists transactions (
  id uuid default gen_random_uuid() primary key,
  tank_id integer,
  tank_name text,
  type text not null,
  amount_liters numeric not null,
  date text not null,
  technician text,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table tanks enable row level security;
alter table transactions enable row level security;

create policy "Allow all select tanks" on tanks for select using (true);
create policy "Allow all insert tanks" on tanks for insert with check (true);
create policy "Allow all update tanks" on tanks for update using (true);

create policy "Allow all select transactions" on transactions for select using (true);
create policy "Allow all insert transactions" on transactions for insert with check (true);
create policy "Allow all update transactions" on transactions for update using (true);
`;

export interface DbWorkRequest {
  code: string;
  workOrderCode?: string;
  place: string;
  created: string;
  title: string;
  priority: string;
  description: string;
  status: 'انجام شد' | 'در حال اقدام' | 'در حال انجام' | 'لغو' | 'در انتظار دستور برنامه ریزی' | string;
  technician?: string;
  coTechnicians?: string[];
  complexityLevel?: 'آسان' | 'معمولی' | 'دشوار';
  operationType?: string;
  actionDetails?: string;
  consumables?: any[];
  woDate?: string;
  woStartTime?: string;
  woEndTime?: string;
  durationMinutes?: number;
  completedAt?: string;
}

export const getStoredSupabaseConfig = () => {
  let envUrl = '';
  let envKey = '';
  try {
    envUrl = (typeof import.meta !== 'undefined' && import.meta?.env?.VITE_SUPABASE_URL) || '';
    envKey = (typeof import.meta !== 'undefined' && import.meta?.env?.VITE_SUPABASE_ANON_KEY) || '';
  } catch {}

  let localUrl = '';
  let localKey = '';
  try {
    localUrl = (typeof localStorage !== 'undefined' && localStorage.getItem('supabase_project_url')) || '';
    localKey = (typeof localStorage !== 'undefined' && localStorage.getItem('supabase_anon_key')) || '';
  } catch {}

  const url = localUrl || envUrl || DEFAULT_SUPABASE_URL;
  const anonKey = localKey || envKey || DEFAULT_SUPABASE_ANON_KEY;
  return { url, anonKey };
};

export const saveSupabaseConfig = (url: string, anonKey: string) => {
  localStorage.setItem('supabase_project_url', url.trim());
  localStorage.setItem('supabase_anon_key', anonKey.trim());
  _client = null;
};

let _client: SupabaseClient | null = null;

export const getSupabase = (): SupabaseClient | null => {
  if (_client) return _client;
  const { url, anonKey } = getStoredSupabaseConfig();
  if (!url || !anonKey) return null;

  try {
    _client = createClient(url, anonKey, {
      auth: {
        persistSession: false
      }
    });
    return _client;
  } catch (err) {
    console.error('Failed to create Supabase client:', err);
    return null;
  }
};

// تبدیل فرمت فرانت‌اند به فرمت دیتابیس
export const mapToDbRow = (item: DbWorkRequest) => ({
  code: item.code,
  work_order_code: item.workOrderCode || null,
  place: item.place,
  created: item.created,
  title: item.title,
  priority: item.priority,
  description: item.description || '—',
  status: item.status,
  technician: item.technician || null,
  operation_type: item.operationType || null,
  action_details: item.actionDetails || null,
  wo_date: item.woDate || null,
  wo_start_time: item.woStartTime || null,
  wo_end_time: item.woEndTime || null,
  duration_minutes: item.durationMinutes ?? null,
  completed_at: item.completedAt || null
});

// تبدیل رکورد دیتابیس به فرمت برنامه فرانت‌اند
export const mapFromDbRow = (row: any): DbWorkRequest => ({
  code: row.code,
  workOrderCode: row.work_order_code || undefined,
  place: row.place,
  created: row.created,
  title: row.title,
  priority: row.priority,
  description: row.description || '—',
  status: row.status,
  technician: row.technician || undefined,
  operationType: row.operation_type || undefined,
  actionDetails: row.action_details || undefined,
  woDate: row.wo_date || undefined,
  woStartTime: row.wo_start_time || undefined,
  woEndTime: row.wo_end_time || undefined,
  durationMinutes: row.duration_minutes ?? undefined,
  completedAt: row.completed_at || undefined
});

// توابع ذخیره و دریافت مستقیم
export const fetchWorkRequestsFromSupabase = async (): Promise<{ data: DbWorkRequest[] | null; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { data: null, error: 'کلاینت Supabase تنظیم نشده است.' };

  try {
    const { data, error } = await client
      .from('work_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return { data: null, error: error.message };
    }
    // فیلتر کردن رکوردهای سیستمی مانند سند ذخیره‌سازی ابری
    const realWorkOrders = (data || []).filter((r: any) => r.code !== 'SYSTEM_CENTRAL_STORAGE');
    return { data: realWorkOrders.map(mapFromDbRow), error: null };
  } catch (err: any) {
    return { data: null, error: err?.message || 'خطا در ارتباط با سرور' };
  }
};

export const upsertWorkRequestInSupabase = async (item: DbWorkRequest): Promise<{ success: boolean; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { success: false, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const row = mapToDbRow(item);
    const { error } = await client
      .from('work_requests')
      .upsert(row, { onConflict: 'code' });

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'خطای شبکه' };
  }
};

export const updateStatusInSupabase = async (code: string, status: string, completedAt?: string): Promise<{ success: boolean; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { success: false, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const payload: any = { status };
    if (completedAt !== undefined) payload.completed_at = completedAt;

    const { error } = await client
      .from('work_requests')
      .update(payload)
      .eq('code', code);

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'خطای شبکه' };
  }
};

export const fetchTanksFromSupabase = async (): Promise<{ data: any[] | null; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { data: null, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const { data, error } = await client
      .from('tanks')
      .select('*')
      .order('id', { ascending: true });

    if (error) {
      return { data: null, error: error.message };
    }
    return { data, error: null };
  } catch (err: any) {
    return { data: null, error: err?.message || 'خطای ارتباط با سرور' };
  }
};

export const updateTankInSupabase = async (tank: {
  id: number;
  name?: string;
  sub_name?: string;
  type?: string;
  capacity_liters?: number;
  current_liters: number;
  min_alert_liters?: number;
  last_refill?: string;
  color_class?: string;
}): Promise<{ success: boolean; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { success: false, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const { error } = await client
      .from('tanks')
      .upsert(tank, { onConflict: 'id' });

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'خطای شبکه' };
  }
};

// ========================================================
// دیتابیس ابری مرکزی روی Supabase جهت همگام‌سازی تضمینی گوشی و کامپیوتر
// ========================================================
export const fetchCentralStorageFromSupabase = async (): Promise<{ data: any | null; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { data: null, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const { data, error } = await client
      .from('work_requests')
      .select('description, created_at')
      .eq('code', 'SYSTEM_CENTRAL_STORAGE')
      .maybeSingle();

    if (error) {
      return { data: null, error: error.message };
    }
    if (!data || !data.description) {
      return { data: null, error: null };
    }
    const parsed = JSON.parse(data.description);
    return { data: parsed, error: null };
  } catch (err: any) {
    return { data: null, error: err?.message || 'خطای دریافت اطلاعات از سرور ابری Supabase' };
  }
};

export const saveCentralStorageToSupabase = async (state: any): Promise<{ success: boolean; error: string | null }> => {
  const client = getSupabase();
  if (!client) return { success: false, error: 'کلاینت Supabase فعال نیست.' };

  try {
    const payloadStr = typeof state === 'string' ? state : JSON.stringify(state);
    const { error } = await client
      .from('work_requests')
      .upsert({
        code: 'SYSTEM_CENTRAL_STORAGE',
        place: 'دیتاسنتر ابری سامانه',
        created: '1405/08/06',
        title: 'مخزن ابری جامع کلیه اطلاعات انبار روغن، چک‌لیست‌ها و تجهیزات',
        priority: 'بحرانی',
        status: 'انجام شد',
        description: payloadStr
      }, { onConflict: 'code' });

    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err?.message || 'خطای شبکه در ذخیره سازی Supabase' };
  }
};
