import React, { useRef } from 'react';
import { X, Printer, Download, Copy, Check, FileText } from 'lucide-react';
import { OilOperation } from '../data/oilTransactionsData';
import { COMPANY_LOGO_WHITEBG, COMPANY_LOGO_DARK } from '../data/auditImages';
import { BRAND_CONFIG } from '../data/brandConfig';
import { usePrintSettings } from '../data/printSettings';

interface OilTank {
  id: number;
  name: string;
  capacityLiters: number;
  currentLiters: number;
  minAlertLiters: number;
  colorClass: string;
}

interface OilOfficialPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: OilOperation[];
  oilTanks: OilTank[];
  filterTankId: string;
  opType: 'in' | 'out';
  startDate: string;
  endDate: string;
  persianClock: string;
}

// تبدیل ارقام انگلیسی به فارسی
function toFa(num: number | string): string {
  if (num === undefined || num === null) return '';
  return String(num).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

function formatNumberFa(num: number): string {
  return Number(num).toLocaleString('en-US').replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

export const OilOfficialPrintModal: React.FC<OilOfficialPrintModalProps> = ({
  isOpen,
  onClose,
  transactions,
  oilTanks,
  filterTankId,
  opType,
  startDate,
  endDate,
  persianClock
}) => {
  const [copied, setCopied] = React.useState(false);
  const printAreaRef = useRef<HTMLDivElement>(null);
  const printSettings = usePrintSettings();
  const oilPrintCfg = printSettings.oilOfficialReport;

  if (!isOpen) return null;

  const targetTankObj = oilTanks.find(t => String(t.id) === String(filterTankId));
  const tankLabel = targetTankObj ? targetTankObj.name : 'تمامی مخازن ۴‌گانه';
  const opTypeLabel = opType === 'out' ? 'برداشت و مصرف روغن' : 'ورود و شارژ مخازن';
  const dateRangeLabel = (startDate || endDate)
    ? `از تاریخ ${startDate || 'ابتدا'} تا تاریخ ${endDate || 'اکنون'}`
    : 'کلیه سوابق ثبت‌شده در سیستم';

  const totalLiters = transactions.reduce((sum, tx) => sum + tx.amount_l, 0);

  // تولید کد کامل HTML خودکفا برای دانلود و چاپ مستقیم در هر مرورگر
  const generateSelfContainedHtml = () => {
    const rowsHtml = transactions.map((tx, idx) => `
      <tr style="${idx % 2 === 1 ? 'background-color: #f8fafc;' : ''}">
        <td style="text-align: center; padding: 7px 5px; border: 1px solid #777; font-family: Tahoma, sans-serif;">${toFa(idx + 1)}</td>
        <td style="padding: 7px 8px; border: 1px solid #777; font-weight: bold;">${tx.tank_name}</td>
        <td style="text-align: center; padding: 7px 6px; border: 1px solid #777; font-weight: 900; font-size: 13px;">${formatNumberFa(tx.amount_l)} لیتر</td>
        <td style="padding: 7px 8px; border: 1px solid #777; font-weight: 600;">${tx.operator || '—'}</td>
        <td style="text-align: center; padding: 7px 6px; border: 1px solid #777; font-weight: bold; color: #1e3a8a;">${tx.equipment || '—'}</td>
        <td style="text-align: center; padding: 7px 6px; border: 1px solid #777; font-size: 11px; direction: ltr;">${tx.created_at}</td>
      </tr>
    `).join('');

    return `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="utf-8">
  <title>${oilPrintCfg.docTitle} - ${opTypeLabel} (${oilPrintCfg.docCode})</title>
  <style>
    @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-FD.woff2') format('woff2'); font-weight: 100 400; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
    @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-Bold-FD.woff2') format('woff2'); font-weight: 500 900; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
    @page { size: A4 portrait; margin: 10mm 10mm 12mm 10mm; }
    * { box-sizing: border-box; font-family: 'PersianDigits', 'Vazirmatn', Tahoma, 'B Nazanin', system-ui, sans-serif; }
    body { margin: 0; padding: 20px; background: #fff; color: #111; font-size: 12px; line-height: 1.4; }
    .header-box { width: 100%; border: 2px solid #1e293b; margin-bottom: 12px; border-collapse: collapse; }
    .header-box td { border: 1px solid #334155; padding: 8px 12px; vertical-align: middle; }
    .meta-strip { display: flex; justify-content: space-between; background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px 14px; margin-bottom: 14px; font-size: 11.5px; }
    .main-table { width: 100%; border-collapse: collapse; margin-bottom: 25px; }
    .main-table th { background: #e2e8f0; border: 1px solid #475569; padding: 8px 6px; font-size: 11.5px; font-weight: 900; color: #0f172a; }
    .main-table td { font-size: 11.5px; }
    .signs { display: flex; justify-content: space-around; margin-top: 50px; text-align: center; page-break-inside: avoid; }
    .sign-col { width: 28%; border-top: 1.5px dashed #64748b; padding-top: 8px; font-weight: bold; font-size: 11.5px; color: #1e293b; }
    .action-bar { margin-bottom: 15px; padding: 10px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; text-align: center; }
    .btn-print { background: #2563eb; color: #fff; padding: 8px 20px; font-size: 13px; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; }
    @media print {
      body { padding: 0; }
      .action-bar { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="action-bar">
    <button class="btn-print" onclick="window.print()">🖨️ چاپ این سند (Print / Save as PDF)</button>
    <span style="margin-right: 15px; font-size: 12px; color: #1e40af;">می‌توانید کلیدهای Ctrl + P را فشار دهید.</span>
  </div>

  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; border-bottom: 2px solid #0f172a; padding-bottom: 12px;">
    <div style="display: flex; align-items: center; gap: 14px;">
      <img src="${COMPANY_LOGO_WHITEBG}" alt="CMMS Logo" style="height: 50px; width: auto; object-fit: contain;" />
      <div>
        <h1 style="margin: 0 0 3px 0; font-size: 19px; font-weight: 900; color: #0f172a;">${oilPrintCfg.docTitle} (${opTypeLabel})</h1>
        <div style="font-size: 11px; color: #475569;">
          ${BRAND_CONFIG.COMPANY_FULL_NAME} — مخزن: <strong>${tankLabel}</strong>
        </div>
      </div>
    </div>
    <div style="text-align: left; font-size: 11px; color: #475569; line-height: 1.6;">
      <div><strong>کد سند:</strong> <span style="font-family: monospace;">${oilPrintCfg.docCode}</span></div>
      <div><strong>بازه:</strong> ${dateRangeLabel}</div>
      <div><strong>تاریخ صدور:</strong> ${toFa(new Date().toLocaleDateString('fa-IR'))} — <strong>ساعت:</strong> ${toFa(new Date().toLocaleTimeString('fa-IR'))}</div>
    </div>
  </div>

  <div style="display: flex; gap: 14px; margin-bottom: 16px;">
    <div style="flex: 2; border: 2px solid #334155; border-radius: 10px; padding: 10px 16px; background: #f8fafc; text-align: center;">
      <div style="font-size: 11.5px; color: #475569; font-weight: bold;">گزارش ${opTypeLabel} — ${dateRangeLabel}</div>
      <div style="font-size: 22px; font-weight: 900; color: #b91c1c; margin-top: 4px; font-family: monospace;">${formatNumberFa(totalLiters)} لیتر</div>
    </div>
    <div style="flex: 1; border: 2px solid #334155; border-radius: 10px; padding: 10px 16px; background: #f8fafc; text-align: center;">
      <div style="font-size: 11.5px; color: #475569; font-weight: bold;">تعداد کل عملیات</div>
      <div style="font-size: 22px; font-weight: 900; color: #0f172a; margin-top: 4px; font-family: monospace;">${toFa(transactions.length)}</div>
    </div>
  </div>

  <table class="main-table">
    <thead>
      <tr>
        <th style="width: 6%;">ردیف</th>
        <th style="width: 22%;">نام مخزن</th>
        <th style="width: 14%;">مقدار (لیتر)</th>
        <th style="width: 18%;">${opType === 'out' ? 'اپراتور تحویل‌گیرنده' : 'ثبت‌کننده'}</th>
        <th style="width: 18%;">${opType === 'out' ? 'کد / نام تجهیز مقصد' : 'منبع تأمین'}</th>
        <th style="width: 22%;">تاریخ و زمان ثبت</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml || '<tr><td colspan="6" style="text-align: center; padding: 25px; color: #64748b;">تراکنشی یافت نشد.</td></tr>'}
    </tbody>
    <tfoot>
      <tr style="background-color: #f1f5f9; font-weight: bold;">
        <td colspan="2" style="padding: 8px 10px; border: 1px solid #777; text-align: left;">جمع کل حجم فیلترشده:</td>
        <td style="text-align: center; padding: 8px; border: 1px solid #777; font-weight: 900; font-size: 13.5px; color: #b91c1c;">${formatNumberFa(totalLiters)} لیتر</td>
        <td colspan="3" style="padding: 8px 10px; border: 1px solid #777; font-size: 11px; color: #475569;">تعداد کل اقلام: ${toFa(transactions.length)} عملیات ثبت‌شده</td>
      </tr>
    </tfoot>
  </table>

  <div class="signs">
    <div class="sign-col">
      <div>مسئول انبار روغن و سیالات</div>
      <div style="height: 48px;"></div>
      <div style="font-size: 10px; color: #64748b; font-weight: normal;">امضاء و تاریخ</div>
    </div>
    <div class="sign-col">
      <div>سرپرست نگهداری و تعمیرات (نت)</div>
      <div style="height: 48px;"></div>
      <div style="font-size: 10px; color: #64748b; font-weight: normal;">امضاء و تاریخ</div>
    </div>
    <div class="sign-col">
      <div>مدیریت فنی / کنترل کیفی</div>
      <div style="height: 48px;"></div>
      <div style="font-size: 10px; color: #64748b; font-weight: normal;">امضاء و تاریخ</div>
    </div>
  </div>
</body>
</html>`;
  };

  // دانلود فایل HTML آماده چاپ برای اجرای بدون مانع و امن در همه سیستم‌ها
  const handleDownloadHtml = () => {
    const htmlContent = generateSelfContainedHtml();
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Gozaresh-Rasmi-Anbar-Rowghan-${Date.now().toString().slice(-6)}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // چاپ مستقیم سند چاپی
  const handleDirectPrint = () => {
    window.print();
  };

  // کپی خلاصه گزارش به کلیپ‌بورد
  const handleCopyTable = () => {
    const header = `ردیف\tمخزن\tمقدار (لیتر)\tتحویل‌گیرنده\tتجهیز مقصد\tزمان ثبت\n`;
    const rows = transactions.map((tx, idx) => 
      `${idx + 1}\t${tx.tank_name}\t${tx.amount_l}\t${tx.operator || '—'}\t${tx.equipment || '—'}\t${tx.created_at}`
    ).join('\n');
    const fullText = `گزارش رسمی ${opTypeLabel}\nبازه: ${dateRangeLabel}\nمجموع حجم: ${totalLiters} لیتر\n\n` + header + rows;
    navigator.clipboard.writeText(fullText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-3xl bg-[#0b0f15] border border-[#2b3543] shadow-2xl flex flex-col my-auto max-h-[96vh]">
        
        {/* نوار ابزار بالای پیش‌نمایش (در چاپ مخفی است) */}
        <div className="no-print p-4 sm:p-5 border-b border-[#242d3a] flex flex-wrap items-center justify-between gap-3 bg-[#111722] rounded-t-3xl">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600/30 border border-blue-500/50 flex items-center justify-center text-blue-300 font-bold">
              <FileText className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <span>پیش‌نمایش برگ چاپی رسمی (سند قطع A4)</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600/40">
                  آماده چاپ
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                فرم استاندارد با سربرگ شرکتی، جدول تراکنش‌ها و جایگاه امضاء
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* دکمه چاپ مستقیم مرورگر */}
            <button
              type="button"
              onClick={handleDirectPrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black shadow-lg shadow-blue-900/50 cursor-pointer transition-all border border-blue-400/30"
              title="ارسال مستقیم به پرینتر یا ذخیره به عنوان PDF در کادر چاپ مرورگر"
            >
              <Printer className="w-4 h-4" />
              <span>🖨️ چاپ مستقیم (Print / PDF)</span>
            </button>

            {/* دکمه دانلود فایل HTML مستقل چاپی */}
            <button
              type="button"
              onClick={handleDownloadHtml}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 cursor-pointer transition-all"
              title="دانلود فایل آماده پرینت که در هر رایانه یا پرینتری به راحتی باز و چاپ می‌شود"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>دانلود فایل چاپی (HTML)</span>
            </button>

            {/* دکمه کپی جدول */}
            <button
              type="button"
              onClick={handleCopyTable}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 cursor-pointer transition-all"
              title="کپی داده‌ها برای اکسل"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'کپی شد' : 'کپی برای اکسل'}</span>
            </button>

            {/* دکمه بستن */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ناحیه سند A4 واقعی با تم سفید شرکتی و خطوط دقیق */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-900/60">
          <div
            id="oil-official-print-document"
            ref={printAreaRef}
            className="w-full max-w-[210mm] mx-auto bg-white text-slate-900 p-6 sm:p-10 rounded-2xl shadow-2xl border border-slate-200 font-sans print:m-0 print:p-0 print:border-none print:shadow-none print:w-full"
            style={{ minHeight: '297mm' }}
          >
            
            {/* سربرگ رسمی و شکیل گزارش همراه با لوگوی رسمی سامانه */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 mb-4 border-b-2 border-slate-800">
              <div className="flex items-center gap-3.5">
                <img
                  src={COMPANY_LOGO_WHITEBG}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-12 w-auto object-contain"
                />
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {oilPrintCfg.docTitle} ({opTypeLabel})
                  </h1>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {BRAND_CONFIG.COMPANY_FULL_NAME} — مخزن: <strong className="text-slate-800">{tankLabel}</strong>
                  </div>
                </div>
              </div>

              <div className="text-left text-xs text-slate-600 leading-relaxed font-mono">
                <div><strong>کد سند:</strong> {oilPrintCfg.docCode}</div>
                <div><strong>بازه زمانی:</strong> <span className="font-sans font-bold text-slate-800">{dateRangeLabel}</span></div>
                <div><strong>تاریخ صدور:</strong> {toFa(new Date().toLocaleDateString('fa-IR'))} — <strong>ساعت:</strong> {persianClock || toFa(new Date().toLocaleTimeString('fa-IR'))}</div>
              </div>
            </div>

            {/* کارت‌های برجسته خلاصه حجم و تعداد عملیات */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
              <div className="sm:col-span-2 border-2 border-slate-700 rounded-xl p-3 bg-slate-50 text-center">
                <div className="text-xs text-slate-600 font-bold">
                  مجموع حجم {opTypeLabel} — {dateRangeLabel}
                </div>
                <div className="text-2xl font-black text-rose-700 font-mono mt-1">
                  {formatNumberFa(totalLiters)} لیتر
                </div>
              </div>

              <div className="border-2 border-slate-700 rounded-xl p-3 bg-slate-50 text-center">
                <div className="text-xs text-slate-600 font-bold">تعداد کل عملیات</div>
                <div className="text-2xl font-black text-slate-900 font-mono mt-1">
                  {toFa(transactions.length)}
                </div>
              </div>
            </div>

            {/* جدول اصلی داده‌ها */}
            <div className="border border-slate-400 rounded-lg overflow-hidden mb-6">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-400">
                    <th className="py-2.5 px-2 text-center w-12 border-l border-slate-300">ردیف</th>
                    <th className="py-2.5 px-3 border-l border-slate-300">نام مخزن</th>
                    <th className="py-2.5 px-3 text-center border-l border-slate-300">مقدار (لیتر)</th>
                    <th className="py-2.5 px-3 border-l border-slate-300">
                      {opType === 'out' ? 'اپراتور تحویل‌گیرنده' : 'ثبت‌کننده'}
                    </th>
                    <th className="py-2.5 px-3 text-center border-l border-slate-300">
                      {opType === 'out' ? 'کد / نام تجهیز مقصد' : 'منبع تأمین'}
                    </th>
                    <th className="py-2.5 px-3 text-center">تاریخ و ساعت ثبت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300">
                  {transactions.map((tx, idx) => (
                    <tr key={tx.id || idx} className={idx % 2 === 1 ? 'bg-slate-50' : 'bg-white'}>
                      <td className="py-2 px-2 text-center font-mono text-slate-600 border-l border-slate-200">
                        {toFa(idx + 1)}
                      </td>
                      <td className="py-2 px-3 font-bold text-slate-800 border-l border-slate-200">
                        {tx.tank_name}
                      </td>
                      <td className="py-2 px-3 text-center font-mono font-black text-slate-900 border-l border-slate-200">
                        {formatNumberFa(tx.amount_l)}
                      </td>
                      <td className="py-2 px-3 text-slate-800 font-medium border-l border-slate-200">
                        {tx.operator || '—'}
                      </td>
                      <td className="py-2 px-3 text-center font-bold text-blue-900 border-l border-slate-200">
                        {tx.equipment || '—'}
                      </td>
                      <td className="py-2 px-3 text-center font-mono text-[11px] text-slate-600">
                        {tx.created_at}
                      </td>
                    </tr>
                  ))}
                  {transactions.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                        هیچ تراکنشی مطابق فیلترهای مشخص‌شده ثبت نشده است.
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 font-bold border-t-2 border-slate-400">
                    <td colSpan={2} className="py-2.5 px-3 text-left border-l border-slate-300">
                      جمع کل حجم:
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-black text-rose-700 text-sm border-l border-slate-300">
                      {formatNumberFa(totalLiters)} لیتر
                    </td>
                    <td colSpan={3} className="py-2.5 px-3 text-xs text-slate-600">
                      تعداد رکوردهای موجود در این گزارش: {toFa(transactions.length)} مورد
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* بخش امضاء و تأییدیه‌های رسمی (۳ جایگاه) */}
            <div className="grid grid-cols-3 gap-6 pt-10 mt-8 border-t border-slate-300 text-center">
              <div className="border-t-2 border-dashed border-slate-400 pt-2">
                <div className="text-xs font-black text-slate-800">مسئول انبار روغن و سیالات</div>
                <div className="h-12"></div>
                <div className="text-[10px] text-slate-500">امضاء و تاریخ</div>
              </div>

              <div className="border-t-2 border-dashed border-slate-400 pt-2">
                <div className="text-xs font-black text-slate-800">سرپرست نگهداری و تعمیرات (نت)</div>
                <div className="h-12"></div>
                <div className="text-[10px] text-slate-500">امضاء و تاریخ</div>
              </div>

              <div className="border-t-2 border-dashed border-slate-400 pt-2">
                <div className="text-xs font-black text-slate-800">مدیر فنی / کنترل کیفی</div>
                <div className="h-12"></div>
                <div className="text-[10px] text-slate-500">امضاء و تاریخ</div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
