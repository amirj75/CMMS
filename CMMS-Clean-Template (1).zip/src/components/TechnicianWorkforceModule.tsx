import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Wrench,
  CheckCircle,
  Clock,
  User,
  Users,
  ChevronDown,
  Filter,
  Plus,
  Printer,
  Download,
  Search,
  CheckSquare,
  AlertTriangle,
  FileText,
  Layers,
  X,
  Check,
  Calendar,
  Sparkles,
  Camera,
  BarChart3,
  Activity,
  ShieldCheck,
  Zap,
  Settings,
  Bot,
  Copy,
  RefreshCw,
  Star
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { COMPANY_LOGO_WHITEBG } from '../data/auditImages';
import { computeMinutesBetweenShamsiDateTimes } from '../data/dateTimeUtils';
import { usePrintSettings } from '../data/printSettings';
import { isStrictPmRecord, loadAutoPmWorkOrders } from '../data/pmAutoWorkOrders';

export const DEFAULT_FACTORY_TECHNICIANS: string[] = [];

export const TECHNICIAN_SPECIALTIES: Record<string, { role: string; dept: string; code: string; color: string }> = {};

// تصاویر پیش‌فرض حرفه‌ای برای هر یک از ۷ تکنسین
export const DEFAULT_TECHNICIAN_AVATARS: Record<string, string> = {};

interface TechnicianWorkforceModuleProps {
  requestsList?: any[];
  onUpdateRequest?: (updatedReq: any) => void;
  onAddRequest?: (newReq: any) => void;
}

export const TechnicianWorkforceModule: React.FC<TechnicianWorkforceModuleProps> = ({
  requestsList: propRequestsList = [],
  onUpdateRequest,
  onAddRequest
}) => {
  const printSettings = usePrintSettings();
  const [technicians] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('technicalServiceTechnicians');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_FACTORY_TECHNICIANS;
  });

  const [technicianPhotos, setTechnicianPhotos] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('technicalServiceTechnicianPhotos') || localStorage.getItem('technicianPhotos');
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_TECHNICIAN_AVATARS, ...parsed };
      }
    } catch {}
    return DEFAULT_TECHNICIAN_AVATARS;
  });

  // بارگذاری قطعی عکس‌های پرسنلی از دیتابیس مرکزی سرور در زمان لود صفحه
  useEffect(() => {
    fetch('/api/portal/sync-state')
      .then(res => res.json())
      .then(result => {
        if (result && result.data && result.data.technicianPhotos) {
          const srvPhotos = result.data.technicianPhotos;
          if (typeof srvPhotos === 'object' && Object.keys(srvPhotos).length > 0) {
            setTechnicianPhotos(prev => {
              const merged = { ...prev, ...srvPhotos };
              try {
                localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(merged));
                localStorage.setItem('technicianPhotos', JSON.stringify(merged));
              } catch {}
              return merged;
            });
          }
        }
      })
      .catch(() => {});
  }, []);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingForTech, setUploadingForTech] = useState<string | null>(null);

  // وضعیت تحلیل هوش مصنوعی اختصاصی تکنسین در کارنامه نیروی انسانی
  const [aiModalTech, setAiModalTech] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiCopied, setAiCopied] = useState(false);
  const [aiResults, setAiResults] = useState<Record<string, any>>({});

  const handleTriggerUpload = (techName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setUploadingForTech(techName);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !uploadingForTech) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl && uploadingForTech) {
        setTechnicianPhotos(prev => {
          const next = { ...prev, [uploadingForTech]: dataUrl };
          try {
            localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(next));
            localStorage.setItem('technicianPhotos', JSON.stringify(next));
          } catch {}

          // ارسال فوری و پایدار به سرور مرکزی جهت ذخیره در دیسک و جلوگیری از حذف
          fetch('/api/portal/sync-state', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ technicianPhotos: next })
          }).catch(() => {});

          return next;
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const [technicianCodes, setTechnicianCodes] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('technicianPersonnelCodes');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    const defaults: Record<string, string> = {};
    DEFAULT_FACTORY_TECHNICIANS.forEach((t, i) => {
      defaults[t] = TECHNICIAN_SPECIALTIES[t]?.code || `TC-10${i + 1}`;
    });
    return defaults;
  });

  const [editingCodeTech, setEditingCodeTech] = useState<string | null>(null);
  const [tempCodeValue, setTempCodeValue] = useState<string>('');

  const handleStartEditCode = (techName: string, currentCode: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingCodeTech(techName);
    setTempCodeValue(currentCode);
  };

  const handleSaveCode = (techName: string, e: React.MouseEvent | React.FormEvent) => {
    e.stopPropagation();
    if (!tempCodeValue.trim()) {
      setEditingCodeTech(null);
      return;
    }
    setTechnicianCodes(prev => {
      const next = { ...prev, [techName]: tempCodeValue.trim() };
      try {
        localStorage.setItem('technicianPersonnelCodes', JSON.stringify(next));
      } catch {}
      return next;
    });
    setEditingCodeTech(null);
  };

  // مورد دوم: به صورت پیش‌فرض همه تکنسین‌ها بسته باشند
  const [expandedTech, setExpandedTech] = useState<string | null>(null);

  // تب فعال درون هر کارت: 'workRequests' | 'techServices' | 'pm'
  const [cardActiveTab, setCardActiveTab] = useState<Record<string, 'workRequests' | 'techServices' | 'pm'>>({});

  const [filterTechnician, setFilterTechnician] = useState<string>('همه');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // مورد اول: تفکیک سه‌گانه در نمودار: 'byCategory' (تعداد کارها) یا 'byHours' (ساعت کارکرد تفکیکی)
  const [chartMetric, setChartMetric] = useState<'byCategory' | 'byHours'>('byCategory');

  // مودال‌های ثبت کار و چاپ
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [selectedTechForAssign, setSelectedTechForAssign] = useState<string>((DEFAULT_FACTORY_TECHNICIANS[0] || ''));
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [individualPrintTech, setIndividualPrintTech] = useState<string | null>(null);
  const [cardWrFilter, setCardWrFilter] = useState<Record<string, 'all' | 'اضطراری' | 'اصلاحی' | 'پیشگیرانه'>>({});
  const [isLogActionModalOpen, setIsLogActionModalOpen] = useState(false);
  const [selectedTaskForAction, setSelectedTaskForAction] = useState<any | null>(null);

  const [assignFormData, setAssignFormData] = useState({
    taskCategory: 'workRequests' as 'workRequests' | 'techServices' | 'pm',
    code: '',
    equipmentCode: '',
    equipmentName: '',
    locationName: 'سالن تولید',
    title: '',
    priority: 'عادی' as 'توقف تولید' | 'توقف تجهیز' | 'عدم توقف تجهیز' | 'عادی' | 'فوری',
    technician: (DEFAULT_FACTORY_TECHNICIANS[0] || ''),
    status: 'در حال اقدام',
    durationMinutes: 60,
    actionDetails: ''
  });

  const [actionFormData, setActionFormData] = useState({
    status: 'انجام شد',
    durationMinutes: 60,
    actionDetails: '',
    coTechnician: ''
  });

  // ۱. درخواست کارها (Work Requests - خرابی‌های تولید)
  const rawWorkRequests = useMemo(() => {
    const list: any[] = [...propRequestsList];
    try {
      const raw = localStorage.getItem('portal_pm_work_requests_v3');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach(item => {
            if (item && !list.some(r => (r.code || r.id) === (item.code || item.id))) {
              list.push(item);
            }
          });
        }
      }
    } catch {}
    return list;
  }, [propRequestsList]);

  // ۲. خدمات فنی (Technical Services - تاسیسات و تعمیرات خدمات فنی)
  const rawTechServices = useMemo(() => {
    try {
      const raw = localStorage.getItem('technicalServiceWorkRequests');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  }, []);

  // ۳. پیشگیرانه (PM - چک‌لیست‌ها و دستورکارهای سرویس دوره‌ای؛ مطلقاً بدون ورود موارد EM/CM)
  const rawPmTasks = useMemo(() => {
    const pmMap = new Map<string, any>();
    const addPm = (item: any, idxFallback: number) => {
      if (!item) return;
      const k = String(item.code || item.woCode || item.workOrderCode || item.id || `pm-${idxFallback}`).trim().toUpperCase();
      if (!pmMap.has(k)) pmMap.set(k, item);
    };

    try {
      const raw = localStorage.getItem('app_pm_schedules_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) parsed.forEach((p, idx) => addPm(p, idx));
      }
    } catch {}

    try {
      loadAutoPmWorkOrders().forEach((o: any, idx: number) => {
        const isDone = o?.status === 'انجام شد' || o?.status === 'completed';
        const hasTechHours = Array.isArray(o?.woTechnicians) && o.woTechnicians.some((t: any) => (Number(t?.hours) || 0) > 0);
        if (isDone || hasTechHours) {
          addPm(o, idx + 10000);
        }
      });
    } catch {}

    try {
      const rawWo = localStorage.getItem('pm_studio_work_orders_v15');
      if (rawWo) {
        const parsedWo = JSON.parse(rawWo);
        if (Array.isArray(parsedWo)) {
          parsedWo.forEach((o: any, idx: number) => {
            const isDone = o?.status === 'انجام شد' || o?.status === 'completed';
            const hasTechHours = Array.isArray(o?.woTechnicians) && o.woTechnicians.some((t: any) => (Number(t?.hours) || 0) > 0);
            if (isDone || hasTechHours || Number(o?.actualHours) > 0) {
              addPm(o, idx + 20000);
            }
          });
        }
      }
    } catch {}

    [...rawWorkRequests, ...rawTechServices].forEach((r, idx) => {
      if (isStrictPmRecord(r)) {
        addPm(r, idx + 30000);
      }
    });

    return Array.from(pmMap.values());
  }, [rawWorkRequests, rawTechServices]);

  const toFaDigits = (n: number | string): string => {
    return String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  };

  const formatTotalTime = (minutes: number): string => {
    const mins = Math.max(0, Math.floor(minutes || 0));
    if (mins === 0) return '۰ ساعت';
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    if (hours > 0 && remMins > 0) {
      return `${toFaDigits(hours)} ساعت ${toFaDigits(remMins)} د`;
    } else if (hours > 0) {
      return `${toFaDigits(hours)} ساعت`;
    } else {
      return `${toFaDigits(mins)} دقیقه`;
    }
  };

  const calcMinutes = (items: any[], techName?: string) => items.reduce((sum, item) => {
    if (techName && Array.isArray(item.woTechnicians) && item.woTechnicians.length > 0) {
      const matched = item.woTechnicians.filter((t: any) => String(t?.name || '').trim() === techName);
      if (matched.length > 0) {
        const mins = matched.reduce((s: number, t: any) => {
          if (t?.startDate && t?.startTime && t?.endDate && t?.endTime && !t?.customHours) {
            const cMins = computeMinutesBetweenShamsiDateTimes(t.startDate, t.startTime, t.endDate, t.endTime);
            if (cMins > 0) return s + cMins;
          }
          return s + Math.round((Number(t?.hours) || 0) * 60);
        }, 0);
        return sum + (isNaN(mins) ? 0 : mins);
      }
      return sum;
    }
    const mins = Number(
      item.durationMinutes ||
      item.durationMin ||
      item.estimatedMinutes ||
      (Number(item.actualHours) > 0 ? Math.round(Number(item.actualHours) * 60) : 0) ||
      (Number(item.estimatedHours) > 0 ? Math.round(Number(item.estimatedHours) * 60) : 0) ||
      0
    );
    return sum + (isNaN(mins) ? 0 : mins);
  }, 0);

  // محاسبه آمار تفکیکی هر تکنسین برای ۳ بخش
  const getTechnicianWorkStats = (techName: string) => {
    const isItemMatch = (r: any) => {
      if (!r) return false;
      const coList = Array.isArray(r.coTechnicians)
        ? r.coTechnicians
        : (typeof r.coTechnicians === 'string' ? r.coTechnicians.split(/[,،]+/).map((s: string) => s.trim()) : []);
      const techList = Array.isArray(r.technicians) ? r.technicians : [];
      const woTechList = Array.isArray(r.woTechnicians)
        ? r.woTechnicians
            .filter((t: any) => (Number(t?.hours) || 0) > 0 || !r.isScheduledPM)
            .map((t: any) => String(t?.name || '').trim())
        : [];
      const assignedToList = typeof r.assignedTo === 'string'
        ? r.assignedTo.split(/\s+و\s+|[،,]+/).map((s: string) => s.trim()).filter(Boolean)
        : [];

      return (
        r.technician === techName ||
        r.assignedTechnician === techName ||
        assignedToList.includes(techName) ||
        coList.includes(techName) ||
        techList.includes(techName) ||
        woTechList.includes(techName) ||
        r.helper === techName ||
        r.assistant === techName ||
        r.secondTechnician === techName ||
        r.coTechnician === techName
      );
    };

    const workRequests = rawWorkRequests.filter(r => {
      const match = isItemMatch(r);
      const isExplicitPM = isStrictPmRecord(r);
      const isTechService = r.category === 'technicalService' || r.source === 'technicalService';
      return match && !isExplicitPM && !isTechService;
    });

    const techServices = rawTechServices.filter(r =>
      isItemMatch(r) &&
      !isStrictPmRecord(r) &&
      r.source !== 'workRequest' &&
      r.originCategory !== 'workRequest'
    );

    const pmTasks = rawPmTasks.filter((s: any) => isItemMatch(s));

    // تفکیک درخواست کارهای خط تولید بر اساس ۳ نوع: اضطراری (EM)، اصلاحی (CM)، پیشگیرانه دوره‌ای درخواست کار (PM)
    const emRequests = workRequests.filter(r => r.requestType === 'اضطراری' || r.type === 'EM' || r.isEmergency);
    const cmRequests = workRequests.filter(r => r.requestType === 'اصلاحی' || r.type === 'CM');
    const pmReqWork = workRequests.filter(r => r.requestType === 'پیشگیرانه' || r.type === 'PM');
    // هر آیتمی که هنوز نوع آن مشخص نشده پیش‌فرض اضطراری در نظر گرفته شود
    const otherWr = workRequests.filter(r => !emRequests.includes(r) && !cmRequests.includes(r) && !pmReqWork.includes(r));
    const finalEmRequests = [...emRequests, ...otherWr];

    const wrMinutes = calcMinutes(workRequests, techName);
    const emMinutes = calcMinutes(finalEmRequests, techName);
    const cmMinutes = calcMinutes(cmRequests, techName);
    const pmReqMinutes = calcMinutes(pmReqWork, techName);

    const tsMinutes = calcMinutes(techServices, techName);
    const pmMinutes = calcMinutes(pmTasks, techName);
    const totalMinutes = wrMinutes + tsMinutes + pmMinutes;

    const allTasksCount = workRequests.length + techServices.length + pmTasks.length;

    const isCompleted = (item: any) => item.status === 'انجام شد' || item.status === 'انجام‌شده';
    const completedCount = 
      workRequests.filter(isCompleted).length +
      techServices.filter(isCompleted).length +
      pmTasks.filter(isCompleted).length;

    // محاسبه کار تیمی در برابر کار انفرادی
    const allAssignedItems = [...workRequests, ...techServices, ...pmTasks];
    let teamCount = 0;
    let soloCount = 0;
    allAssignedItems.forEach((item: any) => {
      const coList = Array.isArray(item.coTechnicians) 
        ? item.coTechnicians 
        : (typeof item.coTechnicians === 'string' ? item.coTechnicians.split(/[,،]+/).map((s: string) => s.trim()) : []);
      const techList = Array.isArray(item.technicians) ? item.technicians : [];
      const text = `${item.actionDetails || ''} ${item.description || ''} ${item.title || ''}`;
      const isCollab = 
        coList.length > 0 ||
        techList.length > 1 ||
        (Array.isArray(item.woTechnicians) && item.woTechnicians.length > 1) ||
        Boolean(item.helper || item.assistant || item.secondTechnician || item.coTechnician) ||
        (item.technician && item.technician !== techName) ||
        text.includes('کمکی') || text.includes('شاگرد') || text.includes('همراه') || text.includes('تیم') || text.includes('دونفره') || text.includes('دو نفره') || text.includes('۲ نفره') || text.includes('تیمی');

      if (isCollab) teamCount++; else soloCount++;
    });

    const teamPercent = allAssignedItems.length > 0 ? Math.round((teamCount / allAssignedItems.length) * 100) : 0;
    const soloPercent = allAssignedItems.length > 0 ? (100 - teamPercent) : 100;

    return {
      workRequests,
      emRequests: finalEmRequests,
      cmRequests,
      pmRequests: pmReqWork,
      techServices,
      pmTasks,
      wrMinutes,
      emMinutes,
      cmMinutes,
      pmReqMinutes,
      tsMinutes,
      pmMinutes,
      wrHours: Math.round((wrMinutes / 60) * 10) / 10,
      emHours: Math.round((emMinutes / 60) * 10) / 10,
      cmHours: Math.round((cmMinutes / 60) * 10) / 10,
      pmReqHours: Math.round((pmReqMinutes / 60) * 10) / 10,
      tsHours: Math.round((tsMinutes / 60) * 10) / 10,
      pmHours: Math.round((pmMinutes / 60) * 10) / 10,
      allTasksCount,
      completedCount,
      teamCount,
      soloCount,
      teamPercent,
      soloPercent,
      totalMinutes,
      completionRate: allTasksCount > 0 ? Math.round((completedCount / allTasksCount) * 100) : 0
    };
  };

  const filteredTechnicians = useMemo(() => {
    return technicians.filter(name => {
      if (filterTechnician !== 'همه' && name !== filterTechnician) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const spec = TECHNICIAN_SPECIALTIES[name];
        return (
          name.toLowerCase().includes(q) ||
          (spec?.role || '').toLowerCase().includes(q) ||
          (spec?.dept || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [technicians, filterTechnician, searchQuery]);

  // ثبت فعالیت تکنسین روی کار موجود
  const handleOpenActionModal = (task: any) => {
    setSelectedTaskForAction(task);
    const existingCo = Array.isArray(task.coTechnicians) && task.coTechnicians.length > 0
      ? task.coTechnicians[0]
      : (task.assistant || task.helper || '');
    setActionFormData({
      status: task.status === 'انجام شد' || task.status === 'انجام‌شده' ? 'انجام شد' : 'انجام شد',
      durationMinutes: task.durationMinutes || task.estimatedMinutes || 60,
      actionDetails: task.actionDetails || '',
      coTechnician: existingCo
    });
    setIsLogActionModalOpen(true);
  };

  const handleSaveAction = () => {
    if (!selectedTaskForAction) return;

    const coList = actionFormData.coTechnician 
      ? [actionFormData.coTechnician] 
      : (Array.isArray(selectedTaskForAction.coTechnicians) ? selectedTaskForAction.coTechnicians : []);

    const updated = {
      ...selectedTaskForAction,
      status: actionFormData.status,
      durationMinutes: Number(actionFormData.durationMinutes) || 60,
      actionDetails: actionFormData.actionDetails || 'عملیات با موفقیت انجام شد',
      coTechnicians: coList,
      assistant: actionFormData.coTechnician || selectedTaskForAction.assistant,
      helper: actionFormData.coTechnician || selectedTaskForAction.helper
    };

    if (onUpdateRequest) onUpdateRequest(updated);

    const updateInStorage = (key: string) => {
      try {
        const raw = localStorage.getItem(key);
        if (raw) {
          const list = JSON.parse(raw);
          if (Array.isArray(list)) {
            const nextList = list.map((item: any) => 
              (item.id || item.code) === (updated.id || updated.code) ? updated : item
            );
            localStorage.setItem(key, JSON.stringify(nextList));
          }
        }
      } catch {}
    };

    updateInStorage('portal_pm_work_requests_v3');
    updateInStorage('technicalServiceWorkRequests');
    updateInStorage('app_pm_schedules_v1');

    // همگام‌سازی با سرور مرکزی
    fetch('/api/portal/sync-state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updatedTask: updated })
    }).catch(() => {});

    setIsLogActionModalOpen(false);
  };

  const handleExportExcel = () => {
    const rows = technicians.map(name => {
      const stats = getTechnicianWorkStats(name);
      const spec = TECHNICIAN_SPECIALTIES[name];
      return {
        'نام تکنسین': name,
        'کد پرسنلی': spec?.code || '—',
        'تعداد درخواست کارها': stats.workRequests.length,
        'ساعت درخواست کارها': stats.wrHours,
        'تعداد خدمات فنی': stats.techServices.length,
        'ساعت خدمات فنی': stats.tsHours,
        'تعداد پیشگیرانه (PM)': stats.pmTasks.length,
        'ساعت پیشگیرانه': stats.pmHours,
        'مجموع کل کارها': stats.allTasksCount,
        'کل ساعت کارکرد': formatTotalTime(stats.totalMinutes)
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'عملکرد ۳ پارامتر');
    XLSX.writeFile(workbook, 'گزارش_عملکرد_تکنسین_ها.xlsx');
  };

  // مورد اول: داده‌های نمودار برای ۳ پارامتر (تعداد یا ساعات کارکرد تفکیکی)
  const chartData = useMemo(() => {
    return technicians.map(name => {
      const stats = getTechnicianWorkStats(name);
      const spec = TECHNICIAN_SPECIALTIES[name];
      return {
        name,
        shortName: name.split(' ')[1] || name,
        spec,
        // تعداد کارها به تفکیک ۳ بخش
        wrCount: stats.workRequests.length,
        tsCount: stats.techServices.length,
        pmCount: stats.pmTasks.length,
        // ساعات کارکرد به تفکیک ۳ بخش (مورد اول کاربر)
        wrHours: stats.wrHours,
        tsHours: stats.tsHours,
        pmHours: stats.pmHours,
        totalHours: Math.round((stats.totalMinutes / 60) * 10) / 10
      };
    });
  }, [technicians, rawWorkRequests, rawTechServices, rawPmTasks]);

  // سقف نمودار متناسب با مقیاس
  const maxChartValue = useMemo(() => {
    if (chartMetric === 'byHours') {
      const maxH = Math.max(...chartData.map(d => Math.max(d.wrHours, d.tsHours, d.pmHours)), 4);
      return Math.ceil(maxH * 1.3);
    }
    const maxVal = Math.max(...chartData.map(d => Math.max(d.wrCount, d.tsCount, d.pmCount)), 4);
    return Math.ceil(maxVal * 1.3);
  }, [chartData, chartMetric]);

  // اجرای پرینت حرفه‌ای با پنجره مستقیم اختصاصی و آی‌فریم پشتیبان
  const triggerPrintForElement = (elementId: string) => {
    const el = document.getElementById(elementId);
    if (!el) {
      window.print();
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head>
        <meta charset="utf-8" />
        <title>گزارش عملکرد واحد نگهداری و خدمات فنی</title>
        <style>
          @page { size: A4 portrait; margin: 8mm; }
          body { font-family: Tahoma, 'Vazirmatn', system-ui, -apple-system, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 12px; }
          * { box-sizing: border-box; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 12px; font-size: 11px; }
          th, td { border: 1px solid #64748b; padding: 6px 8px; text-align: right; }
          th { background: #f1f5f9; font-weight: bold; }
          .text-center { text-align: center; }
          .font-mono { font-family: monospace; }
          .font-bold { font-weight: bold; }
          .no-print { display: none !important; }
          @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div style="margin-bottom: 12px; text-align: left;" class="no-print">
          <button id="directPrintBtn" onclick="window.print()" style="background:#2563eb; color:#ffffff; border:none; padding:8px 18px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px;">ارسال مستقیم به چاپگر (Print)</button>
          <button onclick="window.close()" style="background:#64748b; color:#ffffff; border:none; padding:8px 14px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px; margin-right:6px;">بستن</button>
        </div>
        ${el.innerHTML}
        <script>
          const pBtn = document.getElementById('directPrintBtn');
          if (pBtn) {
            pBtn.addEventListener('click', function() { window.print(); });
          }
          window.focus();
          setTimeout(function() {
            window.print();
          }, 350);
        </script>
      </body>
      </html>
    `;

    // ۱. روش اصلی: باز کردن در یک پنجره مستقل با داکیومنت مستقیم
    let winOpened = false;
    try {
      const printWin = window.open('', '_blank', 'width=950,height=800,top=50,left=50');
      if (printWin) {
        winOpened = true;
        printWin.document.open();
        printWin.document.write(htmlContent);
        printWin.document.close();
        printWin.focus();
      }
    } catch (err) {
      console.warn('Popup blocked or failed, using iframe print:', err);
    }

    // ۲. روش پشتیبان مطمئن: ایجاد iframe درون صفحه و فراخوانی مستقیم پرینتر
    if (!winOpened) {
      try {
        let iframe = document.getElementById('workforce-print-iframe') as HTMLIFrameElement | null;
        if (iframe) {
          iframe.remove();
        }
        iframe = document.createElement('iframe');
        iframe.id = 'workforce-print-iframe';
        iframe.style.position = 'fixed';
        iframe.style.top = '-9999px';
        iframe.style.left = '-9999px';
        iframe.style.width = '1000px';
        iframe.style.height = '1000px';
        iframe.style.border = 'none';
        document.body.appendChild(iframe);

        const frameDoc = iframe.contentWindow?.document;
        if (frameDoc) {
          frameDoc.open();
          frameDoc.write(htmlContent);
          frameDoc.close();
          setTimeout(() => {
            iframe?.contentWindow?.focus();
            iframe?.contentWindow?.print();
          }, 400);
        }
      } catch (e) {
        console.warn('Iframe print fallback trigger, executing window.print():', e);
        window.print();
      }
    }
  };

  const handleExecutePrint = () => {
    triggerPrintForElement('cmms-printable-report');
  };

  const handleExecuteIndividualPrint = () => {
    triggerPrintForElement('cmms-tech-individual-print');
  };

  // اجرای تحلیل هوش مصنوعی تکنسین (متصل به سرور با تایم‌اوت ۵ ثانیه + موتور تحلیلی بومی فوری)
  const handleRunTechnicianAiAnalysis = async (techName: string) => {
    setAiModalTech(techName);
    setAiLoading(true);
    setAiCopied(false);

    const stats = getTechnicianWorkStats(techName);
    const techAllTasks = [
      ...stats.workRequests.map(r => ({
        title: r.failureTitle || r.title || 'درخواست کار تجهیز',
        operationType: r.requestType || r.operationType || 'فنی',
        durationMinutes: Number(r.durationMinutes || r.durationMin || 60),
        status: r.status || 'در حال اقدام',
        complexityLevel: r.complexityLevel || 'معمولی',
        coTechnicians: r.coTechnicians || [],
        details: r.description || r.actionDetails || ''
      })),
      ...stats.techServices.map(r => ({
        title: r.title || 'خدمات فنی',
        operationType: r.operationType || 'عمومی',
        durationMinutes: Number(r.durationMinutes || 60),
        status: r.status || 'در حال اقدام',
        complexityLevel: r.complexityLevel || 'معمولی',
        coTechnicians: r.coTechnicians || [],
        details: r.description || r.actionDetails || ''
      })),
      ...stats.pmTasks.map(r => ({
        title: r.title || r.activityTitle || 'سرویس پیشگیرانه PM',
        operationType: 'مکانیک',
        durationMinutes: Number(r.durationMinutes || (r.estimatedHours ? Number(r.estimatedHours) * 60 : 60)),
        status: r.status === 'completed' || r.status === 'انجام شد' ? 'انجام شد' : 'در حال اقدام',
        complexityLevel: 'معمولی',
        coTechnicians: r.coTechnicians || [],
        details: r.notes || ''
      }))
    ];

    const totalAllTasks = Math.max(techAllTasks.length, rawWorkRequests.length + rawTechServices.length + rawPmTasks.length);
    const totalAllMinutes = techAllTasks.reduce((s, t) => s + (t.durationMinutes || 0), 0);

    try {
      const isFileProtocol = typeof window !== 'undefined' && window.location.protocol === 'file:';
      if (!isFileProtocol) {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        try {
          const res = await fetch('/api/technician-ai-analysis', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              technicianName: techName,
              tasks: techAllTasks,
              totalPlantTasks: totalAllTasks,
              plantTotalMinutes: totalAllMinutes
            })
          });
          clearTimeout(tid);
          if (res.ok) {
            const parsed = await res.json();
            if (parsed && parsed.analysisText) {
              setAiResults(prev => ({ ...prev, [techName]: parsed }));
              setAiLoading(false);
              return;
            }
          }
        } catch {
          clearTimeout(tid);
        }
      }
    } catch {}

    // موتور تحلیلی محلی در صورت قطعی شبکه یا محیط آفلاین
    const taskCount = techAllTasks.length;
    const doneCount = techAllTasks.filter(t => t.status === 'انجام شد').length;
    const activeCount = taskCount - doneCount;
    const totalMinutes = techAllTasks.reduce((s, t) => s + (t.durationMinutes || 0), 0);
    const avgMinutes = taskCount > 0 ? Math.round(totalMinutes / taskCount) : 0;
    const shareOfPlantPercent = totalAllTasks > 0 ? Math.round((taskCount / totalAllTasks) * 100) : (taskCount > 0 ? 100 : 0);

    let soloCount = 0;
    let teamCount = 0;
    const opMap: Record<string, number> = { 'برق صنعتی': 0, 'مکانیک': 0, 'تاسیسات': 0, 'فنی و پیشگیرانه': 0 };
    techAllTasks.forEach(t => {
      if (Array.isArray(t.coTechnicians) && t.coTechnicians.length > 0) teamCount++;
      else soloCount++;
      const op = String(t.operationType || '');
      if (op.includes('برق')) opMap['برق صنعتی']++;
      else if (op.includes('مکانیک')) opMap['مکانیک']++;
      else if (op.includes('تاسیسات')) opMap['تاسیسات']++;
      else opMap['فنی و پیشگیرانه']++;
    });

    const soloPercent = taskCount > 0 ? Math.round((soloCount / taskCount) * 100) : 0;
    const teamPercent = taskCount > 0 ? Math.round((teamCount / taskCount) * 100) : 0;
    const completionRate = taskCount > 0 ? Math.round((doneCount / taskCount) * 100) : 0;
    const topSpecialty = Object.entries(opMap).sort((a, b) => b[1] - a[1])[0]?.[0] || 'فنی و پیشگیرانه';

    let easyCount = 0;
    let normalCount = 0;
    let hardCount = 0;
    let onTimeCount = 0;
    techAllTasks.forEach(t => {
      const comp = t.complexityLevel || 'معمولی';
      const limit = comp === 'آسان' ? 120 : (comp === 'دشوار' ? 480 : 240);
      if (comp === 'آسان') easyCount++;
      else if (comp === 'دشوار') hardCount++;
      else normalCount++;
      if ((t.durationMinutes || 60) <= limit) onTimeCount++;
    });

    const onTimePercent = taskCount > 0 ? Math.round((onTimeCount / taskCount) * 100) : 100;
    const speedLabel = avgMinutes <= 60 ? 'سریع و چابک' : (onTimePercent >= 80 ? 'استاندارد و منظم' : 'پروژه‌ای و نیازمند پیگیری');
    const score = (completionRate / 100) * 55 + (onTimePercent / 100) * 35 + Math.min(10, hardCount * 3);
    const starRating = taskCount === 0 ? 5 : (score >= 88 ? 5 : score >= 76 ? 4.5 : score >= 65 ? 4 : score >= 52 ? 3.5 : 3);
    const starRatingLabel = taskCount === 0 ? 'در انتظار ثبت اولین کار' : `ارزیابی کیفیت عملکرد (${toFaDigits(starRating)} ستاره)`;

    const analysisText = taskCount === 0
      ? `چکیده تحلیلی عملکرد ${techName}:\n• در حال حاضر هیچ درخواست کار، خدمات فنی یا PM برای این تکنسین ثبت نشده است.\n• پس از ثبت اولین فعالیت، سرعت، گرایش تخصصی و نرخ تموم‌کنندگی به‌صورت خودکار محاسبه خواهد شد.`
      : `• بازده زمانی: ${toFaDigits(onTimePercent)}٪ فعالیت‌ها درون سقف استاندارد (میانگین ${toFaDigits(avgMinutes)} دقیقه به ازای هر کار) انجام شده است.\n• تفکیک فعالیت‌ها: ${toFaDigits(stats.workRequests.length)} درخواست کار، ${toFaDigits(stats.techServices.length)} خدمات فنی و ${toFaDigits(stats.pmTasks.length)} سرویس پیشگیرانه با تمرکز بر حوزه «${topSpecialty}».\n• سبک اجرا: ${toFaDigits(soloPercent)}٪ کارها به‌صورت مستقل و ${toFaDigits(teamPercent)}٪ به‌صورت همکاری تیمی به سرانجام رسیده است.\n• تموم‌کنندگی فردی: نرخ بستن و تحویل موفق پرونده‌ها ${toFaDigits(completionRate)}٪ (${toFaDigits(doneCount)} از ${toFaDigits(taskCount)} مورد) است.\n• جمع‌بندی سرپرستی: متناسب با عملکرد فعلی (${speedLabel})، واگذاری کارهای تخصصی ${topSpecialty} و عملیات دارای ${easyCount + normalCount > 0 ? 'اولویت عملیاتی بالا' : 'ماهیت تیمی'} پیشنهاد می‌شود.`;

    setAiResults(prev => ({
      ...prev,
      [techName]: {
        technicianName: techName,
        taskCount,
        doneCount,
        activeCount,
        totalMinutes,
        avgMinutes,
        shareOfPlantPercent,
        soloPercent,
        teamPercent,
        completionRate,
        topSpecialty,
        speedLabel,
        starRating,
        starRatingLabel,
        analysisText
      }
    }));
    setAiLoading(false);
  };

  return (
    <div className="space-y-4">

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* ۱. نوار ابزار مینیمال و خلوت */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-2.5 p-3 rounded-2xl bg-[#081024]/90 border border-indigo-500/20">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="جستجوی تکنسین..."
              className="bg-[#0e1b38] border border-blue-900/40 rounded-xl pr-7 pl-2.5 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-400 w-36 sm:w-44"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-[#0e1b38] px-3 py-1.5 rounded-xl border border-blue-900/40 text-xs">
            <Filter size={12} className="text-cyan-400" />
            <select
              value={filterTechnician}
              onChange={e => setFilterTechnician(e.target.value)}
              className="bg-transparent text-white font-bold outline-none cursor-pointer text-xs"
            >
              <option value="همه" className="bg-[#0c162d]">همه تکنسین‌ها</option>
              {technicians.map((t, idx) => (
                <option key={idx} value={t} className="bg-[#0c162d]">{t}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1 bg-[#0e1b38] p-1 rounded-xl border border-blue-900/40 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              کارت‌ها
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              جدول
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0e1b38] hover:bg-[#152752] border border-emerald-500/30 text-emerald-300 hover:text-white text-xs font-bold transition-all cursor-pointer"
            title="خروجی فایل اکسل"
          >
            <Download size={13} />
            <span>اکسل</span>
          </button>

          {/* مورد سوم: فعال‌سازی چاپ با لوگو و نمودار */}
          <button
            type="button"
            onClick={() => setIsPrintModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
            title="پیش‌نمایش و چاپ رسمی کارنامه و نمودار"
          >
            <Printer size={13} />
            <span>چاپ گزارش و نمودار</span>
          </button>
        </div>
      </div>

      {/* ۲. لیست کارت‌های آکاردئونی تکنسین‌ها (مورد دوم: همه پیش‌فرض بسته | مورد دوم: حذف "در دسترس") */}
      {viewMode === 'cards' && (
        <div className="flex flex-col gap-2.5">
          {filteredTechnicians.map((name, idx) => {
            const spec = TECHNICIAN_SPECIALTIES[name] || { role: 'تکنسین فنی', dept: 'نگهداری و تعمیرات', code: `TC-10${idx + 1}`, color: '#06b6d4' };
            const stats = getTechnicianWorkStats(name);
            const photo = technicianPhotos[name] || DEFAULT_TECHNICIAN_AVATARS[name];
            const isExpanded = expandedTech === name;
            const currentTab = cardActiveTab[name] || 'workRequests';

            return (
              <div
                key={name || idx}
                className={`group bg-[#0c162d] border rounded-2xl p-3 sm:p-3.5 transition-all duration-200 ${
                  isExpanded ? 'border-cyan-500/60 bg-[#0e1b38] shadow-lg' : 'border-[#1d2d52] hover:border-blue-500/50'
                }`}
              >
                {/* هدر کارت (کاملاً خلوت و بدون نوشته در دسترس - مورد دوم کاربر) */}
                <div
                  onClick={() => setExpandedTech(prev => (prev === name ? null : name))}
                  className="flex justify-between items-center cursor-pointer select-none gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative group/avatar shrink-0">
                      <div className="w-11 h-11 rounded-full bg-[#111e3b] border-2 border-blue-500/80 p-0.5 overflow-hidden flex items-center justify-center">
                        <img src={photo} alt={name} className="w-full h-full object-cover rounded-full" />
                      </div>
                      <button
                        type="button"
                        onClick={(e) => handleTriggerUpload(name, e)}
                        title="تغییر عکس"
                        className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-cyan-700 hover:bg-cyan-600 text-white flex items-center justify-center border border-white opacity-80 group-hover/avatar:opacity-100 transition-opacity cursor-pointer"
                      >
                        <Camera size={9} />
                      </button>
                    </div>

                    <div className="min-w-0">
                      <div className="font-bold text-sm text-white flex items-center gap-2 truncate">
                        <span>{name}</span>
                        {/* کد پرسنلی با قابلیت تغییر سریع از طریق نقطه/نشانگر کوچک */}
                        {editingCodeTech === name ? (
                          <div 
                            onClick={(e) => e.stopPropagation()} 
                            className="flex items-center gap-1 bg-[#0b162f] p-0.5 rounded border border-cyan-400"
                          >
                            <input
                              type="text"
                              value={tempCodeValue}
                              onChange={(e) => setTempCodeValue(e.target.value)}
                              placeholder="کد پرسنلی"
                              className="font-mono text-[10px] text-cyan-300 bg-transparent px-1 py-0.2 outline-none w-16"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveCode(name, e as any);
                                if (e.key === 'Escape') setEditingCodeTech(null);
                              }}
                            />
                            <button
                              type="button"
                              onClick={(e) => handleSaveCode(name, e)}
                              className="w-4 h-4 rounded bg-cyan-600 hover:bg-cyan-500 text-white flex items-center justify-center text-[9px] cursor-pointer"
                              title="ذخیره"
                            >
                              ✓
                            </button>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); setEditingCodeTech(null); }}
                              className="w-4 h-4 rounded bg-slate-700 hover:bg-slate-600 text-white flex items-center justify-center text-[9px] cursor-pointer"
                              title="انصراف"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 group/code">
                            <span className="font-mono text-[10px] text-cyan-400 bg-cyan-950/70 px-1.5 py-0.2 rounded border border-cyan-800/40">
                              {technicianCodes[name] || spec.code}
                            </span>
                            {/* علامت / نقطه کوچک جهت تغییر کد پرسنلی طبق خواسته کاربر */}
                            <button
                              type="button"
                              onClick={(e) => handleStartEditCode(name, technicianCodes[name] || spec.code, e)}
                              title="تغییر کد پرسنلی"
                              className="w-2.5 h-2.5 rounded-full bg-cyan-500/30 hover:bg-cyan-400 border border-cyan-400/60 transition-all cursor-pointer flex items-center justify-center"
                            />
                          </div>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {spec.role}
                      </div>
                    </div>
                  </div>

                  {/* نمایش ۳ پارامتر مجزا بدون نوشته "در دسترس" و بدون دکمه چاپ در نوار اصلی */}
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="flex items-center gap-1 sm:gap-1.5 text-[11px]">
                      <span className="px-2 py-0.5 rounded-lg bg-cyan-950/70 text-cyan-300 border border-cyan-800/40 font-medium">
                        درخواست کار: <strong className="font-mono">{toFaDigits(stats.workRequests.length)}</strong>
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-blue-950/70 text-blue-300 border border-blue-800/40 font-medium">
                        خدمات فنی: <strong className="font-mono">{toFaDigits(stats.techServices.length)}</strong>
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-purple-950/70 text-purple-300 border border-purple-800/40 font-medium">
                        پیشگیرانه: <strong className="font-mono">{toFaDigits(stats.pmTasks.length)}</strong>
                      </span>
                    </div>

                    <div className={`text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-cyan-400' : ''}`}>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                {/* بخش باز شونده کارت با ۳ تب کاملاً مجزا و دکمه چاپ تکنسین در زیرمجموعه */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-[#1d2d52] space-y-3 animate-in fade-in duration-150">
                    {/* ردیف تب‌های سه‌گانه همراه با دکمه چاپ اختصاصی در زیرمجموعه (مخفی در هدر، موجود در زیرمجموعه) */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#070e22] border border-indigo-900/40 text-xs w-max">
                        <button
                          type="button"
                          onClick={() => setCardActiveTab(prev => ({ ...prev, [name]: 'workRequests' }))}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                            currentTab === 'workRequests'
                              ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-xs'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <Wrench size={12} />
                          <span>درخواست کارها</span>
                          <span className="font-mono text-[10px] bg-black/40 px-1.5 py-0.2 rounded">
                            {toFaDigits(stats.workRequests.length)}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setCardActiveTab(prev => ({ ...prev, [name]: 'techServices' }))}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                            currentTab === 'techServices'
                              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <Activity size={12} />
                          <span>خدمات فنی</span>
                          <span className="font-mono text-[10px] bg-black/40 px-1.5 py-0.2 rounded">
                            {toFaDigits(stats.techServices.length)}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setCardActiveTab(prev => ({ ...prev, [name]: 'pm' }))}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                            currentTab === 'pm'
                              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-xs'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <Calendar size={12} />
                          <span>پیشگیرانه (PM)</span>
                          <span className="font-mono text-[10px] bg-black/40 px-1.5 py-0.2 rounded">
                            {toFaDigits(stats.pmTasks.length)}
                          </span>
                        </button>
                      </div>

                      {/* دکمه‌های عملیات اختصاصی تکنسین در زیرمجموعه */}
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRunTechnicianAiAnalysis(name);
                          }}
                          title={`تحلیل هوشمند عملکرد ${name}`}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600/80 to-indigo-600/80 hover:from-purple-500 hover:to-indigo-500 border border-purple-400/40 text-white text-xs font-bold transition-all cursor-pointer shadow-xs"
                        >
                          <Bot size={13} />
                          <span>تحلیل هوش مصنوعی</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setIndividualPrintTech(name);
                          }}
                          title={`چاپ کارنامه و نمودار اختصاصی ${name}`}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-900/60 hover:bg-cyan-700 border border-cyan-500/40 text-cyan-200 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-xs"
                        >
                          <Printer size={13} />
                          <span>چاپ کارنامه {name}</span>
                        </button>
                      </div>
                    </div>

                    {/* جدول تب ۱: درخواست کارها با تفکیک دقیق EM - CM - PM درخواست کار */}
                    {currentTab === 'workRequests' && (() => {
                      const activeWrFilter = cardWrFilter[name] || 'all';
                      const filteredWrList = stats.workRequests.filter(req => {
                        if (activeWrFilter === 'all') return true;
                        if (activeWrFilter === 'اضطراری') return stats.emRequests.some(r => (r.code || r.id) === (req.code || req.id));
                        if (activeWrFilter === 'اصلاحی') return stats.cmRequests.some(r => (r.code || r.id) === (req.code || req.id));
                        if (activeWrFilter === 'پیشگیرانه') return stats.pmRequests.some(r => (r.code || r.id) === (req.code || req.id));
                        return true;
                      });

                      return (
                      <div className="space-y-2.5">
                        {/* نوار زیرفیلتر تفکیک سه‌گانه EM - CM - PM برای درخواست کارهای این تکنسین */}
                        <div className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-xl bg-[#091326] border border-cyan-900/30">
                          <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                            <span>تفکیک نوع درخواست کار:</span>
                          </div>
                          <div className="flex items-center gap-1 text-[11px]">
                            <button
                              type="button"
                              onClick={() => setCardWrFilter(prev => ({ ...prev, [name]: 'all' }))}
                              className={`px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                                activeWrFilter === 'all'
                                  ? 'bg-cyan-600 text-white'
                                  : 'text-slate-400 hover:text-white bg-slate-800/60'
                              }`}
                            >
                              همه ({toFaDigits(stats.workRequests.length)})
                            </button>
                            <button
                              type="button"
                              onClick={() => setCardWrFilter(prev => ({ ...prev, [name]: 'اضطراری' }))}
                              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                                activeWrFilter === 'اضطراری'
                                  ? 'bg-red-600 text-white shadow-xs'
                                  : 'text-red-300 hover:text-white bg-red-950/40 border border-red-900/40'
                              }`}
                            >
                              <span>اضطراری (EM)</span>
                              <span className="font-mono text-[10px]">{toFaDigits(stats.emRequests.length)}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setCardWrFilter(prev => ({ ...prev, [name]: 'اصلاحی' }))}
                              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                                activeWrFilter === 'اصلاحی'
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'text-amber-300 hover:text-white bg-amber-950/40 border border-amber-900/40'
                              }`}
                            >
                              <span>اصلاحی (CM)</span>
                              <span className="font-mono text-[10px]">{toFaDigits(stats.cmRequests.length)}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setCardWrFilter(prev => ({ ...prev, [name]: 'پیشگیرانه' }))}
                              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                                activeWrFilter === 'پیشگیرانه'
                                  ? 'bg-teal-600 text-white shadow-xs'
                                  : 'text-teal-300 hover:text-white bg-teal-950/40 border border-teal-900/40'
                              }`}
                            >
                              <span>پیشگیرانه درخواست (PM)</span>
                              <span className="font-mono text-[10px]">{toFaDigits(stats.pmRequests.length)}</span>
                            </button>
                          </div>
                        </div>

                        {filteredWrList.length === 0 ? (
                          <div className="p-4 text-center rounded-xl bg-[#070e22]/50 border border-dashed border-indigo-900/30 text-slate-400 text-xs">
                            درخواست کاری در این دسته برای این تکنسین ثبت نشده است.
                          </div>
                        ) : (
                          <div className="overflow-x-auto rounded-xl border border-indigo-900/40 bg-[#070e22]">
                            <table className="w-full text-right text-xs">
                              <thead>
                                <tr className="border-b border-indigo-900/40 text-slate-400 bg-[#081024]">
                                  <th className="p-2.5">کد</th>
                                  <th className="p-2.5">نوع درخواست</th>
                                  <th className="p-2.5">تجهیز</th>
                                  <th className="p-2.5">شرح عیب</th>
                                  <th className="p-2.5">اولویت</th>
                                  <th className="p-2.5">زمان</th>
                                  <th className="p-2.5">وضعیت</th>
                                  <th className="p-2.5 text-center">اقدام</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-indigo-950/60">
                                {filteredWrList.map((req, rIdx) => {
                                  const isDone = req.status === 'انجام شد';
                                  const reqType = req.requestType === 'اصلاحی' ? 'اصلاحی (CM)' : (req.requestType === 'پیشگیرانه' ? 'پیشگیرانه (PM)' : 'اضطراری (EM)');
                                  const typeBadgeClass = req.requestType === 'اصلاحی'
                                    ? 'bg-amber-950/80 text-amber-300 border-amber-800/50'
                                    : (req.requestType === 'پیشگیرانه'
                                      ? 'bg-teal-950/80 text-teal-300 border-teal-800/50'
                                      : 'bg-red-950/80 text-red-300 border-red-800/50');

                                  return (
                                    <tr key={rIdx} className="hover:bg-[#112042]/50">
                                      <td className="p-2.5 font-mono text-cyan-300 font-bold">{req.code || req.id}</td>
                                      <td className="p-2.5">
                                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${typeBadgeClass}`}>
                                          {reqType}
                                        </span>
                                      </td>
                                      <td className="p-2.5 text-white font-medium">
                                        <div>{req.equipmentName}</div>
                                        {(() => {
                                          const helperName = (Array.isArray(req.coTechnicians) && req.coTechnicians[0]) || req.assistant || req.helper || (req.technician && req.technician !== name ? req.technician : '');
                                          const isHelperForThis = req.technician && req.technician !== name;
                                          if (!helperName) return null;
                                          return (
                                            <div className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-indigo-950/80 border border-indigo-700/50 text-indigo-300 mt-1">
                                              <span>👥 {isHelperForThis ? `به عنوان کمکی (${helperName})` : `با همکاری: ${helperName}`}</span>
                                            </div>
                                          );
                                        })()}
                                      </td>
                                      <td className="p-2.5 text-slate-300">{req.failureTitle || req.title}</td>
                                      <td className="p-2.5">
                                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                                          {req.priority || 'عادی'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 font-mono text-[11px] text-slate-400">{req.requestTime || req.created}</td>
                                      <td className="p-2.5">
                                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                                          isDone ? 'bg-emerald-950 text-emerald-300' : 'bg-cyan-950 text-cyan-300'
                                        }`}>
                                          {req.status || 'در حال اقدام'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 text-center">
                                        <button
                                          type="button"
                                          onClick={() => handleOpenActionModal(req)}
                                          className="text-xs px-2 py-1 rounded bg-cyan-900/60 hover:bg-cyan-800 text-cyan-200 cursor-pointer"
                                        >
                                          {isDone ? 'ویرایش' : 'ثبت خاتمه'}
                                        </button>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                      );
                    })()}

                    {/* جدول تب ۲: خدمات فنی */}
                    {currentTab === 'techServices' && (
                      <div>
                        {stats.techServices.length === 0 ? (
                          <div className="p-4 text-center rounded-xl bg-[#070e22]/50 border border-dashed border-indigo-900/30 text-slate-400 text-xs">
                            کار خدمات فنی برای این تکنسین ثبت نشده است.
                          </div>
                        ) : (
                          <div className="overflow-x-auto rounded-xl border border-indigo-900/40 bg-[#070e22]">
                            <table className="w-full text-right text-xs">
                              <thead>
                                <tr className="border-b border-indigo-900/40 text-slate-400 bg-[#081024]">
                                  <th className="p-2.5">کد دستور</th>
                                  <th className="p-2.5">مکان / سالن</th>
                                  <th className="p-2.5">شرح کار خدمات فنی</th>
                                  <th className="p-2.5">اولویت</th>
                                  <th className="p-2.5">تاریخ ثبت</th>
                                  <th className="p-2.5">وضعیت</th>
                                  <th className="p-2.5 text-center">اقدام</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-indigo-950/60">
                                {stats.techServices.map((task, tIdx) => {
                                  const isDone = task.status === 'انجام شد' || task.status === 'انجام‌شده';
                                  return (
                                    <tr key={tIdx} className="hover:bg-[#112042]/50">
                                      <td className="p-2.5 font-mono text-blue-300 font-bold">{task.code || task.id}</td>
                                      <td className="p-2.5 text-white font-medium">
                                        <div>{task.place || task.locationName || 'تاسیسات'}</div>
                                        {(() => {
                                          const helperName = (Array.isArray(task.coTechnicians) && task.coTechnicians[0]) || task.assistant || task.helper || (task.technician && task.technician !== name ? task.technician : '');
                                          const isHelperForThis = task.technician && task.technician !== name;
                                          if (!helperName) return null;
                                          return (
                                            <div className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-indigo-950/80 border border-indigo-700/50 text-indigo-300 mt-1">
                                              <span>👥 {isHelperForThis ? `به عنوان کمکی (${helperName})` : `با همکاری: ${helperName}`}</span>
                                            </div>
                                          );
                                        })()}
                                      </td>
                                      <td className="p-2.5 text-slate-300">{task.title || task.failureTitle}</td>
                                      <td className="p-2.5">
                                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                                          {task.priority || 'عادی'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 font-mono text-[11px] text-slate-400">{task.created || task.requestTime}</td>
                                      <td className="p-2.5">
                                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                                          isDone ? 'bg-emerald-950 text-emerald-300' : 'bg-blue-950 text-blue-300'
                                        }`}>
                                          {task.status || 'در حال اقدام'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 text-center">
                                        <button
                                          type="button"
                                          onClick={() => handleOpenActionModal(task)}
                                          className="text-xs px-2 py-1 rounded bg-blue-900/60 hover:bg-blue-800 text-blue-200 cursor-pointer"
                                        >
                                          {isDone ? 'ویرایش' : 'ثبت خاتمه'}
                                        </button>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}

                    {/* جدول تب ۳: پیشگیرانه */}
                    {currentTab === 'pm' && (
                      <div>
                        {stats.pmTasks.length === 0 ? (
                          <div className="p-4 text-center rounded-xl bg-[#070e22]/50 border border-dashed border-indigo-900/30 text-slate-400 text-xs">
                            برنامه پیشگیرانه‌ای برای این تکنسین ثبت نشده است.
                          </div>
                        ) : (
                          <div className="overflow-x-auto rounded-xl border border-indigo-900/40 bg-[#070e22]">
                            <table className="w-full text-right text-xs">
                              <thead>
                                <tr className="border-b border-indigo-900/40 text-slate-400 bg-[#081024]">
                                  <th className="p-2.5">کد PM</th>
                                  <th className="p-2.5">تجهیز</th>
                                  <th className="p-2.5">عنوان سرویس پیشگیرانه</th>
                                  <th className="p-2.5">تناوب</th>
                                  <th className="p-2.5">سررسید</th>
                                  <th className="p-2.5">وضعیت</th>
                                  <th className="p-2.5 text-center">اقدام</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-indigo-950/60">
                                {stats.pmTasks.map((task, pIdx) => {
                                  const isDone = task.status === 'انجام شد' || task.status === 'انجام‌شده';
                                  return (
                                    <tr key={pIdx} className="hover:bg-[#112042]/50">
                                      <td className="p-2.5 font-mono text-purple-300 font-bold">{task.id || task.code}</td>
                                      <td className="p-2.5 text-white font-medium">{task.equipmentName}</td>
                                      <td className="p-2.5 text-slate-300">{task.title}</td>
                                      <td className="p-2.5">
                                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-950 text-purple-200">
                                          {task.periodicity || 'دوره‌ای'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 font-mono text-[11px] text-slate-400">{task.nextDueDate || '—'}</td>
                                      <td className="p-2.5">
                                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                                          isDone ? 'bg-emerald-950 text-emerald-300' : 'bg-purple-950 text-purple-300'
                                        }`}>
                                          {task.status || 'در انتظار'}
                                        </span>
                                      </td>
                                      <td className="p-2.5 text-center">
                                        <button
                                          type="button"
                                          onClick={() => handleOpenActionModal(task)}
                                          className="text-xs px-2 py-1 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200 cursor-pointer"
                                        >
                                          {isDone ? 'ویرایش' : 'ثبت انجام'}
                                        </button>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}

                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ۳. نمای جدولی ماتریس تفکیکی */}
      {viewMode === 'table' && (
        <div className="overflow-x-auto rounded-2xl border border-indigo-500/20 bg-[#070e22]/90">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                <th className="p-3">تکنسین</th>
                <th className="p-3">کد</th>
                <th className="p-3 text-center text-cyan-300">درخواست کارها</th>
                <th className="p-3 text-center text-blue-300">خدمات فنی</th>
                <th className="p-3 text-center text-purple-300">پیشگیرانه</th>
                <th className="p-3 text-center font-bold text-white">مجموع کارها</th>
                <th className="p-3 text-center text-amber-300">ساعت کارکرد</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-950/60">
              {filteredTechnicians.map((name, idx) => {
                const spec = TECHNICIAN_SPECIALTIES[name] || { role: 'تکنسین فنی', code: `TC-10${idx + 1}` };
                const stats = getTechnicianWorkStats(name);
                return (
                  <tr key={idx} className="hover:bg-[#112042]/50">
                    <td className="p-3 font-bold text-white">{name}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-1.5 font-mono text-cyan-400">
                        <span>{technicianCodes[name] || spec.code}</span>
                        <button
                          type="button"
                          onClick={(e) => handleStartEditCode(name, technicianCodes[name] || spec.code, e)}
                          title="تغییر کد پرسنلی"
                          className="w-2.5 h-2.5 rounded-full bg-cyan-500/30 hover:bg-cyan-400 border border-cyan-400/60 transition-all cursor-pointer flex items-center justify-center"
                        />
                      </div>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-cyan-300">{toFaDigits(stats.workRequests.length)}</td>
                    <td className="p-3 text-center font-mono font-bold text-blue-300">{toFaDigits(stats.techServices.length)}</td>
                    <td className="p-3 text-center font-mono font-bold text-purple-300">{toFaDigits(stats.pmTasks.length)}</td>
                    <td className="p-3 text-center font-mono font-bold text-white">{toFaDigits(stats.allTasksCount)}</td>
                    <td className="p-3 text-center font-mono text-amber-300">{formatTotalTime(stats.totalMinutes)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ۴. نمودار حرفه‌ای تفکیک کارها در پایین صفحه (مورد اول: تفکیک ۳ گانه ساعت کارکرد نیز پیاده‌سازی شد) */}
      <div className="rounded-2xl border border-indigo-500/20 bg-[#081024]/95 p-4 sm:p-5 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-indigo-900/40">
          <div className="flex items-center gap-2">
            <BarChart3 size={16} className="text-cyan-400" />
            <h3 className="font-bold text-sm text-white">
              نمودار مقایسه‌ای تفکیک کارها به ازای تکنسین‌ها
            </h3>
          </div>

          {/* سوئیچ مقایسه: تعداد کارها به تفکیک ۳ بخش vs ساعات کارکرد به تفکیک ۳ بخش (مورد اول کاربر) */}
          <div className="flex items-center gap-1 bg-[#0b162f] p-1 rounded-xl border border-blue-900/40 text-xs">
            <button
              type="button"
              onClick={() => setChartMetric('byCategory')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                chartMetric === 'byCategory'
                  ? 'bg-gradient-to-r from-cyan-600 to-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              تفکیک ۳ گانه تعداد کارها
            </button>
            <button
              type="button"
              onClick={() => setChartMetric('byHours')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                chartMetric === 'byHours'
                  ? 'bg-gradient-to-r from-cyan-600 to-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              تفکیک ۳ گانه ساعت کارکرد
            </button>
          </div>
        </div>

        {/* راهنمای رنگی ۳ گانه */}
        <div className="flex items-center justify-end gap-4 text-xs pt-0.5">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-cyan-400" />
            <span className="text-slate-300 font-medium">
              {chartMetric === 'byCategory' ? 'درخواست کارها' : 'ساعت درخواست کارها'}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-blue-500" />
            <span className="text-slate-300 font-medium">
              {chartMetric === 'byCategory' ? 'خدمات فنی' : 'ساعت خدمات فنی'}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-purple-400" />
            <span className="text-slate-300 font-medium">
              {chartMetric === 'byCategory' ? 'پیشگیرانه (PM)' : 'ساعت پیشگیرانه'}
            </span>
          </div>
        </div>

        {/* بستر نمودار SVG */}
        <div className="h-60 sm:h-64 w-full pt-1">
          <svg viewBox="0 0 840 240" className="w-full h-full select-none" preserveAspectRatio="none">
            <defs>
              <linearGradient id="barWR" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#0891b2" />
              </linearGradient>
              <linearGradient id="barTS" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#60a5fa" />
                <stop offset="100%" stopColor="#2563eb" />
              </linearGradient>
              <linearGradient id="barPM" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#c084fc" />
                <stop offset="100%" stopColor="#7e22ce" />
              </linearGradient>
            </defs>

            {/* خطوط شبکه */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
              const y = 185 - ratio * 155;
              const val = Math.round(ratio * maxChartValue);
              return (
                <g key={i}>
                  <line x1="45" y1={y} x2="825" y2={y} stroke="#1e293b" strokeDasharray={i === 0 ? 'none' : '3 3'} strokeWidth="1" />
                  <text x="35" y={y + 4} textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                    {toFaDigits(val)}
                  </text>
                </g>
              );
            })}

            <line x1="45" y1="185" x2="825" y2="185" stroke="#334155" strokeWidth="1.5" />

            {/* میله‌های ۳ گانه برای هر یک از ۷ تکنسین (مورد اول کاربر) */}
            {chartData.map((tech, i) => {
              const startX = 60 + i * 110;
              const val1 = chartMetric === 'byCategory' ? tech.wrCount : tech.wrHours;
              const val2 = chartMetric === 'byCategory' ? tech.tsCount : tech.tsHours;
              const val3 = chartMetric === 'byCategory' ? tech.pmCount : tech.pmHours;

              const h1 = maxChartValue > 0 ? (val1 / maxChartValue) * 155 : 0;
              const h2 = maxChartValue > 0 ? (val2 / maxChartValue) * 155 : 0;
              const h3 = maxChartValue > 0 ? (val3 / maxChartValue) * 155 : 0;
              const barWidth = 18;

              return (
                <g key={i}>
                  {/* ۱. درخواست کار */}
                  <rect x={startX} y={185 - h1} width={barWidth} height={Math.max(h1, 3)} rx="3" fill="url(#barWR)" />
                  {h1 > 8 && (
                    <text x={startX + barWidth / 2} y={185 - h1 - 4} textAnchor="middle" fill="#22d3ee" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      {toFaDigits(val1)}
                    </text>
                  )}

                  {/* ۲. خدمات فنی */}
                  <rect x={startX + barWidth + 4} y={185 - h2} width={barWidth} height={Math.max(h2, 3)} rx="3" fill="url(#barTS)" />
                  {h2 > 8 && (
                    <text x={startX + barWidth + 4 + barWidth / 2} y={185 - h2 - 4} textAnchor="middle" fill="#60a5fa" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      {toFaDigits(val2)}
                    </text>
                  )}

                  {/* ۳. پیشگیرانه */}
                  <rect x={startX + (barWidth + 4) * 2} y={185 - h3} width={barWidth} height={Math.max(h3, 3)} rx="3" fill="url(#barPM)" />
                  {h3 > 8 && (
                    <text x={startX + (barWidth + 4) * 2 + barWidth / 2} y={185 - h3 - 4} textAnchor="middle" fill="#c084fc" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      {toFaDigits(val3)}
                    </text>
                  )}

                  {/* برچسب نام */}
                  <text x={startX + 31} y="206" textAnchor="middle" fill="#e2e8f0" fontSize="11" fontWeight="bold">
                    {tech.name}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* ۵. مودال ثبت خاتمه فعالیت */}
      {isLogActionModalOpen && selectedTaskForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#0b152d] border border-indigo-500/30 rounded-2xl max-w-md w-full p-4 space-y-3 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40">
              <h3 className="font-bold text-white text-sm">ثبت خاتمه و فعالیت ({selectedTaskForAction.code || selectedTaskForAction.id})</h3>
              <button
                type="button"
                onClick={() => setIsLogActionModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X size={15} />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-[#070e22] border border-indigo-900/40 space-y-0.5">
                <div className="font-bold text-white">{selectedTaskForAction.equipmentName || selectedTaskForAction.place}</div>
                <div className="text-slate-300">{selectedTaskForAction.failureTitle || selectedTaskForAction.title}</div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">وضعیت</label>
                <select
                  value={actionFormData.status}
                  onChange={e => setActionFormData({ ...actionFormData, status: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-emerald-400 font-bold outline-none"
                >
                  <option value="انجام شد">انجام شد</option>
                  <option value="در حال اقدام">در حال اقدام</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">مدت زمان صرف‌شده (دقیقه)</label>
                <input
                  type="number"
                  value={actionFormData.durationMinutes}
                  onChange={e => setActionFormData({ ...actionFormData, durationMinutes: Number(e.target.value) || 0 })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-amber-300 font-mono font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">نفر کمکی / تکنسین همکار (کار تیمی دو نفره)</label>
                <select
                  value={actionFormData.coTechnician}
                  onChange={e => setActionFormData({ ...actionFormData, coTechnician: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-cyan-300 font-bold outline-none"
                >
                  <option value="">انفرادی (بدون تکنسین همکار)</option>
                  {technicians.map(t => (
                    <option key={t} value={t}>🤝 همکار: {t}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">شرح اقدامات فنی تکنسین</label>
                <textarea
                  rows={2}
                  value={actionFormData.actionDetails}
                  placeholder="شرح مختصری از کار انجام‌شده..."
                  onChange={e => setActionFormData({ ...actionFormData, actionDetails: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white outline-none resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsLogActionModalOpen(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveAction}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md"
              >
                ثبت فعالیت
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ۶. مودال پیش‌نمایش چاپ رسمی با لوگوی سامانه و نمودار کامل (مورد سوم کاربر) */}
      {isPrintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white text-slate-900 rounded-2xl max-w-4xl w-full p-6 space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
            
            {/* بدنه گزارش قابل چاپ */}
            <div id="cmms-printable-report" className="space-y-4 bg-white text-slate-900 p-2">
              {/* هدر با لوگوی رسمی سامانه
              <div className="flex justify-between items-center pb-3 border-b-2 border-slate-900">
                <div className="flex items-center gap-3">
                  <img
                    src={COMPANY_LOGO_WHITEBG}
                    alt="لوگو سامانه"
                    className="h-14 w-auto object-contain"
                  />
                  <div>
                    <h2 className="text-base font-black text-slate-950">
                      {printSettings.workforceAllReport.docTitle}
                    </h2>
                    <div className="text-xs text-slate-600">
                      تفکیک ۳ گانه: درخواست کارها | خدمات فنی | پیشگیرانه (PM)
                    </div>
                  </div>
                </div>
                <div className="text-left font-mono text-xs text-slate-700 space-y-0.5">
                  <div>کد سند: <span className="font-bold">{printSettings.workforceAllReport.docCode}</span></div>
                  <div>تاریخ: <span>{new Date().toLocaleDateString('fa-IR')}</span></div>
                  <div>واحد: <span>نگهداری و خدمات فنی</span></div>
                </div>
              </div>

              {/* جدول رسمی بدون ستون تخصص (مورد سوم: تخصص داخل گزارش حذف بشه) */}
              <table className="w-full text-right text-xs border-collapse border border-slate-400">
                <thead>
                  <tr className="bg-slate-100 text-slate-900 border-b border-slate-400 font-bold">
                    <th className="p-2 border border-slate-400 text-center">ردیف</th>
                    <th className="p-2 border border-slate-400">نام و نام خانوادگی</th>
                    <th className="p-2 border border-slate-400 text-center">کد پرسنلی</th>
                    <th className="p-2 border border-slate-400 text-center bg-cyan-50 text-cyan-950">درخواست کارها</th>
                    <th className="p-2 border border-slate-400 text-center bg-blue-50 text-blue-950">خدمات فنی</th>
                    <th className="p-2 border border-slate-400 text-center bg-purple-50 text-purple-950">پیشگیرانه (PM)</th>
                    <th className="p-2 border border-slate-400 text-center font-bold">مجموع کارها</th>
                    <th className="p-2 border border-slate-400 text-center">ساعت کارکرد</th>
                  </tr>
                </thead>
                <tbody>
                  {technicians.map((name, i) => {
                    const stats = getTechnicianWorkStats(name);
                    const code = technicianCodes[name] || TECHNICIAN_SPECIALTIES[name]?.code || `TC-10${i + 1}`;
                    return (
                      <tr key={i} className="border-b border-slate-300">
                        <td className="p-2 border border-slate-300 text-center font-mono">{toFaDigits(i + 1)}</td>
                        <td className="p-2 border border-slate-300 font-bold">{name}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono">{code}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono font-bold text-cyan-800">{toFaDigits(stats.workRequests.length)}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono font-bold text-blue-800">{toFaDigits(stats.techServices.length)}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono font-bold text-purple-800">{toFaDigits(stats.pmTasks.length)}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono font-bold">{toFaDigits(stats.allTasksCount)}</td>
                        <td className="p-2 border border-slate-300 text-center font-mono">{formatTotalTime(stats.totalMinutes)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {/* نمودار چاپی روی گزارش (مورد سوم: نمودار هم روی گزارش بیاد) */}
              <div className="pt-2 border-t border-slate-300">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-xs font-bold text-slate-900">
                    نمودار تفکیک کارها به ازای تکنسین‌ها (درخواست کارها / خدمات فنی / پیشگیرانه):
                  </div>
                  <div className="flex items-center gap-3 text-[10px]">
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded bg-cyan-600 inline-block" /> درخواست کار
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded bg-blue-600 inline-block" /> خدمات فنی
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded bg-purple-600 inline-block" /> پیشگیرانه (PM)
                    </span>
                  </div>
                </div>

                <div className="h-44 w-full bg-slate-50 border border-slate-300 rounded-lg p-2">
                  <svg viewBox="0 0 840 180" className="w-full h-full" preserveAspectRatio="none">
                    {[0, 0.5, 1].map((ratio, idx) => {
                      const y = 140 - ratio * 120;
                      const val = Math.round(ratio * maxChartValue);
                      return (
                        <g key={idx}>
                          <line x1="45" y1={y} x2="825" y2={y} stroke="#cbd5e1" strokeDasharray="2 2" strokeWidth="1" />
                          <text x="35" y={y + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                            {toFaDigits(val)}
                          </text>
                        </g>
                      );
                    })}
                    <line x1="45" y1="140" x2="825" y2="140" stroke="#475569" strokeWidth="1.5" />

                    {chartData.map((tech, i) => {
                      const startX = 60 + i * 110;
                      const h1 = maxChartValue > 0 ? (tech.wrCount / maxChartValue) * 120 : 0;
                      const h2 = maxChartValue > 0 ? (tech.tsCount / maxChartValue) * 120 : 0;
                      const h3 = maxChartValue > 0 ? (tech.pmCount / maxChartValue) * 120 : 0;
                      const barWidth = 16;

                      return (
                        <g key={i}>
                          <rect x={startX} y={140 - h1} width={barWidth} height={Math.max(h1, 2)} fill="#0891b2" />
                          <rect x={startX + barWidth + 3} y={140 - h2} width={barWidth} height={Math.max(h2, 2)} fill="#2563eb" />
                          <rect x={startX + (barWidth + 3) * 2} y={140 - h3} width={barWidth} height={Math.max(h3, 2)} fill="#7e22ce" />
                          <text x={startX + 27} y="158" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="bold">
                            {tech.name}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </div>

              {/* امضاها (امضای مدیر کارخانه طبق دستور کاربر حذف شد و فقط سرپرست نگهداری باقی ماند) */}
              <div className="pt-6 text-center text-xs text-slate-800 font-bold border-t border-slate-200">
                <div className="inline-block px-12 py-3 bg-slate-50 border border-slate-300 rounded-xl">
                  <div>سرپرست نگهداری و خدمات فنی</div>
                  <div className="mt-8 text-slate-400 font-normal">محل امضا و تایید گزارش</div>
                </div>
              </div>
            </div>

            {/* دکمه‌های پرینت و بستن */}
            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 hover:bg-slate-300 text-xs font-bold cursor-pointer"
              >
                بستن
              </button>
              <button
                type="button"
                onClick={handleExecutePrint}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold cursor-pointer shadow-md"
              >
                <Printer size={14} />
                <span>ارسال مستقیم به چاپگر (Print)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ۷. مودال چاپ کارنامه تک‌نفره هر تکنسین (لوگو رسمی + تفکیک کامل EM-CM-PM + نمودار اختصاصی فرد) */}
      {individualPrintTech && (() => {
        const techName = individualPrintTech;
        const spec = TECHNICIAN_SPECIALTIES[techName];
        const stats = getTechnicianWorkStats(techName);
        const maxIndVal = Math.max(stats.emRequests.length, stats.cmRequests.length, stats.pmRequests.length, stats.techServices.length, stats.pmTasks.length, 3);
        const chartScale = Math.ceil(maxIndVal * 1.3);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
            <div className="bg-white text-slate-900 rounded-2xl max-w-4xl w-full p-6 space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
              
              {/* بدنه گزارش اختصاصی تکنسین */}
              <div id="cmms-tech-individual-print" className="space-y-4 bg-white text-slate-900 p-2">
                {/* هدر رسمی با لوگوی سامانه  */}
                <div className="flex justify-between items-center pb-3 border-b-2 border-slate-900">
                  <div className="flex items-center gap-3">
                    <img
                      src={COMPANY_LOGO_WHITEBG}
                      alt="لوگو سامانه"
                      className="h-14 w-auto object-contain"
                    />
                    <div>
                      <h2 className="text-base font-black text-slate-950">
                        {printSettings.workforceIndividualReport.docTitle}: {techName}
                      </h2>
                      <div className="text-xs text-slate-600">
                        کد پرسنلی: <span className="font-mono font-bold text-slate-800">{technicianCodes[techName] || spec?.code}</span> | گرایش: {spec?.role}
                      </div>
                    </div>
                  </div>
                  <div className="text-left font-mono text-xs text-slate-700 space-y-0.5">
                    <div>کد سند: <span className="font-bold">{printSettings.workforceIndividualReport.docCode}</span></div>
                    <div>تاریخ: <span>{new Date().toLocaleDateString('fa-IR')}</span></div>
                    <div>واحد: <span>نگهداری و خدمات فنی</span></div>
                  </div>
                </div>

                {/* کارت‌های خلاصه آماری تفکیکی تکنسین */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
                  <div className="p-2.5 rounded-lg border border-red-300 bg-red-50/70">
                    <div className="text-[11px] text-red-900 font-bold">درخواست کار اضطراری (EM)</div>
                    <div className="text-lg font-black text-red-700 font-mono mt-0.5">{toFaDigits(stats.emRequests.length)} مورد</div>
                    <div className="text-[10px] text-red-800 font-mono">{toFaDigits(stats.emHours)} ساعت</div>
                  </div>
                  <div className="p-2.5 rounded-lg border border-amber-300 bg-amber-50/70">
                    <div className="text-[11px] text-amber-900 font-bold">درخواست کار اصلاحی (CM)</div>
                    <div className="text-lg font-black text-amber-700 font-mono mt-0.5">{toFaDigits(stats.cmRequests.length)} مورد</div>
                    <div className="text-[10px] text-amber-800 font-mono">{toFaDigits(stats.cmHours)} ساعت</div>
                  </div>
                  <div className="p-2.5 rounded-lg border border-teal-300 bg-teal-50/70">
                    <div className="text-[11px] text-teal-900 font-bold">درخواست کار پیشگیرانه (PM)</div>
                    <div className="text-lg font-black text-teal-700 font-mono mt-0.5">{toFaDigits(stats.pmRequests.length)} مورد</div>
                    <div className="text-[10px] text-teal-800 font-mono">{toFaDigits(stats.pmReqHours)} ساعت</div>
                  </div>
                  <div className="p-2.5 rounded-lg border border-blue-300 bg-blue-50/70">
                    <div className="text-[11px] text-blue-900 font-bold">خدمات فنی و تاسیسات</div>
                    <div className="text-lg font-black text-blue-700 font-mono mt-0.5">{toFaDigits(stats.techServices.length)} مورد</div>
                    <div className="text-[10px] text-blue-800 font-mono">{toFaDigits(stats.tsHours)} ساعت</div>
                  </div>
                </div>

                {/* نمودار گرافیکی شیک تک‌نفره برای تکنسین */}
                <div className="pt-2 border-t border-slate-300">
                  <div className="flex items-center justify-between mb-1.5 text-xs font-bold text-slate-900">
                    <span>نمودار میله‌ای تفکیک وظایف و اقدامات ثبت‌شده برای {techName}:</span>
                    <span className="text-[10px] text-slate-500 font-normal">کل ساعات کارکرد: {formatTotalTime(stats.totalMinutes)}</span>
                  </div>

                  <div className="h-44 w-full bg-slate-50 border border-slate-300 rounded-lg p-3">
                    <svg viewBox="0 0 700 160" className="w-full h-full" preserveAspectRatio="none">
                      {[0, 0.5, 1].map((ratio, idx) => {
                        const y = 125 - ratio * 100;
                        const val = Math.round(ratio * chartScale);
                        return (
                          <g key={idx}>
                            <line x1="40" y1={y} x2="680" y2={y} stroke="#cbd5e1" strokeDasharray="2 2" strokeWidth="1" />
                            <text x="32" y={y + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                              {toFaDigits(val)}
                            </text>
                          </g>
                        );
                      })}
                      <line x1="40" y1="125" x2="680" y2="125" stroke="#475569" strokeWidth="1.5" />

                      {[
                        { label: 'اضطراری (EM)', count: stats.emRequests.length, color: '#dc2626', x: 80 },
                        { label: 'اصلاحی (CM)', count: stats.cmRequests.length, color: '#d97706', x: 200 },
                        { label: 'پیشگیرانه درخواست (PM)', count: stats.pmRequests.length, color: '#0d9488', x: 330 },
                        { label: 'خدمات فنی', count: stats.techServices.length, color: '#2563eb', x: 470 },
                        { label: 'چک‌لیست PM دوره‌ای', count: stats.pmTasks.length, color: '#7c3aed', x: 590 }
                      ].map((bar, bIdx) => {
                        const h = chartScale > 0 ? (bar.count / chartScale) * 100 : 0;
                        const barW = 32;
                        return (
                          <g key={bIdx}>
                            <rect x={bar.x} y={125 - h} width={barW} height={Math.max(h, 3)} rx="2" fill={bar.color} />
                            <text x={bar.x + barW / 2} y={125 - h - 4} textAnchor="middle" fill={bar.color} fontSize="10" fontWeight="bold" fontFamily="monospace">
                              {toFaDigits(bar.count)}
                            </text>
                            <text x={bar.x + barW / 2} y="142" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="bold">
                              {bar.label}
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                  </div>
                </div>

                {/* جدول ریز درخواست کارهای این تکنسین به تفکیک EM-CM-PM */}
                <div className="space-y-1.5 pt-2">
                  <div className="text-xs font-bold text-slate-900">
                    ریز آخرین درخواست کارهای ثبت‌شده به تفکیک نوع اقدام:
                  </div>
                  <table className="w-full text-right text-xs border-collapse border border-slate-300">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                        <th className="p-1.5 border border-slate-300 text-center">ردیف</th>
                        <th className="p-1.5 border border-slate-300 text-center">کد درخواست</th>
                        <th className="p-1.5 border border-slate-300 text-center">نوع درخواست کار</th>
                        <th className="p-1.5 border border-slate-300">تجهیز</th>
                        <th className="p-1.5 border border-slate-300">شرح عیب</th>
                        <th className="p-1.5 border border-slate-300 text-center">اولویت</th>
                        <th className="p-1.5 border border-slate-300 text-center">وضعیت</th>
                      </tr>
                    </thead>
                    <tbody>
                      {stats.workRequests.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-3 text-center text-slate-400">درخواست کاری برای این تکنسین ثبت نشده است.</td>
                        </tr>
                      ) : (
                        stats.workRequests.map((req, rIdx) => {
                          const reqType = req.requestType === 'اصلاحی' ? 'اصلاحی (CM)' : (req.requestType === 'پیشگیرانه' ? 'پیشگیرانه (PM)' : 'اضطراری (EM)');
                          return (
                            <tr key={rIdx} className="border-b border-slate-200">
                              <td className="p-1.5 border border-slate-200 text-center font-mono">{toFaDigits(rIdx + 1)}</td>
                              <td className="p-1.5 border border-slate-200 text-center font-mono font-bold text-blue-800">{req.code || req.id}</td>
                              <td className="p-1.5 border border-slate-200 text-center font-bold">
                                <span className={req.requestType === 'اصلاحی' ? 'text-amber-700' : (req.requestType === 'پیشگیرانه' ? 'text-teal-700' : 'text-red-700')}>
                                  {reqType}
                                </span>
                              </td>
                              <td className="p-1.5 border border-slate-200 font-medium">{req.equipmentName}</td>
                              <td className="p-1.5 border border-slate-200 text-slate-700">{req.failureTitle || req.title}</td>
                              <td className="p-1.5 border border-slate-200 text-center">{req.priority || 'عادی'}</td>
                              <td className="p-1.5 border border-slate-200 text-center">{req.status || 'در حال اقدام'}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {/* امضای تکنسین و سرپرست (بدون امضای مدیر کارخانه) */}
                <div className="grid grid-cols-2 pt-6 text-center text-xs text-slate-800 font-bold border-t border-slate-300">
                  <div>
                    <div>تکنسین مربوطه: {techName}</div>
                    <div className="mt-8 text-slate-400 font-normal">امضا و تایید تکنسین</div>
                  </div>
                  <div>
                    <div>سرپرست نگهداری و خدمات فنی</div>
                    <div className="mt-8 text-slate-400 font-normal">امضا و تایید سرپرست</div>
                  </div>
                </div>
              </div>

              {/* دکمه‌های پرینت و بستن */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIndividualPrintTech(null)}
                  className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 hover:bg-slate-300 text-xs font-bold cursor-pointer"
                >
                  بستن
                </button>
                <button
                  type="button"
                  onClick={handleExecuteIndividualPrint}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold cursor-pointer shadow-md"
                >
                  <Printer size={14} />
                  <span>ارسال مستقیم به چاپگر (Print)</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* مودال تحلیل هوش مصنوعی عملکرد تکنسین */}
      {aiModalTech && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="w-full max-w-3xl bg-[#0c162e] border-2 border-indigo-500/50 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-indigo-500/30 flex items-center justify-between bg-[#070e22]/90">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center shadow-md shrink-0">
                  <Bot size={20} />
                </div>
                <div>
                  <h4 className="text-sm sm:text-base font-black text-white">
                    تحلیل هوش مصنوعی عملکرد تکنسین: {aiModalTech}
                  </h4>
                  <p className="text-[11px] text-blue-200/80 mt-0.5">
                    ارزیابی سرعت اقدام، تخصص برتر، استقلال/تیم‌سازی و نرخ تموم‌کنندگی
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleRunTechnicianAiAnalysis(aiModalTech)}
                  disabled={aiLoading}
                  className="px-2.5 py-1.5 rounded-xl bg-indigo-900/60 hover:bg-indigo-800/70 border border-indigo-400/40 text-indigo-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw size={13} className={aiLoading ? 'animate-spin' : ''} />
                  <span>تحلیل مجدد</span>
                </button>
                {aiResults[aiModalTech]?.analysisText && (
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(aiResults[aiModalTech].analysisText);
                      setAiCopied(true);
                      setTimeout(() => setAiCopied(false), 2000);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-400/40 text-cyan-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {aiCopied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    <span>{aiCopied ? 'کپی شد' : 'کپی متن'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setAiModalTech(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              {aiLoading ? (
                <div className="py-10 flex flex-col items-center justify-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-500 animate-spin flex items-center justify-center shadow-lg">
                    <Sparkles size={22} className="text-white" />
                  </div>
                  <p className="text-xs font-bold text-cyan-200 animate-pulse">
                    در حال پردازش و تحلیل سوابق کاری {aiModalTech}...
                  </p>
                </div>
              ) : aiResults[aiModalTech] ? (() => {
                const res = aiResults[aiModalTech];
                return (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 text-xs">
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                        <span className="text-[10px] text-blue-300 block">سهم از کل کارها:</span>
                        <div className="text-lg font-black font-mono text-cyan-300">{toFaDigits(res.shareOfPlantPercent)}٪</div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                        <span className="text-[10px] text-blue-300 block">سرعت و ریتم:</span>
                        <div className="font-bold text-emerald-300 truncate">{res.speedLabel}</div>
                        <span className="text-[10px] text-blue-300/70 font-mono">میانگین {toFaDigits(res.avgMinutes)} دقیقه</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                        <span className="text-[10px] text-blue-300 block">گرایش تخصصی برتر:</span>
                        <div className="font-bold text-amber-300 truncate">{res.topSpecialty}</div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                        <span className="text-[10px] text-blue-300 block">سبک اجرا:</span>
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-cyan-300 font-bold">{toFaDigits(res.soloPercent)}٪ تکی</span>
                          <span className="text-purple-300">{toFaDigits(res.teamPercent)}٪ تیمی</span>
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1 col-span-2 sm:col-span-1">
                        <span className="text-[10px] text-blue-300 block">تموم‌کنندگی فردی:</span>
                        <div className="text-lg font-black font-mono text-emerald-400">{toFaDigits(res.completionRate)}٪</div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950/90 border border-indigo-500/40 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40 text-xs">
                        <span className="font-bold text-indigo-300 flex items-center gap-1.5">
                          <Sparkles size={14} className="text-amber-300" />
                          <span>جمع‌بندی هوشمند عملکرد:</span>
                        </span>
                        <div className="flex items-center gap-1 text-amber-300 font-bold">
                          <Star size={13} fill="currentColor" />
                          <span>{res.starRatingLabel}</span>
                        </div>
                      </div>
                      <div className="text-xs text-slate-200 leading-7 whitespace-pre-line">
                        {res.analysisText}
                      </div>
                    </div>
                  </div>
                );
              })() : null}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
