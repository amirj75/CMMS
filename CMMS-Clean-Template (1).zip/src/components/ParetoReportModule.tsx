import React, { useState, useMemo, useEffect } from 'react';
import {
  TrendingUp,
  BarChart3,
  Calendar,
  Download,
  Printer,
  Plus,
  Trash2,
  X,
  Check,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { OSVEH_LOGO_WHITEBG_URL } from '../data/auditImages';
import { BRAND_CONFIG } from '../data/brandConfig';
import defaultPlantEquipment from '../data/plantEquipment.json';
import defaultAssetFamilies from '../data/assetFamilies.json';
import defaultFactoryLocations from '../data/factoryLocations.json';
import {
  computeMinutesBetweenShamsiDateTimes,
  extractShamsiDateAndTime,
  parseJalaliExactDays,
  toEnDigits
} from '../data/dateTimeUtils';
import { usePrintSettings } from '../data/printSettings';

// ۵ تب پارتو برگرفته از تصاویر PMWorks
export type ParetoSubTab =
  | 'eqFailure'        // پارتو خرابی تجهیز
  | 'locDowntime'     // زمان خرابی تجهیزات برای مکان
  | 'eqDowntime'      // پارتو زمان توقف تجهیز
  | 'famFailure'      // پارتو خرابی خانواده تجهیز
  | 'locFailure';     // تعداد خرابی تجهیزات برای مکان

export interface EqFailureRow {
  id: string;
  eqCode: string;
  eqName: string;
  familyPath: string;
  locPath: string;
  emCount: number;
  pmCount: number;
  cmCount: number;
  totalCount: number;
  isLive?: boolean;
}

export interface LocDowntimeRow {
  id: string;
  locCode: string;
  locName: string;
  locPathCode: string;
  locPathName: string;
  downtimeHours: string;
  downtimeMinutes: number;
  isLive?: boolean;
}

export interface EqDowntimeRow {
  id: string;
  eqCode: string;
  eqName: string;
  locPath: string;
  downtimeHours: string;
  downtimeMinutes: number;
  isLive?: boolean;
}

export interface FamFailureRow {
  id: string;
  famCode: string;
  famName: string;
  groupName: string;
  emCount: number;
  pmCount: number;
  cmCount: number;
  totalCount: number;
  isLive?: boolean;
}

export interface LocFailureRow {
  id: string;
  locCode: string;
  locName: string;
  locPathCode: string;
  locPathName: string;
  emCount: number;
  pmCount: number;
  cmCount: number;
  totalCount: number;
  isLive?: boolean;
}

interface ParetoDataState {
  eqFailure: EqFailureRow[];
  locDowntime: LocDowntimeRow[];
  eqDowntime: EqDowntimeRow[];
  famFailure: FamFailureRow[];
  locFailure: LocFailureRow[];
}

export interface ParetoReportModuleProps {
  requestsList?: any[];
}

const STORAGE_KEY = 'cmms_factory_pareto_reports_v2';

const compactFaText = (val: unknown): string =>
  toEnDigits(String(val ?? ''))
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u200c\u200f\s_\-()]+/g, '')
    .toLowerCase();

const getTodayShamsiDate = (): string => {
  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    const parts = formatter.formatToParts(new Date());
    const y = parts.find(p => p.type === 'year')?.value || '1405';
    const m = parts.find(p => p.type === 'month')?.value || '08';
    const d = parts.find(p => p.type === 'day')?.value || '23';
    return `${y}/${m}/${d}`;
  } catch {
    return '1405/08/23';
  }
};

const getDefaultEndShamsiDate = (): string => {
  const today = getTodayShamsiDate();
  const year = today.split('/')[0] || '1405';
  return `${year}/12/29`;
};

const formatMinutesToHHMM = (totalMinutes: number): string => {
  const mins = Math.max(0, Math.round(totalMinutes || 0));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}:${m < 10 ? `0${m}` : m}`;
};

export const ParetoReportModule: React.FC<ParetoReportModuleProps> = ({ requestsList = [] }) => {
  const [activeTab, setActiveTab] = useState<ParetoSubTab>('eqFailure');
  const printSettings = usePrintSettings();
  // نمودار زیر گزارش پارتو قرار دارد و قابل باز و بسته شدن است
  const [isChartOpen, setIsChartOpen] = useState(true);
  const [storageTick, setStorageTick] = useState(0);
  const [noticeMsg, setNoticeMsg] = useState<string | null>(null);

  // فیلترهای استاندارد
  const [filterEqCode, setFilterEqCode] = useState('');
  const [filterEqName, setFilterEqName] = useState('');
  const [filterPath, setFilterPath] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('1403/01/01');
  const [filterEndDate, setFilterEndDate] = useState(() => getDefaultEndShamsiDate());

  useEffect(() => {
    const bump = () => setStorageTick(t => t + 1);
    window.addEventListener('storage', bump);
    window.addEventListener('focus', bump);
    window.addEventListener('factory_equipments_updated', bump);
    window.addEventListener('factory_families_updated', bump);
    return () => {
      window.removeEventListener('storage', bump);
      window.removeEventListener('focus', bump);
      window.removeEventListener('factory_equipments_updated', bump);
      window.removeEventListener('factory_families_updated', bump);
    };
  }, []);

  // داده‌های خام دستی ۵ تب پارتو (در کنار داده‌های خودکار سیستم)
  const [data, setData] = useState<ParetoDataState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      eqFailure: [],
      locDowntime: [],
      eqDowntime: [],
      famFailure: [],
      locFailure: []
    };
  });

  const saveData = (newData: ParetoDataState) => {
    setData(newData);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    } catch {}
  };

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [modalForm, setModalForm] = useState<Record<string, string>>({});
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const tabs: Array<{ id: ParetoSubTab; label: string }> = [
    { id: 'eqFailure', label: 'پارتو خرابی تجهیز' },
    { id: 'locDowntime', label: 'زمان خرابی تجهیزات برای مکان' },
    { id: 'eqDowntime', label: 'پارتو زمان توقف تجهیز' },
    { id: 'famFailure', label: 'پارتو خرابی خانواده تجهیز' },
    { id: 'locFailure', label: 'تعداد خرابی تجهیزات برای مکان' }
  ];

  // استخراج خودکار و زنده خرابی‌ها و توقفات ثبت‌شده برای تجهیزات، خانواده‌های تجهیز و مکان‌ها
  const liveAggregated = useMemo<ParetoDataState>(() => {
    // ۱. بارگذاری کاتالوگ تجهیزات، خانواده‌ها و مکان‌ها
    const eqByCode = new Map<string, { id: string; name: string; family: string; location: string }>();
    const eqByName = new Map<string, { id: string; name: string; family: string; location: string }>();
    const loadEqList = (arr: any[]) => {
      arr.forEach((eq: any) => {
        if (!eq) return;
        const id = String(eq.id || eq.code || '').trim();
        const name = String(eq.name || eq.title || '').trim();
        const family = String(eq.family || eq.category || '').trim();
        const location = String(eq.location || eq.hall || eq.zone || '').trim();
        if (!id && !name) return;
        const rec = { id: id || name, name: name || id, family, location };
        if (id) eqByCode.set(id.toLowerCase(), rec);
        if (name) eqByName.set(compactFaText(name), rec);
      });
    };
    loadEqList(defaultPlantEquipment as any[]);
    try {
      const savedV13 = localStorage.getItem('pm_studio_equipments_v13');
      if (savedV13) {
        const parsed = JSON.parse(savedV13);
        if (Array.isArray(parsed)) loadEqList(parsed);
      }
    } catch {}
    try {
      const savedV9 = localStorage.getItem('portal_equipments_v9');
      if (savedV9) {
        const parsed = JSON.parse(savedV9);
        if (Array.isArray(parsed)) loadEqList(parsed);
      }
    } catch {}

    const familiesList: Array<{ id: string; name: string; group: string }> = [];
    const famByCode = new Map<string, { id: string; name: string; group: string }>();
    const famByCompactName = new Map<string, { id: string; name: string; group: string }>();
    const loadFamilies = (arr: any[]) => {
      arr.forEach((f: any) => {
        if (!f) return;
        const id = String(f.id || '').trim();
        const name = String(f.name || '').trim();
        const group = String(f.group || '').trim();
        if (!id && !name) return;
        const rec = { id: id || name, name: name || id, group: group || name };
        familiesList.push(rec);
        if (id) famByCode.set(id.toLowerCase(), rec);
        if (name) famByCompactName.set(compactFaText(name), rec);
      });
    };
    loadFamilies(defaultAssetFamilies as any[]);
    try {
      const savedFam = localStorage.getItem('pm_studio_families_v9');
      if (savedFam) {
        const parsed = JSON.parse(savedFam);
        if (Array.isArray(parsed)) loadFamilies(parsed);
      }
    } catch {}

    const sortedFamPrefixes = [...familiesList].sort((a, b) => b.id.length - a.id.length);

    const locList: Array<{ code: string; name: string }> = [];
    const loadLocations = (arr: any[]) => {
      arr.forEach((l: any) => {
        if (!l) return;
        const code = String(l.code || l.id || '').trim();
        const name = String(l.name || '').trim();
        if (code || name) locList.push({ code: code || name, name: name || code });
      });
    };
    loadLocations(defaultFactoryLocations as any[]);
    try {
      const savedLoc = localStorage.getItem('pm_studio_locations_v2');
      if (savedLoc) {
        const parsed = JSON.parse(savedLoc);
        if (Array.isArray(parsed)) loadLocations(parsed);
      }
    } catch {}

    // ۲. تجمیع و یکتاسازی کلیه رویدادهای خرابی و دستورکار تجهیزات (بدون ترکیب با تیکت‌های خدمات فنی/تأسیسات)
    const isEquipmentRelatedEvent = (item: any): boolean => {
      if (!item || typeof item !== 'object') return false;
      if (item._category === 'techService') return false;
      const src = String(item.source || item.originCategory || '').trim();
      if (src === 'techService') return false;
      const reqType = String(item.requestType || '').trim();
      if (reqType === 'خدمات فنی' || String(item.department || '').includes('خدمات فنی')) return false;

      if (src === 'workRequest' || item.fromWorkRequest === true || item._category === 'workRequest' || item._category === 'pm') {
        return true;
      }
      const idStr = String(item.id || '').trim();
      const codeStr = String(item.code || '').trim().toUpperCase();
      if (idStr.startsWith('pwr-') || codeStr.startsWith('PM-')) return true;
      if (['اضطراری', 'اصلاحی', 'پیشگیرانه', 'PM', 'EM', 'CM'].includes(reqType)) return true;
      if (
        item.equipmentCode ||
        item.eqCode ||
        item.equipmentName ||
        item.eqName ||
        item.equipment ||
        item.equipmentFamilyName ||
        (Array.isArray(item.selectedEquipments) && item.selectedEquipments.length > 0)
      ) {
        return true;
      }
      return false;
    };

    const eventMap = new Map<string, any>();
    const upsertEvent = (item: any, preferNewerRichness = false) => {
      if (!isEquipmentRelatedEvent(item)) return;
      const rawKey = String(item.code || item.id || '').trim().toUpperCase();
      if (!rawKey) return;
      if (!eventMap.has(rawKey)) {
        eventMap.set(rawKey, { ...item });
      } else {
        const prev = eventMap.get(rawKey);
        eventMap.set(rawKey, preferNewerRichness ? { ...prev, ...item } : { ...item, ...prev });
      }
    };

    try {
      const savedWr = localStorage.getItem('portal_pm_work_requests_v3');
      if (savedWr) {
        const parsed = JSON.parse(savedWr);
        if (Array.isArray(parsed)) parsed.forEach(item => upsertEvent({ ...item, _category: item._category || 'workRequest' }, false));
      }
    } catch {}
    if (Array.isArray(requestsList)) {
      requestsList.forEach(item => upsertEvent(item, false));
    }
    try {
      const savedTs = localStorage.getItem('technicalServiceWorkRequests');
      if (savedTs) {
        const parsed = JSON.parse(savedTs);
        if (Array.isArray(parsed)) parsed.forEach(item => upsertEvent(item, false));
      }
    } catch {}
    try {
      const savedPm = localStorage.getItem('pm_studio_work_orders_v15');
      if (savedPm) {
        const parsed = JSON.parse(savedPm);
        if (Array.isArray(parsed)) parsed.forEach(item => upsertEvent({ ...item, _category: item._category || 'pm' }, false));
      }
    } catch {}

    const dStart = parseJalaliExactDays(filterStartDate);
    const dEnd = parseJalaliExactDays(filterEndDate);

    const eqFailMap = new Map<string, EqFailureRow>();
    const famFailMap = new Map<string, FamFailureRow>();
    const eqDtMap = new Map<string, EqDowntimeRow>();
    const locFailMap = new Map<string, LocFailureRow>();
    const locDtMap = new Map<string, LocDowntimeRow>();

    const fallbackFamLabelByPrefix = (eqCodeUpper: string): { code: string; name: string } | null => {
      if (eqCodeUpper.startsWith('TUTN')) return { code: 'TUTN', name: 'تراش تورنوس' };
      if (eqCodeUpper.startsWith('TUCT')) return { code: 'TUCT', name: 'تراش تورنوس CT' };
      if (eqCodeUpper.startsWith('TULT')) return { code: 'TULT', name: 'تراش CNC' };
      if (eqCodeUpper.startsWith('TUMN')) return { code: 'TUMN', name: 'تراش دستی' };
      if (eqCodeUpper.startsWith('MICN')) return { code: 'MICN', name: 'فرزکاری CNC' };
      if (eqCodeUpper.startsWith('MIDR')) return { code: 'MIDR', name: 'دریل فرز' };
      if (eqCodeUpper.startsWith('TUMA')) return { code: 'TUMA', name: 'تراش مایر' };
      if (eqCodeUpper.startsWith('TUSY')) return { code: 'TUSY', name: 'تراش سینتک' };
      if (eqCodeUpper.startsWith('TUST')) return { code: 'TUST', name: 'تراش استار' };
      if (eqCodeUpper.startsWith('PR')) return { code: 'PR', name: 'پرس‌های هیدرولیک' };
      return null;
    };

    const getEventDowntimeMins = (r: any): number => {
      const explicitDt = Number(r?.equipmentDowntimeMinutes || r?.downtimeMinutes || 0);
      if (explicitDt > 0) return explicitDt;
      if (r?.woStartDate && r?.woEndDate && (r?.woStartTimeOnly || r?.woStartTime) && (r?.woEndTimeOnly || r?.woEndTime)) {
        const s = extractShamsiDateAndTime(`${r.woStartDate} ${r.woStartTimeOnly || r.woStartTime}`, r.woStartDate, '08:00');
        const e = extractShamsiDateAndTime(`${r.woEndDate} ${r.woEndTimeOnly || r.woEndTime}`, r.woEndDate, '09:00');
        const computed = computeMinutesBetweenShamsiDateTimes(s.date, s.time, e.date, e.time);
        if (computed > 0) return computed;
      } else if (r?.woStartTime && r?.woEndTime) {
        const s = extractShamsiDateAndTime(r.woStartTime, '', '');
        const e = extractShamsiDateAndTime(r.woEndTime, s.date, '');
        if (s.date && s.time && e.date && e.time) {
          const computed = computeMinutesBetweenShamsiDateTimes(s.date, s.time, e.date, e.time);
          if (computed > 0) return computed;
        }
      }
      const dur = Number(r?.durationMinutes || r?.durationMin || 0);
      return dur > 0 ? dur : 0;
    };

    eventMap.forEach((item: any) => {
      const statusNorm = String(item.status || '').trim();
      if (statusNorm === 'لغو' || statusNorm === 'لغو شده' || statusNorm === 'cancelled') {
        return;
      }

      // فیلتر بازه تاریخ شمسی
      const rawDateStr = toEnDigits(
        String(item.woStartDate || item.woStartTime || item.requestTime || item.created || item.date || item.woDate || item.createdDate || '')
      );
      const dReq = parseJalaliExactDays(rawDateStr);
      if (dReq !== null) {
        if (dStart !== null && dReq < dStart) return;
        if (dEnd !== null && dReq > dEnd) return;
      }

      // تشخیص نوع خرابی (EM / PM / CM)
      const reqType = String(item.requestType || '').trim();
      const codeUpper = String(item.code || item.id || '').trim().toUpperCase();
      const opType = String(item.operationType || item.opType || '').trim();
      let kind: 'EM' | 'PM' | 'CM' = 'EM';
      if (
        item.isPM === true ||
        item.pmGroupId ||
        item.pmPlanId ||
        item.isScheduledPM ||
        reqType.includes('پیشگیرانه') ||
        reqType.toUpperCase() === 'PM' ||
        codeUpper.startsWith('PM-') ||
        opType.includes('(PM)')
      ) {
        kind = 'PM';
      } else if (reqType.includes('اصلاحی') || reqType.toUpperCase() === 'CM' || opType.includes('(CM)')) {
        kind = 'CM';
      } else {
        kind = 'EM';
      }

      const rawEqCode = String(item.equipmentCode || item.eqCode || '').trim();
      const rawEqName = String(item.equipmentName || item.eqName || item.equipment || '').trim();
      const eqRec =
        (rawEqCode && eqByCode.get(rawEqCode.toLowerCase())) ||
        (rawEqName && eqByName.get(compactFaText(rawEqName))) ||
        undefined;

      const resolvedEqCode = rawEqCode || eqRec?.id || '';
      const resolvedEqName = rawEqName || eqRec?.name || resolvedEqCode;
      const resolvedLocPath = String(item.locationName || eqRec?.location || item.place || '').trim();

      // تطبیق خانواده تجهیز
      const rawFamCode = String(item.equipmentFamilyCode || '').trim();
      const rawFamName = String(item.equipmentFamilyName || eqRec?.family || '').trim();
      let matchedFam =
        (rawFamCode && famByCode.get(rawFamCode.toLowerCase())) ||
        (rawFamName && famByCompactName.get(compactFaText(rawFamName))) ||
        undefined;

      if (!matchedFam && resolvedEqCode) {
        const eqUpper = resolvedEqCode.toUpperCase();
        matchedFam = sortedFamPrefixes.find(f => f.id && eqUpper.startsWith(f.id.toUpperCase()));
      }

      const prefixFallback = !matchedFam && resolvedEqCode ? fallbackFamLabelByPrefix(resolvedEqCode.toUpperCase()) : null;
      const finalFamCode = rawFamCode || matchedFam?.id || prefixFallback?.code || (rawFamName ? rawFamName : '');
      const finalFamName = rawFamName || matchedFam?.name || prefixFallback?.name || '';
      const finalGroupName = matchedFam?.group || finalFamName || 'سایر تجهیزات';

      const downtimeMins = getEventDowntimeMins(item);

      // الف) افزودن به پارتو خرابی تجهیز و پارتو توقف تجهیز
      if (resolvedEqCode || resolvedEqName) {
        const eqKey = (resolvedEqCode || resolvedEqName).toLowerCase();
        const existingEq = eqFailMap.get(eqKey) || {
          id: `live-eq-${eqKey}`,
          eqCode: resolvedEqCode || '—',
          eqName: resolvedEqName || '—',
          familyPath: finalFamName || finalFamCode || '—',
          locPath: resolvedLocPath || '—',
          emCount: 0,
          pmCount: 0,
          cmCount: 0,
          totalCount: 0,
          isLive: true
        };
        if (kind === 'EM') existingEq.emCount += 1;
        else if (kind === 'PM') existingEq.pmCount += 1;
        else existingEq.cmCount += 1;
        existingEq.totalCount = existingEq.emCount + existingEq.pmCount + existingEq.cmCount;
        if (existingEq.familyPath === '—' && (finalFamName || finalFamCode)) {
          existingEq.familyPath = finalFamName || finalFamCode;
        }
        if (existingEq.locPath === '—' && resolvedLocPath) {
          existingEq.locPath = resolvedLocPath;
        }
        eqFailMap.set(eqKey, existingEq);

        if (downtimeMins > 0) {
          const existingDt = eqDtMap.get(eqKey) || {
            id: `live-eqdt-${eqKey}`,
            eqCode: resolvedEqCode || '—',
            eqName: resolvedEqName || '—',
            locPath: resolvedLocPath || '—',
            downtimeHours: '0:00',
            downtimeMinutes: 0,
            isLive: true
          };
          existingDt.downtimeMinutes += downtimeMins;
          existingDt.downtimeHours = formatMinutesToHHMM(existingDt.downtimeMinutes);
          eqDtMap.set(eqKey, existingDt);
        }
      }

      // ب) افزودن به پارتو خرابی خانواده تجهیز
      if (finalFamCode || finalFamName) {
        const famKey = compactFaText(finalFamCode || finalFamName) || (finalFamCode || finalFamName).toLowerCase();
        const existingFam = famFailMap.get(famKey) || {
          id: `live-fam-${famKey}`,
          famCode: finalFamCode || '—',
          famName: finalFamName || finalFamCode || '—',
          groupName: finalGroupName || '—',
          emCount: 0,
          pmCount: 0,
          cmCount: 0,
          totalCount: 0,
          isLive: true
        };
        if (kind === 'EM') existingFam.emCount += 1;
        else if (kind === 'PM') existingFam.pmCount += 1;
        else existingFam.cmCount += 1;
        existingFam.totalCount = existingFam.emCount + existingFam.pmCount + existingFam.cmCount;
        famFailMap.set(famKey, existingFam);
      }

      // ج) افزودن به پارتو خرابی و توقف مکان (فقط برای رویدادهای واقعی تجهیزات)
      const hasEquipmentIdentity = Boolean(
        resolvedEqCode ||
        resolvedEqName ||
        item.equipmentFamilyName ||
        (Array.isArray(item.selectedEquipments) && item.selectedEquipments.length > 0)
      );
      if (hasEquipmentIdentity && (resolvedLocPath || item.locationCode)) {
        const mainLocName = resolvedLocPath.split('_')[0].trim() || resolvedLocPath || 'نامشخص';
        const matchedLoc = locList.find(
          l =>
            (item.locationCode && l.code.toLowerCase() === String(item.locationCode).toLowerCase()) ||
            compactFaText(mainLocName) === compactFaText(l.name) ||
            resolvedLocPath.includes(l.name)
        );
        const locCode = String(item.locationCode || matchedLoc?.code || mainLocName).trim();
        const locName = matchedLoc?.name || mainLocName;
        const locKey = (locCode || locName).toLowerCase();

        const existingLocFail = locFailMap.get(locKey) || {
          id: `live-locf-${locKey}`,
          locCode,
          locName,
          locPathCode: locCode,
          locPathName: resolvedLocPath || locName,
          emCount: 0,
          pmCount: 0,
          cmCount: 0,
          totalCount: 0,
          isLive: true
        };
        if (kind === 'EM') existingLocFail.emCount += 1;
        else if (kind === 'PM') existingLocFail.pmCount += 1;
        else existingLocFail.cmCount += 1;
        existingLocFail.totalCount = existingLocFail.emCount + existingLocFail.pmCount + existingLocFail.cmCount;
        locFailMap.set(locKey, existingLocFail);

        if (downtimeMins > 0) {
          const existingLocDt = locDtMap.get(locKey) || {
            id: `live-locdt-${locKey}`,
            locCode,
            locName,
            locPathCode: locCode,
            locPathName: resolvedLocPath || locName,
            downtimeHours: '0:00',
            downtimeMinutes: 0,
            isLive: true
          };
          existingLocDt.downtimeMinutes += downtimeMins;
          existingLocDt.downtimeHours = formatMinutesToHHMM(existingLocDt.downtimeMinutes);
          locDtMap.set(locKey, existingLocDt);
        }
      }
    });

    return {
      eqFailure: Array.from(eqFailMap.values()),
      famFailure: Array.from(famFailMap.values()),
      eqDowntime: Array.from(eqDtMap.values()),
      locFailure: Array.from(locFailMap.values()),
      locDowntime: Array.from(locDtMap.values())
    };
  }, [requestsList, filterStartDate, filterEndDate, storageTick]);

  // ترکیب داده‌های زنده سیستم با سطرهای دستی + اعمال فیلترها + مرتب‌سازی پارتو
  const displayedData = useMemo<ParetoDataState>(() => {
    const qCode = filterEqCode.trim().toLowerCase();
    const qName = filterEqName.trim().toLowerCase();
    const qPath = filterPath.trim().toLowerCase();

    const eqFailure = [...liveAggregated.eqFailure, ...(data.eqFailure || [])]
      .filter(r => {
        if (qCode && !String(r.eqCode || '').toLowerCase().includes(qCode)) return false;
        if (qName && !String(r.eqName || '').toLowerCase().includes(qName)) return false;
        if (qPath && !String(r.familyPath || '').toLowerCase().includes(qPath) && !String(r.locPath || '').toLowerCase().includes(qPath)) return false;
        return true;
      })
      .sort((a, b) => (b.totalCount - a.totalCount) || (b.emCount - a.emCount));

    const famFailure = [...liveAggregated.famFailure, ...(data.famFailure || [])]
      .filter(r => {
        if (qCode && !String(r.famCode || '').toLowerCase().includes(qCode)) return false;
        if (qName && !String(r.famName || '').toLowerCase().includes(qName)) return false;
        if (qPath && !String(r.groupName || '').toLowerCase().includes(qPath)) return false;
        return true;
      })
      .sort((a, b) => (b.totalCount - a.totalCount) || (b.emCount - a.emCount));

    const eqDowntime = [...liveAggregated.eqDowntime, ...(data.eqDowntime || [])]
      .filter(r => {
        if (qCode && !String(r.eqCode || '').toLowerCase().includes(qCode)) return false;
        if (qName && !String(r.eqName || '').toLowerCase().includes(qName)) return false;
        if (qPath && !String(r.locPath || '').toLowerCase().includes(qPath)) return false;
        return true;
      })
      .sort((a, b) => (b.downtimeMinutes || parseTimeToMinutes(b.downtimeHours)) - (a.downtimeMinutes || parseTimeToMinutes(a.downtimeHours)));

    const locFailure = [...liveAggregated.locFailure, ...(data.locFailure || [])]
      .filter(r => {
        if (qCode && !String(r.locCode || '').toLowerCase().includes(qCode)) return false;
        if (qName && !String(r.locName || '').toLowerCase().includes(qName)) return false;
        if (qPath && !String(r.locPathName || '').toLowerCase().includes(qPath)) return false;
        return true;
      })
      .sort((a, b) => (b.totalCount - a.totalCount) || (b.emCount - a.emCount));

    const locDowntime = [...liveAggregated.locDowntime, ...(data.locDowntime || [])]
      .filter(r => {
        if (qCode && !String(r.locCode || '').toLowerCase().includes(qCode)) return false;
        if (qName && !String(r.locName || '').toLowerCase().includes(qName)) return false;
        if (qPath && !String(r.locPathName || '').toLowerCase().includes(qPath)) return false;
        return true;
      })
      .sort((a, b) => (b.downtimeMinutes || parseTimeToMinutes(b.downtimeHours)) - (a.downtimeMinutes || parseTimeToMinutes(a.downtimeHours)));

    return { eqFailure, famFailure, eqDowntime, locFailure, locDowntime };
  }, [liveAggregated, data, filterEqCode, filterEqName, filterPath]);

  // محاسبه داده‌های مرتب‌شده پارتو برای نمودار و جدول
  const parsedChartData = useMemo(() => {
    let items: Array<{ label: string; subLabel: string; value: number }> = [];

    if (activeTab === 'eqFailure') {
      items = (displayedData.eqFailure || []).map(r => ({
        label: r.eqCode || '—',
        subLabel: r.eqName || '',
        value: Number(r.totalCount) || Number(r.emCount) || 0
      }));
    } else if (activeTab === 'locDowntime') {
      items = (displayedData.locDowntime || []).map(r => ({
        label: r.locName || r.locCode || '—',
        subLabel: r.locCode || '',
        value: r.downtimeMinutes > 0 ? r.downtimeMinutes : parseTimeToMinutes(r.downtimeHours)
      }));
    } else if (activeTab === 'eqDowntime') {
      items = (displayedData.eqDowntime || []).map(r => ({
        label: r.eqCode || '—',
        subLabel: r.eqName || '',
        value: r.downtimeMinutes > 0 ? r.downtimeMinutes : parseTimeToMinutes(r.downtimeHours)
      }));
    } else if (activeTab === 'famFailure') {
      items = (displayedData.famFailure || []).map(r => ({
        label: r.famName || r.famCode || '—',
        subLabel: r.famCode || '',
        value: Number(r.totalCount) || Number(r.emCount) || 0
      }));
    } else if (activeTab === 'locFailure') {
      items = (displayedData.locFailure || []).map(r => ({
        label: r.locName || r.locCode || '—',
        subLabel: r.locCode || '',
        value: Number(r.totalCount) || Number(r.emCount) || 0
      }));
    }

    // مرتب‌سازی نزولی طبق قانون پارتو
    items.sort((a, b) => b.value - a.value);

    // محاسبه درصدهای تجمعی
    const totalSum = items.reduce((sum, item) => sum + item.value, 0);
    let runningSum = 0;
    const withCumulative = items.map(item => {
      runningSum += item.value;
      const cumPercent = totalSum > 0 ? Math.round((runningSum / totalSum) * 100) : 0;
      return {
        ...item,
        cumPercent
      };
    });

    return {
      items: withCumulative,
      totalSum,
      maxVal: items.length > 0 ? Math.max(...items.map(i => i.value), 1) : 1
    };
  }, [activeTab, displayedData]);

  function parseTimeToMinutes(timeStr: string): number {
    if (!timeStr) return 0;
    try {
      const parts = timeStr.split(':');
      if (parts.length >= 2) {
        const h = parseInt(parts[0], 10) || 0;
        const m = parseInt(parts[1], 10) || 0;
        return h * 60 + m;
      }
      return parseFloat(timeStr) || 0;
    } catch {
      return 0;
    }
  }

  // ثبت سطر جدید
  const handleSaveModal = () => {
    const id = Date.now().toString();
    const copy = { ...data };

    if (activeTab === 'eqFailure') {
      const em = parseInt(modalForm.emCount, 10) || 0;
      const pm = parseInt(modalForm.pmCount, 10) || 0;
      const cm = parseInt(modalForm.cmCount, 10) || 0;
      const total = em + pm + cm;
      copy.eqFailure = [
        ...copy.eqFailure,
        {
          id,
          eqCode: modalForm.eqCode || '',
          eqName: modalForm.eqName || '',
          familyPath: modalForm.familyPath || '',
          locPath: modalForm.locPath || '',
          emCount: em,
          pmCount: pm,
          cmCount: cm,
          totalCount: total
        }
      ];
    } else if (activeTab === 'locDowntime') {
      const dt = modalForm.downtimeHours || '00:00';
      copy.locDowntime = [
        ...copy.locDowntime,
        {
          id,
          locCode: modalForm.locCode || '',
          locName: modalForm.locName || '',
          locPathCode: modalForm.locPathCode || modalForm.locCode || '',
          locPathName: modalForm.locPathName || modalForm.locName || '',
          downtimeHours: dt,
          downtimeMinutes: parseTimeToMinutes(dt)
        }
      ];
    } else if (activeTab === 'eqDowntime') {
      const dt = modalForm.downtimeHours || '00:00';
      copy.eqDowntime = [
        ...copy.eqDowntime,
        {
          id,
          eqCode: modalForm.eqCode || '',
          eqName: modalForm.eqName || '',
          locPath: modalForm.locPath || '',
          downtimeHours: dt,
          downtimeMinutes: parseTimeToMinutes(dt)
        }
      ];
    } else if (activeTab === 'famFailure') {
      const em = parseInt(modalForm.emCount, 10) || 0;
      const pm = parseInt(modalForm.pmCount, 10) || 0;
      const cm = parseInt(modalForm.cmCount, 10) || 0;
      const total = em + pm + cm;
      copy.famFailure = [
        ...copy.famFailure,
        {
          id,
          famCode: modalForm.famCode || '',
          famName: modalForm.famName || '',
          groupName: modalForm.groupName || '',
          emCount: em,
          pmCount: pm,
          cmCount: cm,
          totalCount: total
        }
      ];
    } else if (activeTab === 'locFailure') {
      const em = parseInt(modalForm.emCount, 10) || 0;
      const pm = parseInt(modalForm.pmCount, 10) || 0;
      const cm = parseInt(modalForm.cmCount, 10) || 0;
      const total = em + pm + cm;
      copy.locFailure = [
        ...copy.locFailure,
        {
          id,
          locCode: modalForm.locCode || '',
          locName: modalForm.locName || '',
          locPathCode: modalForm.locPathCode || modalForm.locCode || '',
          locPathName: modalForm.locPathName || modalForm.locName || '',
          emCount: em,
          pmCount: pm,
          cmCount: cm,
          totalCount: total
        }
      ];
    }

    saveData(copy);
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string) => {
    const copy = { ...data };
    if (activeTab === 'eqFailure') copy.eqFailure = copy.eqFailure.filter(i => i.id !== id);
    if (activeTab === 'locDowntime') copy.locDowntime = copy.locDowntime.filter(i => i.id !== id);
    if (activeTab === 'eqDowntime') copy.eqDowntime = copy.eqDowntime.filter(i => i.id !== id);
    if (activeTab === 'famFailure') copy.famFailure = copy.famFailure.filter(i => i.id !== id);
    if (activeTab === 'locFailure') copy.locFailure = copy.locFailure.filter(i => i.id !== id);
    saveData(copy);
  };

  // خروجی اکسل
  const handleExportExcel = () => {
    let rows: any[] = [];
    let fileName = 'گزارش_پارتو.xlsx';

    if (activeTab === 'eqFailure') {
      fileName = 'پارتو_خرابی_تجهیز.xlsx';
      rows = displayedData.eqFailure.map(r => ({
        'کد تجهیز': r.eqCode,
        'عنوان تجهیز': r.eqName,
        'مسیر عنوان خانواده تجهیز': r.familyPath,
        'مسیر عنوان مکان': r.locPath,
        'تعداد درخواست کار EM': r.emCount,
        'تعداد درخواست کار PM': r.pmCount,
        'تعداد درخواست کار CM': r.cmCount,
        'تعداد درخواست کار کل': r.totalCount
      }));
    } else if (activeTab === 'locDowntime') {
      fileName = 'زمان_خرابی_تجهیزات_برای_مکان.xlsx';
      rows = displayedData.locDowntime.map(r => ({
        'کد مکان': r.locCode,
        'عنوان مکان': r.locName,
        'مسیر کد مکان': r.locPathCode,
        'مسیر عنوان مکان': r.locPathName,
        'زمان توقف': r.downtimeHours
      }));
    } else if (activeTab === 'eqDowntime') {
      fileName = 'پارتو_زمان_توقف_تجهیز.xlsx';
      rows = displayedData.eqDowntime.map(r => ({
        'کد تجهیز': r.eqCode,
        'عنوان تجهیز': r.eqName,
        'مسیر عنوان مکان': r.locPath,
        'زمان توقف': r.downtimeHours
      }));
    } else if (activeTab === 'famFailure') {
      fileName = 'پارتو_خرابی_خانواده_تجهیز.xlsx';
      rows = displayedData.famFailure.map(r => ({
        'کد خانواده تجهیز': r.famCode,
        'نام خانواده تجهیز': r.famName,
        'نام گروه خانواده تجهیز': r.groupName,
        'تعداد درخواست کار EM': r.emCount,
        'تعداد درخواست کار PM': r.pmCount,
        'تعداد درخواست کار CM': r.cmCount,
        'تعداد درخواست کار کل': r.totalCount
      }));
    } else if (activeTab === 'locFailure') {
      fileName = 'تعداد_خرابی_تجهیزات_برای_مکان.xlsx';
      rows = displayedData.locFailure.map(r => ({
        'کد مکان': r.locCode,
        'عنوان مکان': r.locName,
        'مسیر کد مکان': r.locPathCode,
        'مسیر عنوان مکان': r.locPathName,
        'تعداد درخواست کار EM': r.emCount,
        'تعداد درخواست کار PM': r.pmCount,
        'تعداد درخواست کار CM': r.cmCount,
        'تعداد درخواست کار کل': r.totalCount
      }));
    }

    if (rows.length === 0) {
      setNoticeMsg('داده‌ای برای خروجی اکسل وجود ندارد.');
      setTimeout(() => setNoticeMsg(null), 3500);
      return;
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'پارتو');
    XLSX.writeFile(wb, fileName);
  };

  const currentTabTitle = tabs.find(t => t.id === activeTab)?.label || 'گزارش پارتو';

  return (
    <div className="space-y-3 font-sans">
      {noticeMsg && (
        <div className="px-3.5 py-2 rounded-xl bg-amber-950/90 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center justify-between">
          <span>{noticeMsg}</span>
          <button type="button" onClick={() => setNoticeMsg(null)} className="text-amber-300 hover:text-white cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}
      
      {/* ۵ تب پارتو: طراحی جمع‌وجور، خلوت و یکپارچه در یک ردیف */}
      <div className="bg-[#070e22]/90 border border-indigo-900/40 rounded-xl p-1.5 flex items-center justify-between gap-1 overflow-x-auto scrollbar-none shadow-sm">
        <div className="flex items-center gap-1 min-w-max">
          {tabs.map(tab => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#112042]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* نوار فیلتر و ابزارها (کد، عنوان، مسیر، تاریخ‌ها و دکمه‌ها در یک سطح خلوت) */}
      <div className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        
        {/* فیلدها */}
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <input
            type="text"
            value={filterEqCode}
            onChange={e => setFilterEqCode(e.target.value)}
            placeholder="کد تجهیز / مکان..."
            className="bg-[#0c162e] border border-indigo-500/30 rounded-lg px-2.5 py-1.5 text-white placeholder-slate-500 font-mono text-right outline-none focus:border-cyan-400 w-32"
          />

          <input
            type="text"
            value={filterEqName}
            onChange={e => setFilterEqName(e.target.value)}
            placeholder="عنوان..."
            className="bg-[#0c162e] border border-indigo-500/30 rounded-lg px-2.5 py-1.5 text-white placeholder-slate-500 text-right outline-none focus:border-cyan-400 w-36"
          />

          <input
            type="text"
            value={filterPath}
            onChange={e => setFilterPath(e.target.value)}
            placeholder="مسیر عنوان یا مکان..."
            className="bg-[#0c162e] border border-indigo-500/30 rounded-lg px-2.5 py-1.5 text-white placeholder-slate-500 text-right outline-none focus:border-cyan-400 w-40"
          />

          <div className="flex items-center gap-1 bg-[#0c162e] border border-indigo-500/30 rounded-lg px-2 py-1">
            <span className="text-[10px] text-slate-400">از:</span>
            <input
              type="text"
              value={filterStartDate}
              onChange={e => setFilterStartDate(e.target.value)}
              className="bg-transparent text-slate-200 text-right font-mono outline-none text-xs w-20"
            />
          </div>

          <div className="flex items-center gap-1 bg-[#0c162e] border border-indigo-500/30 rounded-lg px-2 py-1">
            <span className="text-[10px] text-slate-400">تا:</span>
            <input
              type="text"
              value={filterEndDate}
              onChange={e => setFilterEndDate(e.target.value)}
              className="bg-transparent text-slate-200 text-right font-mono outline-none text-xs w-20"
            />
          </div>
        </div>

        {/* دکمه‌های اکشن */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => { setModalForm({}); setIsAddModalOpen(true); }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all shadow-sm cursor-pointer"
          >
            <Plus size={13} />
            <span>افزودن سطر</span>
          </button>

          <button
            type="button"
            onClick={() => setIsPrintModalOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0c162e] hover:bg-[#132448] border border-indigo-500/40 text-cyan-300 hover:text-white transition-all cursor-pointer"
            title="چاپ رسمی"
          >
            <Printer size={13} />
            <span>چاپ</span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0c162e] hover:bg-[#132448] border border-emerald-500/40 text-emerald-300 hover:text-white transition-all cursor-pointer"
            title="دانلود اکسل"
          >
            <Download size={13} />
            <span>اکسل</span>
          </button>
        </div>
      </div>

      {/* ۱. ابتدا جدول گزارش پارتو نمایش داده می‌شود (خلوت و مستقیم) */}
      <div className="bg-[#0c162e]/90 backdrop-blur-xl border border-indigo-500/20 rounded-xl overflow-hidden shadow-md">
        
        {/* تب ۱: پارتو خرابی تجهیز */}
        {activeTab === 'eqFailure' && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">کد تجهیز</th>
                  <th className="p-3">عنوان تجهیز</th>
                  <th className="p-3">مسیر عنوان خانواده تجهیز</th>
                  <th className="p-3">مسیر عنوان مکان</th>
                  <th className="p-3 text-center text-amber-300">تعداد درخواست کار EM ↓</th>
                  <th className="p-3 text-center">تعداد درخواست کار PM</th>
                  <th className="p-3 text-center">تعداد درخواست کار CM</th>
                  <th className="p-3 text-center font-black text-cyan-300">تعداد درخواست کار کل</th>
                  <th className="p-3 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {displayedData.eqFailure.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-500">
                      هنوز خرابی یا درخواستی در این بازه زمانی ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  displayedData.eqFailure.map(row => (
                    <tr key={row.id} className="hover:bg-[#112042]/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-cyan-300">{row.eqCode || '—'}</td>
                      <td className="p-3 font-bold text-white">{row.eqName || '—'}</td>
                      <td className="p-3 text-slate-300">{row.familyPath || '—'}</td>
                      <td className="p-3 text-slate-400">{row.locPath || '—'}</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-300">{row.emCount}</td>
                      <td className="p-3 text-center font-mono text-purple-300">{row.pmCount}</td>
                      <td className="p-3 text-center font-mono text-blue-300">{row.cmCount}</td>
                      <td className="p-3 text-center font-mono font-black text-cyan-300">{row.totalCount}</td>
                      <td className="p-3 text-center">
                        {row.isLive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                            خودکار
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(row.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* تب ۲: زمان خرابی تجهیزات برای مکان */}
        {activeTab === 'locDowntime' && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">کد مکان</th>
                  <th className="p-3">عنوان مکان</th>
                  <th className="p-3">مسیر کد مکان</th>
                  <th className="p-3">مسیر عنوان مکان</th>
                  <th className="p-3 text-center font-black text-amber-300">زمان توقف</th>
                  <th className="p-3 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {displayedData.locDowntime.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-500">
                      هنوز توقف زمانی برای مکان‌ها در این بازه ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  displayedData.locDowntime.map(row => (
                    <tr key={row.id} className="hover:bg-[#112042]/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-cyan-300">{row.locCode || '—'}</td>
                      <td className="p-3 font-bold text-white">{row.locName || '—'}</td>
                      <td className="p-3 font-mono text-slate-400">{row.locPathCode || '—'}</td>
                      <td className="p-3 text-slate-300">{row.locPathName || '—'}</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-300">{row.downtimeHours}</td>
                      <td className="p-3 text-center">
                        {row.isLive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                            خودکار
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(row.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* تب ۳: پارتو زمان توقف تجهیز */}
        {activeTab === 'eqDowntime' && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">کد تجهیز</th>
                  <th className="p-3">عنوان تجهیز</th>
                  <th className="p-3">مسیر عنوان مکان</th>
                  <th className="p-3 text-center font-black text-amber-300">زمان توقف ↓</th>
                  <th className="p-3 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {displayedData.eqDowntime.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-500">
                      هنوز توقف تجهیز ثبت‌شده‌ای در این بازه وجود ندارد.
                    </td>
                  </tr>
                ) : (
                  displayedData.eqDowntime.map(row => (
                    <tr key={row.id} className="hover:bg-[#112042]/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-cyan-300">{row.eqCode || '—'}</td>
                      <td className="p-3 font-bold text-white">{row.eqName || '—'}</td>
                      <td className="p-3 text-slate-300">{row.locPath || '—'}</td>
                      <td className="p-3 text-center font-mono font-black text-amber-300">{row.downtimeHours}</td>
                      <td className="p-3 text-center">
                        {row.isLive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                            خودکار
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(row.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* تب ۴: پارتو خرابی خانواده تجهیز */}
        {activeTab === 'famFailure' && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">کد خانواده تجهیز</th>
                  <th className="p-3">نام خانواده تجهیز</th>
                  <th className="p-3">نام گروه خانواده تجهیز</th>
                  <th className="p-3 text-center text-amber-300">تعداد درخواست کار EM ↓</th>
                  <th className="p-3 text-center">تعداد درخواست کار PM</th>
                  <th className="p-3 text-center">تعداد درخواست کار CM</th>
                  <th className="p-3 text-center font-black text-cyan-300">تعداد درخواست کار کل</th>
                  <th className="p-3 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {displayedData.famFailure.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500">
                      هنوز خرابی یا درخواستی برای خانواده‌های تجهیز در این بازه ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  displayedData.famFailure.map(row => (
                    <tr key={row.id} className="hover:bg-[#112042]/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-cyan-300">{row.famCode || '—'}</td>
                      <td className="p-3 font-bold text-white">{row.famName || '—'}</td>
                      <td className="p-3 text-slate-300">{row.groupName || '—'}</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-300">{row.emCount}</td>
                      <td className="p-3 text-center font-mono text-purple-300">{row.pmCount}</td>
                      <td className="p-3 text-center font-mono text-blue-300">{row.cmCount}</td>
                      <td className="p-3 text-center font-mono font-black text-cyan-300">{row.totalCount}</td>
                      <td className="p-3 text-center">
                        {row.isLive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                            خودکار
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(row.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* تب ۵: تعداد خرابی تجهیزات برای مکان */}
        {activeTab === 'locFailure' && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">کد مکان</th>
                  <th className="p-3">عنوان مکان</th>
                  <th className="p-3">مسیر کد مکان</th>
                  <th className="p-3">مسیر عنوان مکان</th>
                  <th className="p-3 text-center text-amber-300">تعداد درخواست کار EM ↓</th>
                  <th className="p-3 text-center">تعداد درخواست کار PM</th>
                  <th className="p-3 text-center">تعداد درخواست کار CM</th>
                  <th className="p-3 text-center font-black text-cyan-300">تعداد درخواست کار کل</th>
                  <th className="p-3 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {displayedData.locFailure.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-500">
                      هنوز خرابی یا درخواستی برای مکان‌ها در این بازه ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  displayedData.locFailure.map(row => (
                    <tr key={row.id} className="hover:bg-[#112042]/50 transition-colors">
                      <td className="p-3 font-mono font-bold text-cyan-300">{row.locCode || '—'}</td>
                      <td className="p-3 font-bold text-white">{row.locName || '—'}</td>
                      <td className="p-3 font-mono text-slate-400">{row.locPathCode || '—'}</td>
                      <td className="p-3 text-slate-300">{row.locPathName || '—'}</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-300">{row.emCount}</td>
                      <td className="p-3 text-center font-mono text-purple-300">{row.pmCount}</td>
                      <td className="p-3 text-center font-mono text-blue-300">{row.cmCount}</td>
                      <td className="p-3 text-center font-mono font-black text-cyan-300">{row.totalCount}</td>
                      <td className="p-3 text-center">
                        {row.isLive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                            خودکار
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDelete(row.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {/* ۲. نمودار زیر جدول گزارش پارتو قرار می‌گیرد (طبق دستور صریح کاربر) */}
      <div className="bg-[#0c162e]/90 backdrop-blur-xl border border-indigo-500/20 rounded-xl overflow-hidden shadow-md">
        
        {/* نوار عنوان نمودار و دکمه باز/بستن */}
        <button
          type="button"
          onClick={() => setIsChartOpen(!isChartOpen)}
          className="w-full p-3 bg-[#070e22]/90 flex items-center justify-between text-xs font-bold text-white cursor-pointer hover:bg-[#112042] transition-colors"
        >
          <div className="flex items-center gap-2">
            <BarChart3 size={16} className="text-cyan-400" />
            <span>نمودار تحلیلی پارتو (قانون ۸۰/۲۰)</span>
            <span className="text-[10px] text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/40">
              {currentTabTitle}
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <div className="flex items-center gap-3 text-[10px]">
              <span className="text-cyan-300">■ ستون‌ها (مقدار)</span>
              <span className="text-amber-300">— درصد تجمعی</span>
              <span className="text-rose-400">-- مرز ۸۰٪</span>
            </div>
            {isChartOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </div>
        </button>

        {/* محتوای نمودار (وقتی باز است) */}
        {isChartOpen && (
          <div className="p-4 border-t border-indigo-900/40 space-y-3">
            {parsedChartData.items.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500">
                جهت رسم نمودار، اطلاعات را در جدول بالا ثبت فرمایید.
              </div>
            ) : (
              <div className="space-y-3">
                <div className="relative w-full h-52 bg-[#070e22] border border-indigo-950 rounded-xl p-3 overflow-hidden">
                  
                  {/* خط مرز ۸۰٪ پارتو */}
                  <div 
                    className="absolute left-6 right-6 border-t border-dashed border-rose-500/70 z-10 flex items-center justify-between pointer-events-none"
                    style={{ bottom: '80%' }}
                  >
                    <span className="text-[9px] text-rose-400 font-mono bg-[#070e22] px-1 font-bold">۸۰٪ مرز بحرانی پارتو</span>
                  </div>

                  {/* ستون‌ها */}
                  <div className="w-full h-full flex items-end justify-around gap-2 px-4 pt-4 pb-1">
                    {parsedChartData.items.slice(0, 12).map((item, index) => {
                      const barHeightPercent = Math.max(8, Math.round((item.value / parsedChartData.maxVal) * 85));
                      return (
                        <div key={index} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-9 z-30 pointer-events-none bg-slate-900 border border-cyan-500/50 rounded px-2 py-0.5 text-center shadow whitespace-nowrap text-[9px] text-white">
                            {item.label} ({item.subLabel}): {item.value} | {item.cumPercent}٪
                          </div>

                          <div className="text-[8px] font-mono text-amber-300 font-bold mb-0.5">
                            {item.cumPercent}٪
                          </div>

                          <div 
                            className="w-full max-w-[32px] rounded-t bg-gradient-to-t from-blue-700 to-cyan-400 group-hover:from-blue-600 group-hover:to-cyan-300 transition-all cursor-pointer"
                            style={{ height: `${barHeightPercent}%` }}
                          />

                          <div className="mt-1 text-center">
                            <div className="text-[9px] font-mono font-bold text-slate-200 truncate max-w-[45px]">{item.label}</div>
                            <div className="text-[8px] text-slate-400 font-mono">{item.value}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* آمار خلاصه در یک خط کوچک */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-mono">
                  <span>تعداد کل موارد: <strong className="text-white">{parsedChartData.items.length}</strong></span>
                  <span>مجموع کل: <strong className="text-cyan-300">{parsedChartData.totalSum}</strong></span>
                  <span>عامل رتبه اول: <strong className="text-amber-300">{parsedChartData.items[0]?.label || '—'}</strong></span>
                  <span>سهم ۸۰٪ بحرانی: <strong className="text-rose-400">{parsedChartData.items.filter(i => i.cumPercent <= 80).length} مورد</strong></span>
                </div>
              </div>
            )}
          </div>
        )}

      </div>

      {/* مودال ثبت سطر جدید */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#0c162e] rounded-2xl shadow-2xl border border-indigo-500/30 p-5 space-y-4 text-right animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <span className="font-bold text-sm text-white">
                ثبت سطر: {currentTabTitle}
              </span>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {activeTab === 'eqFailure' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">کد تجهیز *</label>
                      <input
                        type="text"
                        placeholder="TUTN17"
                        value={modalForm.eqCode || ''}
                        onChange={e => setModalForm({ ...modalForm, eqCode: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-cyan-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">عنوان تجهیز *</label>
                      <input
                        type="text"
                        placeholder="تورنوس"
                        value={modalForm.eqName || ''}
                        onChange={e => setModalForm({ ...modalForm, eqName: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">مسیر عنوان خانواده تجهیز</label>
                    <input
                      type="text"
                      placeholder="تراش تورنوس DECO - 20 a"
                      value={modalForm.familyPath || ''}
                      onChange={e => setModalForm({ ...modalForm, familyPath: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">مسیر عنوان مکان</label>
                    <input
                      type="text"
                      placeholder="سالن دو_طبقه همکف_تولید"
                      value={modalForm.locPath || ''}
                      onChange={e => setModalForm({ ...modalForm, locPath: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست EM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.emCount || ''}
                        onChange={e => setModalForm({ ...modalForm, emCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-amber-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست PM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.pmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, pmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-purple-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست CM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.cmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, cmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-blue-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'locDowntime' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">کد مکان *</label>
                      <input
                        type="text"
                        placeholder="S01"
                        value={modalForm.locCode || ''}
                        onChange={e => setModalForm({ ...modalForm, locCode: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-cyan-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">عنوان مکان *</label>
                      <input
                        type="text"
                        placeholder="سالن یک"
                        value={modalForm.locName || ''}
                        onChange={e => setModalForm({ ...modalForm, locName: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">زمان توقف (ساعت:دقیقه) *</label>
                    <input
                      type="text"
                      placeholder="25530:15"
                      value={modalForm.downtimeHours || ''}
                      onChange={e => setModalForm({ ...modalForm, downtimeHours: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-amber-300 font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'eqDowntime' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">کد تجهیز *</label>
                      <input
                        type="text"
                        placeholder="TUTN06"
                        value={modalForm.eqCode || ''}
                        onChange={e => setModalForm({ ...modalForm, eqCode: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-cyan-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">عنوان تجهیز *</label>
                      <input
                        type="text"
                        placeholder="تورنوس"
                        value={modalForm.eqName || ''}
                        onChange={e => setModalForm({ ...modalForm, eqName: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">مسیر عنوان مکان</label>
                    <input
                      type="text"
                      placeholder="سالن یک_طبقه همکف_تولید"
                      value={modalForm.locPath || ''}
                      onChange={e => setModalForm({ ...modalForm, locPath: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">زمان توقف (ساعت:دقیقه) *</label>
                    <input
                      type="text"
                      placeholder="3202:25"
                      value={modalForm.downtimeHours || ''}
                      onChange={e => setModalForm({ ...modalForm, downtimeHours: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-amber-300 font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'famFailure' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">کد خانواده *</label>
                      <input
                        type="text"
                        placeholder="TUTN01"
                        value={modalForm.famCode || ''}
                        onChange={e => setModalForm({ ...modalForm, famCode: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-cyan-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">نام خانواده *</label>
                      <input
                        type="text"
                        placeholder="تراش تورنوس DECO - 13 a"
                        value={modalForm.famName || ''}
                        onChange={e => setModalForm({ ...modalForm, famName: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">گروه خانواده تجهیز</label>
                    <input
                      type="text"
                      placeholder="تراش تورنوس"
                      value={modalForm.groupName || ''}
                      onChange={e => setModalForm({ ...modalForm, groupName: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست EM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.emCount || ''}
                        onChange={e => setModalForm({ ...modalForm, emCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-amber-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست PM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.pmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, pmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-purple-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست CM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.cmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, cmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-blue-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'locFailure' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">کد مکان *</label>
                      <input
                        type="text"
                        placeholder="S01"
                        value={modalForm.locCode || ''}
                        onChange={e => setModalForm({ ...modalForm, locCode: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-cyan-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">عنوان مکان *</label>
                      <input
                        type="text"
                        placeholder="سالن یک"
                        value={modalForm.locName || ''}
                        onChange={e => setModalForm({ ...modalForm, locName: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست EM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.emCount || ''}
                        onChange={e => setModalForm({ ...modalForm, emCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-amber-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست PM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.pmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, pmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-purple-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-bold mb-1">درخواست CM</label>
                      <input
                        type="number"
                        placeholder="0"
                        value={modalForm.cmCount || ''}
                        onChange={e => setModalForm({ ...modalForm, cmCount: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-blue-300 font-mono outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveModal}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Check size={14} />
                <span>ثبت اطلاعات</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* مودال پیش‌نمایش چاپ رسمی */}
      {isPrintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 text-right font-sans my-auto max-h-[92vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-4 border-b-2 border-slate-300">
              <div className="flex items-center gap-3">
                <img src={OSVEH_LOGO_WHITEBG_URL} alt={BRAND_CONFIG.COMPANY_NAME} className="h-12 w-auto object-contain" />
                <div>
                  <h2 className="text-base font-black text-slate-900">{printSettings.paretoReport.docTitle}</h2>
                  <p className="text-xs text-slate-600 font-bold">{BRAND_CONFIG.COMPANY_FULL_NAME} • {BRAND_CONFIG.SYSTEM_NAME}</p>
                </div>
              </div>

              <div className="text-left font-mono text-xs text-slate-600 space-y-0.5">
                <div>کد سند: <strong>{printSettings.paretoReport.docCode}</strong></div>
                <div>تاریخ گزارش: <strong>{getTodayShamsiDate()}</strong></div>
                <div>تحلیل: <strong>پارتو (۸۰/۲۰)</strong></div>
              </div>
            </div>

            <div className="bg-slate-100 p-2.5 rounded-lg border border-slate-300 flex justify-between items-center text-xs">
              <div><strong>عنوان گزارش:</strong> {currentTabTitle}</div>
              <div><strong>بازه زمانی:</strong> از {filterStartDate} تا {filterEndDate}</div>
              <div><strong>تعداد:</strong> {parsedChartData.items.length} مورد</div>
            </div>

            <div className="overflow-x-auto border border-slate-300 rounded-lg">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-200 text-slate-800 border-b border-slate-300 font-bold">
                    <th className="p-2">ردیف</th>
                    <th className="p-2">شناسه</th>
                    <th className="p-2">عنوان</th>
                    <th className="p-2 text-center">مقدار</th>
                    <th className="p-2 text-center">درصد تجمعی</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {parsedChartData.items.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-500">داده‌ای ثبت نشده است.</td>
                    </tr>
                  ) : (
                    parsedChartData.items.map((item, idx) => (
                      <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                        <td className="p-2 font-mono">{idx + 1}</td>
                        <td className="p-2 font-mono font-bold">{item.label}</td>
                        <td className="p-2">{item.subLabel || '—'}</td>
                        <td className="p-2 text-center font-mono font-bold">{item.value}</td>
                        <td className="p-2 text-center font-mono">{item.cumPercent}٪</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-300 text-xs text-center">
              <div className="border border-dashed border-slate-400 p-3 rounded-xl min-h-[70px] flex flex-col justify-between">
                <span className="font-bold">تهیه‌کننده گزارش:</span>
                <span className="text-slate-400 text-[10px]">امضا و تاریخ</span>
              </div>
              <div className="border border-dashed border-slate-400 p-3 rounded-xl min-h-[70px] flex flex-col justify-between">
                <span className="font-bold">تایید سرپرست خدمات فنی:</span>
                <span className="text-slate-400 text-[10px]">امضا و تاریخ</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold cursor-pointer"
              >
                بستن
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black cursor-pointer shadow"
              >
                <Printer size={14} />
                <span>ارسال به چاپگر</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
