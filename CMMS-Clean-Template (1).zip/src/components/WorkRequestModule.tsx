import React, { useState, useMemo, useEffect, useRef } from 'react';
import TimeInput24 from './TimeInput24';
import {
  FileText,
  Plus,
  Search,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Eye,
  Printer,
  X,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Wrench,
  User,
  Users,
  Building,
  Building2,
  FolderTree,
  SlidersHorizontal,
  ArrowRight,
  ArrowUpDown,
  RefreshCw,
  QrCode,
  HandMetal,
  Check,
  Send,
  Sparkles,
  Menu,
  MoreVertical,
  Pencil,
  Trash2,
  FolderPlus,
  ShieldCheck,
  Package,
  Layers,
  FilePlus,
  Home,
  Calendar,
  Settings,
  UserPlus,
  Briefcase,
  Download,
  BarChart2,
  Zap,
  Box,
  Timer,
  ClipboardList,
  Archive,
  RotateCcw
} from 'lucide-react';
import { createPortal } from 'react-dom';
import { COMPANY_LOGO, OSVEH_LOGO_WHITEBG_URL, OSVEH_LOGO_URL } from '../data/auditImages';
import { BRAND_CONFIG } from '../data/brandConfig';
import { EquipmentItem } from '../data/portalData';
import { ProductionOperator, PRODUCTION_OPERATORS_LIST } from '../data/operatorsData';
import defaultPlantEquipment from '../data/plantEquipment.json';
import defaultAssetFamilies from '../data/assetFamilies.json';
import defaultFactoryLocations from '../data/factoryLocations.json';
import { AssetClassDetailView } from './AssetClassDetailView';
import { WorkRequestReportsView } from './WorkRequestReportsView';
import {
  getUnifiedSpareParts,
  DEFAULT_PRESET_CONSUMABLES,
  WorkOrderConsumableItem
} from '../data/sparePartsData';
import {
  computeMinutesBetweenShamsiDateTimes,
  extractShamsiDateAndTime,
  formatMinutesDurationFa
} from '../data/dateTimeUtils';
import {
  PRINT_TEMPLATE_DEFINITIONS,
  PrintSettingsMap,
  PrintTemplateKey,
  getDefaultPrintSettings,
  loadPrintSettings,
  savePrintSettings,
  usePrintSettings
} from '../data/printSettings';

import { addShamsiDaysPm, isStrictPmRecord, syncAndReconcilePmTechStorage } from '../data/pmAutoWorkOrders';

export interface WoWorkDayEntry {
  id: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
}

export interface WoActivityEntry {
  id: string;
  code: string;
  title: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
}

export interface WoTechnicianEntry {
  id: string;
  name: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  date?: string;
  hours: number;
  customStartDate?: boolean;
  customStartTime?: boolean;
  customEndDate?: boolean;
  customEndTime?: boolean;
  customHours?: boolean;
}

export interface WoDelayEntry {
  id: string;
  code: string;
  title: string;
  days: number;
  hours: number;
}

export interface PmWorkRequestItem {
  id: string;
  code: string;                      // مانند WR000001
  equipmentName: string;             // مانند تورنوس
  equipmentCode: string;             // مانند TUTN02
  locationName: string;              // مانند سالن یک_طبقه همکف_تولید
  locationCode?: string;             // مانند S01
  requestTime: string;               // مانند ۱۴۰۵/۰۸/۱۶ - ۰۸:۵۷
  equipmentFamilyName: string;       // مانند تراش تورنوس 20 - DECO
  equipmentFamilyCode?: string;      // مانند TUTN
  failureTitle: string;              // مانند خرابی محور X4
  failureCode?: string;              // مانند FL-01
  priority: 'توقف تولید' | 'توقف تجهیز' | 'عدم توقف تجهیز';
  description: string;               // مانند atc alarm، محور Z
  requestType: 'اضطراری' | 'اصلاحی' | 'پیشگیرانه';
  status: string;                    // در انتظار دستور برنامه ریزی | در حال اقدام | انجام شد
  operatorName?: string;             // نام ثبت‌کننده
  operatorPersonnelCode?: string;    // کد پرسنلی ثبت‌کننده
  technician?: string;               // تکنسین مسئول
  coTechnicians?: string[];          // تکنسین‌های همکار
  durationMinutes?: number;          // مدت زمان توقف/کارکرد (دقیقه)
  equipmentDowntimeMinutes?: number; // مدت دقیق خواب تجهیز از بخش وضعیت دستور کار (دقیقه)
  downtimeMinutes?: number;          // هم‌ارز استاندارد جهت قابلیت اطمینان و گزارش‌ها
  completedAt?: string;              // تاریخ و ساعت تکمیل
  actionDetails?: string;            // شرح اقدامات فنی تکنسین
  woCode?: string;                   // کد دستور کار مرتبط (مثلاً WO001955)
  workOrderCode?: string;
  woStartDate?: string;
  woStartTimeOnly?: string;
  woEndDate?: string;
  woEndTimeOnly?: string;
  woStartTime?: string;
  woEndTime?: string;
  woWorkDays?: WoWorkDayEntry[];
  woActivities?: WoActivityEntry[];
  woTechnicians?: WoTechnicianEntry[];
  consumables?: WorkOrderConsumableItem[];
  partsUsed?: string;
  woDelays?: WoDelayEntry[];
  woNotes?: string;
  isArchivedWorkOrder?: boolean;
  isPM?: boolean;
  isScheduledPM?: boolean;
  pmGroupId?: string;
  pmGroupName?: string;
  pmPeriodKey?: string;
  pmPeriodLabel?: string;
  pmDueDate?: string;
  pmSourceKey?: string;
  pmCandidateEquipments?: Array<{ id: string; name: string; location?: string; family?: string }>;
  pmSelectedEquipmentIds?: string[];
  timestamp: number;
}

// لیست پیش‌فرض درخواست کارها (کاملاً خالی طبق دستور کاربر برای ثبت داده واقعی از ابتدا)
export const INITIAL_PM_WORK_REQUESTS: PmWorkRequestItem[] = [];

// عادی‌سازی متن فارسی جهت تطبیق دقیق خانواده تجهیز با شناسنامه خانواده
const normalizeFaFamilyText = (val: string) =>
  String(val || '')
    .replace(/ي/g, 'ی')
    .replace(/ى/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\u200c/g, '')
    .trim()
    .toLowerCase();

const compactFaFamilyText = (val: string) =>
  normalizeFaFamilyText(val).replace(/[\s_\-–—()（）/\\]+/g, '');

const tokenKeyFaFamilyText = (val: string) =>
  normalizeFaFamilyText(val)
    .split(/[\s_\-–—()（）/\\]+/)
    .filter(Boolean)
    .sort()
    .join('|');

interface WorkRequestModuleProps {
  onBackToPortal: () => void;
  equipments: EquipmentItem[];
  operators: ProductionOperator[];
  technicians?: string[];
  onUpdateOperators?: (updated: ProductionOperator[]) => void;
  onUpdateEquipments?: (updated: EquipmentItem[]) => void;
  systemTheme?: 'dark' | 'light';
  onSyncWithServer?: (newRequest: PmWorkRequestItem) => void;
}

export const WorkRequestModule: React.FC<WorkRequestModuleProps> = ({
  onBackToPortal,
  equipments,
  operators,
  technicians = [],
  onUpdateOperators,
  onUpdateEquipments,
  systemTheme = 'dark',
  onSyncWithServer
}) => {
  // ویو فعال ماژول (کارتابل درخواست‌ها، بایگانی دستور کار، مدیریت تجهیزات، مدیریت مکان‌ها، لیست اپراتورها، گزارش‌ها)
  const [activeView, setActiveView] = useState<'requests' | 'woArchive' | 'equipment' | 'locations' | 'operators' | 'reports' | 'printSettings'>('requests');

  // سایدبار کشویی مشابه PM Studio (عکس ارسالی کاربر)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const printSettings = usePrintSettings();
  const [printSettingsDraft, setPrintSettingsDraft] = useState<PrintSettingsMap>(() => loadPrintSettings());
  const [printSettingsSearch, setPrintSettingsSearch] = useState('');
  const [printSettingsSectionFilter, setPrintSettingsSectionFilter] = useState<'all' | 'درخواست کار و دستورکار' | 'گزارش‌های تحلیلی و پارتو' | 'خدمات فنی، PM و انبار'>('all');
  const [printSettingsToast, setPrintSettingsToast] = useState<string | null>(null);
  const [printSavedRowKey, setPrintSavedRowKey] = useState<PrintTemplateKey | null>(null);

  // ========================================================
  // پایگاه داده تجهیزات و خانواده‌ها (دقیقاً همگام با کل سامانه)
  // ========================================================
  const [equipmentList, setEquipmentList] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('pm_studio_equipments_v13');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultPlantEquipment;
  });

  useEffect(() => {
    const handleEqUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setEquipmentList(e.detail);
      } else {
        try {
          const s = localStorage.getItem('pm_studio_equipments_v13');
          if (s) setEquipmentList(JSON.parse(s));
        } catch {}
      }
    };
    window.addEventListener('factory_equipments_updated', handleEqUpdated);
    return () => window.removeEventListener('factory_equipments_updated', handleEqUpdated);
  }, []);

  const [equipmentPage, setEquipmentPage] = useState(1);
  const [equipmentTab, setEquipmentTab] = useState<'list' | 'families'>('list');
  const [equipmentSearch, setEquipmentSearch] = useState('');
  const [selectedLocationFilter, setSelectedLocationFilter] = useState('all');

  // خانواده تجهیزات (همگام با تمام کارت‌ها)
  const [familyPage, setFamilyPage] = useState(1);
  const [familyList, setFamilyList] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('pm_studio_families_v9');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultAssetFamilies;
  });
  const [selectedFamilyForDetail, setSelectedFamilyForDetail] = useState<any | null>(null);

  useEffect(() => {
    const handleFamUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setFamilyList(e.detail);
      } else {
        try {
          const s = localStorage.getItem('pm_studio_families_v9');
          if (s) setFamilyList(JSON.parse(s));
        } catch {}
      }
    };
    window.addEventListener('factory_families_updated', handleFamUpdated);
    return () => window.removeEventListener('factory_families_updated', handleFamUpdated);
  }, []);

  // مودال‌های ویرایش/افزودن تجهیز و خانواده
  const [isEqModalOpen, setIsEqModalOpen] = useState(false);
  const [isEditingEq, setIsEditingEq] = useState(false);
  const [eqFormData, setEqFormData] = useState({ id: '', name: '', family: '', location: '', priority: 'سطح C' });

  const [isFamModalOpen, setIsFamModalOpen] = useState(false);
  const [isEditingFam, setIsEditingFam] = useState(false);
  const [famFormData, setFamFormData] = useState({ id: '', name: '', group: '' });

  // ========================================================
  // پایگاه داده مکان‌ها و سالن‌ها (S01 تا S08) همگام با کل سامانه
  // ========================================================
  const [locationsList, setLocationsList] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('pm_studio_locations_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultFactoryLocations;
  });

  useEffect(() => {
    const handleLocUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setLocationsList(e.detail);
      } else {
        try {
          const s = localStorage.getItem('pm_studio_locations_v2');
          if (s) setLocationsList(JSON.parse(s));
        } catch {}
      }
    };
    window.addEventListener('factory_locations_updated', handleLocUpdated);
    return () => window.removeEventListener('factory_locations_updated', handleLocUpdated);
  }, []);

  const [expandedLocations, setExpandedLocations] = useState<Record<string, boolean>>({});
  const [locationSearch, setLocationSearch] = useState('');
  const [newSubLocInputs, setNewSubLocInputs] = useState<Record<string, string>>({});
  const [isLocModalOpen, setIsLocModalOpen] = useState(false);
  const [isEditingLoc, setIsEditingLoc] = useState(false);
  const [locFormData, setLocFormData] = useState({ id: '', code: 'S01', name: '', description: '' });

  // ========================================================
  // پایگاه داده اپراتورها و پرسنل (مورد چهارم و پنجم: همگام با تمام کارت‌ها)
  // ========================================================
  const [operatorsList, setOperatorsList] = useState<ProductionOperator[]>(() => {
    try {
      const saved = localStorage.getItem('portal_production_operators_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return operators && operators.length > 0 ? operators : PRODUCTION_OPERATORS_LIST;
  });

  useEffect(() => {
    const handleOpUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setOperatorsList(e.detail);
      } else {
        try {
          const s = localStorage.getItem('portal_production_operators_v2');
          if (s) setOperatorsList(JSON.parse(s));
        } catch {}
      }
    };
    window.addEventListener('factory_operators_updated', handleOpUpdated);
    return () => window.removeEventListener('factory_operators_updated', handleOpUpdated);
  }, []);

  const [operatorSearch, setOperatorSearch] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');

  // مودال افزودن / ویرایش اپراتور
  const [isOperatorModalOpen, setIsOperatorModalOpen] = useState(false);
  const [isEditingOperator, setIsEditingOperator] = useState(false);
  const [operatorFormData, setOperatorFormData] = useState({
    id: '',
    name: '',
    personnelCode: '',
    department: 'تولید',
    shift: 'صبح',
    phone: ''
  });

  // ========================================================
  // لیست درخواست کارها
  // ========================================================
  const [requestsList, setRequestsList] = useState<PmWorkRequestItem[]>(() => {
    try {
      const stored = localStorage.getItem('portal_pm_work_requests_v3');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          return parsed.filter(
            (r: any) =>
              !r?.isScheduledPM &&
              !r?.pmSourceKey &&
              !/^PM(?:WR|WO)?\d+$/i.test(String(r?.code || '').trim())
          );
        }
      }
      return [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_pm_work_requests_v3', JSON.stringify(requestsList));
    } catch (e) {
      console.warn('Error saving PM work requests:', e);
    }
  }, [requestsList]);

  // مودال ایجاد درخواست کار و پرینت
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedRequestForPrint, setSelectedRequestForPrint] = useState<PmWorkRequestItem | null>(null);
  const [isWoPrintModalOpen, setIsWoPrintModalOpen] = useState(false);
  const [selectedWoForPrint, setSelectedWoForPrint] = useState<PmWorkRequestItem | null>(null);
  const [classDataVersion, setClassDataVersion] = useState(0);

  useEffect(() => {
    const handleClassDataUpdated = () => setClassDataVersion(v => v + 1);
    window.addEventListener('asset_class_data_updated', handleClassDataUpdated);
    return () => window.removeEventListener('asset_class_data_updated', handleClassDataUpdated);
  }, []);

  // فیلتر و جستجو در کارتابل درخواست‌ها
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<'all' | 'توقف تولید' | 'توقف تجهیز' | 'عدم توقف تجهیز'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'اضطراری' | 'اصلاحی' | 'پیشگیرانه'>('all');

  // صفحه‌بندی کارتابل درخواست‌ها (۱۰ ردیف در هر صفحه)
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // محاسبه کد درخواست بعدی
  const getNextWorkRequestCode = (): string => {
    try {
      let maxNum = 0;
      requestsList.forEach(r => {
        if (r.code && r.code.startsWith('WR')) {
          const num = parseInt(r.code.replace('WR', ''), 10);
          if (!isNaN(num) && num > maxNum) maxNum = num;
        }
      });
      return `WR${String(maxNum + 1).padStart(6, '0')}`;
    } catch {
      return 'WR000001';
    }
  };

  // دریافت تاریخ جاری شمسی (فرمت استاندارد)
  const getCurrentShamsiDateOnly = (): string => {
    try {
      const formatter = new Intl.DateTimeFormat('fa-IR-u-nu-latn', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
      return formatter.format(new Date());
    } catch {
      return '1405/08/23';
    }
  };

  // دریافت زمان جاری شمسی
  const getCurrentShamsiDateTime = (): string => {
    try {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const formatter = new Intl.DateTimeFormat('fa-IR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
      const parts = formatter.format(now);
      return `${timeStr} ${parts}`;
    } catch {
      return '10:00 1405/08/19';
    }
  };

  // لیست ترکیبی تکنسین‌های پیشگیرانه (PM) و خدمات فنی
  const combinedTechnicians = useMemo(() => {
    const set = new Set<string>();
    const addName = (raw: any) => {
      const clean = String(raw || '').trim();
      if (clean) set.add(clean);
    };

    if (Array.isArray(technicians)) {
      technicians.forEach(addName);
    }

    try {
      const tsSaved = localStorage.getItem('technicalServiceTechnicians');
      if (tsSaved) {
        const parsed = JSON.parse(tsSaved);
        if (Array.isArray(parsed)) parsed.forEach(addName);
      }
    } catch {}

    try {
      let deletedNames: string[] = [];
      const delRaw = localStorage.getItem('pm_studio_deleted_techs_v2');
      if (delRaw) {
        const parsedDel = JSON.parse(delRaw);
        if (Array.isArray(parsedDel)) deletedNames = parsedDel;
      }
      const pmSaved = localStorage.getItem('pm_studio_techs_v5');
      if (pmSaved) {
        const parsedPm = JSON.parse(pmSaved);
        if (Array.isArray(parsedPm)) {
          parsedPm.forEach((t: any) => {
            const name = typeof t === 'string' ? t : t?.name;
            if (name && !deletedNames.includes(name)) addName(name);
          });
        }
      }
    } catch {}

    return Array.from(set);
  }, [technicians, activeView]);

  // استخراج فعالیت‌های نگه‌داشت ثبت‌شده در خانواده تجهیز مربوطه
  const getFamilyMaintenanceActivities = (reqItem: PmWorkRequestItem | null) => {
    if (!reqItem) return [] as Array<{ id: string; code: string; title: string; type?: string; frequency?: string; role?: string }>;
    const famCode = (reqItem.equipmentFamilyCode || '').trim();
    const famName = (reqItem.equipmentFamilyName || '').trim();
    const eqCode = (reqItem.equipmentCode || '').trim();
    if (!famCode && !famName && !eqCode) return [];

    const famNameCompact = compactFaFamilyText(famName);
    const famNameTokens = tokenKeyFaFamilyText(famName);
    const matchedIds: string[] = [];
    const addId = (id: string) => {
      if (id && !matchedIds.includes(id)) matchedIds.push(id);
    };

    if (famCode) {
      const byCode = familyList.find(f => (f.id || '').toLowerCase() === famCode.toLowerCase());
      addId(byCode ? byCode.id : famCode);
    }
    if (famNameCompact) {
      familyList.forEach(f => {
        if (
          compactFaFamilyText(f.name || '') === famNameCompact ||
          (famNameTokens && tokenKeyFaFamilyText(f.name || '') === famNameTokens)
        ) {
          addId(f.id);
        }
      });
    }
    if (matchedIds.length === 0 && eqCode) {
      const matchedEq = equipmentList.find(eq => (eq.id || '').toLowerCase() === eqCode.toLowerCase());
      if (matchedEq?.family) {
        const eqFamC = compactFaFamilyText(matchedEq.family);
        const eqFamT = tokenKeyFaFamilyText(matchedEq.family);
        familyList.forEach(f => {
          if (
            compactFaFamilyText(f.name || '') === eqFamC ||
            (eqFamT && tokenKeyFaFamilyText(f.name || '') === eqFamT)
          ) {
            addId(f.id);
          }
        });
      }
      const byEqId = familyList.find(f => (f.id || '').toLowerCase() === eqCode.toLowerCase());
      if (byEqId) addId(byEqId.id);
    }

    const seen = new Set<string>();
    const results: Array<{ id: string; code: string; title: string; type?: string; frequency?: string; role?: string }> = [];
    matchedIds.forEach(fId => {
      try {
        const raw = localStorage.getItem(`pmworks_asset_class_data_${fId}`);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed?.maintenance)) {
          parsed.maintenance.forEach((m: any, idx: number) => {
            const title = String(m?.title || '').trim();
            const code = String(m?.code || '').trim();
            if (!title) return;
            const key = `${code}||${title}`;
            if (seen.has(key)) return;
            seen.add(key);
            results.push({
              id: m?.id || `${fId}-act-${idx}`,
              code,
              title,
              type: m?.type,
              frequency: m?.frequency,
              role: m?.role
            });
          });
        }
      } catch {}
    });

    return results;
  };

  // وضعیت مودال فرم دستور کار ۳ صفحه‌ای (مشخصات | فعالیت | وضعیت)
  const [woTargetRequest, setWoTargetRequest] = useState<PmWorkRequestItem | null>(null);
  const [isWorkOrderModalOpen, setIsWorkOrderModalOpen] = useState(false);
  const [woModalPage, setWoModalPage] = useState<1 | 2 | 3>(1);
  const [woNoticeToast, setWoNoticeToast] = useState<string | null>(null);
  const [woValidationError, setWoValidationError] = useState<string | null>(null);
  const [woActivityRangeEdited, setWoActivityRangeEdited] = useState(false);
  const [woActivitySearch, setWoActivitySearch] = useState('');
  const [isWoActivityDropdownOpen, setIsWoActivityDropdownOpen] = useState(false);
  const woActivityDropdownRef = useRef<HTMLDivElement>(null);

  const [woConsumableTab, setWoConsumableTab] = useState<'برقی' | 'مکانیکی' | 'سایر'>('مکانیکی');
  const [woShowPresetsBar, setWoShowPresetsBar] = useState(false);
  const [isWoSparePartsOpen, setIsWoSparePartsOpen] = useState(false);
  const [isWoDelaysOpen, setIsWoDelaysOpen] = useState(false);
  const [woNewPartName, setWoNewPartName] = useState('');
  const [woNewPartCount, setWoNewPartCount] = useState(1);
  const [woNewPartUnit, setWoNewPartUnit] = useState('عدد');

  const [woForm, setWoForm] = useState<{
    woCode: string;
    status: string;
    woStartDate: string;
    woStartTime: string;
    woEndDate: string;
    woEndTime: string;
    workDays: WoWorkDayEntry[];
    activities: WoActivityEntry[];
    technicians: WoTechnicianEntry[];
    consumables: WorkOrderConsumableItem[];
    delays: WoDelayEntry[];
    notes: string;
  }>({
    woCode: '',
    status: 'در حال اقدام',
    woStartDate: '',
    woStartTime: '08:00',
    woEndDate: '',
    woEndTime: '10:00',
    workDays: [],
    activities: [],
    technicians: [],
    consumables: [],
    delays: [],
    notes: ''
  });

  const woFamilyMaintenanceActivities = useMemo(() => {
    return getFamilyMaintenanceActivities(woTargetRequest);
  }, [woTargetRequest, familyList, equipmentList, classDataVersion, isWorkOrderModalOpen]);

  const filteredWoFamilyActivities = useMemo(() => {
    const q = normalizeFaFamilyText(woActivitySearch);
    if (!q) return woFamilyMaintenanceActivities;
    return woFamilyMaintenanceActivities.filter(a =>
      normalizeFaFamilyText(a.title).includes(q) ||
      normalizeFaFamilyText(a.code).includes(q)
    );
  }, [woFamilyMaintenanceActivities, woActivitySearch]);

  const unifiedInventoryParts = useMemo(() => {
    try {
      return getUnifiedSpareParts();
    } catch {
      return [];
    }
  }, [isWorkOrderModalOpen]);

  const calcTechRowHours = (sDate: string, sTime: string, eDate: string, eTime: string, fallbackHours = 1): number => {
    const mins = computeMinutesBetweenShamsiDateTimes(sDate, sTime, eDate, eTime);
    if (mins > 0) return Math.round((mins / 60) * 100) / 100;
    return fallbackHours;
  };

  const handleOpenWorkOrderForm = (item: PmWorkRequestItem) => {
    const todayStr = getCurrentShamsiDateOnly();
    const now = new Date();
    const nowTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const resolveDefaultWoCode = (rawCode?: string) => {
      const c = String(rawCode || '').trim();
      if (!c) return '';
      if (/^(PM|WO)/i.test(c)) return c;
      if (c.startsWith('WR')) return c.replace(/^WR/, 'WO');
      return `WO-${c}`;
    };
    const defaultWoCode =
      item.woCode ||
      item.workOrderCode ||
      resolveDefaultWoCode(item.code);

    const parsedStart = extractShamsiDateAndTime(
      item.woStartDate ? `${item.woStartDate} ${item.woStartTimeOnly || ''}` : (item.woStartTime || item.requestTime),
      todayStr,
      '08:00'
    );
    const parsedEnd = extractShamsiDateAndTime(
      item.woEndDate ? `${item.woEndDate} ${item.woEndTimeOnly || ''}` : (item.woEndTime || item.completedAt),
      todayStr,
      nowTimeStr
    );

    const initialTechs: WoTechnicianEntry[] =
      Array.isArray(item.woTechnicians) && item.woTechnicians.length > 0
        ? item.woTechnicians.map((t: any, idx: number) => {
            const sDate = t.startDate || t.date || parsedStart.date || todayStr;
            const eDate = t.endDate || t.startDate || t.date || parsedEnd.date || todayStr;
            const sTime = t.startTime || '08:00';
            const eTime = t.endTime || '09:00';
            const computedHrs = calcTechRowHours(sDate, sTime, eDate, eTime, Number(t.hours) || 1);
            return {
              id: t.id || `wt-${Date.now()}-${idx}`,
              name: t.name || '',
              startDate: sDate,
              startTime: sTime,
              endDate: eDate,
              endTime: eTime,
              hours: t.customHours && Number(t.hours) > 0 ? Number(t.hours) : (t.startTime && t.endTime ? computedHrs : (Number(t.hours) || computedHrs)),
              customStartDate: Boolean(t.customStartDate),
              customStartTime: Boolean(t.customStartTime),
              customEndDate: Boolean(t.customEndDate),
              customEndTime: Boolean(t.customEndTime),
              customHours: Boolean(t.customHours)
            };
          })
        : item.technician
        ? [
            {
              id: `wt-${Date.now()}-0`,
              name: item.technician,
              startDate: parsedStart.date,
              startTime: parsedStart.time,
              endDate: parsedEnd.date,
              endTime: parsedEnd.time,
              hours: item.durationMinutes
                ? Math.round((item.durationMinutes / 60) * 100) / 100
                : calcTechRowHours(parsedStart.date, parsedStart.time, parsedEnd.date, parsedEnd.time, 1)
            },
            ...(Array.isArray(item.coTechnicians)
              ? item.coTechnicians.map((co, idx) => ({
                  id: `wt-${Date.now()}-${idx + 1}`,
                  name: co,
                  startDate: parsedStart.date,
                  startTime: parsedStart.time,
                  endDate: parsedEnd.date,
                  endTime: parsedEnd.time,
                  hours: calcTechRowHours(parsedStart.date, parsedStart.time, parsedEnd.date, parsedEnd.time, 1)
                }))
              : [])
          ]
        : [];

    setWoTargetRequest(item);
    setWoModalPage(1);
    setWoActivitySearch('');
    setIsWoActivityDropdownOpen(false);
    setWoConsumableTab('مکانیکی');
    setWoShowPresetsBar(false);
    setIsWoSparePartsOpen(false);
    setIsWoDelaysOpen(false);
    setWoNewPartName('');
    setWoNewPartCount(1);
    setWoNewPartUnit('عدد');
    setWoValidationError(null);
    setWoActivityRangeEdited(Boolean(item.woStartDate || item.woEndDate));
    setClassDataVersion(v => v + 1);
    const initStartDate = item.woStartDate || parsedStart.date;
    const initStartTime = item.woStartTimeOnly || parsedStart.time;
    const initEndDate = item.woEndDate || parsedEnd.date;
    const initEndTime = item.woEndTimeOnly || parsedEnd.time;
    const initialWorkDays: WoWorkDayEntry[] =
      Array.isArray(item.woWorkDays) && item.woWorkDays.length > 0
        ? item.woWorkDays.map((wd, idx) => ({
            id: wd.id || `wd-${Date.now()}-${idx + 1}`,
            startDate: wd.startDate || initStartDate,
            startTime: wd.startTime || initStartTime,
            endDate: wd.endDate || initEndDate,
            endTime: wd.endTime || initEndTime
          }))
        : [
            {
              id: `wd-${Date.now()}-1`,
              startDate: initStartDate,
              startTime: initStartTime,
              endDate: initEndDate,
              endTime: initEndTime
            }
          ];

    setWoForm({
      woCode: defaultWoCode,
      status: item.status === 'لغو شده' ? 'لغو' : (item.status === 'در حال اقدام' ? 'در انتظار دستور برنامه ریزی' : (item.status || 'در انتظار دستور برنامه ریزی')),
      woStartDate: initialWorkDays[0].startDate,
      woStartTime: initialWorkDays[0].startTime,
      woEndDate: initialWorkDays[initialWorkDays.length - 1].endDate,
      woEndTime: initialWorkDays[initialWorkDays.length - 1].endTime,
      workDays: initialWorkDays,
      activities: Array.isArray(item.woActivities) ? item.woActivities : [],
      technicians: initialTechs,
      consumables: Array.isArray(item.consumables) ? item.consumables : [],
      delays: Array.isArray(item.woDelays) ? item.woDelays : [],
      notes: item.woNotes || ''
    });
    setIsWorkOrderModalOpen(true);
  };

  const handleAddWoWorkDay = () => {
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      const currentDays: WoWorkDayEntry[] =
        prev.workDays.length > 0
          ? prev.workDays
          : [
              {
                id: `wd-${Date.now()}-1`,
                startDate: prev.woStartDate || getCurrentShamsiDateOnly(),
                startTime: prev.woStartTime || '08:00',
                endDate: prev.woEndDate || getCurrentShamsiDateOnly(),
                endTime: prev.woEndTime || '10:00'
              }
            ];
      const last = currentDays[currentDays.length - 1];
      const nextDate = addShamsiDaysPm(last.endDate || last.startDate || getCurrentShamsiDateOnly(), 1);
      const nextDays: WoWorkDayEntry[] = [
        ...currentDays,
        {
          id: `wd-${Date.now()}-${currentDays.length + 1}`,
          startDate: nextDate,
          startTime: last.startTime || '08:00',
          endDate: nextDate,
          endTime: last.endTime || '16:00'
        }
      ];
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleUpdateWoWorkDay = (
    wdId: string,
    field: 'startDate' | 'startTime' | 'endDate' | 'endTime',
    value: string
  ) => {
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      const baseDays: WoWorkDayEntry[] =
        prev.workDays.length > 0
          ? prev.workDays
          : [
              {
                id: wdId,
                startDate: prev.woStartDate || getCurrentShamsiDateOnly(),
                startTime: prev.woStartTime || '08:00',
                endDate: prev.woEndDate || getCurrentShamsiDateOnly(),
                endTime: prev.woEndTime || '10:00'
              }
            ];
      const nextDays = baseDays.map(d => (d.id === wdId ? { ...d, [field]: value } : d));
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleRemoveWoWorkDay = (wdId: string) => {
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      if (prev.workDays.length <= 1) return prev;
      const nextDays = prev.workDays.filter(d => d.id !== wdId);
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleAddWoActivity = (act: { id: string; code: string; title: string }) => {
    setWoForm(prev => ({
      ...prev,
      activities: [
        ...prev.activities,
        {
          id: `woa-${Date.now()}-${prev.activities.length + 1}`,
          code: act.code,
          title: act.title,
          startDate: prev.woStartDate || getCurrentShamsiDateOnly(),
          startTime: prev.woStartTime || '08:00',
          endDate: prev.woEndDate || getCurrentShamsiDateOnly(),
          endTime: prev.woEndTime || '10:00'
        }
      ]
    }));
    setWoActivitySearch('');
    setIsWoActivityDropdownOpen(false);
    setWoValidationError(null);
  };

  const handleAddWoTechnician = (techName?: string) => {
    const todayStr = getCurrentShamsiDateOnly();
    const fallbackName = techName || combinedTechnicians[0] || '';
    setWoForm(prev => {
      const firstTech = prev.technicians[0];
      const inheritedStartDate = firstTech?.startDate || prev.woStartDate || todayStr;
      const inheritedStartTime = firstTech?.startTime || prev.woStartTime || '08:00';
      const inheritedEndDate = firstTech?.endDate || prev.woEndDate || inheritedStartDate;
      const inheritedEndTime = firstTech?.endTime || prev.woEndTime || '09:00';
      const inheritedHours = calcTechRowHours(
        inheritedStartDate,
        inheritedStartTime,
        inheritedEndDate,
        inheritedEndTime,
        1
      );
      return {
        ...prev,
        technicians: [
          ...prev.technicians,
          {
            id: `wot-${Date.now()}-${prev.technicians.length + 1}`,
            name: fallbackName,
            startDate: inheritedStartDate,
            startTime: inheritedStartTime,
            endDate: inheritedEndDate,
            endTime: inheritedEndTime,
            hours: inheritedHours,
            customStartDate: false,
            customStartTime: false,
            customEndDate: false,
            customEndTime: false,
            customHours: false
          }
        ]
      };
    });
  };

  const handleAddWoConsumablePreset = (pName: string, cat: 'برقی' | 'مکانیکی' | 'سایر') => {
    setWoForm(prev => {
      const existing = prev.consumables.find(c => c.name === pName && c.category === cat);
      if (existing) {
        return {
          ...prev,
          consumables: prev.consumables.map(c =>
            c.id === existing.id ? { ...c, count: c.count + 1 } : c
          )
        };
      }
      return {
        ...prev,
        consumables: [
          ...prev.consumables,
          { id: `woc-${Date.now()}-${prev.consumables.length + 1}`, name: pName, count: 1, category: cat, unit: 'عدد' }
        ]
      };
    });
  };

  const handleAddWoCustomConsumable = () => {
    const cleanName = woNewPartName.trim();
    if (!cleanName) return;
    setWoForm(prev => {
      const existing = prev.consumables.find(c => c.name === cleanName && c.category === woConsumableTab);
      if (existing) {
        return {
          ...prev,
          consumables: prev.consumables.map(c =>
            c.id === existing.id ? { ...c, count: c.count + Math.max(1, woNewPartCount) } : c
          )
        };
      }
      return {
        ...prev,
        consumables: [
          ...prev.consumables,
          {
            id: `woc-${Date.now()}-${prev.consumables.length + 1}`,
            name: cleanName,
            count: Math.max(1, woNewPartCount),
            category: woConsumableTab,
            unit: woNewPartUnit || 'عدد'
          }
        ]
      };
    });
    setWoNewPartName('');
    setWoNewPartCount(1);
  };

  const handleAddWoDelay = () => {
    setWoForm(prev => ({
      ...prev,
      delays: [
        ...prev.delays,
        {
          id: `wod-${Date.now()}-${prev.delays.length + 1}`,
          code: '',
          title: '',
          days: 0,
          hours: 0
        }
      ]
    }));
  };

  const handleSaveWorkOrder = (overrideStatus?: string) => {
    if (!woTargetRequest) return;
    if (isArchivedWorkOrderItem(woTargetRequest)) return;
    const rawStatus = overrideStatus || woForm.status || 'در انتظار دستور برنامه ریزی';
    const finalStatus = rawStatus === 'انجام شده' ? 'انجام شد' : (rawStatus === 'لغو شده' ? 'لغو' : rawStatus);

    if (finalStatus === 'انجام شد' && woForm.activities.length === 0) {
      setWoValidationError('برای تغییر وضعیت دستور کار به «انجام شده»، ثبت حداقل یک فعالیت نگه‌داشت در تب «فعالیت» الزامی است.');
      setWoModalPage(3);
      return;
    }
    setWoValidationError(null);

    const validTechs = woForm.technicians
      .filter(t => t.name && t.name.trim())
      .map(t => {
        const calcMins = computeMinutesBetweenShamsiDateTimes(t.startDate, t.startTime, t.endDate, t.endTime);
        const effHours = !t.customHours && calcMins > 0 ? Math.round((calcMins / 60) * 100) / 100 : (Number(t.hours) || 0);
        return { ...t, hours: effHours };
      });

    const uniqueTechNames = Array.from(new Set(validTechs.map(t => t.name.trim())));
    const primaryTech = uniqueTechNames[0] || undefined;
    const coTechs = uniqueTechNames.slice(1);
    const totalTechHours = validTechs.reduce((sum, t) => sum + Math.max(0, Number(t.hours) || 0), 0);
    const techDurationMinutes = totalTechHours > 0 ? Math.round(totalTechHours * 60) : 0;

    // محاسبه دقیق خواب تجهیز از صفحه سوم (وضعیت) به عنوان مبنای اصلی قابلیت اطمینان و گزارش‌ها
    const equipmentDowntimeMinutes = computeMinutesBetweenShamsiDateTimes(
      woForm.woStartDate,
      woForm.woStartTime,
      woForm.woEndDate,
      woForm.woEndTime
    );
    const durationMinutes = equipmentDowntimeMinutes > 0
      ? equipmentDowntimeMinutes
      : (techDurationMinutes > 0 ? techDurationMinutes : woTargetRequest.durationMinutes);

    const woStartTime = `${woForm.woStartDate || ''} - ${woForm.woStartTime || ''}`.trim();
    const woEndTime = `${woForm.woEndDate || ''} - ${woForm.woEndTime || ''}`.trim();

    const partsUsedText = woForm.consumables
      .map(c => `${c.name} (${c.count} ${c.unit || 'عدد'})`)
      .join('، ');

    const normalizedActivities: WoActivityEntry[] = woForm.activities.map(a => ({
      ...a,
      startDate: woForm.woStartDate || a.startDate,
      startTime: woForm.woStartTime || a.startTime,
      endDate: woForm.woEndDate || a.endDate,
      endTime: woForm.woEndTime || a.endTime
    }));

    const actSummaryLines = normalizedActivities.map(
      a => `${a.code ? `[${a.code}] ` : ''}${a.title}`
    );
    const techSummaryLines = validTechs.map(
      t => `${t.name}: ${t.hours} ساعت (${t.startDate} ${t.startTime || ''} تا ${t.endDate} ${t.endTime || ''})`
    );
    const delaySummaryLines = woForm.delays
      .filter(d => d.code.trim() || d.title.trim() || Number(d.days) > 0 || Number(d.hours) > 0)
      .map(d => `تاخیر ${d.code ? `[${d.code}] ` : ''}${d.title || '—'}: ${Number(d.days) || 0} روز و ${Number(d.hours) || 0} ساعت`);

    const actionDetailsParts = [
      actSummaryLines.length > 0
        ? `فعالیت‌ها: ${actSummaryLines.join(' ، ')}${woStartTime && woEndTime ? ` (${woStartTime} تا ${woEndTime})` : ''}`
        : '',
      techSummaryLines.length > 0 ? `تکنسین‌ها: ${techSummaryLines.join(' | ')}` : '',
      equipmentDowntimeMinutes > 0 ? `خواب تجهیز: ${formatMinutesDurationFa(equipmentDowntimeMinutes)} (${woStartTime} تا ${woEndTime})` : '',
      delaySummaryLines.length > 0 ? delaySummaryLines.join(' | ') : '',
      woForm.notes.trim() ? `توضیحات: ${woForm.notes.trim()}` : ''
    ].filter(Boolean);

    const fallbackWoFromCode = (rawCode?: string) => {
      const c = String(rawCode || '').trim();
      if (/^(PM|WO)/i.test(c)) return c;
      if (c.startsWith('WR')) return c.replace(/^WR/, 'WO');
      return c;
    };
    const resolvedWoCode = woForm.woCode.trim() || woTargetRequest.woCode || fallbackWoFromCode(woTargetRequest.code);

    const updatedItem: PmWorkRequestItem = {
      ...woTargetRequest,
      woCode: resolvedWoCode,
      workOrderCode: resolvedWoCode,
      status: finalStatus,
      technician: primaryTech,
      coTechnicians: coTechs.length > 0 ? coTechs : undefined,
      durationMinutes,
      equipmentDowntimeMinutes,
      downtimeMinutes: equipmentDowntimeMinutes,
      woStartDate: woForm.woStartDate,
      woStartTimeOnly: woForm.woStartTime,
      woEndDate: woForm.woEndDate,
      woEndTimeOnly: woForm.woEndTime,
      woStartTime,
      woEndTime,
      completedAt: finalStatus === 'انجام شد' ? (woEndTime || getCurrentShamsiDateTime()) : woTargetRequest.completedAt,
      woWorkDays: woForm.workDays,
      woActivities: normalizedActivities,
      woTechnicians: validTechs,
      consumables: woForm.consumables,
      partsUsed: partsUsedText || undefined,
      woDelays: woForm.delays,
      woNotes: woForm.notes.trim() || undefined,
      actionDetails: actionDetailsParts.join(' — ') || woTargetRequest.actionDetails,
      isArchivedWorkOrder: true
    };

    // فقط دستور کارهای پیشگیرانه (PM) اجازه به‌روزرسانی آمار تکنسین‌های PM را دارند (موارد EM و CM هرگز وارد PM نمی‌شوند)
    const isPmWorkOrder = isStrictPmRecord(updatedItem);

    setRequestsList(prev => {
      const next = prev.map(r => (r.id === updatedItem.id || r.code === updatedItem.code ? updatedItem : r));
      try {
        localStorage.setItem('portal_pm_work_requests_v3', JSON.stringify(next));
        syncAndReconcilePmTechStorage({ portalWorkRequests: next });
        if (isPmWorkOrder || localStorage.getItem('pm_studio_techs_v5')) {
          window.dispatchEvent(new CustomEvent('pm_tech_hours_reconcile'));
        }
      } catch {}
      return next;
    });
    if (onSyncWithServer) {
      onSyncWithServer(updatedItem);
    }

    setIsWorkOrderModalOpen(false);
    setWoTargetRequest(null);
    setWoNoticeToast(`✓ دستور کار ${updatedItem.woCode} ثبت شد و به «بایگانی دستور کار» منتقل گردید.`);
    setTimeout(() => setWoNoticeToast(null), 6000);
  };

  // وضعیت ورودی فرم ایجاد درخواست کار
  const [formData, setFormData] = useState({
    code: '',
    equipmentCode: '',
    equipmentName: '',
    equipmentFamilyCode: '',
    equipmentFamilyName: '',
    locationCode: 'S01',
    locationName: 'سالن یک_طبقه همکف_تولید',
    failureCode: '',
    failureTitle: '',
    priority: 'توقف تجهیز' as 'توقف تولید' | 'توقف تجهیز' | 'عدم توقف تجهیز',
    requestType: 'اضطراری' as 'اضطراری' | 'اصلاحی' | 'پیشگیرانه',
    requestTime: '',
    operatorName: '',
    operatorPersonnelCode: '',
    description: ''
  });

  // کنترل باز بودن لیست کشویی اتوکامپلیت هنگام تایپ کد تجهیز
  const [isEqDropdownVisible, setIsEqDropdownVisible] = useState(false);
  const eqInputContainerRef = useRef<HTMLDivElement>(null);

  // کنترل باز بودن لیست سرچ سریع حالت خرابی مرتبط با خانواده تجهیز انتخابی
  const [isFailureDropdownVisible, setIsFailureDropdownVisible] = useState(false);
  const failureInputContainerRef = useRef<HTMLDivElement>(null);

  // کنترل باز بودن لیست و جستجوی سریع اپراتور در مودال
  const [isOpDropdownVisible, setIsOpDropdownVisible] = useState(false);
  const [operatorSearchQuery, setOperatorSearchQuery] = useState('');
  const opInputContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (eqInputContainerRef.current && !eqInputContainerRef.current.contains(event.target as Node)) {
        setIsEqDropdownVisible(false);
      }
      if (failureInputContainerRef.current && !failureInputContainerRef.current.contains(event.target as Node)) {
        setIsFailureDropdownVisible(false);
      }
      if (opInputContainerRef.current && !opInputContainerRef.current.contains(event.target as Node)) {
        setIsOpDropdownVisible(false);
      }
      if (woActivityDropdownRef.current && !woActivityDropdownRef.current.contains(event.target as Node)) {
        setIsWoActivityDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // فیلتر سریع لیست اپراتورها برای انتخاب در فرم ایجاد درخواست کار
  const filteredOperatorsForForm = useMemo(() => {
    const q = (operatorSearchQuery || '').toLowerCase().trim();
    if (!q) return operatorsList.slice(0, 30);
    return operatorsList.filter(op =>
      (op.name || '').toLowerCase().includes(q) ||
      (op.personnelCode || '').toLowerCase().includes(q) ||
      (op.department || '').toLowerCase().includes(q)
    ).slice(0, 40);
  }, [operatorsList, operatorSearchQuery]);

  // باز کردن فرم ایجاد جدید
  const handleOpenCreateModal = () => {
    setFormData({
      code: getNextWorkRequestCode(),
      equipmentCode: '',
      equipmentName: '',
      equipmentFamilyCode: '',
      equipmentFamilyName: '',
      locationCode: 'S01',
      locationName: 'سالن یک_طبقه همکف_تولید',
      failureCode: '',
      failureTitle: '',
      priority: 'توقف تجهیز',
      requestType: 'اضطراری',
      requestTime: getCurrentShamsiDateTime(),
      operatorName: operatorsList[0]?.name || '',
      operatorPersonnelCode: operatorsList[0]?.personnelCode || '',
      description: ''
    });
    setOperatorSearchQuery('');
    setIsOpDropdownVisible(false);
    setIsFailureDropdownVisible(false);
    setClassDataVersion(v => v + 1);
    setIsCreateModalOpen(true);
  };

  // استخراج خانواده، نام و سالن برای تجهیز انتخابی
  const extractEquipmentDetails = (eq: any) => {
    const code = eq.id || eq.code || '';
    const name = eq.name || '';
    const eqFamCompact = compactFaFamilyText(eq.family || '');
    const eqFamTokens = tokenKeyFaFamilyText(eq.family || '');

    const matchedFamily =
      (eqFamCompact && familyList.find(f => compactFaFamilyText(f.name || '') === eqFamCompact)) ||
      (eqFamTokens && familyList.find(f => tokenKeyFaFamilyText(f.name || '') === eqFamTokens)) ||
      (code && familyList.find(f => (f.id || '').toUpperCase() === code.toUpperCase()));

    let familyCode = matchedFamily?.id || '';
    let familyName = eq.family || matchedFamily?.name || '';

    if (!familyCode) {
      if (code.startsWith('TUTN')) {
        familyCode = 'TUTN';
        familyName = familyName || `تراش تورنوس سوئیسی (${name})`;
      } else if (code.startsWith('TUCT')) {
        familyCode = 'TUCT';
        familyName = familyName || `تراش تورنوس CT (${name})`;
      } else if (code.startsWith('TULT')) {
        familyCode = 'TULT';
        familyName = familyName || `تراش CNC (${name})`;
      } else if (code.startsWith('TUMN')) {
        familyCode = 'TUMN';
        familyName = familyName || `تراش دستی Manual (${name})`;
      } else if (code.startsWith('MICN')) {
        familyCode = 'MICN';
        familyName = familyName || `فرزکاری CNC (${name})`;
      } else if (code.startsWith('MIDR')) {
        familyCode = 'MIDR';
        familyName = familyName || `دریل فرز (${name})`;
      } else if (code.startsWith('TUMA')) {
        familyCode = 'TUMA';
        familyName = familyName || `تراش مایر اختصاصی (${name})`;
      } else if (code.startsWith('TUSY')) {
        familyCode = 'TUSY';
        familyName = familyName || `تراش سینتک AXIS (${name})`;
      } else if (code.startsWith('TUST')) {
        familyCode = 'TUST';
        familyName = familyName || `تراش استار (${name})`;
      } else if (code.startsWith('PR')) {
        familyCode = 'PR';
        familyName = familyName || `پرس‌های هیدرولیک (${name})`;
      } else {
        familyCode = eq.family || 'GEN';
        familyName = familyName || `${eq.family || 'خانواده تجهیز'} - ${name}`;
      }
    }

    let locName = eq.location || 'سالن یک_طبقه همکف_تولید';
    let locCode = 'S01';
    if (locName.includes('S02') || locName.includes('دو')) locCode = 'S02';
    else if (locName.includes('S03') || locName.includes('سه')) locCode = 'S03';
    else if (locName.includes('S04') || locName.includes('بیومواد')) locCode = 'S04';
    else if (locName.includes('S05') || locName.includes('پروتز')) locCode = 'S05';
    else if (locName.includes('S06') || locName.includes('پرس')) locCode = 'S06';
    else if (locName.includes('S07') || locName.includes('محوطه')) locCode = 'S07';
    else if (locName.includes('S08') || locName.includes('خارج')) locCode = 'S08';

    return { code, name, familyCode, familyName, locCode, locName };
  };

  // انتخاب تجهیز و پر شدن خودکار تمام فیلدها
  const handleSelectEquipmentForRequest = (eq: any) => {
    const details = extractEquipmentDetails(eq);
    setFormData(prev => ({
      ...prev,
      equipmentCode: details.code,
      equipmentName: details.name || details.familyName,
      equipmentFamilyCode: details.familyCode,
      equipmentFamilyName: details.familyName,
      locationCode: details.locCode,
      locationName: details.locName,
      failureCode: '',
      failureTitle: ''
    }));
    setIsEqDropdownVisible(false);
    setIsFailureDropdownVisible(false);
  };

  // استخراج حالت‌های خرابی ثبت‌شده منحصراً برای خانواده تجهیز انتخاب‌شده
  const selectedFamilyFailureInfo = useMemo(() => {
    const famCode = formData.equipmentFamilyCode.trim();
    const famName = formData.equipmentFamilyName.trim();
    const eqCode = formData.equipmentCode.trim();
    const hasSelectedEquipment = Boolean(famCode || famName || eqCode);

    if (!hasSelectedEquipment) {
      return {
        hasSelectedEquipment: false,
        familyLabel: '',
        items: [] as Array<{ id: string; code: string; title: string }>
      };
    }

    const famNameCompact = compactFaFamilyText(famName);
    const famNameTokens = tokenKeyFaFamilyText(famName);

    const matchedFamilyIds: string[] = [];
    let matchedFamilyLabel = famName || famCode;

    const addFamId = (id: string, name?: string) => {
      if (id && !matchedFamilyIds.includes(id)) {
        matchedFamilyIds.push(id);
        if (!matchedFamilyLabel && name) matchedFamilyLabel = name;
      }
    };

    if (famCode) {
      const byCode = familyList.find(f => (f.id || '').toLowerCase() === famCode.toLowerCase());
      addFamId(byCode ? byCode.id : famCode, byCode?.name);
    }
    if (famNameCompact) {
      familyList.forEach(f => {
        if (
          compactFaFamilyText(f.name || '') === famNameCompact ||
          (famNameTokens && tokenKeyFaFamilyText(f.name || '') === famNameTokens)
        ) {
          addFamId(f.id, f.name);
        }
      });
    }
    if (matchedFamilyIds.length === 0 && eqCode) {
      const byEqId = familyList.find(f => (f.id || '').toLowerCase() === eqCode.toLowerCase());
      if (byEqId) addFamId(byEqId.id, byEqId.name);
    }

    const seen = new Set<string>();
    const items: Array<{ id: string; code: string; title: string }> = [];

    matchedFamilyIds.forEach(fId => {
      try {
        const raw = localStorage.getItem(`pmworks_asset_class_data_${fId}`);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed?.failures)) {
          parsed.failures.forEach((fl: any, idx: number) => {
            const title = String(fl?.title || '').trim();
            const code = String(fl?.code || '').trim();
            if (!title) return;
            const key = `${code}||${title}`;
            if (seen.has(key)) return;
            seen.add(key);
            items.push({
              id: fl?.id || `${fId}-${idx}`,
              code,
              title
            });
          });
        }
      } catch {}
    });

    return {
      hasSelectedEquipment: true,
      familyLabel: matchedFamilyLabel,
      items
    };
  }, [
    formData.equipmentCode,
    formData.equipmentFamilyCode,
    formData.equipmentFamilyName,
    familyList,
    isCreateModalOpen,
    classDataVersion
  ]);

  const filteredFamilyFailureModes = useMemo(() => {
    const q = normalizeFaFamilyText(formData.failureTitle);
    if (!q) return selectedFamilyFailureInfo.items;
    return selectedFamilyFailureInfo.items.filter(item =>
      normalizeFaFamilyText(item.title).includes(q) ||
      normalizeFaFamilyText(item.code).includes(q)
    );
  }, [selectedFamilyFailureInfo.items, formData.failureTitle]);

  // فیلتر کم‌کم و زنده تجهیزات هنگام تایپ در اینپوت کد یا نام تجهیز (مورد دوم کاربر)
  const liveFilteredEquipments = useMemo(() => {
    const q = formData.equipmentCode.trim().toLowerCase();
    if (!q) return equipmentList;
    return equipmentList.filter(eq => {
      const matchId = (eq.id || '').toLowerCase().includes(q);
      const matchName = (eq.name || '').toLowerCase().includes(q);
      const matchFam = (eq.family || '').toLowerCase().includes(q);
      const matchLoc = (eq.location || '').toLowerCase().includes(q);
      return matchId || matchName || matchFam || matchLoc;
    });
  }, [equipmentList, formData.equipmentCode]);

  // انتخاب مکان از بخش مکان‌ها برای درخواست کار
  const handleSelectLocationForRequest = (loc: any, subLocName?: string) => {
    const fullName = subLocName ? `${loc.name}_${subLocName}` : loc.name;
    setFormData(prev => ({
      ...prev,
      locationCode: loc.code,
      locationName: fullName
    }));
    setIsCreateModalOpen(true);
    setActiveView('requests');
  };

  // انتخاب اپراتور برای درخواست کار
  const handleSelectOperator = (op: ProductionOperator) => {
    setFormData(prev => ({
      ...prev,
      operatorName: op.name,
      operatorPersonnelCode: op.personnelCode
    }));
    setIsCreateModalOpen(true);
    setActiveView('requests');
  };

  // ذخیره فرم درخواست کار
  const handleSaveWorkRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.equipmentCode.trim()) {
      alert('لطفاً کد تجهیز را وارد نمایید یا یک تجهیز انتخاب کنید.');
      return;
    }

    const newReq: PmWorkRequestItem = {
      id: `pwr-${Date.now()}`,
      code: formData.code || getNextWorkRequestCode(),
      equipmentName: formData.equipmentName || 'تجهیز صنعتی',
      equipmentCode: formData.equipmentCode,
      locationName: formData.locationName || 'سالن تولید',
      locationCode: formData.locationCode || 'S01',
      requestTime: formData.requestTime || getCurrentShamsiDateTime(),
      equipmentFamilyName: formData.equipmentFamilyName || 'خانواده تجهیز',
      equipmentFamilyCode: formData.equipmentFamilyCode || '',
      failureTitle: formData.failureTitle || 'اعلام نقص فنی',
      failureCode: formData.failureCode || '',
      priority: formData.priority,
      description: formData.description || '—',
      requestType: formData.requestType,
      status: 'در انتظار دستور برنامه ریزی',
      operatorName: formData.operatorName || 'اپراتور شیفت',
      operatorPersonnelCode: formData.operatorPersonnelCode || '',
      timestamp: Date.now()
    };

    setRequestsList(prev => [newReq, ...prev]);

    if (onSyncWithServer) {
      onSyncWithServer(newReq);
    }

    setIsCreateModalOpen(false);
    setSelectedRequestForPrint(newReq);
    setIsPrintModalOpen(true);
  };

  const isArchivedWorkOrderItem = (item: PmWorkRequestItem): boolean =>
    Boolean(item?.isArchivedWorkOrder) ||
    item?.status === 'انجام شد' ||
    item?.status === 'انجام شده' ||
    item?.status === 'لغو' ||
    item?.status === 'لغو شده';

  const activeRequestsList = useMemo(
    () => requestsList.filter(item => !isArchivedWorkOrderItem(item)),
    [requestsList]
  );

  const archivedWorkOrdersList = useMemo(
    () => requestsList.filter(isArchivedWorkOrderItem),
    [requestsList]
  );

  const matchesWorkRequestFilters = (item: PmWorkRequestItem) => {
    if (priorityFilter !== 'all' && item.priority !== priorityFilter) return false;
    if (typeFilter !== 'all' && item.requestType !== typeFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchCode = (item.code || '').toLowerCase().includes(q);
      const matchWoCode = (item.woCode || item.workOrderCode || '').toLowerCase().includes(q);
      const matchEq = (item.equipmentName || '').toLowerCase().includes(q);
      const matchEqCode = (item.equipmentCode || '').toLowerCase().includes(q);
      const matchLoc = (item.locationName || '').toLowerCase().includes(q);
      const matchFam = (item.equipmentFamilyName || '').toLowerCase().includes(q);
      const matchFail = (item.failureTitle || '').toLowerCase().includes(q);
      if (!matchCode && !matchWoCode && !matchEq && !matchEqCode && !matchLoc && !matchFam && !matchFail) return false;
    }
    return true;
  };

  // فیلتر رکوردهای جدول کارتابل درخواست کار (فقط موارد باز که هنوز بایگانی نشده‌اند)
  const filteredRequests = useMemo(() => {
    return activeRequestsList.filter(matchesWorkRequestFilters);
  }, [activeRequestsList, priorityFilter, typeFilter, searchQuery]);

  // فیلتر رکوردهای بایگانی دستور کار
  const filteredArchivedWorkOrders = useMemo(() => {
    return archivedWorkOrdersList.filter(matchesWorkRequestFilters);
  }, [archivedWorkOrdersList, priorityFilter, typeFilter, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredRequests.length / pageSize));
  const paginatedRequests = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRequests.slice(start, start + pageSize);
  }, [filteredRequests, currentPage, pageSize]);

  // ========================================================
  // همگام‌سازی و ذخیره تجهیزات در همه کارت‌ها (مورد پنجم)
  // ========================================================
  const broadcastEquipmentsUpdate = (updatedList: any[]) => {
    setEquipmentList(updatedList);
    try {
      localStorage.setItem('pm_studio_equipments_v13', JSON.stringify(updatedList));
      const portalFormatted: EquipmentItem[] = updatedList.map(eq => ({
        id: eq.id,
        code: eq.id,
        name: eq.name,
        category: eq.family || 'سایر',
        hall: eq.location || 'سالن تولید',
        operatorName: 'تیم فنی',
        status: 'سالم',
        lastInspectionDate: '۱۴۰۵/۰۸/۱۹',
        inspector: 'مسئول PM',
        criticalChecks: ['بازرسی عمومی', 'روانکاری'],
        updatedAt: Date.now()
      }));
      localStorage.setItem('portal_equipments_v9', JSON.stringify(portalFormatted));
      if (onUpdateEquipments) onUpdateEquipments(portalFormatted);
    } catch {}
    window.dispatchEvent(new CustomEvent('factory_equipments_updated', { detail: updatedList }));
  };

  const saveEquipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eqFormData.id.trim() || !eqFormData.name.trim()) return;

    let updated: any[];
    if (isEditingEq) {
      updated = equipmentList.map(eq => eq.id === eqFormData.id ? eqFormData : eq);
    } else {
      if (equipmentList.some(eq => eq.id === eqFormData.id)) {
        alert('کد تجهیز تکراری است.');
        return;
      }
      updated = [eqFormData, ...equipmentList];
    }
    broadcastEquipmentsUpdate(updated);
    setIsEqModalOpen(false);
  };

  const deleteEquipment = (id: string) => {
    if (confirm(`آیا از حذف تجهیز «${id}» از کلیه بخش‌های سیستم اطمینان دارید؟`)) {
      const updated = equipmentList.filter(eq => eq.id !== id);
      broadcastEquipmentsUpdate(updated);
    }
  };

  // ========================================================
  // همگام‌سازی و ذخیره خانواده تجهیزات در همه کارت‌ها
  // ========================================================
  const broadcastFamiliesUpdate = (updatedList: any[]) => {
    setFamilyList(updatedList);
    try {
      localStorage.setItem('pm_studio_families_v9', JSON.stringify(updatedList));
    } catch {}
    window.dispatchEvent(new CustomEvent('factory_families_updated', { detail: updatedList }));
  };

  const saveFamily = (e: React.FormEvent) => {
    e.preventDefault();
    if (!famFormData.id.trim() || !famFormData.name.trim()) return;

    let updated: any[];
    if (isEditingFam) {
      updated = familyList.map(f => f.id === famFormData.id ? famFormData : f);
    } else {
      if (familyList.some(f => f.id === famFormData.id)) {
        alert('کد خانواده تکراری است.');
        return;
      }
      updated = [famFormData, ...familyList];
    }
    broadcastFamiliesUpdate(updated);
    setIsFamModalOpen(false);
  };

  const deleteFamily = (id: string) => {
    if (confirm(`آیا از حذف خانواده «${id}» اطمینان دارید؟`)) {
      const updated = familyList.filter(f => f.id !== id);
      broadcastFamiliesUpdate(updated);
    }
  };

  // ========================================================
  // همگام‌سازی و ذخیره اپراتورها در همه کارت‌ها (مورد چهارم و پنجم)
  // ========================================================
  const broadcastOperatorsUpdate = (updatedList: ProductionOperator[]) => {
    setOperatorsList(updatedList);
    try {
      localStorage.setItem('portal_production_operators_v2', JSON.stringify(updatedList));
    } catch {}
    if (onUpdateOperators) {
      onUpdateOperators(updatedList);
    }
    window.dispatchEvent(new CustomEvent('factory_operators_updated', { detail: updatedList }));
  };

  const handleOpenAddOperator = () => {
    setOperatorFormData({
      id: `op-${Date.now()}`,
      name: '',
      personnelCode: '',
      department: 'تولید',
      shift: 'صبح',
      phone: ''
    });
    setIsEditingOperator(false);
    setIsOperatorModalOpen(true);
  };

  const handleOpenEditOperator = (op: ProductionOperator) => {
    setOperatorFormData({
      id: op.id,
      name: op.name,
      personnelCode: op.personnelCode,
      department: op.department || 'تولید',
      shift: (op as any).shift || 'صبح',
      phone: (op as any).phone || ''
    });
    setIsEditingOperator(true);
    setIsOperatorModalOpen(true);
  };

  const saveOperator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!operatorFormData.name.trim() || !operatorFormData.personnelCode.trim()) {
      alert('لطفاً نام و کد پرسنلی را وارد نمایید.');
      return;
    }

    let updated: ProductionOperator[];
    if (isEditingOperator) {
      updated = operatorsList.map(op => {
        if (op.id === operatorFormData.id || op.personnelCode === operatorFormData.personnelCode) {
          return {
            ...op,
            name: operatorFormData.name,
            personnelCode: operatorFormData.personnelCode,
            department: operatorFormData.department,
            shift: operatorFormData.shift,
            phone: operatorFormData.phone
          } as ProductionOperator;
        }
        return op;
      });
    } else {
      if (operatorsList.some(op => op.personnelCode === operatorFormData.personnelCode)) {
        alert('کد پرسنلی تکراری است. لطفاً کد دیگری وارد نمایید.');
        return;
      }
      const newOp: ProductionOperator = {
        id: `op-${Date.now()}`,
        name: operatorFormData.name,
        personnelCode: operatorFormData.personnelCode,
        department: operatorFormData.department,
        shift: operatorFormData.shift,
        phone: operatorFormData.phone,
        activeTasksCount: 0,
        completedTasksCount: 0,
        rating: 5,
        totalHoursWorked: 0
      } as any;
      updated = [newOp, ...operatorsList];
    }

    broadcastOperatorsUpdate(updated);
    setIsOperatorModalOpen(false);
  };

  const deleteOperator = (personnelCode: string, name: string) => {
    if (confirm(`آیا از حذف اپراتور «${name}» با کد پرسنلی «${personnelCode}» اطمینان دارید؟`)) {
      const updated = operatorsList.filter(op => op.personnelCode !== personnelCode);
      broadcastOperatorsUpdate(updated);
    }
  };

  // ========================================================
  // همگام‌سازی و ذخیره مکان‌ها
  // ========================================================
  const broadcastLocationsUpdate = (updatedList: any[]) => {
    setLocationsList(updatedList);
    try {
      localStorage.setItem('pm_studio_locations_v2', JSON.stringify(updatedList));
    } catch {}
    window.dispatchEvent(new CustomEvent('factory_locations_updated', { detail: updatedList }));
  };

  const toggleLocationExpand = (locId: string) => {
    setExpandedLocations(prev => ({ ...prev, [locId]: !prev[locId] }));
  };

  const addSubLocation = (locId: string) => {
    const val = (newSubLocInputs[locId] || '').trim();
    if (!val) return;
    const updated = locationsList.map(loc => {
      if (loc.id === locId) {
        const currentSubs = loc.subLocations || [];
        const newSub = {
          id: `${loc.code}-SUB-${Date.now().toString().slice(-4)}`,
          name: val,
          description: `زیرسیستم ${val}`
        };
        return { ...loc, subLocations: [...currentSubs, newSub] };
      }
      return loc;
    });
    broadcastLocationsUpdate(updated);
    setNewSubLocInputs(prev => ({ ...prev, [locId]: '' }));
  };

  const deleteSubLocation = (locId: string, subId: string) => {
    const updated = locationsList.map(loc => {
      if (loc.id === locId) {
        return { ...loc, subLocations: (loc.subLocations || []).filter((s: any) => s.id !== subId) };
      }
      return loc;
    });
    broadcastLocationsUpdate(updated);
  };

  const saveLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!locFormData.code.trim() || !locFormData.name.trim()) return;

    let updated: any[];
    if (isEditingLoc) {
      updated = locationsList.map(loc => loc.id === locFormData.id ? { ...loc, ...locFormData } : loc);
    } else {
      const newLoc = {
        id: `loc-${Date.now()}`,
        code: locFormData.code,
        name: locFormData.name,
        description: locFormData.description,
        subLocations: []
      };
      updated = [...locationsList, newLoc];
    }
    broadcastLocationsUpdate(updated);
    setIsLocModalOpen(false);
  };

  const deleteLocation = (id: string) => {
    if (confirm('آیا از حذف این سالن / مکان اطمینان دارید؟')) {
      const updated = locationsList.filter(l => l.id !== id);
      broadcastLocationsUpdate(updated);
    }
  };

  // ساخت محتوای HTML استاندارد برگه درخواست کار با ابعاد دقیق A5 و لوگوی امبدشده Base64
  const getA5HtmlString = (target: PmWorkRequestItem) => {
    const logoUrl = OSVEH_LOGO_WHITEBG_URL;
    const isStopProd = target.priority === 'توقف تولید';
    const isStopEq = target.priority === 'توقف تجهیز';
    const wrPrintCfg = printSettings.workRequestA5;

    return `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="utf-8">
  <title>${escHtml(wrPrintCfg.docTitle)} - ${escHtml(target.code)} (${escHtml(wrPrintCfg.docCode)})</title>
  <style>
    @page {
      size: A5 portrait;
      margin: 4mm 6mm;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Tahoma", "Vazir", sans-serif;
      background: #ffffff;
      color: #0f172a;
      direction: rtl;
      text-align: right;
      padding: 2mm 3mm;
      font-size: 8.5pt;
      line-height: 1.35;
    }
    .sheet-wrapper {
      border: 1.5px solid #0f172a;
      border-radius: 6px;
      padding: 10px 14px;
    }
    .header-box {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1.5px solid #0f172a;
      padding-bottom: 8px;
      margin-bottom: 8px;
    }
    .header-right {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .logo-img {
      height: 48px;
      width: auto;
      object-fit: contain;
    }
    .titles h1 {
      font-size: 11pt;
      font-weight: 900;
      color: #0f172a;
    }
    .header-left {
      text-align: left;
      font-size: 8pt;
      line-height: 1.5;
    }
    .header-left strong {
      font-family: monospace;
      font-size: 9.5pt;
    }
    .sec-heading {
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      padding: 3px 8px;
      font-weight: bold;
      font-size: 8.5pt;
      color: #0f172a;
      border-radius: 4px;
      margin-top: 6px;
      margin-bottom: 4px;
    }
    table.table-info {
      width: 100%;
      border-collapse: collapse;
      font-size: 8pt;
      margin-bottom: 2px;
    }
    table.table-info td {
      border: 1px solid #cbd5e1;
      padding: 4px 6px;
      text-align: right;
    }
    table.table-info td.lbl {
      background: #f8fafc;
      font-weight: bold;
      color: #334155;
      width: 24%;
    }
    table.table-info td.val {
      width: 26%;
    }
    .desc-box {
      border: 1px solid #cbd5e1;
      padding: 6px 8px;
      min-height: 38px;
      background: #fafafa;
      font-size: 8pt;
      line-height: 1.4;
      border-radius: 4px;
    }
    .sig-container {
      margin-top: 8px;
      border: 1px solid #cbd5e1;
      border-radius: 4px;
      padding: 6px 10px;
      background: #f8fafc;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .sig-right {
      font-size: 8.5pt;
      font-weight: bold;
      color: #0f172a;
    }
    .sig-box {
      width: 38%;
      text-align: center;
      border: 1px dashed #64748b;
      border-radius: 4px;
      padding: 6px 8px;
      background: #ffffff;
    }
    .sig-title {
      font-size: 8.5pt;
      font-weight: 900;
      color: #0f172a;
      margin-bottom: 26px;
    }
    .sig-subtitle {
      font-size: 7.5pt;
      color: #64748b;
    }
    .footer-note {
      margin-top: 8px;
      padding-top: 4px;
      border-top: 1px solid #cbd5e1;
      text-align: center;
      font-size: 7.5pt;
      color: #64748b;
      font-family: monospace;
    }
    @media print {
      .no-print {
        display: none !important;
      }
    }
  </style>
  <script>
    window.addEventListener('load', function() {
      setTimeout(function() {
        window.print();
      }, 200);
    });
  </script>
</head>
<body>
  <div class="no-print" style="margin-bottom: 8px; display: flex; gap: 8px; justify-content: flex-end;">
    <button onclick="window.print()" style="background:#059669; color:#fff; border:none; padding:7px 16px; border-radius:6px; font-size:12px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif;">چاپ مجدد برگه (A5)</button>
    <button onclick="window.close()" style="background:#475569; color:#fff; border:none; padding:7px 14px; border-radius:6px; font-size:12px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif;">بستن صفحه</button>
  </div>

  <div class="sheet-wrapper">
    <div class="header-box">
      <div class="header-right">
        <img class="logo-img" src="${logoUrl}" alt="${escHtml(wrPrintCfg.docTitle)}" />
        <div class="titles">
          <h1>${escHtml(wrPrintCfg.docTitle)}</h1>
        </div>
      </div>
      <div class="header-left">
        <div>کد سند: <strong style="font-family:monospace; font-size:9.5pt; color:#0f172a;">${escHtml(wrPrintCfg.docCode)}</strong></div>
        <div>شماره درخواست: <strong style="color:#0284c7; font-family:monospace;">${target.code}</strong></div>
        <div>تاریخ و ساعت: <strong>${target.requestTime}</strong></div>
      </div>
    </div>

    <div class="sec-heading">۱. مشخصات تجهیز و موقعیت استقرار</div>
    <table class="table-info">
      <tr>
        <td class="lbl">کد دستگاه:</td>
        <td class="val"><strong style="font-family:monospace; font-size:9pt;">${target.equipmentCode}</strong></td>
        <td class="lbl">عنوان و نوع دستگاه:</td>
        <td class="val"><strong>${target.equipmentName}</strong></td>
      </tr>
      <tr>
        <td class="lbl">خانواده تجهیز:</td>
        <td class="val">${target.equipmentFamilyName || '—'}</td>
        <td class="lbl">سالن و موقعیت استقرار:</td>
        <td class="val">${target.locationName || '—'}</td>
      </tr>
    </table>

    <div class="sec-heading">۲. شرح عیب، اولویت کاری و فوریت اقدام</div>
    <table class="table-info">
      <tr>
        <td class="lbl">عنوان حالت خرابی:</td>
        <td class="val"><strong style="color:#b91c1c;">${target.failureTitle}</strong></td>
        <td class="lbl">اولویت کاری:</td>
        <td class="val"><strong style="color:${isStopProd || isStopEq ? '#b91c1c' : '#047857'};">${target.priority}</strong></td>
      </tr>
      <tr>
        <td class="lbl">نوع درخواست:</td>
        <td class="val"><strong>${target.requestType}</strong></td>
        <td class="lbl">کد حالت خرابی:</td>
        <td class="val"><span style="font-family:monospace;">${target.failureCode || 'FL-01'}</span></td>
      </tr>
    </table>

    <div class="sec-heading">۳. شرح و توضیحات تکمیلی</div>
    <div class="desc-box">
      ${target.description ? target.description : 'توضیحات تکمیلی توسط درخواست‌کننده ثبت نگردیده است.'}
    </div>

    <div class="sec-heading">۴. مشخصات متقاضی و تحویل‌دهنده</div>
    <table class="table-info">
      <tr>
        <td class="lbl">نام و نام خانوادگی درخواست‌کننده:</td>
        <td class="val"><strong>${target.operatorName || 'اپراتور خط'}</strong></td>
        <td class="lbl">کد پرسنلی:</td>
        <td class="val"><span style="font-family:monospace;">${target.operatorPersonnelCode || '—'}</span></td>
      </tr>
    </table>

    <!-- فقط تایید و دستور سرپرست مربوطه مطابق درخواست کاربر -->
    <div class="sig-container">
      <div class="sig-right">
        تایید و دستور سرپرست مربوطه:
      </div>
      <div class="sig-box">
        <div class="sig-title">امضا و تایید سرپرست مربوطه</div>
        <div class="sig-subtitle">محل امضا و تاریخ</div>
      </div>
    </div>

    <div class="footer-note">
      ${BRAND_CONFIG.SYSTEM_NAME} • فرم استاندارد CMMS-WR-01 (اندازه A5)
    </div>
  </div>
</body>
</html>`;
  };

  // دانلود فایل چاپ مستقل A5 با لوگوی امبدشده Base64
  const downloadA5Html = (target?: PmWorkRequestItem | null) => {
    const item = target || selectedRequestForPrint;
    if (!item) return;
    const html = getA5HtmlString(item);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `WorkRequest-${item.code}-A5.html`;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 500);
  };

  // متد چاپ برگه A5: باز کردن فوری برگه در تب جدید با پنجره پرینت خودکار و لوگوی Base64
  const triggerOfficialPrint = (request?: PmWorkRequestItem | null) => {
    const target = request || selectedRequestForPrint;
    if (!target) return;

    const html = getA5HtmlString(target);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);

    let windowOpened = false;

    // ۱. تلاش برای باز کردن برگه در پنجره جدید با پرینت خودکار
    try {
      const printWindow = window.open(blobUrl, '_blank');
      if (printWindow) {
        windowOpened = true;
        printWindow.focus();
      }
    } catch (e) {
      console.warn('window.open popup blocked:', e);
    }

    // ۲. فراخوانی پرینت محلی (در صورتی که برنامه خارج از آی‌فریم و در دسکتاپ اجرا شود)
    try {
      window.print();
    } catch (e) {
      // ignore
    }

    // ۳. اگر مرورگر مانع باز شدن تب جدید شد، بلافاصله دانلود خودکار فایل پرینت فعال می‌شود
    if (!windowOpened) {
      downloadA5Html(target);
    }
  };

  const triggerBrowserPrint = () => {
    triggerOfficialPrint(selectedRequestForPrint);
  };

  const escHtml = (val: unknown): string =>
    String(val ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

  const getClosedWorkOrderHtmlString = (target: PmWorkRequestItem, options?: { autoPrint?: boolean }) => {
    const autoPrint = options?.autoPrint !== false;
    const logoUrl = OSVEH_LOGO_WHITEBG_URL;
    const woNum = target.woCode || target.workOrderCode || (target.code ? (/^(PM|WO)/i.test(target.code) ? target.code : target.code.replace(/^WR/, 'WO')) : '—');
    const isDone = target.status === 'انجام شد' || target.status === 'انجام شده';
    const statusLabel = isDone ? 'انجام شده' : (target.status || 'بایگانی‌شده');
    const startLabel = target.woStartDate
      ? `${target.woStartDate}${target.woStartTimeOnly ? ` - ${target.woStartTimeOnly}` : ''}`
      : (target.woStartTime || '—');
    const endLabel = target.woEndDate
      ? `${target.woEndDate}${target.woEndTimeOnly ? ` - ${target.woEndTimeOnly}` : ''}`
      : (target.woEndTime || '—');
    const downtimeMins = Number(target.equipmentDowntimeMinutes ?? target.downtimeMinutes ?? target.durationMinutes ?? 0);
    const downtimeLabel = downtimeMins > 0 ? formatMinutesDurationFa(downtimeMins) : '—';
    const activities = Array.isArray(target.woActivities) ? target.woActivities : [];
    const techRows =
      Array.isArray(target.woTechnicians) && target.woTechnicians.length > 0
        ? target.woTechnicians.map(t => ({
            name: t.name || '—',
            dateRange: t.startDate && t.endDate && t.endDate !== t.startDate ? `${t.startDate} تا ${t.endDate}` : (t.startDate || t.endDate || '—'),
            timeRange: t.startTime && t.endTime ? `${t.startTime} تا ${t.endTime}` : '—',
            minutes: Math.round((Number(t.hours) || 0) * 60),
            hours: Number(t.hours) || 0
          }))
        : [target.technician, ...(Array.isArray(target.coTechnicians) ? target.coTechnicians : [])]
            .filter(Boolean)
            .map(name => ({
              name: String(name),
              dateRange: target.woStartDate || '—',
              timeRange: target.woStartTimeOnly && target.woEndTimeOnly ? `${target.woStartTimeOnly} تا ${target.woEndTimeOnly}` : '—',
              minutes: Number(target.durationMinutes || 0),
              hours: Math.round((Number(target.durationMinutes || 0) / 60) * 100) / 100
            }));
    const consumables = Array.isArray(target.consumables) ? target.consumables : [];
    const delays = Array.isArray(target.woDelays) ? target.woDelays : [];

    const activitiesRowsHtml =
      activities.length > 0
        ? activities
            .map(
              (a, idx) => `
          <tr>
            <td style="text-align:center;font-family:monospace;">${idx + 1}</td>
            <td style="font-weight:bold;">${escHtml(a.title)}</td>
            <td style="text-align:center;font-size:11pt;">${isDone ? '☑' : '☐'}</td>
            <td>${escHtml(target.woNotes || '—')}</td>
          </tr>`
            )
            .join('')
        : `<tr><td colspan="4" style="text-align:center;color:#64748b;">فعالیتی ثبت نشده است</td></tr>`;

    const techRowsHtml =
      techRows.length > 0
        ? techRows
            .map(
              t => `
          <tr>
            <td style="font-weight:bold;">${escHtml(t.name)}</td>
            <td style="text-align:center;font-family:monospace;" dir="ltr">${escHtml(t.dateRange)}</td>
            <td style="text-align:center;font-family:monospace;" dir="ltr">${escHtml(t.timeRange)}</td>
            <td style="text-align:center;font-family:monospace;font-weight:bold;">${t.minutes > 0 ? `${t.minutes} دقیقه (${t.hours} س)` : `${t.hours} ساعت`}</td>
          </tr>`
            )
            .join('')
        : `<tr><td colspan="4" style="text-align:center;color:#64748b;">تکنسینی ثبت نشده است</td></tr>`;

    const partsRowsHtml =
      consumables.length > 0
        ? consumables
            .map(
              c => `
          <tr>
            <td>${escHtml(c.category || '—')}</td>
            <td style="font-weight:bold;">${escHtml(c.name)}</td>
            <td style="text-align:center;font-family:monospace;font-weight:bold;">${escHtml(c.count)} ${escHtml(c.unit || 'عدد')}</td>
          </tr>`
            )
            .join('')
        : `<tr><td colspan="3" style="text-align:center;color:#64748b;">قطعه یدکی ثبت نشده است</td></tr>`;

    const delaysRowsHtml =
      delays.length > 0
        ? delays
            .map(
              d => `
          <tr>
            <td style="font-weight:bold;">${escHtml(d.title || '—')}</td>
            <td style="text-align:center;font-family:monospace;">${escHtml(d.code || '—')}</td>
            <td style="text-align:center;font-family:monospace;">${escHtml(d.days || 0)}</td>
            <td style="text-align:center;font-family:monospace;">${escHtml(d.hours || 0)}</td>
          </tr>`
            )
            .join('')
        : `<tr><td colspan="4" style="text-align:center;color:#64748b;">تاخیری ثبت نشده است</td></tr>`;

    const autoPrintScript = autoPrint
      ? `<script>
    function triggerSheetPrint() {
      var t0 = Date.now();
      try { window.print(); } catch (e) {}
      if (Date.now() - t0 < 30) {
        var hint = document.getElementById('print-shortcut-hint');
        if (hint) hint.style.display = 'inline-block';
      }
    }
    window.addEventListener('load', function() {
      setTimeout(triggerSheetPrint, 250);
    });
  </script>`
      : '';

    const woPrintCfg = printSettings.workOrderClosedA4;

    return `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="utf-8">
  <title>${escHtml(woPrintCfg.docTitle)} - ${escHtml(woNum)} (${escHtml(woPrintCfg.docCode)})</title>
  <style>
    @page { size: A4 portrait; margin: 8mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Tahoma, "Vazir", sans-serif;
      background: #ffffff;
      color: #0f172a;
      direction: rtl;
      text-align: right;
      font-size: 9pt;
      line-height: 1.45;
    }
    .sheet { border: 1.5px solid #0f172a; border-radius: 6px; padding: 12px 14px; }
    .hdr { display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 10px; gap: 12px; }
    .hdr img { height: 48px; width: auto; object-fit: contain; }
    .hdr-title { text-align: center; flex: 1; }
    .hdr-title h1 { font-size: 13pt; font-weight: 900; color: #0f172a; }
    .hdr-title span { font-size: 8pt; color: #475569; }
    .hdr-meta { text-align: left; font-size: 8pt; line-height: 1.6; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-size: 8pt; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; vertical-align: middle; }
    th { background: #f1f5f9; font-weight: 800; color: #1e293b; text-align: right; }
    .lbl { background: #f8fafc; font-weight: bold; color: #475569; font-size: 7.5pt; display: block; margin-bottom: 2px; }
    .val { font-weight: bold; color: #0f172a; font-size: 8.5pt; }
    .sec-title { background: #e2e8f0; border: 1px solid #94a3b8; padding: 4px 8px; font-weight: 900; font-size: 8.5pt; color: #0f172a; margin-top: 8px; margin-bottom: 4px; border-radius: 4px; }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 6px; }
    .box { border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px 8px; background: #fff; }
    .box h3 { font-size: 8.5pt; font-weight: 900; text-align: center; margin-bottom: 5px; padding-bottom: 4px; border-bottom: 1px solid #cbd5e1; color: #0f172a; }
    @media print { .no-print { display: none !important; } }
  </style>
  ${autoPrintScript}
</head>
<body>
  <div class="no-print" style="margin: 10px; display: flex; gap: 8px; align-items: center; justify-content: flex-end; flex-wrap: wrap;">
    <span id="print-shortcut-hint" style="display:none;background:#fef3c7;color:#92400e;border:1px solid #f59e0b;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:bold;">برای چاپ فوری در این برگه کلیدهای Ctrl + P را فشار دهید</span>
    <button onclick="typeof triggerSheetPrint==='function'?triggerSheetPrint():window.print()" style="background:#059669;color:#fff;border:none;padding:7px 16px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;">چاپ دستور کار (A4)</button>
    <button onclick="window.close()" style="background:#475569;color:#fff;border:none;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;">بستن</button>
  </div>
  <div class="sheet">
    <div class="hdr">
      <img src="${logoUrl}" alt="لوگو" />
      <div class="hdr-title">
        <h1>${escHtml(woPrintCfg.docTitle)}</h1>
        <span>فرم بسته و بایگانی‌شده رسمی واحد نگهداری و تعمیرات</span>
      </div>
      <div class="hdr-meta">
        <div>کد سند: <strong style="font-family:monospace;font-size:9.5pt;color:#0f172a;">${escHtml(woPrintCfg.docCode)}</strong></div>
        <div>کد دستورکار: <strong style="font-family:monospace;font-size:9.5pt;">${escHtml(woNum)}</strong></div>
        <div>کد درخواست: <strong style="font-family:monospace;">${escHtml(target.code)}</strong></div>
        <div>تاریخ تکمیل: <strong style="font-family:monospace;" dir="ltr">${escHtml(endLabel)}</strong></div>
      </div>
    </div>

    <table>
      <tr>
        <td style="width:20%"><span class="lbl">کد دستورکار</span><span class="val" style="font-family:monospace;">${escHtml(woNum)}</span></td>
        <td style="width:18%"><span class="lbl">کد تجهیز</span><span class="val" style="font-family:monospace;">${escHtml(target.equipmentCode)}</span></td>
        <td style="width:20%"><span class="lbl">عنوان تجهیز</span><span class="val">${escHtml(target.equipmentName)}</span></td>
        <td style="width:22%"><span class="lbl">مسیر عنوان خانواده تجهیز</span><span class="val">${escHtml(target.equipmentFamilyName || '—')}</span></td>
        <td style="width:20%"><span class="lbl">مسیر عنوان مکان</span><span class="val">${escHtml(target.locationName || '—')}</span></td>
      </tr>
      <tr>
        <td colspan="2"><span class="lbl">توضیحات درخواست کار</span><span class="val">${escHtml(target.description || '—')}</span></td>
        <td><span class="lbl">عنوان وضعیت</span><span class="val">${escHtml(statusLabel)}</span></td>
        <td><span class="lbl">عنوان دپارتمان</span><span class="val">نگهداری و تعمیرات</span></td>
        <td><span class="lbl">عنوان حالت خرابی</span><span class="val">${escHtml(target.failureTitle || '—')}${target.failureCode ? ` (${escHtml(target.failureCode)})` : ''}</span></td>
      </tr>
      <tr>
        <td><span class="lbl">زمان درخواست کار</span><span class="val" style="font-family:monospace;" dir="ltr">${escHtml(target.requestTime || '—')}</span></td>
        <td><span class="lbl">زمان شروع دستورکار</span><span class="val" style="font-family:monospace;" dir="ltr">${escHtml(startLabel)}</span></td>
        <td><span class="lbl">زمان پایان دستورکار</span><span class="val" style="font-family:monospace;" dir="ltr">${escHtml(endLabel)}</span></td>
        <td><span class="lbl">مدت خواب تجهیز</span><span class="val">${escHtml(downtimeLabel)}</span></td>
        <td><span class="lbl">متقاضی / زمان ثبت</span><span class="val">${escHtml(target.operatorName || '—')}</span></td>
      </tr>
      <tr>
        <td colspan="5"><span class="lbl">توضیحات دستورکار</span><span class="val">${escHtml(target.woNotes || '—')}</span></td>
      </tr>
    </table>

    <div class="sec-title">مشخصات تجهیز و فعالیت‌های انجام‌شده</div>
    <table>
      <thead>
        <tr>
          <th style="width:8%;text-align:center;">ردیف</th>
          <th style="width:45%;">عنوان فعالیت</th>
          <th style="width:12%;text-align:center;">وضعیت انجام</th>
          <th style="width:35%;">توضیحات</th>
        </tr>
      </thead>
      <tbody>
        ${activitiesRowsHtml}
      </tbody>
    </table>

    <div class="two-col">
      <div class="box">
        <h3>لیست نیروی انسانی</h3>
        <table>
          <thead>
            <tr>
              <th>نام و نام خانوادگی</th>
              <th style="text-align:center;">تاریخ انجام کار</th>
              <th style="text-align:center;">ساعت</th>
              <th style="text-align:center;">زمان انجام کار</th>
            </tr>
          </thead>
          <tbody>
            ${techRowsHtml}
          </tbody>
        </table>
      </div>
      <div class="box">
        <h3>لیست قطعات یدکی</h3>
        <table>
          <thead>
            <tr>
              <th>گروه قطعه</th>
              <th>نام قطعه</th>
              <th style="text-align:center;">تعداد</th>
            </tr>
          </thead>
          <tbody>
            ${partsRowsHtml}
          </tbody>
        </table>
      </div>
    </div>

    <div class="two-col">
      <div class="box">
        <h3>لیست تاخیرات</h3>
        <table>
          <thead>
            <tr>
              <th>عنوان تاخیر</th>
              <th style="text-align:center;">کد تاخیر</th>
              <th style="text-align:center;">مدت (روز)</th>
              <th style="text-align:center;">مدت (ساعت)</th>
            </tr>
          </thead>
          <tbody>
            ${delaysRowsHtml}
          </tbody>
        </table>
      </div>
      <div class="box">
        <h3>تحویل و تایید</h3>
        <table>
          <tr>
            <td colspan="2"><span class="lbl">نام و نام خانوادگی تحویل‌گیرنده:</span><span class="val">${escHtml(target.operatorName || '........................')}</span></td>
          </tr>
          <tr>
            <td colspan="2">آیا درخواست مورد تایید می‌باشد؟ &nbsp;&nbsp; ☐ بله &nbsp;&nbsp;&nbsp;&nbsp; ☐ خیر</td>
          </tr>
          <tr>
            <td style="width:50%;">تاریخ: ....................</td>
            <td style="width:50%;">ساعت: .................... &nbsp;&nbsp; امضا: ....................</td>
          </tr>
        </table>
      </div>
    </div>

    <div style="margin-top:8px;padding-top:5px;border-top:1px solid #cbd5e1;text-align:center;font-size:7.5pt;color:#64748b;font-family:monospace;">
      ${BRAND_CONFIG.SYSTEM_NAME} • کد سند: ${escHtml(woPrintCfg.docCode)} (اندازه A4)
    </div>
  </div>
</body>
</html>`;
  };

  const downloadClosedWorkOrderHtml = (target?: PmWorkRequestItem | null) => {
    const item = target || selectedWoForPrint;
    if (!item) return;
    const woNum = item.woCode || item.workOrderCode || item.code;
    const woDocCode = printSettings.workOrderClosedA4.docCode || 'FR069';
    const html = getClosedWorkOrderHtmlString(item);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `WorkOrder-${woNum}-${woDocCode}-A4.html`;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 500);
  };

  const triggerClosedWorkOrderPrint = (target?: PmWorkRequestItem | null) => {
    const item = target || selectedWoForPrint;
    if (!item) {
      try {
        window.print();
      } catch (e) {
        console.warn('print failed:', e);
      }
      return;
    }

    const woNum = item.woCode || item.workOrderCode || (item.code ? (/^(PM|WO)/i.test(item.code) ? item.code : item.code.replace(/^WR/, 'WO')) : '—');
    const htmlForIframe = getClosedWorkOrderHtmlString(item, { autoPrint: false });
    const htmlForStandalone = getClosedWorkOrderHtmlString(item, { autoPrint: true });

    // ۱. تلاش هم‌زمان درون‌صفحه‌ای (بدون setTimeout تا مرورگر مجوز کلیک کاربر را لغو نکند)
    let printedNatively = false;
    try {
      const existing = document.getElementById('closed-wo-print-iframe');
      if (existing) existing.remove();

      const iframe = document.createElement('iframe');
      iframe.id = 'closed-wo-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.top = '-9999px';
      iframe.style.left = '-9999px';
      iframe.style.width = '210mm';
      iframe.style.height = '297mm';
      iframe.style.border = '0';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const fDoc = iframe.contentWindow?.document;
      if (fDoc) {
        fDoc.open();
        fDoc.write(htmlForIframe);
        fDoc.close();
        const t0 = performance.now();
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        if (performance.now() - t0 >= 30) {
          printedNatively = true;
        }
      }
    } catch (e) {
      console.warn('hidden iframe print failed:', e);
    }

    if (printedNatively) return;

    // ۲. در محیط‌های آی‌فریم که چاپ مستقیم مسدود است: باز کردن نسخه مستقل چاپی در تب جدید + دانلود پشتیبان
    try {
      const blob = new Blob([htmlForStandalone], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      const tabLink = document.createElement('a');
      tabLink.href = blobUrl;
      tabLink.target = '_blank';
      tabLink.style.display = 'none';
      document.body.appendChild(tabLink);
      tabLink.click();
      document.body.removeChild(tabLink);

      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 60000);

      // اگر مرورگر مانع باز شدن تب جدید شد (فوکوس همچنان در صفحه باقی ماند)، فایل آماده چاپ بلافاصله دانلود می‌شود
      setTimeout(() => {
        try {
          if (document.hasFocus() && document.visibilityState === 'visible') {
            downloadClosedWorkOrderHtml(item);
            setWoNoticeToast(`فایل چاپی دستور کار (${woNum} • ${printSettings.workOrderClosedA4.docCode}) آماده و دانلود شد؛ آن را باز کرده و چاپ بگیرید.`);
            setTimeout(() => setWoNoticeToast(null), 5000);
          }
        } catch {
          downloadClosedWorkOrderHtml(item);
        }
      }, 280);
    } catch (e) {
      console.warn('standalone print tab failed:', e);
      downloadClosedWorkOrderHtml(item);
    }
  };

  return (
    <div className="w-full min-h-screen text-slate-100 relative font-sans select-none overflow-x-hidden">
      
      {/* ======================================================== */}
      {/* سایدبار کشویی ناوبری (منطبق بر عکس ارسالی کاربر)        */}
      {/* ======================================================== */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs transition-opacity" 
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <aside 
        className={`fixed inset-y-0 right-0 z-50 w-72 bg-[#0c162e] border-l border-white/10 flex flex-col justify-between shadow-2xl transition-transform duration-300 ease-in-out ${
          isSidebarOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div>
          {/* سربرگ نوار ابزار */}
          <div className="h-16 flex items-center justify-between px-6 border-b border-white/10 bg-[#070e22]/90">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-900/40">
                <Sparkles size={18} />
              </div>
              <span className="font-bold text-base text-slate-100 tracking-wide">Work Request Studio</span>
            </div>

            {/* دکمه بستن منو (ضربدر) */}
            <button 
              className="text-slate-400 hover:text-rose-400 transition-colors bg-[#070e22] p-1.5 rounded-md border border-indigo-500/30 cursor-pointer" 
              onClick={() => setIsSidebarOpen(false)}
              title="بستن منو"
            >
              <X size={18} />
            </button>
          </div>
          
          <nav className="p-4 space-y-1">
            {[
              { id: 'requests', name: 'کارتابل درخواست‌های کار', icon: FileText, badge: activeRequestsList.length },
              { id: 'woArchive', name: 'بایگانی دستور کار', icon: Archive, badge: archivedWorkOrdersList.length },
              { id: 'equipment', name: 'مدیریت تجهیزات', icon: Wrench, badge: equipmentList.length },
              { id: 'locations', name: 'مدیریت مکان‌ها', icon: Building2, badge: locationsList.length },
              { id: 'operators', name: 'مدیریت اپراتورها', icon: Users, badge: operatorsList.length },
              { id: 'reports', name: 'گزارش‌ها', icon: BarChart2 },
              { id: 'printSettings', name: 'تنظیمات پرینت', icon: Printer },
            ].map((item) => {
              const isActive = activeView === item.id;
              return (
                <button 
                  key={item.id} 
                  onClick={() => { 
                    setActiveView(item.id as any); 
                    setSelectedFamilyForDetail(null);
                    setIsSidebarOpen(false);
                  }} 
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 outline-none text-right cursor-pointer ${
                    isActive 
                      ? 'bg-[#132448] text-cyan-400 font-medium border border-cyan-500/40 shadow-sm' 
                      : 'text-slate-400 hover:bg-[#112042] hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon 
                      size={18} 
                      className={isActive ? "drop-shadow-[0_0_8px_rgba(6,182,212,0.6)] text-cyan-400" : ""} 
                    />
                    <span className="text-sm">{item.name}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                      isActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* پاورقی سایدبار */}
        <div className="w-full p-4 border-t border-indigo-900/40 bg-[#070e22]/95 backdrop-blur-md space-y-3">
          <button
            type="button"
            onClick={onBackToPortal}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 hover:text-white border border-cyan-500/30 text-xs font-bold transition-all cursor-pointer shadow-md"
          >
            <ArrowRight size={14} />
            <span>بازگشت به پرتال اصلی</span>
          </button>
          <div className="flex items-center gap-3 px-2 pt-1 border-t border-indigo-900/30">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-cyan-700 to-blue-600 flex items-center justify-center font-medium text-sm text-white border border-cyan-400/40 shadow-inner">
              م
            </div>
            <div className="flex flex-col text-right">
              <span className="text-xs font-bold text-slate-200">مدیر سیستم</span>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                آنلاین
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* ======================================================== */}
      {/* سربرگ اصلی صفحه                                          */}
      {/* ======================================================== */}
      <header className="h-16 bg-[#0c162e]/60 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-4 sm:px-6 z-10 sticky top-0">
        <div className="flex items-center gap-3">
          {/* دکمه باز کردن نوار ابزار کشویی */}
          <button 
            type="button"
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-cyan-200 hover:text-white transition-all cursor-pointer border border-cyan-500/40 bg-cyan-600/25 hover:bg-cyan-600/40 shadow-md shadow-cyan-950/40 group active:scale-95" 
            onClick={() => setIsSidebarOpen(true)}
            title="باز کردن نوار ابزار"
          >
            <Menu size={18} className="text-cyan-300 group-hover:rotate-90 transition-transform duration-200" />
            <span className="text-xs font-bold">نوار ابزار</span>
          </button>

          {activeView !== 'requests' && (
            <button
              type="button"
              onClick={() => {
                setActiveView('requests');
                setSelectedFamilyForDetail(null);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-xs font-bold text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
            >
              <ChevronRight size={14} />
              <span>بازگشت به کارتابل درخواست‌ها</span>
            </button>
          )}
        </div>

        {/* دکمه ثبت درخواست کار جدید */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-black shadow-lg shadow-cyan-950/50 cursor-pointer transition-all active:scale-95"
          >
            <Plus size={16} />
            <span>ثبت درخواست کار جدید</span>
          </button>
        </div>
      </header>

      {/* ======================================================== */}
      {/* محتوای ویوهای مختلف                                     */}
      {/* ======================================================== */}
      <main className="max-w-[1900px] mx-auto p-4 sm:p-6 space-y-6">

        {/* ---------------------------------------------------- */}
        {/* VIEW 1: کارتابل درخواست‌های کار                      */}
        {/* ---------------------------------------------------- */}
        {activeView === 'requests' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="inline-flex items-center gap-1.5 p-1 rounded-xl bg-[#070e22]/90 border border-indigo-500/30">
                <button
                  type="button"
                  onClick={() => setActiveView('requests')}
                  className="px-3.5 py-2 rounded-lg text-xs font-bold bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>درخواست‌های کار فعال</span>
                  <span className="font-mono text-[11px] px-1.5 py-0.2 rounded-full bg-slate-950/70 text-cyan-200">{activeRequestsList.length}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveView('woArchive')}
                  className="px-3.5 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-indigo-900/40 flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Archive className="w-3.5 h-3.5 text-emerald-400" />
                  <span>بایگانی دستور کار</span>
                  <span className="font-mono text-[11px] px-1.5 py-0.2 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">{archivedWorkOrdersList.length}</span>
                </button>
              </div>
            </div>
            
            {/* نوار جستجو و فیلترها */}
            <div className="rounded-2xl bg-[#0c162e]/85 backdrop-blur-xl border border-indigo-500/20 p-4 shadow-lg flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setCurrentPage(1);
                    }}
                    placeholder="جستجو بر اساس کد، تجهیز، مکان یا عیب..."
                    className="w-full pr-10 pl-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-all"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <select
                  value={priorityFilter}
                  onChange={(e) => {
                    setPriorityFilter(e.target.value as any);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="all">⚡ کلیه اولویت‌ها</option>
                  <option value="توقف تولید">توقف تولید</option>
                  <option value="توقف تجهیز">توقف تجهیز</option>
                  <option value="عدم توقف تجهیز">عدم توقف تجهیز</option>
                </select>

                <select
                  value={typeFilter}
                  onChange={(e) => {
                    setTypeFilter(e.target.value as any);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="all">📌 کلیه انواع درخواست</option>
                  <option value="اضطراری">اضطراری (EM)</option>
                  <option value="اصلاحی">اصلاحی (CM)</option>
                  <option value="پیشگیرانه">پیشگیرانه (PM)</option>
                </select>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 font-mono">
                  تعداد کل ردیف‌ها: <strong className="text-cyan-300 font-bold">{filteredRequests.length}</strong>
                </span>
                <button
                  type="button"
                  onClick={handleOpenCreateModal}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-black flex items-center gap-2 shadow-md cursor-pointer transition-all active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  <span>افزودن درخواست کار</span>
                </button>
              </div>
            </div>

            {/* جدول کارتابل */}
            <div className="rounded-2xl bg-[#0c162e]/85 backdrop-blur-xl border border-indigo-500/20 overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-[#070e22]/90 text-slate-400 border-b border-indigo-900/40 whitespace-nowrap">
                      <th className="py-3.5 px-4 font-bold">کد درخواست کار</th>
                      <th className="py-3.5 px-4 font-bold">عنوان تجهیز</th>
                      <th className="py-3.5 px-4 font-bold">کد تجهیز</th>
                      <th className="py-3.5 px-4 font-bold">مسیر عنوان مکان</th>
                      <th className="py-3.5 px-4 font-bold">زمان درخواست کار</th>
                      <th className="py-3.5 px-4 font-bold">مسیر عنوان خانواده تجهیز</th>
                      <th className="py-3.5 px-4 font-bold">عنوان حالت خرابی</th>
                      <th className="py-3.5 px-4 font-bold">اولویت درخواست کار</th>
                      <th className="py-3.5 px-4 font-bold">توضیحات درخواست کار</th>
                      <th className="py-3.5 px-4 font-bold">نوع درخواست کار</th>
                      <th className="py-3.5 px-4 font-bold">عنوان وضعیت</th>
                      <th className="py-3.5 px-4 font-bold text-center">عملیات / پرینت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#333538]/50 text-slate-200">
                    {paginatedRequests.length === 0 ? (
                      <tr>
                        <td colSpan={12} className="py-16 text-center text-slate-400">
                          <div className="flex flex-col items-center justify-center space-y-3">
                            <div className="w-16 h-16 rounded-3xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center text-slate-500">
                              <FileText className="w-8 h-8" />
                            </div>
                            <div className="font-bold text-base text-slate-300">هیچ درخواست کاری ثبت نشده است</div>
                            <p className="text-xs text-slate-500 max-w-md">
                              کارتابل آماده ثبت اطلاعات است. با زدن دکمه زیر اطلاعات را ثبت فرمایید.
                            </p>
                            <button
                              type="button"
                              onClick={handleOpenCreateModal}
                              className="mt-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-cyan-950/60 cursor-pointer active:scale-95"
                            >
                              <Plus className="w-4 h-4" />
                              <span>ثبت اولین درخواست کار</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      paginatedRequests.map((item) => {
                        const isStopProd = item.priority === 'توقف تولید';
                        const isStopEq = item.priority === 'توقف تجهیز';
                        const isEmergency = item.requestType === 'اضطراری';

                        return (
                          <tr 
                            key={item.id} 
                            onClick={() => {
                              setSelectedRequestForPrint(item);
                              setIsPrintModalOpen(true);
                            }}
                            className="hover:bg-[#112042]/70 transition-colors whitespace-nowrap group cursor-pointer"
                          >
                            <td className="py-3.5 px-4 font-mono font-bold text-cyan-300">
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedRequestForPrint(item);
                                    setIsPrintModalOpen(true);
                                  }}
                                  className="p-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-600 text-cyan-400 hover:text-white border border-cyan-500/40 transition-all cursor-pointer shadow-sm group"
                                  title="مشاهده برگه رسمی و پرینت فرم"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <div>
                                  <span>{item.code}</span>
                                  {(item.woCode || item.workOrderCode) && (
                                    <span className="block text-[10px] text-indigo-300 font-mono">
                                      {item.woCode || item.workOrderCode}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </td>
                            <td className="py-3.5 px-4 font-bold text-white">{item.equipmentName}</td>
                            <td className="py-3.5 px-4 font-mono text-slate-300">
                              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700/80 font-bold">
                                {item.equipmentCode}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-slate-300">{item.locationName}</td>
                            <td className="py-3.5 px-4 font-mono text-slate-300 text-[11px]" dir="ltr">{item.requestTime}</td>
                            <td className="py-3.5 px-4 text-slate-200 font-medium">{item.equipmentFamilyName}</td>
                            <td className="py-3.5 px-4 text-amber-200 font-bold">{item.failureTitle}</td>
                            <td className="py-3.5 px-4">
                              <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold border ${
                                isStopProd 
                                  ? 'bg-rose-950/80 text-rose-300 border-rose-500/40 animate-pulse'
                                  : isStopEq
                                  ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                              }`}>
                                {item.priority}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-slate-400 text-xs max-w-xs truncate">{item.description || '—'}</td>
                            <td className="py-3.5 px-4">
                              <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold ${
                                isEmergency
                                  ? 'text-rose-400 bg-rose-950/40 border border-rose-500/30'
                                  : item.requestType === 'پیشگیرانه'
                                  ? 'text-purple-300 bg-purple-950/50 border border-purple-500/40'
                                  : 'text-blue-300 bg-blue-950/40 border border-blue-500/30'
                              }`}>
                                {item.requestType}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-xs text-slate-300">
                              <span className={`inline-flex items-center gap-1.5 ${
                                item.status === 'لغو' || item.status === 'لغو شده'
                                  ? 'text-rose-300'
                                  : item.status === 'انجام شد'
                                  ? 'text-emerald-300'
                                  : 'text-slate-300'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${
                                  item.status === 'لغو' || item.status === 'لغو شده'
                                    ? 'bg-rose-400'
                                    : item.status === 'انجام شد'
                                    ? 'bg-emerald-400'
                                    : 'bg-cyan-400 animate-pulse'
                                }`} />
                                <span>{item.status || 'در انتظار دستور برنامه ریزی'}</span>
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <div className="flex flex-col items-center justify-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedRequestForPrint(item);
                                    setIsPrintModalOpen(true);
                                  }}
                                  className="p-1.5 rounded-lg bg-[#112448] hover:bg-cyan-600 text-cyan-300 hover:text-white border border-cyan-500/40 transition-all cursor-pointer shadow-sm active:scale-95 group"
                                  title="مشاهده فرم رسمی و چاپ A4 (آیکون چشم)"
                                >
                                  <Eye className="w-4 h-4 text-cyan-300 group-hover:text-white" />
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenWorkOrderForm(item);
                                  }}
                                  className={`p-1.5 rounded-lg transition-all cursor-pointer border ${
                                    item.woCode || item.workOrderCode
                                      ? 'bg-indigo-600/80 hover:bg-indigo-500 text-white border-indigo-400/60 shadow-sm'
                                      : 'bg-slate-800/80 hover:bg-indigo-600 text-slate-400 hover:text-white border-slate-700'
                                  }`}
                                  title="ورود به فرم دستور کار"
                                >
                                  <ArrowUpDown className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* صفحه‌بندی */}
              <div className="p-3.5 bg-[#070e22]/90 border-t border-indigo-900/40 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-3">
                <div className="flex items-center gap-3">
                  <span>ردیف در صفحه: <strong className="text-white font-mono">۱۰</strong></span>
                  <span>
                    {filteredRequests.length > 0 
                      ? `${(currentPage - 1) * pageSize + 1} - ${Math.min(currentPage * pageSize, filteredRequests.length)} از ${filteredRequests.length}` 
                      : '۰ از ۰'}
                  </span>
                </div>

                <div className="flex items-center gap-1 font-mono">
                  <button
                    type="button"
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="p-1 rounded-md bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-700 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  {Array.from({ length: totalPages }).map((_, idx) => {
                    const pageNum = idx + 1;
                    const isActive = pageNum === currentPage;
                    return (
                      <button
                        key={pageNum}
                        type="button"
                        onClick={() => setCurrentPage(pageNum)}
                        className={`px-2.5 py-1 rounded-md border text-xs font-bold transition-colors cursor-pointer ${
                          isActive 
                            ? 'bg-cyan-600 border-cyan-400 text-white shadow-sm' 
                            : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}

                  <button
                    type="button"
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="p-1 rounded-md bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-700 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 1B: بایگانی دستور کار                          */}
        {/* ---------------------------------------------------- */}
        {activeView === 'woArchive' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="inline-flex items-center gap-1.5 p-1 rounded-xl bg-[#070e22]/90 border border-indigo-500/30">
                <button
                  type="button"
                  onClick={() => {
                    setActiveView('requests');
                    setCurrentPage(1);
                  }}
                  className="px-3.5 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-indigo-900/40 flex items-center gap-2 cursor-pointer transition-all"
                >
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  <span>درخواست‌های کار فعال</span>
                  <span className="font-mono text-[11px] px-1.5 py-0.2 rounded-full bg-slate-900 text-cyan-300 border border-cyan-500/30">{activeRequestsList.length}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveView('woArchive')}
                  className="px-3.5 py-2 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>بایگانی دستور کار</span>
                  <span className="font-mono text-[11px] px-1.5 py-0.2 rounded-full bg-slate-950/70 text-emerald-200">{archivedWorkOrdersList.length}</span>
                </button>
              </div>
            </div>

            {/* نوار جستجو و فیلتر بایگانی */}
            <div className="rounded-2xl bg-[#0c162e]/85 backdrop-blur-xl border border-emerald-500/20 p-4 shadow-lg flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو در بایگانی بر اساس شماره دستور کار، کد درخواست، تجهیز، مکان یا عیب..."
                    className="w-full pr-10 pl-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 transition-all"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value as any)}
                  className="px-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-slate-200 focus:outline-none focus:border-emerald-400 cursor-pointer"
                >
                  <option value="all">⚡ کلیه اولویت‌ها</option>
                  <option value="توقف تولید">توقف تولید</option>
                  <option value="توقف تجهیز">توقف تجهیز</option>
                  <option value="عدم توقف تجهیز">عدم توقف تجهیز</option>
                </select>

                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value as any)}
                  className="px-3 py-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs text-slate-200 focus:outline-none focus:border-emerald-400 cursor-pointer"
                >
                  <option value="all">📌 کلیه انواع درخواست</option>
                  <option value="اضطراری">اضطراری (EM)</option>
                  <option value="اصلاحی">اصلاحی (CM)</option>
                  <option value="پیشگیرانه">پیشگیرانه (PM)</option>
                </select>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 font-mono">
                  تعداد بایگانی: <strong className="text-emerald-300 font-bold">{filteredArchivedWorkOrders.length}</strong>
                </span>
              </div>
            </div>

            {/* جدول بایگانی دستور کار */}
            <div className="rounded-2xl bg-[#0c162e]/85 backdrop-blur-xl border border-emerald-500/20 overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-[#070e22]/90 text-slate-400 border-b border-indigo-900/40 whitespace-nowrap">
                      <th className="py-3.5 px-4 font-bold">شماره دستور کار</th>
                      <th className="py-3.5 px-4 font-bold">کد درخواست</th>
                      <th className="py-3.5 px-4 font-bold">تجهیز</th>
                      <th className="py-3.5 px-4 font-bold">فعالیت‌های ثبت‌شده</th>
                      <th className="py-3.5 px-4 font-bold">تکنسین‌ها</th>
                      <th className="py-3.5 px-4 font-bold">زمان شروع تا پایان</th>
                      <th className="py-3.5 px-4 font-bold">خواب تجهیز</th>
                      <th className="py-3.5 px-4 font-bold">توضیحات</th>
                      <th className="py-3.5 px-4 font-bold">وضعیت</th>
                      <th className="py-3.5 px-4 font-bold text-center">عملیات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#333538]/50 text-slate-200">
                    {filteredArchivedWorkOrders.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="py-16 text-center text-slate-400">
                          <div className="flex flex-col items-center justify-center space-y-3">
                            <div className="w-16 h-16 rounded-3xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center text-slate-500">
                              <Archive className="w-8 h-8" />
                            </div>
                            <div className="font-bold text-base text-slate-300">هنوز دستور کاری در بایگانی ثبت نشده است</div>
                            <p className="text-xs text-slate-500 max-w-md">
                              پس از تکمیل و زدن دکمه «ثبت» در فرم دستور کار، پرونده به‌صورت خودکار به این بخش منتقل می‌شود.
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      filteredArchivedWorkOrders.map((item) => {
                        const woNum = item.woCode || item.workOrderCode || (item.code ? (/^(PM|WO)/i.test(item.code) ? item.code : item.code.replace(/^WR/, 'WO')) : '—');
                        const activities = Array.isArray(item.woActivities) ? item.woActivities : [];
                        const techNames = Array.isArray(item.woTechnicians) && item.woTechnicians.length > 0
                          ? item.woTechnicians.map(t => t.name).filter(Boolean)
                          : [item.technician, ...(Array.isArray(item.coTechnicians) ? item.coTechnicians : [])].filter(Boolean) as string[];
                        const startLabel = item.woStartDate
                          ? `${item.woStartDate}${item.woStartTimeOnly ? ` (${item.woStartTimeOnly})` : ''}`
                          : (item.woStartTime || '—');
                        const endLabel = item.woEndDate
                          ? `${item.woEndDate}${item.woEndTimeOnly ? ` (${item.woEndTimeOnly})` : ''}`
                          : (item.woEndTime || '—');
                        const downtimeMins = Number(item.equipmentDowntimeMinutes ?? item.downtimeMinutes ?? item.durationMinutes ?? 0);
                        const isDone = item.status === 'انجام شد' || item.status === 'انجام شده';
                        const isCancelled = item.status === 'لغو' || item.status === 'لغو شده';

                        return (
                          <tr
                            key={item.id}
                            onClick={() => handleOpenWorkOrderForm(item)}
                            className="hover:bg-[#112042]/70 transition-colors cursor-pointer"
                          >
                            <td className="py-3.5 px-4 font-mono font-bold text-emerald-300 whitespace-nowrap">{woNum}</td>
                            <td className="py-3.5 px-4 font-mono text-cyan-300 whitespace-nowrap">{item.code}</td>
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <div className="font-bold text-white">{item.equipmentName}</div>
                              <div className="text-[10px] font-mono text-slate-400">{item.equipmentCode}</div>
                            </td>
                            <td className="py-3.5 px-4 max-w-xs">
                              {activities.length === 0 ? (
                                <span className="text-slate-500">—</span>
                              ) : (
                                <div className="flex flex-wrap gap-1.5">
                                  {activities.map((a, idx) => (
                                    <span key={a.id || idx} className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-[#070e22] border border-cyan-500/30 text-[11px] text-slate-200 whitespace-nowrap">
                                      {a.title}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </td>
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              {techNames.length > 0 ? (
                                <span className="text-indigo-200 text-xs">{Array.from(new Set(techNames)).join('، ')}</span>
                              ) : (
                                <span className="text-slate-500">—</span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 font-mono text-[11px] text-slate-300 whitespace-nowrap" dir="ltr">
                              <div>{startLabel}</div>
                              <div className="text-slate-500">→ {endLabel}</div>
                            </td>
                            <td className="py-3.5 px-4 font-mono text-amber-300 font-bold whitespace-nowrap">
                              {downtimeMins > 0 ? formatMinutesDurationFa(downtimeMins) : '—'}
                            </td>
                            <td className="py-3.5 px-4 text-slate-300 max-w-xs truncate" title={item.woNotes || ''}>
                              {item.woNotes || '—'}
                            </td>
                            <td className="py-3.5 px-4 whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border ${
                                isDone
                                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                                  : isCancelled
                                  ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                                  : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${
                                  isDone ? 'bg-emerald-400' : isCancelled ? 'bg-rose-400' : 'bg-cyan-400'
                                }`} />
                                <span>{isDone ? 'انجام شده' : (item.status || 'بایگانی‌شده')}</span>
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedWoForPrint(item);
                                    setIsWoPrintModalOpen(true);
                                  }}
                                  className="p-1.5 rounded-lg bg-[#112448] hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition-all cursor-pointer shadow-sm"
                                  title={`مشاهده فرم کامل دستور کار بسته (${printSettings.workOrderClosedA4.docCode})`}
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedWoForPrint(item);
                                    triggerClosedWorkOrderPrint(item);
                                  }}
                                  className="p-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition-all cursor-pointer shadow-sm"
                                  title={`چاپ مستقیم دستور کار (${printSettings.workOrderClosedA4.docCode})`}
                                >
                                  <Printer className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenWorkOrderForm(item);
                                  }}
                                  className="p-1.5 rounded-lg bg-indigo-600/80 hover:bg-indigo-500 text-white border border-indigo-400/60 transition-all cursor-pointer shadow-sm"
                                  title="مشاهده جزئیات دستور کار (بایگانی)"
                                >
                                  <ArrowUpDown className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 2: مدیریت تجهیزات                              */}
        {/* ---------------------------------------------------- */}
        {activeView === 'equipment' && (
          selectedFamilyForDetail ? (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-1">
                <button
                  type="button"
                  onClick={() => setSelectedFamilyForDetail(null)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                >
                  <ArrowRight size={14} />
                  <span>بازگشت به لیست خانواده‌ها</span>
                </button>
              </div>
              <AssetClassDetailView
                family={selectedFamilyForDetail}
                onBack={() => setSelectedFamilyForDetail(null)}
                onUpdateFamily={(updated) => {
                  const updatedList = familyList.map(f => f.id === selectedFamilyForDetail.id ? updated : f);
                  broadcastFamiliesUpdate(updatedList);
                  setSelectedFamilyForDetail(updated);
                }}
                equipments={equipmentList}
              />
            </div>
          ) : (
          <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 overflow-hidden shadow-lg flex flex-col min-h-[550px] animate-in fade-in duration-200">
            <div className="p-5 sm:p-6 border-b border-indigo-900/40 flex flex-col lg:flex-row justify-between lg:items-center gap-4 bg-[#070e22]/90">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActiveView('requests')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
                  >
                    <ArrowRight size={14} />
                    <span>بازگشت به کارتابل</span>
                  </button>
                  <h2 className="text-base font-bold text-slate-200 flex items-center gap-2">
                    <Wrench size={18} className="text-blue-400" /> 
                    <span>مدیریت تجهیزات و ماشین‌آلات (Equipment Management)</span>
                  </h2>
                </div>
                <div className="flex items-center gap-1 bg-[#070e22]/90 p-1 rounded-xl border border-indigo-500/20 w-fit">
                  <button 
                    onClick={() => { setEquipmentTab('list'); setSelectedFamilyForDetail(null); }} 
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      equipmentTab === 'list' ? 'bg-[#132448] text-slate-200 border border-[#484F58]' : 'text-slate-500'
                    }`}
                  >
                    لیست تجهیزات ({equipmentList.length})
                  </button>
                  <button 
                    onClick={() => { setEquipmentTab('families'); setSelectedFamilyForDetail(null); }} 
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      equipmentTab === 'families' ? 'bg-[#132448] text-slate-200 border border-[#484F58]' : 'text-slate-500'
                    }`}
                  >
                    خانواده تجهیزات ({familyList.length})
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
                <select
                  value={selectedLocationFilter}
                  onChange={e => {
                    setSelectedLocationFilter(e.target.value);
                    setEquipmentPage(1);
                  }}
                  className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                >
                  <option value="all">📍 همه مکان‌ها (۸ سالن)</option>
                  {locationsList.map(loc => (
                    <option key={loc.id} value={loc.name}>
                      {loc.code} - {loc.name}
                    </option>
                  ))}
                </select>

                <div className="relative">
                  <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    value={equipmentSearch}
                    onChange={e => {
                      setEquipmentSearch(e.target.value);
                      setEquipmentPage(1);
                      setFamilyPage(1);
                    }}
                    placeholder="جستجو در کد، نام، خانواده..."
                    className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-200 outline-none focus:border-blue-500 w-full sm:w-56"
                  />
                </div>
                <button 
                  onClick={equipmentTab === 'list' ? () => { setEqFormData({ id: '', name: '', family: '', location: '', priority: 'سطح C' }); setIsEditingEq(false); setIsEqModalOpen(true); } : () => { setFamFormData({ id: '', name: '', group: '' }); setIsEditingFam(false); setIsFamModalOpen(true); }} 
                  className="flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  <Plus size={15} /> 
                  <span>افزودن {equipmentTab === 'list' ? 'دستگاه جدید' : 'خانواده جدید'}</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto flex-1">
              {equipmentTab === 'list' ? (() => {
                const filtered = equipmentList.filter(eq => {
                  if (selectedLocationFilter !== 'all') {
                    if (!eq.location || !eq.location.includes(selectedLocationFilter)) {
                      return false;
                    }
                  }
                  if (!equipmentSearch.trim()) return true;
                  const q = equipmentSearch.toLowerCase().trim();
                  return (
                    (eq.id && eq.id.toLowerCase().includes(q)) ||
                    (eq.name && eq.name.toLowerCase().includes(q)) ||
                    (eq.family && eq.family.toLowerCase().includes(q)) ||
                    (eq.location && eq.location.toLowerCase().includes(q)) ||
                    (eq.priority && eq.priority.toLowerCase().includes(q))
                  );
                });
                const perPage = 25;
                const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
                const currentPage = Math.min(equipmentPage, totalPages);
                const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

                return (
                  <div className="flex flex-col">
                    <table className="w-full text-right whitespace-nowrap text-xs">
                      <thead>
                        <tr className="bg-[#070e22]/90 text-slate-400 border-b border-indigo-900/40">
                          <th className="px-5 py-3.5 font-bold">کد تجهیز</th>
                          <th className="px-5 py-3.5 font-bold">نام دستگاه</th>
                          <th className="px-5 py-3.5 font-bold">خانواده</th>
                          <th className="px-5 py-3.5 font-bold">مکان / سالن</th>
                          <th className="px-5 py-3.5 font-bold">اولویت</th>
                          <th className="px-5 py-3.5 font-bold text-center">عملیات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#333538]/50">
                        {filtered.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="text-center py-12 text-slate-400">
                              <Wrench size={32} className="mx-auto mb-2 text-slate-600" />
                              <span className="block text-xs font-bold text-slate-300">هیچ تجهیزی یافت نشد</span>
                            </td>
                          </tr>
                        ) : (
                          paginated.map(eq => (
                            <tr key={eq.id} className="hover:bg-[#112042]/50 transition-colors">
                              <td className="px-5 py-3.5 font-mono font-bold text-cyan-300">{eq.id}</td>
                              <td className="px-5 py-3.5 font-bold text-slate-200">{eq.name}</td>
                              <td className="px-5 py-3.5 text-slate-300">
                                {eq.family ? (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const matched = familyList.find(f => f.name === eq.family || f.id === eq.family);
                                      if (matched) {
                                        setSelectedFamilyForDetail(matched);
                                      } else {
                                        setSelectedFamilyForDetail({
                                          id: eq.id || 'FAM',
                                          name: eq.family,
                                          group: 'ماشین‌آلات تولید'
                                        });
                                      }
                                    }}
                                    className="text-purple-300 hover:text-cyan-300 hover:underline font-medium text-right text-xs transition-colors cursor-pointer"
                                    title="مشاهده شناسنامه و مشخصات این خانواده تجهیز"
                                  >
                                    {eq.family}
                                  </button>
                                ) : (
                                  <span className="text-slate-500">—</span>
                                )}
                              </td>
                              <td className="px-5 py-3.5 text-slate-400">{eq.location}</td>
                              <td className="px-5 py-3.5">
                                <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                                  eq.priority === 'سطح A' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' : 
                                  eq.priority === 'سطح B' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                                  'bg-slate-800 text-slate-300'
                                }`}>{eq.priority}</span>
                              </td>
                              <td className="px-5 py-3.5 text-center">
                                <div className="flex justify-center items-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleSelectEquipmentForRequest(eq)}
                                    className="px-2 py-1 rounded-md bg-cyan-950/80 hover:bg-cyan-800 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all shadow-sm"
                                    title="ثبت فوری درخواست کار برای این دستگاه"
                                  >
                                    <FilePlus size={13} />
                                    <span>درخواست کار</span>
                                  </button>
                                  <button 
                                    onClick={() => { setEqFormData(eq); setIsEditingEq(true); setIsEqModalOpen(true); }}
                                    className="p-1.5 text-slate-400 hover:text-blue-300 cursor-pointer"
                                  >
                                    <Pencil size={14} />
                                  </button>
                                  <button 
                                    onClick={() => deleteEquipment(eq.id)}
                                    className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>

                    {totalPages > 1 && (
                      <div className="p-3 bg-[#070e22]/90 border-t border-indigo-900/40 flex items-center justify-between text-xs text-slate-400">
                        <span>صفحه {currentPage} از {totalPages} ({filtered.length} تجهیز)</span>
                        <div className="flex gap-1">
                          <button 
                            disabled={currentPage <= 1}
                            onClick={() => setEquipmentPage(prev => Math.max(1, prev - 1))}
                            className="px-2.5 py-1 rounded bg-slate-800 disabled:opacity-40"
                          >
                            قبلی
                          </button>
                          <button 
                            disabled={currentPage >= totalPages}
                            onClick={() => setEquipmentPage(prev => Math.min(totalPages, prev + 1))}
                            className="px-2.5 py-1 rounded bg-slate-800 disabled:opacity-40"
                          >
                            بعدی
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })() : (() => {
                const filtered = familyList.filter(f => {
                  if (!equipmentSearch.trim()) return true;
                  const q = equipmentSearch.toLowerCase().trim();
                  return (
                    (f.id && f.id.toLowerCase().includes(q)) ||
                    (f.name && f.name.toLowerCase().includes(q)) ||
                    (f.group && f.group.toLowerCase().includes(q))
                  );
                });
                const perPage = 25;
                const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
                const currentPage = Math.min(familyPage, totalPages);
                const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

                return (
                  <div className="flex flex-col">
                    <table className="w-full text-right whitespace-nowrap text-xs">
                      <thead>
                        <tr className="bg-[#070e22]/90 text-slate-400 border-b border-indigo-900/40">
                          <th className="px-5 py-3.5 font-bold">کد خانواده</th>
                          <th className="px-5 py-3.5 font-bold">نام خانواده تجهیز</th>
                          <th className="px-5 py-3.5 font-bold">گروه اصلی</th>
                          <th className="px-5 py-3.5 font-bold text-center">عملیات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#333538]/50">
                        {paginated.map(f => (
                          <tr 
                            key={f.id} 
                            onClick={() => setSelectedFamilyForDetail(f)}
                            className="hover:bg-[#112042] transition-colors cursor-pointer group"
                          >
                            <td className="px-5 py-3.5 font-mono font-bold text-purple-300 group-hover:text-cyan-300 group-hover:underline">
                              {f.id}
                            </td>
                            <td className="px-5 py-3.5 font-bold text-slate-200 group-hover:text-cyan-300">
                              {f.name}
                            </td>
                            <td className="px-5 py-3.5 text-slate-400">
                              {f.group || 'ماشین‌آلات تولید'}
                            </td>
                            <td className="px-5 py-3.5 text-center" onClick={e => e.stopPropagation()}>
                              <div className="flex justify-center items-center gap-1.5">
                                <button 
                                  type="button"
                                  onClick={() => setSelectedFamilyForDetail(f)}
                                  title="مشاهده فرم خانواده تجهیز"
                                  className="p-1.5 text-slate-400 hover:text-cyan-300 cursor-pointer transition-colors"
                                >
                                  <Eye size={15} />
                                </button>
                                <button 
                                  type="button"
                                  onClick={() => { setFamFormData(f); setIsEditingFam(true); setIsFamModalOpen(true); }}
                                  className="p-1.5 text-slate-400 hover:text-purple-300 cursor-pointer"
                                  title="ویرایش"
                                >
                                  <Pencil size={14} />
                                </button>
                                <button 
                                  type="button"
                                  onClick={() => deleteFamily(f.id)}
                                  className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                                  title="حذف"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    {totalPages > 1 && (
                      <div className="p-3 bg-[#070e22]/90 border-t border-indigo-900/40 flex items-center justify-between text-xs text-slate-400">
                        <span>صفحه {currentPage} از {totalPages} ({filtered.length} خانواده تجهیز)</span>
                        <div className="flex gap-1">
                          <button 
                            type="button"
                            disabled={currentPage <= 1}
                            onClick={() => setFamilyPage(prev => Math.max(1, prev - 1))}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                          >
                            قبلی
                          </button>
                          <button 
                            type="button"
                            disabled={currentPage >= totalPages}
                            onClick={() => setFamilyPage(prev => Math.min(totalPages, prev + 1))}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                          >
                            بعدی
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          </div>
          )
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 3: مدیریت مکان‌ها                              */}
        {/* ---------------------------------------------------- */}
        {activeView === 'locations' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 p-5 sm:p-6 shadow-lg flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveView('requests')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
                >
                  <ArrowRight size={14} />
                  <span>بازگشت به کارتابل</span>
                </button>
                <div>
                  <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <Building2 size={18} className="text-emerald-400" />
                    <span>مدیریت مکان‌ها و سالن‌های استقرار (Plant Locations & Zones)</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    سلسله‌مراتب مکان‌ها و سالن‌های اصلی با امکان افزودن زیرسیستم‌ها (طبقات، بخش‌ها و نواحی تحت پوشش)
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                <div className="relative">
                  <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={locationSearch}
                    onChange={e => setLocationSearch(e.target.value)}
                    placeholder="جستجو در نام، کد یا زیرسیستم..."
                    className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-200 outline-none focus:border-emerald-500 w-full sm:w-60"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextNum = locationsList.length + 1;
                    const codeStr = nextNum < 10 ? `S0${nextNum}` : `S${nextNum}`;
                    setLocFormData({ id: '', code: codeStr, name: '', description: '' });
                    setIsEditingLoc(false);
                    setIsLocModalOpen(true);
                  }}
                  className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  <Plus size={15} />
                  <span>افزودن مکان / سالن جدید</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-emerald-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Building2 size={20} />
                </div>
                <div>
                  <div className="text-xl font-bold font-mono text-emerald-300">{locationsList.length}</div>
                  <div className="text-xs text-slate-400">سالن و بخش اصلی ثبت‌شده</div>
                </div>
              </div>

              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-blue-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <FolderTree size={20} />
                </div>
                <div>
                  <div className="text-xl font-mono font-bold text-blue-300">
                    {locationsList.reduce((acc, loc) => acc + (loc.subLocations?.length || 0), 0)}
                  </div>
                  <div className="text-xs text-slate-400">زیرسیستم، طبقه و ناحیه فعال</div>
                </div>
              </div>

              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-purple-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                  <Wrench size={20} />
                </div>
                <div>
                  <div className="text-xl font-mono font-bold text-purple-300">
                    {equipmentList.length}
                  </div>
                  <div className="text-xs text-slate-400">دستگاه و تجهیز تحت پوشش مکان‌ها</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {locationsList
                .filter(loc => {
                  if (!locationSearch.trim()) return true;
                  const q = locationSearch.toLowerCase().trim();
                  const matchMain = (loc.code || '').toLowerCase().includes(q) || (loc.name || '').toLowerCase().includes(q) || (loc.description && loc.description.toLowerCase().includes(q));
                  const matchSub = (loc.subLocations || []).some((s: any) => (s.name || '').toLowerCase().includes(q));
                  return matchMain || matchSub;
                })
                .map(loc => {
                  const isExpanded = !!expandedLocations[loc.id];
                  const assignedEquipments = equipmentList.filter(eq => eq.location && (eq.location.includes(loc.name) || eq.location.includes(loc.code)));
                  const subList = loc.subLocations || [];

                  return (
                    <div key={loc.id} className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 overflow-hidden shadow-lg transition-all">
                      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#070e22]/60 hover:bg-[#112042]/50 transition-colors">
                        <div className="flex items-center gap-3 flex-1 cursor-pointer select-none" onClick={() => toggleLocationExpand(loc.id)}>
                          <button
                            type="button"
                            className="w-8 h-8 rounded-lg bg-[#132448] text-slate-300 hover:text-white flex items-center justify-center border border-indigo-500/30"
                          >
                            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                          </button>
                          
                          <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 font-mono font-bold text-xs text-emerald-400">
                            {loc.code}
                          </div>

                          <div>
                            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                              <span>{loc.name}</span>
                              <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                                {subList.length} زیرسیستم
                              </span>
                              <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                {assignedEquipments.length} دستگاه
                              </span>
                            </div>
                            {loc.description && (
                              <p className="text-[11px] text-slate-400 mt-0.5">{loc.description}</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            type="button"
                            onClick={() => handleSelectLocationForRequest(loc)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-950/80 hover:bg-emerald-800 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1 cursor-pointer shadow-sm transition-all"
                            title="ثبت درخواست کار در این سالن"
                          >
                            <FilePlus size={13} />
                            <span>درخواست کار در سالن</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setLocFormData(loc);
                              setIsEditingLoc(true);
                              setIsLocModalOpen(true);
                            }}
                            className="p-1.5 text-slate-400 hover:text-emerald-300 cursor-pointer"
                          >
                            <Pencil size={15} />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteLocation(loc.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="p-4 sm:p-5 border-t border-indigo-900/40 bg-[#070e22]/90 space-y-4">
                          <div>
                            <div className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                              <FolderTree size={14} className="text-emerald-400" />
                              <span>زیرسیستم‌ها و بخش‌های تابعه ({loc.name})</span>
                            </div>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                              {subList.map((sub: any) => (
                                <div key={sub.id} className="p-2.5 rounded-xl bg-[#0c162e] border border-indigo-500/20 flex items-center justify-between text-xs">
                                  <div>
                                    <div className="font-bold text-slate-200">{sub.name}</div>
                                    <div className="text-[10px] text-slate-500 font-mono">{sub.id}</div>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleSelectLocationForRequest(loc, sub.name)}
                                      className="p-1 text-cyan-400 hover:text-cyan-200"
                                      title="ثبت کار در این بخش"
                                    >
                                      <FilePlus size={13} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => deleteSubLocation(loc.id, sub.id)}
                                      className="p-1 text-slate-500 hover:text-rose-400"
                                    >
                                      <X size={13} />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>

                            <div className="mt-3 flex gap-2 max-w-md">
                              <input
                                type="text"
                                value={newSubLocInputs[loc.id] || ''}
                                onChange={e => setNewSubLocInputs(prev => ({ ...prev, [loc.id]: e.target.value }))}
                                placeholder="نام زیرسیستم جدید (مانند طبقه همکف، ناحیه A)..."
                                className="flex-1 bg-[#0c162e] border border-indigo-500/30 rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-emerald-400"
                              />
                              <button
                                type="button"
                                onClick={() => addSubLocation(loc.id)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                              >
                                افزودن بخش
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 4: مدیریت حرفه‌ای اپراتورها (مورد چهارم)          */}
        {/* ---------------------------------------------------- */}
        {activeView === 'operators' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 p-5 sm:p-6 shadow-lg flex flex-col lg:flex-row justify-between lg:items-center gap-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveView('requests')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
                >
                  <ArrowRight size={14} />
                  <span>بازگشت به کارتابل</span>
                </button>
                <div>
                  <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <Users size={18} className="text-purple-400" />
                    <span>مدیریت اپراتورها و پرسنل (Operators Directory)</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    فهرست رسمی پرسنل و اپراتورهای خط تولید با کدهای پرسنلی یکتا جهت ثبت سریع درخواست کار
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                <div className="relative">
                  <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={operatorSearch}
                    onChange={e => setOperatorSearch(e.target.value)}
                    placeholder="جستجو در نام، کد پرسنلی یا بخش..."
                    className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl pr-8 pl-3 py-1.5 text-xs text-white outline-none focus:border-purple-400 w-full sm:w-60"
                  />
                </div>

                <select
                  value={selectedDeptFilter}
                  onChange={e => setSelectedDeptFilter(e.target.value)}
                  className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-purple-400 cursor-pointer"
                >
                  <option value="all">همه واحدها</option>
                  <option value="تولید">واحد تولید</option>
                  <option value="تراشکاری">تراشکاری CNC</option>
                  <option value="فرزکاری">فرزکاری CNC</option>
                  <option value="پرس">پرسکاری</option>
                  <option value="کنترل کیفیت">کنترل کیفیت</option>
                  <option value="خدمات فنی">خدمات فنی</option>
                </select>

                <button
                  type="button"
                  onClick={handleOpenAddOperator}
                  className="flex items-center justify-center gap-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer active:scale-95"
                >
                  <UserPlus size={15} />
                  <span>افزودن اپراتور جدید</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-purple-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                  <Users size={20} />
                </div>
                <div>
                  <div className="text-xl font-bold font-mono text-purple-300">{operatorsList.length}</div>
                  <div className="text-xs text-slate-400">اپراتور و پرسنل ثبت‌شده</div>
                </div>
              </div>

              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-cyan-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <div className="text-xl font-mono font-bold text-cyan-300">
                    {operatorsList.filter(o => o.personnelCode).length}
                  </div>
                  <div className="text-xs text-slate-400">دارای کد پرسنلی معتبر</div>
                </div>
              </div>

              <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-emerald-500/20 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Briefcase size={20} />
                </div>
                <div>
                  <div className="text-xl font-mono font-bold text-emerald-300">
                    {Array.from(new Set(operatorsList.map(o => o.department || 'تولید'))).length}
                  </div>
                  <div className="text-xs text-slate-400">واحد و بخش فعال در سامانه</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
              {operatorsList
                .filter(op => {
                  if (selectedDeptFilter !== 'all') {
                    if (!op.department || !op.department.includes(selectedDeptFilter)) return false;
                  }
                  if (!operatorSearch.trim()) return true;
                  const q = operatorSearch.toLowerCase().trim();
                  return (
                    (op.name || '').toLowerCase().includes(q) ||
                    (op.personnelCode || '').toLowerCase().includes(q) ||
                    (op.department || '').toLowerCase().includes(q)
                  );
                })
                .map(op => {
                  return (
                    <div 
                      key={op.id || op.personnelCode} 
                      className="p-4 rounded-2xl bg-[#0c162e]/85 backdrop-blur-xl border border-indigo-500/20 hover:border-purple-500/40 transition-all flex flex-col justify-between gap-3 shadow-md hover:shadow-lg group"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="font-bold text-white text-xs group-hover:text-purple-300 transition-colors">
                            {op.name}
                          </div>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <span className="font-mono text-amber-300 text-[11px] px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-500/30 font-bold">
                              کد: {op.personnelCode}
                            </span>
                            <span className="text-[10px] text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
                              {op.department || 'تولید'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEditOperator(op)}
                            className="p-1.5 text-slate-400 hover:text-purple-300 transition-colors cursor-pointer"
                            title="ویرایش مشخصات اپراتور"
                          >
                            <Pencil size={13} />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteOperator(op.personnelCode, op.name)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                            title="حذف اپراتور"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-indigo-900/40 flex items-center justify-between text-xs">
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Clock size={12} className="text-slate-500" />
                          <span>شیفت: {(op as any).shift || 'صبح'}</span>
                        </span>
                        
                        <button
                          type="button"
                          onClick={() => handleSelectOperator(op)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-950/80 hover:bg-purple-900 text-purple-200 border border-indigo-500/40 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-sm"
                        >
                          <FilePlus size={12} />
                          <span>انتخاب متقاضی</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 5: گزارش‌ها و تحلیل‌های فنی                      */}
        {/* ---------------------------------------------------- */}
        {activeView === 'reports' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <WorkRequestReportsView
              onBack={() => setActiveView('requests')}
              systemTheme={systemTheme}
              requestsList={requestsList}
              onUpdateRequest={(updatedReq: any) => {
                setRequestsList(prev => prev.map(r => r.id === updatedReq.id ? updatedReq : r));
                try {
                  const stored = localStorage.getItem('portal_pm_work_requests_v3');
                  const list = stored ? JSON.parse(stored) : [];
                  const updated = list.map((r: any) => r.id === updatedReq.id ? updatedReq : r);
                  localStorage.setItem('portal_pm_work_requests_v3', JSON.stringify(updated));
                } catch {}
              }}
              onAddRequest={(newReq: any) => {
                setRequestsList(prev => [newReq, ...prev]);
                try {
                  const stored = localStorage.getItem('portal_pm_work_requests_v3');
                  const list = stored ? JSON.parse(stored) : [];
                  localStorage.setItem('portal_pm_work_requests_v3', JSON.stringify([newReq, ...list]));
                } catch {}
              }}
            />
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* VIEW 6: تنظیمات پرینت (کد سند و عنوان تمام برگه‌های چاپی) */}
        {/* ---------------------------------------------------- */}
        {activeView === 'printSettings' && (() => {
          const defaultsMap = getDefaultPrintSettings();
          const sections: Array<'all' | 'درخواست کار و دستورکار' | 'گزارش‌های تحلیلی و پارتو' | 'خدمات فنی، PM و انبار'> = [
            'all',
            'درخواست کار و دستورکار',
            'گزارش‌های تحلیلی و پارتو',
            'خدمات فنی، PM و انبار'
          ];
          const q = printSettingsSearch.trim().toLowerCase();
          const filteredDefs = PRINT_TEMPLATE_DEFINITIONS.filter(def => {
            if (printSettingsSectionFilter !== 'all' && def.section !== printSettingsSectionFilter) return false;
            if (!q) return true;
            const current = printSettingsDraft[def.key];
            return (
              def.label.toLowerCase().includes(q) ||
              def.description.toLowerCase().includes(q) ||
              (current?.docCode || '').toLowerCase().includes(q) ||
              (current?.docTitle || '').toLowerCase().includes(q)
            );
          });

          const handleDraftFieldChange = (
            key: PrintTemplateKey,
            field: 'docCode' | 'docTitle',
            value: string
          ) => {
            setPrintSettingsDraft(prev => ({
              ...prev,
              [key]: {
                ...prev[key],
                [field]: value
              }
            }));
          };

          const handleSaveSingleRow = (key: PrintTemplateKey) => {
            const def = PRINT_TEMPLATE_DEFINITIONS.find(d => d.key === key);
            if (!def) return;
            const entry = printSettingsDraft[key];
            const sanitizedEntry = {
              docCode: entry?.docCode?.trim() ? entry.docCode.trim() : def.defaultDocCode,
              docTitle: entry?.docTitle?.trim() ? entry.docTitle.trim() : def.defaultDocTitle
            };
            const currentSaved = loadPrintSettings();
            const nextSaved: PrintSettingsMap = {
              ...currentSaved,
              [key]: sanitizedEntry
            };
            savePrintSettings(nextSaved);
            setPrintSettingsDraft(prev => ({
              ...prev,
              [key]: sanitizedEntry
            }));
            setPrintSavedRowKey(key);
            setTimeout(() => setPrintSavedRowKey(prev => (prev === key ? null : prev)), 2500);
            setPrintSettingsToast(`«${def.label}» با کد سند «${sanitizedEntry.docCode}» و عنوان «${sanitizedEntry.docTitle}» ثبت و داخل فرم مربوطه اعمال شد.`);
            setTimeout(() => setPrintSettingsToast(null), 5000);
          };

          const handleResetSingleRow = (key: PrintTemplateKey) => {
            const def = defaultsMap[key];
            const currentSaved = loadPrintSettings();
            const nextSaved = {
              ...currentSaved,
              [key]: { ...def }
            };
            savePrintSettings(nextSaved);
            setPrintSettingsDraft(prev => ({
              ...prev,
              [key]: { ...def }
            }));
            setPrintSettingsToast('مقادیر پیش‌فرض این برگه بازگردانی و ثبت شد.');
            setTimeout(() => setPrintSettingsToast(null), 4000);
          };

          return (
            <div className="space-y-5 animate-in fade-in duration-200">
              {printSettingsToast && (
                <div className="rounded-xl bg-emerald-950/90 border border-emerald-500/40 px-4 py-2.5 text-xs font-bold text-emerald-200 flex items-center justify-between gap-2 shadow">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{printSettingsToast}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPrintSettingsToast(null)}
                    className="text-emerald-300 hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* فیلتر بخش و جستجو */}
              <div className="rounded-2xl bg-[#0c162e]/85 border border-indigo-500/20 p-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  {sections.map(sec => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => setPrintSettingsSectionFilter(sec)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        printSettingsSectionFilter === sec
                          ? 'bg-cyan-600 text-white shadow'
                          : 'bg-[#070e22] text-slate-300 hover:text-white border border-indigo-500/25'
                      }`}
                    >
                      {sec === 'all' ? `همه برگه‌ها (${PRINT_TEMPLATE_DEFINITIONS.length})` : sec}
                    </button>
                  ))}
                </div>

                <div className="relative min-w-[230px] flex-1 max-w-xs">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={printSettingsSearch}
                    onChange={e => setPrintSettingsSearch(e.target.value)}
                    placeholder="جستجو در نام برگه، کد سند یا عنوان..."
                    className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* جدول ویرایش کد سند و عنوان برگه‌های چاپی */}
              <div className="rounded-2xl bg-[#0c162e]/90 border border-indigo-500/20 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-[#070e22] text-slate-300 border-b border-indigo-900/50 font-bold">
                        <th className="p-3.5 w-12 text-center">#</th>
                        <th className="p-3.5 min-w-[220px]">برگه / گزارش چاپی</th>
                        <th className="p-3.5 w-40">بخش</th>
                        <th className="p-3.5 w-48">کد سند (Doc Code)</th>
                        <th className="p-3.5 min-w-[260px]">عنوان چاپی (Title)</th>
                        <th className="p-3.5 w-40 text-center">ثبت / عملیات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-indigo-950/60">
                      {filteredDefs.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-500">
                            موردی با فیلتر انتخاب‌شده یافت نشد.
                          </td>
                        </tr>
                      ) : (
                        filteredDefs.map((def, idx) => {
                          const entry = printSettingsDraft[def.key] || {
                            docCode: def.defaultDocCode,
                            docTitle: def.defaultDocTitle
                          };
                          const savedEntry = printSettings[def.key] || {
                            docCode: def.defaultDocCode,
                            docTitle: def.defaultDocTitle
                          };
                          const hasUnsavedChanges =
                            entry.docCode.trim() !== savedEntry.docCode.trim() ||
                            entry.docTitle.trim() !== savedEntry.docTitle.trim();
                          const isCustomized =
                            entry.docCode.trim() !== def.defaultDocCode ||
                            entry.docTitle.trim() !== def.defaultDocTitle;
                          const isJustSaved = printSavedRowKey === def.key;
                          return (
                            <tr key={def.key} className="hover:bg-[#112042]/45 transition-colors">
                              <td className="p-3 text-center font-mono text-slate-400">{idx + 1}</td>
                              <td className="p-3">
                                <div className="font-bold text-white flex items-center gap-2">
                                  <span>{def.label}</span>
                                  {isCustomized && (
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-500/30">
                                      سفارشی
                                    </span>
                                  )}
                                  {hasUnsavedChanges && (
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40">
                                      تغییر یافته
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-400 mt-0.5">{def.description}</div>
                              </td>
                              <td className="p-3">
                                <span className="inline-block px-2 py-1 rounded-lg bg-[#070e22] border border-indigo-500/25 text-[11px] text-cyan-300 font-bold">
                                  {def.section}
                                </span>
                              </td>
                              <td className="p-3">
                                <input
                                  type="text"
                                  dir="ltr"
                                  value={entry.docCode}
                                  onChange={e => handleDraftFieldChange(def.key, 'docCode', e.target.value)}
                                  onKeyDown={e => { if (e.key === 'Enter') handleSaveSingleRow(def.key); }}
                                  placeholder={def.defaultDocCode}
                                  className="w-full bg-[#070e22] border border-indigo-500/35 rounded-xl px-3 py-2 text-xs font-mono font-bold text-cyan-300 text-left outline-none focus:border-cyan-400"
                                />
                              </td>
                              <td className="p-3">
                                <input
                                  type="text"
                                  value={entry.docTitle}
                                  onChange={e => handleDraftFieldChange(def.key, 'docTitle', e.target.value)}
                                  onKeyDown={e => { if (e.key === 'Enter') handleSaveSingleRow(def.key); }}
                                  placeholder={def.defaultDocTitle}
                                  className="w-full bg-[#070e22] border border-indigo-500/35 rounded-xl px-3 py-2 text-xs font-bold text-white text-right outline-none focus:border-cyan-400"
                                />
                              </td>
                              <td className="p-3 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleSaveSingleRow(def.key)}
                                    title="ثبت و اعمال فوری روی فرم مربوطه"
                                    className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer active:scale-95 ${
                                      isJustSaved
                                        ? 'bg-emerald-600 text-white border border-emerald-400 shadow-md'
                                        : hasUnsavedChanges
                                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md shadow-emerald-950/60'
                                        : 'bg-emerald-950/70 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40'
                                    }`}
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>{isJustSaved ? 'ثبت شد' : 'ثبت'}</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleResetSingleRow(def.key)}
                                    disabled={!isCustomized}
                                    title="بازگردانی این ردیف به پیش‌فرض"
                                    className={`p-1.5 rounded-xl border transition-all ${
                                      isCustomized
                                        ? 'bg-slate-800 hover:bg-amber-600/30 text-amber-300 border-amber-500/40 cursor-pointer'
                                        : 'bg-slate-900/40 text-slate-600 border-slate-800 cursor-not-allowed'
                                    }`}
                                  >
                                    <RotateCcw className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          );
        })()}

      </main>

      {/* ======================================================== */}
      {/* مودال افزودن درخواست کار (تصویر اول با اتوکامپلیت هوشمند) */}
      {/* ======================================================== */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl rounded-3xl bg-[#0e1424] border border-slate-700 shadow-2xl p-5 sm:p-8 space-y-6 my-auto max-h-[94vh] overflow-y-auto text-right">
            
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-700 text-white flex items-center justify-center font-bold text-lg shadow-md">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-white">افزودن درخواست کار</h2>
                  <p className="text-xs text-slate-400 font-mono">شناسه جدید: {formData.code}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveWorkRequest} className="space-y-4">
              
              {/* ردیف ۱: کد تجهیز با فیلتر کم‌کم زنده + عنوان تجهیز */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div className="space-y-1.5 relative" ref={eqInputContainerRef}>
                  <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                    <span>کد تجهیز * (تایپ کنید تا خودکار فیلتر شود)</span>
                    <span className="text-[10px] text-cyan-400 font-mono">
                      {liveFilteredEquipments.length} مورد منطبق
                    </span>
                  </label>
                  
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={formData.equipmentCode}
                      onFocus={() => setIsEqDropdownVisible(true)}
                      onChange={e => {
                        const val = e.target.value;
                        setIsEqDropdownVisible(true);
                        const exactMatch = equipmentList.find(eq => (eq.id || '').toUpperCase() === val.trim().toUpperCase());
                        if (exactMatch) {
                          const details = extractEquipmentDetails(exactMatch);
                          setFormData(prev => ({
                            ...prev,
                            equipmentCode: details.code,
                            equipmentName: details.name || details.familyName,
                            equipmentFamilyCode: details.familyCode,
                            equipmentFamilyName: details.familyName,
                            locationCode: details.locCode,
                            locationName: details.locName,
                            failureCode: '',
                            failureTitle: ''
                          }));
                        } else {
                          setFormData(prev => ({ ...prev, equipmentCode: val }));
                        }
                      }}
                      placeholder=""
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 font-mono text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="button"
                      onClick={() => setIsEqDropdownVisible(!isEqDropdownVisible)}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <ChevronDown size={16} />
                    </button>
                  </div>

                  {isEqDropdownVisible && (
                    <div className="absolute z-50 right-0 left-0 mt-1 max-h-56 overflow-y-auto rounded-xl bg-[#091122] border border-cyan-500/40 shadow-2xl divide-y divide-slate-800 text-right">
                      {liveFilteredEquipments.length === 0 ? (
                        <div className="p-3 text-center text-xs text-slate-400">
                          دستگاهی با این مشخصات یافت نشد.
                        </div>
                      ) : (
                        liveFilteredEquipments.map(eq => {
                          const details = extractEquipmentDetails(eq);
                          return (
                            <div
                              key={eq.id}
                              onClick={() => handleSelectEquipmentForRequest(eq)}
                              className="p-2.5 hover:bg-cyan-950/60 cursor-pointer transition-colors flex items-center justify-between text-xs group"
                            >
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-cyan-500/30">
                                  {eq.id}
                                </span>
                                <span className="text-white font-bold group-hover:text-cyan-200">
                                  {eq.name}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                                  {details.familyName}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {eq.location || 'سالن تولید'}
                                </span>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">عنوان و نوع تجهیز</label>
                  <input
                    type="text"
                    value={formData.equipmentName}
                    onChange={e => setFormData({ ...formData, equipmentName: e.target.value })}
                    placeholder=""
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* ردیف ۲: مسیر عنوان خانواده تجهیز و کد خانواده تجهیز */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">مسیر عنوان خانواده تجهیز (خودکار)</label>
                  <input
                    type="text"
                    value={formData.equipmentFamilyName}
                    onChange={e => setFormData({ ...formData, equipmentFamilyName: e.target.value })}
                    placeholder=""
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">مسیر کد خانواده تجهیز</label>
                  <input
                    type="text"
                    value={formData.equipmentFamilyCode}
                    onChange={e => setFormData({ ...formData, equipmentFamilyCode: e.target.value })}
                    placeholder=""
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 font-mono text-xs text-slate-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* ردیف ۳: مسیر عنوان مکان و مسیر کد مکان */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">مسیر عنوان مکان</label>
                  <input
                    type="text"
                    value={formData.locationName}
                    onChange={e => setFormData({ ...formData, locationName: e.target.value })}
                    placeholder="مانند: سالن یک_طبقه همکف_تولید"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">مسیر کد مکان</label>
                  <select
                    value={formData.locationCode}
                    onChange={e => {
                      const loc = locationsList.find(l => l.code === e.target.value);
                      setFormData({
                        ...formData,
                        locationCode: e.target.value,
                        locationName: loc ? `${loc.name}_طبقه همکف_تولید` : formData.locationName
                      });
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 focus:outline-none focus:border-cyan-400 cursor-pointer"
                  >
                    {locationsList.map(loc => (
                      <option key={loc.id} value={loc.code}>
                        {loc.code} - {loc.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* ردیف ۴: سرچ سریع عنوان حالت خرابی (فقط از خانواده تجهیز انتخابی) و کد حالت خرابی */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5 relative" ref={failureInputContainerRef}>
                  <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                    <span>عنوان حالت خرابی *</span>
                    {selectedFamilyFailureInfo.hasSelectedEquipment && (
                      <span className="text-[10px] text-amber-400 font-mono">
                        {selectedFamilyFailureInfo.items.length} حالت در خانواده
                      </span>
                    )}
                  </label>
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      required
                      value={formData.failureTitle}
                      onFocus={() => setIsFailureDropdownVisible(true)}
                      onChange={e => {
                        const val = e.target.value;
                        setIsFailureDropdownVisible(true);
                        const normVal = normalizeFaFamilyText(val);
                        const exact = selectedFamilyFailureInfo.items.find(
                          item =>
                            normalizeFaFamilyText(item.title) === normVal ||
                            (item.code && normalizeFaFamilyText(item.code) === normVal)
                        );
                        setFormData(prev => ({
                          ...prev,
                          failureTitle: exact ? exact.title : val,
                          failureCode: exact ? exact.code : (!val.trim() ? '' : prev.failureCode)
                        }));
                      }}
                      placeholder=""
                      className="w-full pr-9 pl-12 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-amber-200 font-bold focus:outline-none focus:border-amber-400"
                    />
                    <div className="absolute left-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      {formData.failureTitle && (
                        <button
                          type="button"
                          onClick={() => {
                            setFormData(prev => ({ ...prev, failureTitle: '', failureCode: '' }));
                            setIsFailureDropdownVisible(true);
                          }}
                          className="text-slate-400 hover:text-white p-0.5"
                          title="پاک کردن"
                        >
                          <X size={13} />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setIsFailureDropdownVisible(v => !v)}
                        className="text-slate-400 hover:text-white p-0.5"
                      >
                        <ChevronDown size={15} />
                      </button>
                    </div>
                  </div>

                  {isFailureDropdownVisible && (
                    <div className="absolute z-50 right-0 left-0 mt-1 max-h-56 overflow-y-auto rounded-xl bg-[#091122] border border-amber-500/40 shadow-2xl divide-y divide-slate-800 text-right">
                      {!selectedFamilyFailureInfo.hasSelectedEquipment ? (
                        <div className="p-3 text-center text-xs text-slate-400">
                          ابتدا کد تجهیز را در بالا انتخاب کنید تا حالت‌های خرابی همان خانواده نمایش داده شود.
                        </div>
                      ) : selectedFamilyFailureInfo.items.length === 0 ? (
                        <div className="p-3 text-center text-xs text-slate-400 leading-relaxed">
                          حالت خرابی برای خانواده «{selectedFamilyFailureInfo.familyLabel}» ثبت نشده است.
                        </div>
                      ) : filteredFamilyFailureModes.length === 0 ? (
                        <div className="p-3 text-center text-xs text-slate-400">
                          موردی با عبارت جستجو شده در این خانواده یافت نشد.
                        </div>
                      ) : (
                        filteredFamilyFailureModes.map(item => (
                          <div
                            key={item.id}
                            onClick={() => {
                              setFormData(prev => ({
                                ...prev,
                                failureTitle: item.title,
                                failureCode: item.code
                              }));
                              setIsFailureDropdownVisible(false);
                            }}
                            className="p-2.5 hover:bg-amber-950/40 cursor-pointer transition-colors flex items-center justify-between gap-2 text-xs group"
                          >
                            <span className="text-slate-100 font-bold group-hover:text-amber-200 truncate">
                              {item.title}
                            </span>
                            {item.code && (
                              <span className="font-mono font-bold text-rose-300 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-500/30 shrink-0">
                                {item.code}
                              </span>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">کد حالت خرابی</label>
                  <input
                    type="text"
                    value={formData.failureCode}
                    onChange={e => setFormData({ ...formData, failureCode: e.target.value })}
                    placeholder=""
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 font-mono text-xs text-slate-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* ردیف ۵: اولویت (۳ گزینه درخواستی) و نوع درخواست کار (۳ گزینه) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    اولویت درخواست کار (۳ گزینه اختصاصی)
                  </label>
                  <select
                    value={formData.priority}
                    onChange={e => setFormData({ ...formData, priority: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer font-bold"
                  >
                    <option value="توقف تولید">🔴 توقف تولید (اضطراری بالا)</option>
                    <option value="توقف تجهیز">🟡 توقف تجهیز (دستگاه متوقف شده)</option>
                    <option value="عدم توقف تجهیز">🟢 عدم توقف تجهیز (فعال با عیب جزئی)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    نوع درخواست کار (EM / CM / PM)
                  </label>
                  <select
                    value={formData.requestType}
                    onChange={e => setFormData({ ...formData, requestType: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer font-bold"
                  >
                    <option value="اضطراری">اضطراری (EM - Emergency Maintenance)</option>
                    <option value="اصلاحی">اصلاحی (CM - Corrective Maintenance)</option>
                    <option value="پیشگیرانه">پیشگیرانه (PM - Preventive Maintenance)</option>
                  </select>
                </div>
              </div>

              {/* ردیف ۶: متقاضی / اپراتور و زمان درخواست کار با قابلیت سرچ سریع */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5" ref={opInputContainerRef}>
                  <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                    <span>متقاضی و ثبت‌کننده درخواست کار *</span>
                    <span className="text-[10px] text-purple-400">جستجوی سریع اپراتور ({operatorsList.length})</span>
                  </label>

                  {/* نمایش اپراتور انتخاب‌شده */}
                  {formData.operatorName && (
                    <div className="flex items-center justify-between p-2 rounded-xl bg-purple-950/40 border border-purple-500/30 text-xs">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-purple-400 shrink-0" />
                        <span className="font-bold text-white">{formData.operatorName}</span>
                        {formData.operatorPersonnelCode && (
                          <span className="font-mono text-purple-300 bg-purple-900/60 px-2 py-0.5 rounded text-[11px]">
                            کد پرسنلی: {formData.operatorPersonnelCode}
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData({ ...formData, operatorName: '', operatorPersonnelCode: '' });
                          setIsOpDropdownVisible(true);
                        }}
                        className="text-slate-400 hover:text-rose-400 p-1 transition-colors"
                        title="تغییر متقاضی"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* اینپوت سرچ سریع با لیست شناور نتایج */}
                  <div className="relative">
                    <div className="relative flex items-center">
                      <Search className="absolute right-3 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
                      <input
                        type="text"
                        value={operatorSearchQuery}
                        onChange={e => {
                          setOperatorSearchQuery(e.target.value);
                          setIsOpDropdownVisible(true);
                        }}
                        onFocus={() => setIsOpDropdownVisible(true)}
                        placeholder="جستجوی سریع اپراتور (نام یا کد پرسنلی)..."
                        className="w-full pr-9 pl-8 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 transition-colors"
                      />
                      {operatorSearchQuery && (
                        <button
                          type="button"
                          onClick={() => setOperatorSearchQuery('')}
                          className="absolute left-2.5 p-1 text-slate-400 hover:text-white"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* منوی کشویی نتایج جستجوی اپراتور */}
                    {isOpDropdownVisible && (
                      <div className="absolute top-full right-0 left-0 mt-1 max-h-56 overflow-y-auto rounded-xl bg-[#0f172a] border border-purple-500/40 shadow-2xl z-50 divide-y divide-slate-800 text-right">
                        {filteredOperatorsForForm.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-400">
                            اپراتوری با مشخصات «{operatorSearchQuery}» یافت نشد.
                          </div>
                        ) : (
                          filteredOperatorsForForm.map(op => {
                            const isSelected = formData.operatorPersonnelCode === op.personnelCode;
                            return (
                              <div
                                key={op.id || op.personnelCode}
                                onClick={() => {
                                  setFormData(prev => ({
                                    ...prev,
                                    operatorName: op.name,
                                    operatorPersonnelCode: op.personnelCode
                                  }));
                                  setIsOpDropdownVisible(false);
                                  setOperatorSearchQuery('');
                                }}
                                className={`p-2.5 hover:bg-purple-950/60 cursor-pointer transition-colors flex items-center justify-between text-xs group ${
                                  isSelected ? 'bg-purple-950/40' : ''
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <User className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
                                  <span className="text-white font-bold group-hover:text-purple-200">
                                    {op.name}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono text-[11px] text-purple-300 bg-purple-900/40 px-2 py-0.5 rounded border border-purple-500/30">
                                    کد: {op.personnelCode}
                                  </span>
                                  {op.department && (
                                    <span className="text-[10px] text-slate-400">
                                      {op.department}
                                    </span>
                                  )}
                                  {isSelected && (
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">زمان درخواست کار</label>
                  <input
                    type="text"
                    value={formData.requestTime}
                    onChange={e => setFormData({ ...formData, requestTime: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 font-mono text-xs text-slate-300 focus:outline-none focus:border-cyan-400"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* ردیف ۷: توضیحات */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">توضیحات تکمیلی نقص فنی</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="شرح دقیق‌تر عیب (مانند atc alarm، محور Z، نشت روغن و...)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400 leading-relaxed"
                />
              </div>

              {/* دکمه‌های پایانی فرم */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  انصراف
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-950/60 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>ذخیره و صدور برگه رسمی چاپی</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}


      {/* ======================================================== */}
      {/* مودال افزودن / ویرایش اپراتور (مورد چهارم و پنجم)         */}
      {/* ======================================================== */}
      {isOperatorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#0c162e] border border-purple-500/40 rounded-3xl p-6 w-full max-w-md shadow-2xl text-right space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <UserPlus size={18} className="text-purple-400" />
                <span>{isEditingOperator ? 'ویرایش مشخصات اپراتور' : 'افزودن اپراتور جدید'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsOperatorModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={saveOperator} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">کد پرسنلی (یکتا) *</label>
                <input
                  type="text"
                  required
                  disabled={isEditingOperator}
                  value={operatorFormData.personnelCode}
                  onChange={e => setOperatorFormData({ ...operatorFormData, personnelCode: e.target.value })}
                  placeholder="مانند: 1042"
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-xs text-amber-300 font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">نام و نام خانوادگی *</label>
                <input
                  type="text"
                  required
                  value={operatorFormData.name}
                  onChange={e => setOperatorFormData({ ...operatorFormData, name: e.target.value })}
                  placeholder="نام و نام خانوادگی ثبت‌کننده"
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">واحد سازمانی / بخش</label>
                <select
                  value={operatorFormData.department}
                  onChange={e => setOperatorFormData({ ...operatorFormData, department: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
                >
                  <option value="تولید">واحد تولید</option>
                  <option value="تراشکاری">تراشکاری CNC</option>
                  <option value="فرزکاری">فرزکاری CNC</option>
                  <option value="پرسکاری">پرسکاری</option>
                  <option value="کنترل کیفیت">کنترل کیفیت</option>
                  <option value="خدمات فنی">خدمات فنی و نگهداری</option>
                  <option value="مونتاژ">مونتاژ و بسته‌بندی</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">شیفت کاری</label>
                <select
                  value={operatorFormData.shift}
                  onChange={e => setOperatorFormData({ ...operatorFormData, shift: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
                >
                  <option value="صبح">شیفت صبح</option>
                  <option value="عصر">شیفت عصر</option>
                  <option value="شب">شیفت شب</option>
                  <option value="گردش">شیفت گردشی</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">شماره تماس یا توضیحات</label>
                <input
                  type="text"
                  value={operatorFormData.phone}
                  onChange={e => setOperatorFormData({ ...operatorFormData, phone: e.target.value })}
                  placeholder="اختیاری..."
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-indigo-900/40">
                <button
                  type="button"
                  onClick={() => setIsOperatorModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-xs font-bold text-white shadow-md"
                >
                  ذخیره اپراتور
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال افزودن / ویرایش تجهیز                             */}
      {/* ======================================================== */}
      {isEqModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0c162e] border border-indigo-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl text-right">
            <h3 className="text-base font-bold text-slate-100 mb-4 flex items-center gap-2">
              <Wrench size={18} className="text-blue-400" />
              <span>{isEditingEq ? 'ویرایش اطلاعات دستگاه' : 'افزودن دستگاه جدید'}</span>
            </h3>
            <form onSubmit={saveEquipment} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">کد تجهیز (یکتا)</label>
                <input
                  type="text"
                  required
                  disabled={isEditingEq}
                  value={eqFormData.id}
                  onChange={e => setEqFormData({ ...eqFormData, id: e.target.value })}
                  placeholder="مثال: TUTN20"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">نام دستگاه</label>
                <input
                  type="text"
                  required
                  value={eqFormData.name}
                  onChange={e => setEqFormData({ ...eqFormData, name: e.target.value })}
                  placeholder="مثال: تراش تورنوس سوئیسی شماره ۲۰"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">خانواده تجهیز</label>
                <select
                  value={eqFormData.family}
                  onChange={e => setEqFormData({ ...eqFormData, family: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="">انتخاب خانواده...</option>
                  {familyList.map(f => (
                    <option key={f.id} value={f.name}>{f.id} - {f.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">مکان / سالن استقرار</label>
                <select
                  value={eqFormData.location}
                  onChange={e => setEqFormData({ ...eqFormData, location: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="">انتخاب سالن...</option>
                  {locationsList.map(loc => (
                    <option key={loc.id} value={loc.name}>{loc.code} - {loc.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">اولویت تجهیز</label>
                <select
                  value={eqFormData.priority}
                  onChange={e => setEqFormData({ ...eqFormData, priority: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="سطح A">سطح A (حیاتی)</option>
                  <option value="سطح B">سطح B (متوسط)</option>
                  <option value="سطح C">سطح C (عادی)</option>
                </select>
              </div>
              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEqModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white shadow-md"
                >
                  ذخیره
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال افزودن / ویرایش خانواده تجهیز                      */}
      {/* ======================================================== */}
      {isFamModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0c162e] border border-indigo-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl text-right">
            <h3 className="text-base font-bold text-slate-100 mb-4 flex items-center gap-2">
              <FolderPlus size={18} className="text-purple-400" />
              <span>{isEditingFam ? 'ویرایش خانواده تجهیز' : 'افزودن خانواده تجهیز جدید'}</span>
            </h3>
            <form onSubmit={saveFamily} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">کد خانواده (یکتا)</label>
                <input
                  type="text"
                  required
                  disabled={isEditingFam}
                  value={famFormData.id}
                  onChange={e => setFamFormData({ ...famFormData, id: e.target.value })}
                  placeholder="مثال: TULT"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">نام خانواده</label>
                <input
                  type="text"
                  required
                  value={famFormData.name}
                  onChange={e => setFamFormData({ ...famFormData, name: e.target.value })}
                  placeholder="مثال: تراش CNC"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">گروه اصلی</label>
                <input
                  type="text"
                  value={famFormData.group}
                  onChange={e => setFamFormData({ ...famFormData, group: e.target.value })}
                  placeholder="ماشین‌آلات تولید"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFamModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-bold text-white shadow-md"
                >
                  ذخیره
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال افزودن / ویرایش مکان و سالن                        */}
      {/* ======================================================== */}
      {isLocModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0c162e] border border-indigo-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl text-right">
            <h3 className="text-base font-bold text-slate-100 mb-4 flex items-center gap-2">
              <Building2 size={18} className="text-emerald-400" />
              <span>{isEditingLoc ? 'ویرایش مکان / سالن' : 'افزودن مکان / سالن جدید'}</span>
            </h3>
            <form onSubmit={saveLocation} className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">کد سالن</label>
                <input
                  type="text"
                  required
                  value={locFormData.code}
                  onChange={e => setLocFormData({ ...locFormData, code: e.target.value })}
                  placeholder="مثال: S09"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">نام سالن یا بخش</label>
                <input
                  type="text"
                  required
                  value={locFormData.name}
                  onChange={e => setLocFormData({ ...locFormData, name: e.target.value })}
                  placeholder="مثال: سالن ۹ (بسته‌بندی نهایی)"
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">توضیحات</label>
                <textarea
                  rows={2}
                  value={locFormData.description}
                  onChange={e => setLocFormData({ ...locFormData, description: e.target.value })}
                  placeholder="توضیحات موقعیت استقرار..."
                  className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsLocModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md"
                >
                  ذخیره
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* صفحه فرم چاپی رسمی با لوگوی رسمی سامانه                   */}
      {/* ======================================================== */}
      {isPrintModalOpen && selectedRequestForPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-3xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 sm:p-8 space-y-6 my-auto max-h-[95vh] overflow-y-auto text-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 text-white">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm sm:text-base font-bold">پیش‌نمایش فرم چاپی درخواست کار (قطع استاندارد A5)</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerOfficialPrint(selectedRequestForPrint)}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/60 cursor-pointer active:scale-95"
                  title="چاپ فوری با تنظیمات A5"
                >
                  <Printer className="w-4 h-4" />
                  <span>چاپ برگه (A5)</span>
                </button>

                <button
                  type="button"
                  onClick={() => downloadA5Html(selectedRequestForPrint)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-600 cursor-pointer active:scale-95"
                  title="دانلود فایل مستقل HTML جهت چاپ آفلاین"
                >
                  <Download className="w-3.5 h-3.5 text-sky-400" />
                  <span>دانلود برگه A5</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(false)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div id="official-work-request-sheet" className="p-5 sm:p-6 rounded-2xl bg-white text-slate-900 shadow-xl border border-slate-300 space-y-4 select-text text-right font-sans max-w-[620px] mx-auto">
              
              {/* سربرگ برگه: عنوان و کد سند پویا از تنظیمات پرینت */}
              <div className="flex items-center justify-between pb-3 border-b-2 border-slate-900">
                <div className="flex items-center gap-3">
                  <img
                    src={OSVEH_LOGO_WHITEBG_URL}
                    alt={printSettings.workRequestA5.docTitle}
                    className="h-12 w-auto object-contain shrink-0"
                  />
                  <div>
                    <h1 className="text-base sm:text-lg font-black text-slate-950">{printSettings.workRequestA5.docTitle}</h1>
                  </div>
                </div>

                <div className="text-left font-mono text-xs space-y-1">
                  <div>کد سند: <strong className="text-xs font-black text-slate-900">{printSettings.workRequestA5.docCode}</strong></div>
                  <div>شماره درخواست: <strong className="text-sm font-black text-sky-700">{selectedRequestForPrint.code}</strong></div>
                  <div>تاریخ و ساعت: <strong>{selectedRequestForPrint.requestTime}</strong></div>
                </div>
              </div>

              {/* ۱. مشخصات تجهیز و موقعیت استقرار */}
              <div className="space-y-1">
                <div className="text-[11px] font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded border border-slate-300">
                  ۱. مشخصات تجهیز و موقعیت استقرار
                </div>
                <table className="w-full text-xs border border-slate-300 border-collapse">
                  <tbody>
                    <tr className="border-b border-slate-300">
                      <td className="w-1/4 p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">کد دستگاه:</td>
                      <td className="w-1/4 p-2 font-mono font-black text-slate-900 border-l border-slate-300">{selectedRequestForPrint.equipmentCode}</td>
                      <td className="w-1/4 p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">عنوان و نوع دستگاه:</td>
                      <td className="w-1/4 p-2 font-bold text-slate-900">{selectedRequestForPrint.equipmentName}</td>
                    </tr>
                    <tr className="border-b border-slate-300">
                      <td className="p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">خانواده تجهیز:</td>
                      <td className="p-2 font-medium text-slate-900 border-l border-slate-300">{selectedRequestForPrint.equipmentFamilyName}</td>
                      <td className="p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">سالن و موقعیت استقرار:</td>
                      <td className="p-2 font-medium text-slate-900">{selectedRequestForPrint.locationName}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* ۲. شرح عیب، اولویت کاری و فوریت اقدام */}
              <div className="space-y-1">
                <div className="text-[11px] font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded border border-slate-300">
                  ۲. شرح عیب، اولویت کاری و فوریت اقدام
                </div>
                <table className="w-full text-xs border border-slate-300 border-collapse">
                  <tbody>
                    <tr className="border-b border-slate-300">
                      <td className="w-1/4 p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">عنوان حالت خرابی:</td>
                      <td className="w-1/4 p-2 font-black text-rose-700 border-l border-slate-300">{selectedRequestForPrint.failureTitle}</td>
                      <td className="w-1/4 p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">اولویت کاری:</td>
                      <td className="w-1/4 p-2 font-black text-slate-900">{selectedRequestForPrint.priority}</td>
                    </tr>
                    <tr className="border-b border-slate-300">
                      <td className="p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">نوع درخواست:</td>
                      <td className="p-2 font-bold text-slate-900 border-l border-slate-300">{selectedRequestForPrint.requestType}</td>
                      <td className="p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">کد حالت خرابی:</td>
                      <td className="p-2 font-mono text-slate-900">{selectedRequestForPrint.failureCode || 'FL-01'}</td>
                    </tr>
                    <tr>
                      <td className="p-2 bg-slate-50 font-bold text-slate-700 border-l border-slate-300">شرح و توضیحات تکمیلی:</td>
                      <td colSpan={3} className="p-2 text-slate-800 leading-relaxed font-medium">
                        {selectedRequestForPrint.description || 'توضیحات تکمیلی توسط درخواست‌کننده ثبت نگردیده است.'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* ۳. مشخصات متقاضی و تحویل‌دهنده */}
              <div className="space-y-1">
                <div className="text-[11px] font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded border border-slate-300">
                  ۳. مشخصات متقاضی و تحویل‌دهنده
                </div>
                <div className="grid grid-cols-2 gap-3 p-2.5 border border-slate-300 rounded text-xs bg-white">
                  <div>نام و نام خانوادگی درخواست‌کننده: <strong>{selectedRequestForPrint.operatorName || 'اپراتور خط'}</strong></div>
                  <div>کد پرسنلی: <strong className="font-mono">{selectedRequestForPrint.operatorPersonnelCode || '—'}</strong></div>
                </div>
              </div>

              {/* ۴. تایید و دستور سرپرست مربوطه - بدون توضیحات زیرین مطابق بند ۷ کاربر */}
              <div className="pt-2 border-2 border-slate-300 rounded-xl p-3.5 bg-slate-50/80 flex items-center justify-between gap-4 text-xs">
                <div className="text-right">
                  <span className="font-black text-slate-900 text-xs block">تایید و دستور سرپرست مربوطه</span>
                </div>
                <div className="p-3 border border-dashed border-slate-400 rounded-xl text-center min-w-[210px] bg-white space-y-6 shadow-sm">
                  <div className="font-black text-xs text-slate-900">امضا و تایید سرپرست مربوطه</div>
                  <div className="text-[10px] text-slate-400">محل امضا و تاریخ</div>
                </div>
              </div>

              {/* پاورقی برگه بدون تاریخ چاپ طبق بند ۵ کاربر */}
              <div className="pt-2 border-t border-slate-300 text-center text-[10px] text-slate-500 font-mono">
                <span>{BRAND_CONFIG.SYSTEM_NAME} • فرم استاندارد CMMS-WR-01 (اندازه A5)</span>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* فرم چاپی کامل دستور کار بسته‌شده (بایگانی دستور کار)     */}
      {/* ======================================================== */}
      {isWoPrintModalOpen && selectedWoForPrint && createPortal((() => {
        const wo = selectedWoForPrint;
        const woNum = wo.woCode || wo.workOrderCode || (wo.code ? (/^(PM|WO)/i.test(wo.code) ? wo.code : wo.code.replace(/^WR/, 'WO')) : '—');
        const isDone = wo.status === 'انجام شد' || wo.status === 'انجام شده';
        const statusLabel = isDone ? 'انجام شده' : (wo.status || 'بایگانی‌شده');
        const startLabel = wo.woStartDate
          ? `${wo.woStartDate}${wo.woStartTimeOnly ? ` - ${wo.woStartTimeOnly}` : ''}`
          : (wo.woStartTime || '—');
        const endLabel = wo.woEndDate
          ? `${wo.woEndDate}${wo.woEndTimeOnly ? ` - ${wo.woEndTimeOnly}` : ''}`
          : (wo.woEndTime || '—');
        const downtimeMins = Number(wo.equipmentDowntimeMinutes ?? wo.downtimeMinutes ?? wo.durationMinutes ?? 0);
        const downtimeLabel = downtimeMins > 0 ? formatMinutesDurationFa(downtimeMins) : '—';
        const activities = Array.isArray(wo.woActivities) ? wo.woActivities : [];
        const techRows =
          Array.isArray(wo.woTechnicians) && wo.woTechnicians.length > 0
            ? wo.woTechnicians.map(t => ({
                name: t.name || '—',
                dateRange: t.startDate && t.endDate && t.endDate !== t.startDate ? `${t.startDate} تا ${t.endDate}` : (t.startDate || t.endDate || '—'),
                timeRange: t.startTime && t.endTime ? `${t.startTime} تا ${t.endTime}` : '—',
                minutes: Math.round((Number(t.hours) || 0) * 60),
                hours: Number(t.hours) || 0
              }))
            : [wo.technician, ...(Array.isArray(wo.coTechnicians) ? wo.coTechnicians : [])]
                .filter(Boolean)
                .map(name => ({
                  name: String(name),
                  dateRange: wo.woStartDate || '—',
                  timeRange: wo.woStartTimeOnly && wo.woEndTimeOnly ? `${wo.woStartTimeOnly} تا ${wo.woEndTimeOnly}` : '—',
                  minutes: Number(wo.durationMinutes || 0),
                  hours: Math.round((Number(wo.durationMinutes || 0) / 60) * 100) / 100
                }));
        const consumables = Array.isArray(wo.consumables) ? wo.consumables : [];
        const delays = Array.isArray(wo.woDelays) ? wo.woDelays : [];

        return (
          <div
            dir="rtl"
            className="wo-print-modal-backdrop fixed inset-0 z-[150] flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md overflow-y-auto"
            onClick={() => setIsWoPrintModalOpen(false)}
          >
            <div
              className="wo-print-modal-container relative w-full max-w-5xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-4 sm:p-7 space-y-5 my-auto max-h-[95vh] overflow-y-auto text-slate-900"
              onClick={e => e.stopPropagation()}
            >
              {/* نوار ابزار بالای پیش‌نمایش */}
              <div className="no-print flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-700 text-white">
                <div className="flex items-center gap-2.5">
                  <Printer className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h3 className="text-sm sm:text-base font-black">فرم کامل {printSettings.workOrderClosedA4.docTitle} ({printSettings.workOrderClosedA4.docCode})</h3>
                    <span className="text-[11px] text-slate-400 font-mono">
                      شماره دستور کار: {woNum} • درخواست مبدا: {wo.code}
                    </span>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => triggerClosedWorkOrderPrint(wo)}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg cursor-pointer active:scale-95"
                  >
                    <Printer className="w-4 h-4" />
                    <span>چاپ دستور کار</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadClosedWorkOrderHtml(wo)}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-600 cursor-pointer active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5 text-sky-400" />
                    <span>دانلود نسخه چاپی</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsWoPrintModalOpen(false)}
                    className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                    title="بستن"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* برگه رسمی دستور کار با لوگوی شرکت */}
              <div
                id="official-work-order-sheet"
                className="p-5 sm:p-6 rounded-2xl bg-white text-slate-900 shadow-xl border border-slate-300 space-y-4 select-text text-right font-sans"
              >
                {/* سربرگ */}
                <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b-2 border-slate-900">
                  <div className="flex items-center gap-3">
                    <img
                      src={OSVEH_LOGO_WHITEBG_URL}
                      alt="لوگو"
                      className="h-14 w-auto object-contain shrink-0"
                    />
                  </div>
                  <div className="text-center flex-1">
                    <h1 className="text-base sm:text-lg font-black text-slate-950">{printSettings.workOrderClosedA4.docTitle}</h1>
                    <span className="text-[11px] text-slate-500 font-bold">گزارش نهایی عملیات و بایگانی دستور کار</span>
                  </div>
                  <div className="text-left text-xs space-y-1">
                    <div>کد سند: <strong className="font-mono text-sm font-black text-slate-950">{printSettings.workOrderClosedA4.docCode}</strong></div>
                    <div>کد دستورکار: <strong className="font-mono text-sm text-slate-950">{woNum}</strong></div>
                    <div>کد درخواست: <strong className="font-mono text-sky-700">{wo.code}</strong></div>
                    <div>تاریخ تکمیل: <strong className="font-mono" dir="ltr">{endLabel}</strong></div>
                  </div>
                </div>

                {/* جدول مشخصات کلی دستورکار */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border border-slate-300 border-collapse">
                    <tbody>
                      <tr className="border-b border-slate-300">
                        <td className="p-2 border-l border-slate-300 bg-slate-50/70">
                          <span className="block text-[10px] text-slate-500 font-bold">کد دستورکار</span>
                          <strong className="font-mono text-slate-950">{woNum}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">کد تجهیز</span>
                          <strong className="font-mono text-slate-950">{wo.equipmentCode || '—'}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">عنوان تجهیز</span>
                          <strong className="text-slate-950">{wo.equipmentName || '—'}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">مسیر عنوان خانواده تجهیز</span>
                          <strong className="text-slate-950">{wo.equipmentFamilyName || '—'}</strong>
                        </td>
                        <td className="p-2">
                          <span className="block text-[10px] text-slate-500 font-bold">مسیر عنوان مکان</span>
                          <strong className="text-slate-950">{wo.locationName || '—'}</strong>
                        </td>
                      </tr>
                      <tr className="border-b border-slate-300">
                        <td colSpan={2} className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">توضیحات درخواست کار</span>
                          <span className="font-bold text-slate-900">{wo.description || '—'}</span>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">عنوان وضعیت</span>
                          <strong className={isDone ? 'text-emerald-700' : 'text-rose-700'}>{statusLabel}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">عنوان دپارتمان</span>
                          <strong className="text-slate-900">نگهداری و تعمیرات</strong>
                        </td>
                        <td className="p-2">
                          <span className="block text-[10px] text-slate-500 font-bold">عنوان حالت خرابی</span>
                          <strong className="text-rose-700">
                            {wo.failureTitle || '—'}{wo.failureCode ? ` (${wo.failureCode})` : ''}
                          </strong>
                        </td>
                      </tr>
                      <tr className="border-b border-slate-300">
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">زمان درخواست کار</span>
                          <strong className="font-mono text-slate-900" dir="ltr">{wo.requestTime || '—'}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">زمان شروع دستورکار</span>
                          <strong className="font-mono text-slate-900" dir="ltr">{startLabel}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">زمان پایان دستورکار</span>
                          <strong className="font-mono text-slate-900" dir="ltr">{endLabel}</strong>
                        </td>
                        <td className="p-2 border-l border-slate-300">
                          <span className="block text-[10px] text-slate-500 font-bold">مدت خواب تجهیز</span>
                          <strong className="text-amber-700">{downtimeLabel}</strong>
                        </td>
                        <td className="p-2">
                          <span className="block text-[10px] text-slate-500 font-bold">متقاضی / ثبت‌کننده</span>
                          <strong className="text-slate-900">
                            {wo.operatorName || '—'}{wo.operatorPersonnelCode ? ` (${wo.operatorPersonnelCode})` : ''}
                          </strong>
                        </td>
                      </tr>
                      <tr>
                        <td colSpan={5} className="p-2 bg-slate-50/50">
                          <span className="block text-[10px] text-slate-500 font-bold">توضیحات دستورکار</span>
                          <span className="font-medium text-slate-900 whitespace-pre-line">{wo.woNotes || '—'}</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* مشخصات تجهیز و لیست فعالیت‌ها */}
                <div className="border border-slate-300 rounded-lg overflow-hidden">
                  <div className="grid grid-cols-4 bg-slate-100 border-b border-slate-300 text-xs font-black text-slate-800 p-2 text-center">
                    <div>کد تجهیز: <span className="font-mono">{wo.equipmentCode || '—'}</span></div>
                    <div>عنوان تجهیز: {wo.equipmentName || '—'}</div>
                    <div>مکان: {wo.locationName || '—'}</div>
                    <div>خانواده تجهیز: {wo.equipmentFamilyName || '—'}</div>
                  </div>
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-300 text-slate-700">
                        <th className="p-2 w-12 text-center border-l border-slate-300">ردیف</th>
                        <th className="p-2 text-right border-l border-slate-300">عنوان فعالیت</th>
                        <th className="p-2 w-24 text-center border-l border-slate-300">وضعیت انجام</th>
                        <th className="p-2 text-right">توضیحات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {activities.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="p-3 text-center text-slate-400">فعالیتی ثبت نشده است</td>
                        </tr>
                      ) : (
                        activities.map((a, idx) => (
                          <tr key={a.id || idx} className="border-b border-slate-200 last:border-b-0">
                            <td className="p-2 text-center font-mono border-l border-slate-300">{idx + 1}</td>
                            <td className="p-2 font-bold text-slate-900 border-l border-slate-300">{a.title}</td>
                            <td className="p-2 text-center text-base border-l border-slate-300">{isDone ? '☑' : '☐'}</td>
                            <td className="p-2 text-slate-700">{wo.woNotes || '—'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* دو ستون: لیست نیروی انسانی و لیست قطعات یدکی */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <div className="bg-slate-100 border-b border-slate-300 py-1.5 px-3 text-xs font-black text-center text-slate-900">
                      لیست نیروی انسانی
                    </div>
                    <table className="w-full text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-300 text-slate-700">
                          <th className="p-2 text-right border-l border-slate-300">نام و نام خانوادگی</th>
                          <th className="p-2 text-center border-l border-slate-300">تاریخ انجام کار</th>
                          <th className="p-2 text-center border-l border-slate-300">ساعت</th>
                          <th className="p-2 text-center">زمان انجام کار</th>
                        </tr>
                      </thead>
                      <tbody>
                        {techRows.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="p-3 text-center text-slate-400">تکنسینی ثبت نشده است</td>
                          </tr>
                        ) : (
                          techRows.map((t, idx) => (
                            <tr key={idx} className="border-b border-slate-200 last:border-b-0">
                              <td className="p-2 font-bold text-slate-900 border-l border-slate-300">{t.name}</td>
                              <td className="p-2 text-center font-mono border-l border-slate-300" dir="ltr">{t.dateRange}</td>
                              <td className="p-2 text-center font-mono border-l border-slate-300" dir="ltr">{t.timeRange}</td>
                              <td className="p-2 text-center font-mono font-bold text-slate-900">
                                {t.minutes > 0 ? `${t.minutes} دقیقه (${t.hours} س)` : `${t.hours} ساعت`}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <div className="bg-slate-100 border-b border-slate-300 py-1.5 px-3 text-xs font-black text-center text-slate-900">
                      لیست قطعات یدکی
                    </div>
                    <table className="w-full text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-300 text-slate-700">
                          <th className="p-2 text-right border-l border-slate-300">گروه قطعه</th>
                          <th className="p-2 text-right border-l border-slate-300">نام قطعه</th>
                          <th className="p-2 text-center">تعداد</th>
                        </tr>
                      </thead>
                      <tbody>
                        {consumables.length === 0 ? (
                          <tr>
                            <td colSpan={3} className="p-3 text-center text-slate-400">قطعه یدکی ثبت نشده است</td>
                          </tr>
                        ) : (
                          consumables.map((c, idx) => (
                            <tr key={c.id || idx} className="border-b border-slate-200 last:border-b-0">
                              <td className="p-2 text-slate-700 border-l border-slate-300">{c.category || '—'}</td>
                              <td className="p-2 font-bold text-slate-900 border-l border-slate-300">{c.name}</td>
                              <td className="p-2 text-center font-mono font-bold text-slate-900">{c.count} {c.unit || 'عدد'}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* دو ستون: لیست تاخیرات و تحویل */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <div className="bg-slate-100 border-b border-slate-300 py-1.5 px-3 text-xs font-black text-center text-slate-900">
                      لیست تاخیرات
                    </div>
                    <table className="w-full text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-300 text-slate-700">
                          <th className="p-2 text-right border-l border-slate-300">عنوان تاخیر</th>
                          <th className="p-2 text-center border-l border-slate-300">کد تاخیر</th>
                          <th className="p-2 text-center border-l border-slate-300">مدت زمان (روز)</th>
                          <th className="p-2 text-center">مدت زمان (ساعت)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {delays.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="p-3 text-center text-slate-400">تاخیری ثبت نشده است</td>
                          </tr>
                        ) : (
                          delays.map((d, idx) => (
                            <tr key={d.id || idx} className="border-b border-slate-200 last:border-b-0">
                              <td className="p-2 font-bold text-slate-900 border-l border-slate-300">{d.title || '—'}</td>
                              <td className="p-2 text-center font-mono border-l border-slate-300">{d.code || '—'}</td>
                              <td className="p-2 text-center font-mono border-l border-slate-300">{d.days || 0}</td>
                              <td className="p-2 text-center font-mono">{d.hours || 0}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <div className="bg-slate-100 border-b border-slate-300 py-1.5 px-3 text-xs font-black text-center text-slate-900">
                      تحویل و تایید
                    </div>
                    <div className="p-3 space-y-2.5 text-xs">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                        <span className="text-slate-600 font-bold">نام و نام خانوادگی تحویل‌گیرنده:</span>
                        <strong className="text-slate-950">{wo.operatorName || '........................'}</strong>
                      </div>
                      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                        <span className="text-slate-600 font-bold">آیا درخواست مورد تایید می‌باشد؟</span>
                        <div className="flex items-center gap-4 font-bold">
                          <span>☐ بله</span>
                          <span>☐ خیر</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2 pt-1 text-slate-700 font-bold">
                        <div>تاریخ: ..............</div>
                        <div>ساعت: ..............</div>
                        <div>امضا: ..............</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-300 text-center text-[10px] text-slate-500 font-mono">
                  <span>{BRAND_CONFIG.SYSTEM_NAME} • کد سند: {printSettings.workOrderClosedA4.docCode} (اندازه A4)</span>
                </div>
              </div>
            </div>
          </div>
        );
      })(), document.body)}

      {/* اعلان ذخیره موفق دستور کار */}
      {woNoticeToast && (
        <div className="fixed bottom-5 left-5 z-[200] px-4 py-3 rounded-2xl bg-emerald-950/95 border border-emerald-500/50 text-emerald-200 text-xs font-bold shadow-2xl flex flex-wrap items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{woNoticeToast}</span>
          </div>
          <button
            type="button"
            onClick={() => {
              setActiveView('woArchive');
              setWoNoticeToast(null);
            }}
            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold cursor-pointer"
          >
            مشاهده بایگانی دستور کار
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال فرم دستور کار (۲ صفحه‌ای: صفحه ۱ مشخصات | صفحه ۲ فعالیت، تکنسین، قطعات و تاخیر) */}
      {/* ======================================================== */}
      {isWorkOrderModalOpen && woTargetRequest && createPortal((() => {
        const isWoReadOnly = isArchivedWorkOrderItem(woTargetRequest);
        return (
        <div
          dir="rtl"
          className="fixed inset-0 z-[130] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto"
          onClick={() => setIsWorkOrderModalOpen(false)}
        >
          <div
            className="relative w-full max-w-4xl rounded-3xl bg-[#0e1424] border border-indigo-500/40 shadow-2xl flex flex-col max-h-[93vh] overflow-hidden text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* سربرگ مودال دستور کار */}
            <div className="px-5 py-4 bg-[#070e22] border-b border-indigo-900/50 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-600 text-white flex items-center justify-center shadow-md">
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-black text-white flex flex-wrap items-center gap-2">
                    <span>فرم دستور کار</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded-lg bg-cyan-950/80 text-cyan-300 border border-cyan-500/40">
                      {woForm.woCode}
                    </span>
                    {isWoReadOnly && (
                      <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                        بایگانی‌شده (فقط مشاهده)
                      </span>
                    )}
                  </h2>
                  <p className="text-[11px] text-slate-400 font-mono">
                    مبدا درخواست کار: {woTargetRequest.code} • {woTargetRequest.equipmentName} ({woTargetRequest.equipmentCode})
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsWorkOrderModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800/80 hover:bg-rose-600/80 text-slate-400 hover:text-white transition-all cursor-pointer"
                title="بستن فرم"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* نوار جابجایی بین تب مشخصات، فعالیت و وضعیت */}
            <div className="px-5 py-2.5 bg-[#091124] border-b border-indigo-900/40 grid grid-cols-3 gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setWoModalPage(1)}
                className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                  woModalPage === 1
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-400/50 shadow-md'
                    : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
                }`}
              >
                <span>مشخصات</span>
              </button>
              <button
                type="button"
                onClick={() => setWoModalPage(2)}
                className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                  woModalPage === 2
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-400/50 shadow-md'
                    : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
                }`}
              >
                <span>فعالیت</span>
              </button>
              <button
                type="button"
                onClick={() => setWoModalPage(3)}
                className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                  woModalPage === 3
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-400/50 shadow-md'
                    : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
                }`}
              >
                <span>وضعیت</span>
              </button>
            </div>

            {/* بدنه اسکرول‌شونده صفحات */}
            <div className="p-5 space-y-5 overflow-y-auto flex-1">
              {woModalPage === 1 ? (
                /* ================= صفحه اول: مشخصات کامل درخواست کار ================= */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                      <span className="text-[11px] text-slate-400 block mb-1">کد درخواست کار</span>
                      <span className="font-mono font-bold text-sm text-cyan-300">{woTargetRequest.code}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                      <label className="text-[11px] text-slate-400 block mb-1">شماره دستور کار</label>
                      <input
                        type="text"
                        value={woForm.woCode}
                        disabled={isWoReadOnly}
                        onChange={e => !isWoReadOnly && setWoForm(prev => ({ ...prev, woCode: e.target.value }))}
                        className={`w-full bg-[#0c162e] border border-cyan-500/40 rounded-lg px-2.5 py-1 text-xs font-mono font-bold text-white outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                        dir="ltr"
                      />
                    </div>
                    <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                      <span className="text-[11px] text-slate-400 block mb-1">وضعیت فعلی دستور کار</span>
                      <span className={`inline-flex px-2.5 py-0.5 rounded-lg text-xs font-bold border ${
                        woForm.status === 'انجام شد'
                          ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                          : woForm.status === 'لغو' || woForm.status === 'لغو شده'
                          ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                          : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                      }`}>
                        {woForm.status === 'انجام شد' ? 'انجام شده' : woForm.status}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/25 space-y-3">
                    <h3 className="text-xs font-black text-cyan-300 pb-2 border-b border-indigo-900/40">
                      مشخصات کامل تجهیز و مکان
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">کد تجهیز</span>
                        <span className="font-mono font-bold text-white">{woTargetRequest.equipmentCode || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">عنوان و نوع تجهیز</span>
                        <span className="font-bold text-white">{woTargetRequest.equipmentName || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">مسیر کد خانواده تجهیز</span>
                        <span className="font-mono font-bold text-indigo-300">{woTargetRequest.equipmentFamilyCode || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-2">
                        <span className="text-[10px] text-slate-400 block mb-0.5">مسیر عنوان خانواده تجهیز</span>
                        <span className="font-bold text-slate-100">{woTargetRequest.equipmentFamilyName || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">کد مکان</span>
                        <span className="font-mono font-bold text-slate-200">{woTargetRequest.locationCode || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-3">
                        <span className="text-[10px] text-slate-400 block mb-0.5">مسیر عنوان مکان</span>
                        <span className="font-bold text-slate-100">{woTargetRequest.locationName || '—'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/25 space-y-3">
                    <h3 className="text-xs font-black text-amber-300 pb-2 border-b border-indigo-900/40">
                      مشخصات خرابی، اولویت و ثبت‌کننده
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">کد حالت خرابی</span>
                        <span className="font-mono font-bold text-amber-300">{woTargetRequest.failureCode || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-2">
                        <span className="text-[10px] text-slate-400 block mb-0.5">عنوان حالت خرابی</span>
                        <span className="font-bold text-amber-200">{woTargetRequest.failureTitle || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">نوع درخواست کار</span>
                        <span className="font-bold text-blue-300">{woTargetRequest.requestType || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">اولویت درخواست کار</span>
                        <span className="font-bold text-rose-300">{woTargetRequest.priority || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">زمان درخواست کار</span>
                        <span className="font-mono text-slate-200" dir="ltr">{woTargetRequest.requestTime || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">متقاضی و ثبت‌کننده</span>
                        <span className="font-bold text-white">{woTargetRequest.operatorName || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">کد پرسنلی متقاضی</span>
                        <span className="font-mono text-slate-200">{woTargetRequest.operatorPersonnelCode || '—'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block mb-0.5">وضعیت اولیه درخواست</span>
                        <span className="font-bold text-cyan-300">{woTargetRequest.status || '—'}</span>
                      </div>
                      <div className="p-3 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-3">
                        <span className="text-[10px] text-slate-400 block mb-1">توضیحات درخواست کار</span>
                        <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                          {woTargetRequest.description || '—'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : woModalPage === 2 ? (
                /* ================= صفحه دوم: فعالیت، تکنسین، قطعات و تاخیر ================= */
                <div className="space-y-5">
                  {/* ۱. فعالیت‌های نگه‌داشت (فقط از فعالیت‌های خانواده تجهیز با کد، تاریخ و ساعت شروع و پایان) */}
                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-cyan-500/30 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                      <div className="flex items-center gap-2">
                        <Wrench className="w-4 h-4 text-cyan-400" />
                        <div>
                          <h3 className="text-xs font-black text-white">فعالیت‌های نگه‌داشت انجام‌شده</h3>
                          <span className="text-[10px] text-slate-400 block">
                            انتخاب صرفاً از فعالیت‌های ثبت‌شده در خانواده تجهیز ({woTargetRequest.equipmentFamilyName || woTargetRequest.equipmentFamilyCode || '—'})
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                        {woForm.activities.length} فعالیت
                      </span>
                    </div>

                    {/* تاریخ و ساعت اجرای فعالیت‌ها (با قابلیت افزودن روز کاری) */}
                    <div className="p-3 rounded-xl bg-[#0c162e] border border-cyan-500/25 space-y-2.5">
                      {(woForm.workDays.length > 0
                        ? woForm.workDays
                        : [
                            {
                              id: 'wd-fallback-1',
                              startDate: woForm.woStartDate,
                              startTime: woForm.woStartTime,
                              endDate: woForm.woEndDate,
                              endTime: woForm.woEndTime
                            }
                          ]
                      ).map((wd, wdIdx, wdArr) => (
                        <div key={wd.id} className="flex flex-col sm:flex-row sm:items-end gap-2">
                          {wdArr.length > 1 && (
                            <span className="text-[10px] font-bold px-2 py-1.5 rounded-lg bg-cyan-950/70 text-cyan-300 border border-cyan-500/30 shrink-0 self-start sm:self-end text-center">
                              روز {wdIdx + 1}
                            </span>
                          )}
                          <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                            <div>
                              <label className="text-slate-400 block mb-1">تاریخ شروع</label>
                              <input
                                type="text"
                                value={wd.startDate}
                                disabled={isWoReadOnly}
                                onChange={e => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'startDate', e.target.value)}
                                dir="ltr"
                                placeholder="1405/08/23"
                                className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                              />
                            </div>
                            <div>
                              <label className="text-slate-400 block mb-1">ساعت شروع</label>
                              <TimeInput24
                                value={wd.startTime}
                                disabled={isWoReadOnly}
                                onChange={nextVal => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'startTime', nextVal)}
                                className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400"
                              />
                            </div>
                            <div>
                              <label className="text-slate-400 block mb-1">تاریخ پایان</label>
                              <input
                                type="text"
                                value={wd.endDate}
                                disabled={isWoReadOnly}
                                onChange={e => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'endDate', e.target.value)}
                                dir="ltr"
                                placeholder="1405/08/23"
                                className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                              />
                            </div>
                            <div>
                              <label className="text-slate-400 block mb-1">ساعت پایان</label>
                              <TimeInput24
                                value={wd.endTime}
                                disabled={isWoReadOnly}
                                onChange={nextVal => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'endTime', nextVal)}
                                className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400"
                              />
                            </div>
                          </div>
                          {!isWoReadOnly && (
                            wdIdx === 0 ? (
                              <button
                                type="button"
                                onClick={handleAddWoWorkDay}
                                title="افزودن یک روز کاری"
                                className="h-[30px] px-2.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-300 border border-cyan-500/40 flex items-center justify-center transition-all cursor-pointer shrink-0 self-end"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleRemoveWoWorkDay(wd.id)}
                                title="حذف این روز کاری"
                                className="h-[30px] px-2.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 border border-rose-500/30 flex items-center justify-center transition-all cursor-pointer shrink-0 self-end"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )
                          )}
                        </div>
                      ))}
                    </div>

                    {!isWoReadOnly && (woFamilyMaintenanceActivities.length === 0 ? (
                      <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200 text-[11px]">
                        هیچ فعالیت نگه‌داشتی برای خانواده تجهیز «{woTargetRequest.equipmentFamilyName || woTargetRequest.equipmentCode}» ثبت نشده است. لطفاً از بخش خانواده تجهیزات، تب فعالیت‌های نگه‌داشت را تکمیل کنید.
                      </div>
                    ) : (
                      <div ref={woActivityDropdownRef} className="relative">
                        <div className="relative">
                          <Search className="w-3.5 h-3.5 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            value={woActivitySearch}
                            onFocus={() => setIsWoActivityDropdownOpen(true)}
                            onChange={e => {
                              setWoActivitySearch(e.target.value);
                              setIsWoActivityDropdownOpen(true);
                            }}
                            placeholder="جستجو و انتخاب چندگانه از فعالیت‌های نگه‌داشت خانواده تجهیز (با کد یا عنوان)..."
                            className="w-full bg-[#0c162e] border border-cyan-500/40 rounded-xl pr-9 pl-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                          />
                        </div>

                        {isWoActivityDropdownOpen && (
                          <div className="absolute left-0 right-0 mt-1.5 max-h-48 overflow-y-auto rounded-xl bg-[#0b1530] border border-cyan-500/40 shadow-2xl z-30 divide-y divide-slate-800">
                            {filteredWoFamilyActivities.length === 0 ? (
                              <div className="p-3 text-center text-xs text-slate-400">موردی یافت نشد.</div>
                            ) : (
                              filteredWoFamilyActivities.map(act => (
                                <button
                                  key={act.id}
                                  type="button"
                                  onClick={() => handleAddWoActivity(act)}
                                  className="w-full px-3 py-2 text-right hover:bg-cyan-900/40 flex items-center justify-between gap-2 text-xs transition-colors cursor-pointer"
                                >
                                  <span className="text-white font-semibold truncate">{act.title}</span>
                                  <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 shrink-0">
                                    {act.code || 'بدون کد'}
                                  </span>
                                </button>
                              ))
                            )}
                          </div>
                        )}
                      </div>
                    ))}

                    {woForm.activities.length > 0 && (
                      <div className="space-y-2 pt-1">
                        {woForm.activities.map((act, actIdx) => (
                          <div key={act.id} className="px-3 py-2 rounded-xl bg-[#0c162e] border border-indigo-500/30 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="text-[10px] font-mono text-slate-400 shrink-0">{actIdx + 1}.</span>
                              <span className="font-mono text-[11px] px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-500/40 shrink-0">
                                {act.code || '—'}
                              </span>
                              <span className="text-xs font-bold text-white truncate">{act.title}</span>
                            </div>
                            {!isWoReadOnly && (
                              <button
                                type="button"
                                onClick={() =>
                                  setWoForm(prev => ({
                                    ...prev,
                                    activities: prev.activities.filter(a => a.id !== act.id)
                                  }))
                                }
                                className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer shrink-0"
                                title="حذف فعالیت"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* ۲. تکنسین‌های مجری (از لیست تکنسین‌های پیشگیرانه و خدمات فنی با تاریخ و ساعت کارکرد) */}
                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-indigo-400" />
                        <div>
                          <h3 className="text-xs font-black text-white">تکنسین‌های انجام‌دهنده</h3>
                          <span className="text-[10px] text-slate-400 block">
                            تامین‌شده از تکنسین‌های ثبت‌شده در بخش پیشگیرانه و خدمات فنی
                          </span>
                        </div>
                      </div>
                      {!isWoReadOnly && (
                        <button
                          type="button"
                          onClick={() => handleAddWoTechnician()}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>افزودن تکنسین</span>
                        </button>
                      )}
                    </div>

                    {!isWoReadOnly && combinedTechnicians.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {combinedTechnicians.map(tName => (
                          <button
                            key={tName}
                            type="button"
                            onClick={() => handleAddWoTechnician(tName)}
                            className="px-2.5 py-1 rounded-lg bg-[#0c162e] hover:bg-indigo-900/60 border border-indigo-500/30 text-[11px] text-slate-200 hover:text-white flex items-center gap-1 transition-all cursor-pointer"
                            title="کلیک برای ثبت فعالیت این تکنسین"
                          >
                            <Plus className="w-3 h-3 text-indigo-400" />
                            <span>{tName}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {woForm.technicians.length === 0 ? (
                      <div className="text-center py-3 text-[11px] text-slate-500 border border-dashed border-slate-700 rounded-xl">
                        {isWoReadOnly ? 'تکنسینی برای این دستور کار ثبت نشده است.' : 'برای ثبت کارکرد، روی نام تکنسین یا دکمه «افزودن تکنسین» کلیک کنید.'}
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {woForm.technicians.map((techRow, techIdx) => {
                          const updateFirstAndFollowers = (
                            field: 'startDate' | 'startTime' | 'endDate' | 'endTime',
                            customFlag: 'customStartDate' | 'customStartTime' | 'customEndDate' | 'customEndTime',
                            nextVal: string
                          ) => {
                            if (isWoReadOnly) return;
                            const statusFieldMap = {
                              startDate: 'woStartDate',
                              startTime: 'woStartTime',
                              endDate: 'woEndDate',
                              endTime: 'woEndTime'
                            } as const;
                            setWoForm(prev => ({
                              ...prev,
                              ...(techIdx === 0 && !woActivityRangeEdited
                                ? {
                                    [statusFieldMap[field]]: nextVal,
                                    ...(prev.workDays.length <= 1
                                      ? {
                                          workDays: (prev.workDays.length > 0
                                            ? prev.workDays
                                            : [{
                                                id: `wd-${Date.now()}-1`,
                                                startDate: prev.woStartDate,
                                                startTime: prev.woStartTime,
                                                endDate: prev.woEndDate,
                                                endTime: prev.woEndTime
                                              }]
                                          ).map((d, i) => (i === 0 ? { ...d, [field]: nextVal } : d))
                                        }
                                      : {})
                                  }
                                : {}),
                              technicians: prev.technicians.map((t, idx) => {
                                const shouldUpdate =
                                  techIdx === 0
                                    ? (idx === 0 || !t[customFlag])
                                    : t.id === techRow.id;
                                if (!shouldUpdate) return t;
                                const updated = {
                                  ...t,
                                  [field]: nextVal,
                                  ...(techIdx !== 0 ? { [customFlag]: true } : {}),
                                  customHours: false
                                };
                                updated.hours = calcTechRowHours(
                                  updated.startDate,
                                  updated.startTime,
                                  updated.endDate,
                                  updated.endTime,
                                  updated.hours
                                );
                                return updated;
                              })
                            }));
                          };

                          return (
                            <div key={techRow.id} className="grid grid-cols-12 gap-2 items-center p-2.5 rounded-xl bg-[#0c162e] border border-indigo-500/25 text-xs">
                              <div className="col-span-12 sm:col-span-3">
                                <label className="text-[10px] text-slate-400 block mb-0.5">نام تکنسین</label>
                                <select
                                  value={techRow.name}
                                  disabled={isWoReadOnly}
                                  onChange={e =>
                                    !isWoReadOnly &&
                                    setWoForm(prev => ({
                                      ...prev,
                                      technicians: prev.technicians.map(t =>
                                        t.id === techRow.id ? { ...t, name: e.target.value } : t
                                      )
                                    }))
                                  }
                                  className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                >
                                  <option value="">انتخاب تکنسین...</option>
                                  {combinedTechnicians.map(name => (
                                    <option key={name} value={name}>{name}</option>
                                  ))}
                                  {techRow.name && !combinedTechnicians.includes(techRow.name) && (
                                    <option value={techRow.name}>{techRow.name}</option>
                                  )}
                                </select>
                              </div>
                              <div className="col-span-6 sm:col-span-2">
                                <label className="text-[10px] text-slate-400 block mb-0.5">تاریخ شروع</label>
                                <input
                                  type="text"
                                  value={techRow.startDate}
                                  disabled={isWoReadOnly}
                                  onChange={e => updateFirstAndFollowers('startDate', 'customStartDate', e.target.value)}
                                  dir="ltr"
                                  className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                />
                              </div>
                              <div className="col-span-6 sm:col-span-2">
                                <label className="text-[10px] text-slate-400 block mb-0.5">ساعت شروع</label>
                                <TimeInput24
                                  value={techRow.startTime}
                                  disabled={isWoReadOnly}
                                  onChange={nextVal => updateFirstAndFollowers('startTime', 'customStartTime', nextVal)}
                                  className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-1.5 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400"
                                />
                              </div>
                              <div className="col-span-6 sm:col-span-2">
                                <label className="text-[10px] text-slate-400 block mb-0.5">تاریخ پایان</label>
                                <input
                                  type="text"
                                  value={techRow.endDate}
                                  disabled={isWoReadOnly}
                                  onChange={e => updateFirstAndFollowers('endDate', 'customEndDate', e.target.value)}
                                  dir="ltr"
                                  className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                />
                              </div>
                              <div className="col-span-6 sm:col-span-2">
                                <label className="text-[10px] text-slate-400 block mb-0.5">ساعت پایان</label>
                                <TimeInput24
                                  value={techRow.endTime}
                                  disabled={isWoReadOnly}
                                  onChange={nextVal => updateFirstAndFollowers('endTime', 'customEndTime', nextVal)}
                                  className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-1.5 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400"
                                />
                              </div>
                              <div className="col-span-9 sm:col-span-1">
                                <label className="text-[10px] text-slate-400 block mb-0.5">ساعت کارکرد</label>
                                <input
                                  type="number"
                                  min={0}
                                  step="0.25"
                                  value={techRow.hours}
                                  disabled={isWoReadOnly}
                                  onChange={e =>
                                    !isWoReadOnly &&
                                    setWoForm(prev => ({
                                      ...prev,
                                      technicians: prev.technicians.map(t =>
                                        t.id === techRow.id
                                          ? { ...t, hours: Math.max(0, parseFloat(e.target.value) || 0), customHours: true }
                                          : t
                                      )
                                    }))
                                  }
                                  dir="ltr"
                                  className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-1 py-1.5 text-emerald-300 font-mono font-bold text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                />
                              </div>
                              <div className="col-span-3 sm:col-span-12 lg:col-span-12 flex items-center justify-between pt-1 border-t border-slate-800/60">
                                <span className="text-[10px] text-slate-400 font-mono">
                                  بازه ثبت‌شده: {techRow.startDate} ({techRow.startTime}) تا {techRow.endDate} ({techRow.endTime}) • {formatMinutesDurationFa(Math.round((Number(techRow.hours) || 0) * 60))}
                                </span>
                                {!isWoReadOnly && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setWoForm(prev => ({
                                        ...prev,
                                        technicians: prev.technicians.filter(t => t.id !== techRow.id)
                                      }))
                                    }
                                    className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer flex items-center gap-1 text-[10px]"
                                    title="حذف تکنسین"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>حذف</span>
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                        <div className="text-left text-[11px] text-emerald-300 font-mono font-bold pt-1">
                          جمع ساعت کارکرد ثبت‌شده: {Math.round(woForm.technicians.reduce((s, t) => s + (Number(t.hours) || 0), 0) * 100) / 100} ساعت
                        </div>
                      </div>
                    )}
                  </div>

                  {/* ۳. لوازم و قطعات مصرفی دستور کار (به‌صورت پیش‌فرض بسته و با کلیک باز می‌شود) */}
                  <div className="rounded-2xl bg-gradient-to-b from-slate-900/90 to-blue-950/90 border border-amber-500/40 shadow-lg overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setIsWoSparePartsOpen(prev => !prev)}
                      className="w-full p-4 flex flex-wrap items-center justify-between gap-2 text-right hover:bg-slate-900/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                          <Package className="w-4 h-4 text-amber-400" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-amber-300 block">لوازم و قطعات مصرفی دستور کار</span>
                          <span className="text-[10px] text-blue-200/70 block">ثبت اقلام مصرفی از انبار در ۳ گروه برقی، مکانیکی و سایر</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40">
                          {woForm.consumables.reduce((acc, c) => acc + c.count, 0)} قلم انتخاب‌شده
                        </span>
                        {isWoSparePartsOpen ? (
                          <ChevronUp className="w-4 h-4 text-amber-300" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-amber-300" />
                        )}
                      </div>
                    </button>

                    {isWoSparePartsOpen && (
                      <div className="px-4 pb-4 pt-2 border-t border-blue-900/40 space-y-3">
                        {!isWoReadOnly && (
                          <>
                            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-950/80 border border-blue-900/60">
                              {(['برقی', 'مکانیکی', 'سایر'] as const).map(cat => {
                                const isActive = woConsumableTab === cat;
                                const catCount = woForm.consumables.filter(c => c.category === cat).reduce((s, c) => s + c.count, 0);
                                return (
                                  <button
                                    key={cat}
                                    type="button"
                                    onClick={() => setWoConsumableTab(cat)}
                                    className={`py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                      isActive
                                        ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-md border border-amber-400/50'
                                        : 'text-blue-300 hover:text-white hover:bg-blue-900/30'
                                    }`}
                                  >
                                    {cat === 'برقی' && <Zap className="w-3.5 h-3.5" />}
                                    {cat === 'مکانیکی' && <Wrench className="w-3.5 h-3.5" />}
                                    {cat === 'سایر' && <Box className="w-3.5 h-3.5" />}
                                    <span>{cat === 'سایر' ? 'سایر اقلام' : `لوازم ${cat}`}</span>
                                    {catCount > 0 && (
                                      <span className="text-[10px] px-1.5 rounded-full bg-slate-950/90 text-amber-200 font-mono font-bold">
                                        {catCount}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>

                            <div className="space-y-1.5 pt-1">
                              <div className="flex items-center justify-between">
                                <button
                                  type="button"
                                  onClick={() => setWoShowPresetsBar(!woShowPresetsBar)}
                                  className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300 hover:text-amber-200 transition-colors cursor-pointer"
                                >
                                  <span className="p-1 rounded-md bg-amber-950/80 border border-amber-500/40">
                                    {woShowPresetsBar ? <ChevronUp className="w-3 h-3 text-amber-400" /> : <ChevronDown className="w-3 h-3 text-amber-400" />}
                                  </span>
                                  <span>پیشنهادات سریع {woConsumableTab === 'سایر' ? 'سایر اقلام' : `لوازم ${woConsumableTab}`}</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setWoShowPresetsBar(!woShowPresetsBar)}
                                  className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-900/90 border border-amber-500/30 text-amber-300 hover:text-white cursor-pointer"
                                >
                                  {woShowPresetsBar ? '▲ بستن نوار' : '▼ نمایش نوار اقلام'}
                                </button>
                              </div>

                              {woShowPresetsBar && (
                                <div className="flex items-center gap-2 overflow-x-auto py-2 px-2.5 rounded-xl bg-slate-950/90 border border-amber-500/40">
                                  {Array.from(new Set([
                                    ...unifiedInventoryParts
                                      .filter(p =>
                                        woConsumableTab === 'برقی'
                                          ? p.category === 'برقی' || p.category === 'ابزار دقیق'
                                          : woConsumableTab === 'مکانیکی'
                                          ? p.category === 'مکانیکی' || p.category === 'هیدرولیک و پنوماتیک'
                                          : p.category === 'عمومی و سایر'
                                      )
                                      .map(p => p.name),
                                    ...DEFAULT_PRESET_CONSUMABLES[woConsumableTab]
                                  ])).map((pName, idx) => {
                                    const inList = woForm.consumables.find(c => c.name === pName && c.category === woConsumableTab);
                                    return (
                                      <button
                                        key={idx}
                                        type="button"
                                        onClick={() => handleAddWoConsumablePreset(pName, woConsumableTab)}
                                        className={`shrink-0 whitespace-nowrap px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-all border cursor-pointer ${
                                          inList
                                            ? 'bg-amber-950/90 border-amber-500/80 text-amber-200 font-bold'
                                            : 'bg-slate-900/90 hover:bg-amber-950/40 border-blue-800/60 text-blue-200 hover:text-white'
                                        }`}
                                      >
                                        <span className="text-amber-400 font-bold">+</span>
                                        <span>{pName}</span>
                                        {inList && (
                                          <span className="font-mono text-[10px] px-1.5 bg-amber-900/90 text-amber-300 rounded-full font-bold">
                                            ×{inList.count}
                                          </span>
                                        )}
                                      </button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>

                            <div className="pt-2 border-t border-blue-900/40">
                              <datalist id="wo-unified-parts-datalist">
                                {unifiedInventoryParts.map(p => (
                                  <option key={p.id} value={p.name} />
                                ))}
                              </datalist>
                              <div className="grid grid-cols-12 gap-2">
                                <div className="col-span-12 sm:col-span-6">
                                  <input
                                    type="text"
                                    list="wo-unified-parts-datalist"
                                    value={woNewPartName}
                                    onChange={e => setWoNewPartName(e.target.value)}
                                    onKeyDown={e => {
                                      if (e.key === 'Enter') {
                                        e.preventDefault();
                                        handleAddWoCustomConsumable();
                                      }
                                    }}
                                    placeholder={`نام قطعه ${woConsumableTab}...`}
                                    className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                                  />
                                </div>
                                <div className="col-span-4 sm:col-span-2">
                                  <input
                                    type="number"
                                    min={1}
                                    value={woNewPartCount}
                                    onChange={e => setWoNewPartCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                                    className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white font-mono text-center focus:outline-none focus:border-amber-400"
                                  />
                                </div>
                                <div className="col-span-4 sm:col-span-2">
                                  <select
                                    value={woNewPartUnit}
                                    onChange={e => setWoNewPartUnit(e.target.value)}
                                    className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                                  >
                                    <option value="عدد">عدد</option>
                                    <option value="متر">متر</option>
                                    <option value="لیتر">لیتر</option>
                                    <option value="کیلوگرم">کیلوگرم</option>
                                    <option value="بسته">بسته</option>
                                    <option value="شاخه">شاخه</option>
                                  </select>
                                </div>
                                <div className="col-span-4 sm:col-span-2">
                                  <button
                                    type="button"
                                    onClick={handleAddWoCustomConsumable}
                                    className="w-full py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1 cursor-pointer"
                                  >
                                    <Plus className="w-3.5 h-3.5" />
                                    <span>افزودن</span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </>
                        )}

                        {woForm.consumables.length === 0 ? (
                          isWoReadOnly && (
                            <div className="text-center py-3 text-[11px] text-slate-500 border border-dashed border-slate-700 rounded-xl">
                              قطعه یا قلم مصرفی برای این دستور کار ثبت نشده است.
                            </div>
                          )
                        ) : (
                          <div className={`space-y-1.5 ${!isWoReadOnly ? 'pt-2 border-t border-blue-900/40' : ''}`}>
                            {woForm.consumables.map(part => (
                              <div key={part.id} className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/90 border border-amber-500/30 text-xs">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 text-[10px] font-bold shrink-0">
                                    {part.category}
                                  </span>
                                  <span className="font-bold text-white truncate">{part.name}</span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  {!isWoReadOnly && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setWoForm(prev => ({
                                          ...prev,
                                          consumables: prev.consumables.map(c =>
                                            c.id === part.id ? { ...c, count: Math.max(1, c.count - 1) } : c
                                          )
                                        }))
                                      }
                                      className="w-6 h-6 rounded bg-slate-800 text-slate-300 hover:text-white font-mono cursor-pointer"
                                    >
                                      -
                                    </button>
                                  )}
                                  <span className="font-mono font-bold text-amber-300">
                                    {part.count} {part.unit || 'عدد'}
                                  </span>
                                  {!isWoReadOnly && (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setWoForm(prev => ({
                                            ...prev,
                                            consumables: prev.consumables.map(c =>
                                              c.id === part.id ? { ...c, count: c.count + 1 } : c
                                            )
                                          }))
                                        }
                                        className="w-6 h-6 rounded bg-slate-800 text-slate-300 hover:text-white font-mono cursor-pointer"
                                      >
                                        +
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setWoForm(prev => ({
                                            ...prev,
                                            consumables: prev.consumables.filter(c => c.id !== part.id)
                                          }))
                                        }
                                        className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* ۴. تاخیر (به‌صورت پیش‌فرض بسته و با کلیک باز می‌شود) */}
                  <div className="rounded-2xl bg-[#070e22]/90 border border-rose-500/30 overflow-hidden">
                    <div
                      role="button"
                      tabIndex={0}
                      onClick={() => setIsWoDelaysOpen(prev => !prev)}
                      onKeyDown={e => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          setIsWoDelaysOpen(prev => !prev);
                        }
                      }}
                      className="w-full p-4 flex flex-wrap items-center justify-between gap-2 text-right hover:bg-[#0c162e]/60 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <Timer className="w-4 h-4 text-rose-400" />
                        <div>
                          <h3 className="text-xs font-black text-white">تاخیر</h3>
                          <span className="text-[10px] text-slate-400 block">
                            ثبت کد تاخیر، عنوان، تعداد روز و ساعت تاخیر
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-rose-950/80 text-rose-300 border border-rose-500/40">
                          {woForm.delays.length} مورد
                        </span>
                        {isWoDelaysOpen ? (
                          <ChevronUp className="w-4 h-4 text-rose-300" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-rose-300" />
                        )}
                      </div>
                    </div>

                    {isWoDelaysOpen && (
                      <div className="px-4 pb-4 pt-2 border-t border-rose-900/40 space-y-3">
                        {!isWoReadOnly && (
                          <div className="flex justify-end">
                            <button
                              type="button"
                              onClick={handleAddWoDelay}
                              className="px-3 py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>افزودن تاخیر</span>
                            </button>
                          </div>
                        )}

                        {woForm.delays.length === 0 ? (
                          <div className="text-center py-3 text-[11px] text-slate-500 border border-dashed border-slate-700 rounded-xl">
                            {isWoReadOnly ? 'تاخیری برای این دستور کار ثبت نشده است.' : 'در صورت بروز تاخیر در انجام دستور کار، روی «افزودن تاخیر» کلیک کنید.'}
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {woForm.delays.map(delay => (
                              <div key={delay.id} className="grid grid-cols-12 gap-2 items-center p-2.5 rounded-xl bg-[#0c162e] border border-rose-500/25 text-xs">
                                <div className="col-span-5 sm:col-span-3">
                                  <label className="text-[10px] text-slate-400 block mb-0.5">کد تاخیر</label>
                                  <input
                                    type="text"
                                    value={delay.code}
                                    disabled={isWoReadOnly}
                                    onChange={e =>
                                      !isWoReadOnly &&
                                      setWoForm(prev => ({
                                        ...prev,
                                        delays: prev.delays.map(d =>
                                          d.id === delay.id ? { ...d, code: e.target.value } : d
                                        )
                                      }))
                                    }
                                    placeholder="کد تاخیر"
                                    dir="ltr"
                                    className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-rose-300 font-mono outline-none focus:border-rose-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                  />
                                </div>
                                <div className="col-span-7 sm:col-span-4">
                                  <label className="text-[10px] text-slate-400 block mb-0.5">عنوان تاخیر</label>
                                  <input
                                    type="text"
                                    value={delay.title}
                                    disabled={isWoReadOnly}
                                    onChange={e =>
                                      !isWoReadOnly &&
                                      setWoForm(prev => ({
                                        ...prev,
                                        delays: prev.delays.map(d =>
                                          d.id === delay.id ? { ...d, title: e.target.value } : d
                                        )
                                      }))
                                    }
                                    placeholder="عنوان و علت تاخیر..."
                                    className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white outline-none focus:border-rose-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                  />
                                </div>
                                <div className="col-span-5 sm:col-span-2">
                                  <label className="text-[10px] text-slate-400 block mb-0.5">تعداد روز</label>
                                  <input
                                    type="number"
                                    min={0}
                                    value={delay.days}
                                    disabled={isWoReadOnly}
                                    onChange={e =>
                                      !isWoReadOnly &&
                                      setWoForm(prev => ({
                                        ...prev,
                                        delays: prev.delays.map(d =>
                                          d.id === delay.id ? { ...d, days: Math.max(0, parseInt(e.target.value, 10) || 0) } : d
                                        )
                                      }))
                                    }
                                    dir="ltr"
                                    className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-rose-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                  />
                                </div>
                                <div className="col-span-5 sm:col-span-2">
                                  <label className="text-[10px] text-slate-400 block mb-0.5">ساعت</label>
                                  <input
                                    type="number"
                                    min={0}
                                    step="0.5"
                                    value={delay.hours}
                                    disabled={isWoReadOnly}
                                    onChange={e =>
                                      !isWoReadOnly &&
                                      setWoForm(prev => ({
                                        ...prev,
                                        delays: prev.delays.map(d =>
                                          d.id === delay.id ? { ...d, hours: Math.max(0, parseFloat(e.target.value) || 0) } : d
                                        )
                                      }))
                                    }
                                    dir="ltr"
                                    className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-rose-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                                  />
                                </div>
                                {!isWoReadOnly && (
                                  <div className="col-span-2 sm:col-span-1 flex justify-end pt-4">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setWoForm(prev => ({
                                          ...prev,
                                          delays: prev.delays.filter(d => d.id !== delay.id)
                                        }))
                                      }
                                      className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                                      title="حذف تاخیر"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                )}
                              </div>
                            ))}
                            <div className="text-left text-[11px] text-rose-300 font-mono font-bold pt-1">
                              جمع تاخیر: {woForm.delays.reduce((s, d) => s + (Number(d.days) || 0), 0)} روز و {woForm.delays.reduce((s, d) => s + (Number(d.hours) || 0), 0)} ساعت
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                /* ================= صفحه سوم: وضعیت دستور کار و خواب تجهیز ================= */
                <div className="space-y-5">
                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-emerald-500/35 space-y-3">
                    <div className="flex items-center gap-2 pb-2 border-b border-emerald-900/40">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <div>
                        <h3 className="text-xs font-black text-white">تغییر وضعیت دستور کار</h3>
                        <span className="text-[10px] text-slate-400 block">
                          وضعیت نهایی پرونده (مثلاً انجام شده) را انتخاب نمایید
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { value: 'در انتظار دستور برنامه ریزی', label: 'در انتظار دستور' },
                        { value: 'در حال انجام', label: 'در حال انجام' },
                        { value: 'انجام شد', label: 'انجام شده' },
                        { value: 'لغو', label: 'لغو' }
                      ].map(opt => {
                        const isSelected =
                          woForm.status === opt.value ||
                          (opt.value === 'انجام شد' && woForm.status === 'انجام شده') ||
                          (opt.value === 'لغو' && woForm.status === 'لغو شده');
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            disabled={isWoReadOnly}
                            onClick={() => {
                              if (isWoReadOnly) return;
                              setWoValidationError(null);
                              setWoForm(prev => ({ ...prev, status: opt.value }));
                            }}
                            className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                              isWoReadOnly ? 'cursor-not-allowed opacity-85' : 'cursor-pointer'
                            } ${
                              isSelected
                                ? opt.value === 'انجام شد'
                                  ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                                  : opt.value === 'لغو'
                                  ? 'bg-rose-600 text-white border-rose-400 shadow-md'
                                  : 'bg-cyan-600 text-white border-cyan-400 shadow-md'
                                : 'bg-[#0c162e] text-slate-300 hover:text-white border-slate-700/80'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5" />}
                            <span>{opt.label}</span>
                          </button>
                        );
                      })}
                    </div>

                    {!isWoReadOnly && ((woForm.status === 'انجام شد' || woForm.status === 'انجام شده') && woForm.activities.length === 0) && (
                      <div className={`p-3 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
                        woValidationError
                          ? 'bg-rose-950/70 border-rose-500/60 text-rose-200'
                          : 'bg-amber-950/50 border-amber-500/40 text-amber-200'
                      }`}>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                          <span>
                            {woValidationError || 'برای ثبت وضعیت «انجام شده»، ابتدا حداقل یک فعالیت نگه‌داشت در تب «فعالیت» ثبت نمایید.'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setWoModalPage(2)}
                          className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold transition-all cursor-pointer shrink-0"
                        >
                          ثبت فعالیت در تب فعالیت
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-cyan-500/35 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-cyan-400" />
                        <div>
                          <h3 className="text-xs font-black text-white">زمان‌بندی خواب تجهیز (شروع و پایان توقف)</h3>
                          <span className="text-[10px] text-slate-400 block">
                            این بازه به‌عنوان مبنای رسمی محاسبه شاخص‌های قابلیت اطمینان (MTBF / MTTR / MTTF) و گزارش‌گیری‌ها ثبت می‌شود
                          </span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-amber-950/80 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold">
                        مدت خواب تجهیز:{' '}
                        {formatMinutesDurationFa(
                          computeMinutesBetweenShamsiDateTimes(
                            woForm.woStartDate,
                            woForm.woStartTime,
                            woForm.woEndDate,
                            woForm.woEndTime
                          )
                        )}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                        <label className="text-[11px] text-slate-400 block mb-1.5">تاریخ شروع</label>
                        <input
                          type="text"
                          value={woForm.woStartDate}
                          disabled={isWoReadOnly}
                          onChange={e => !isWoReadOnly && setWoForm(prev => ({
                            ...prev,
                            woStartDate: e.target.value,
                            workDays: prev.workDays.map((d, i) => (i === 0 ? { ...d, startDate: e.target.value } : d))
                          }))}
                          dir="ltr"
                          placeholder="1405/08/23"
                          className={`w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                        />
                      </div>
                      <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                        <label className="text-[11px] text-slate-400 block mb-1.5">ساعت شروع</label>
                        <TimeInput24
                          value={woForm.woStartTime}
                          disabled={isWoReadOnly}
                          onChange={nextVal => !isWoReadOnly && setWoForm(prev => ({
                            ...prev,
                            woStartTime: nextVal,
                            workDays: prev.workDays.map((d, i) => (i === 0 ? { ...d, startTime: nextVal } : d))
                          }))}
                          className="w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400"
                        />
                      </div>
                      <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                        <label className="text-[11px] text-slate-400 block mb-1.5">تاریخ پایان</label>
                        <input
                          type="text"
                          value={woForm.woEndDate}
                          disabled={isWoReadOnly}
                          onChange={e => !isWoReadOnly && setWoForm(prev => ({
                            ...prev,
                            woEndDate: e.target.value,
                            workDays: prev.workDays.map((d, i, arr) => (i === arr.length - 1 ? { ...d, endDate: e.target.value } : d))
                          }))}
                          dir="ltr"
                          placeholder="1405/08/23"
                          className={`w-full bg-[#070e22] border border-emerald-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-emerald-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                        />
                      </div>
                      <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                        <label className="text-[11px] text-slate-400 block mb-1.5">ساعت پایان</label>
                        <TimeInput24
                          value={woForm.woEndTime}
                          disabled={isWoReadOnly}
                          onChange={nextVal => !isWoReadOnly && setWoForm(prev => ({
                            ...prev,
                            woEndTime: nextVal,
                            workDays: prev.workDays.map((d, i, arr) => (i === arr.length - 1 ? { ...d, endTime: nextVal } : d))
                          }))}
                          className="w-full bg-[#070e22] border border-emerald-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-emerald-400"
                        />
                      </div>
                    </div>
                  </div>

                  {/* توضیحات وضعیت دستور کار */}
                  <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 space-y-2.5">
                    <label className="text-xs font-black text-white flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <span>توضیحات</span>
                    </label>
                    <textarea
                      rows={3}
                      value={woForm.notes}
                      disabled={isWoReadOnly}
                      readOnly={isWoReadOnly}
                      onChange={e => !isWoReadOnly && setWoForm(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder={isWoReadOnly ? 'توضیحاتی ثبت نشده است.' : 'توضیحات تکمیلی درباره وضعیت دستور کار، علت توقف یا اقدامات انجام‌شده...'}
                      className={`w-full bg-[#0c162e] border border-indigo-500/35 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-400 leading-relaxed ${isWoReadOnly ? 'opacity-85 cursor-not-allowed' : ''}`}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* پاورقی فرم دستور کار (دکمه ثبت فقط در صفحه وضعیت دستورکارهای فعال نمایش داده می‌شود) */}
            <div className="px-5 py-3.5 bg-[#070e22] border-t border-indigo-900/50 flex items-center justify-between gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsWorkOrderModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
              >
                {isWoReadOnly ? 'بستن' : 'انصراف'}
              </button>

              {woModalPage === 3 && !isWoReadOnly && (
                <button
                  type="button"
                  onClick={() => handleSaveWorkOrder()}
                  className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>ثبت</span>
                </button>
              )}

              {isWoReadOnly && woTargetRequest && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedWoForPrint(woTargetRequest);
                      setIsWoPrintModalOpen(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#112448] hover:bg-indigo-700 text-cyan-200 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Eye className="w-4 h-4" />
                    <span>پیش‌نمایش فرم ({printSettings.workOrderClosedA4.docCode})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedWoForPrint(woTargetRequest);
                      triggerClosedWorkOrderPrint(woTargetRequest);
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>چاپ دستور کار</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
        );
      })(), document.body)}

      {/* استایل‌های اختصاصی چاپ A5 و A4 */}
      <style>{`
        @media print {
          @page {
            size: ${isWoPrintModalOpen ? 'A4 portrait' : 'A5 portrait'};
            margin: ${isWoPrintModalOpen ? '8mm' : '4mm 5mm'};
          }
          html, body {
            background: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 0 !important;
            height: auto !important;
            min-height: auto !important;
            overflow: visible !important;
          }
          body:has(#official-work-order-sheet) > #root {
            display: none !important;
          }
          .wo-print-modal-backdrop,
          .wo-print-modal-container {
            position: static !important;
            inset: auto !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            max-height: none !important;
            overflow: visible !important;
            padding: 0 !important;
            margin: 0 !important;
            background: transparent !important;
            backdrop-filter: none !important;
            border: none !important;
            box-shadow: none !important;
          }
          body * {
            visibility: hidden !important;
          }
          #official-work-request-sheet,
          #official-work-request-sheet *,
          #official-work-order-sheet,
          #official-work-order-sheet * {
            visibility: visible !important;
          }
          #official-work-request-sheet,
          #official-work-order-sheet {
            display: block !important;
            left: 0 !important;
            top: 0 !important;
            right: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: ${isWoPrintModalOpen ? '4mm' : '2mm 3mm'} !important;
            box-shadow: none !important;
            border: 1.5px solid #000 !important;
            border-radius: 4px !important;
            background: #ffffff !important;
            color: #000000 !important;
            z-index: 9999999 !important;
          }
          #official-work-request-sheet {
            position: absolute !important;
          }
          #official-work-order-sheet {
            position: relative !important;
          }
        }
      `}</style>
    </div>
  );
};

export default WorkRequestModule;
