import React, { useState, useEffect, useRef } from 'react';
import { Calendar, ChevronRight, ChevronLeft, X, Check } from 'lucide-react';

interface JalaliDatePickerProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  label?: string;
  className?: string;
}

const PERSIAN_MONTHS = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند'
];

const WEEK_DAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

// تبدیل ارقام فارسی به انگلیسی
function faToEn(str: string): string {
  if (!str) return '';
  return str.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
}

// تبدیل ارقام انگلیسی به فارسی
function enToFa(num: number | string): string {
  if (num === undefined || num === null) return '';
  return String(num).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

// تعداد روزهای ماه شمسی
function getDaysInMonth(year: number, monthIndex: number): number {
  if (monthIndex < 6) return 31; // فروردین تا شهریور
  if (monthIndex < 11) return 30; // مهر تا بهمن
  // اسفند: کبیسه بودن ساده
  const isLeap = [1, 5, 9, 13, 17, 22, 26, 30].includes(year % 33);
  return isLeap ? 30 : 29;
}

export const JalaliDatePicker: React.FC<JalaliDatePickerProps> = ({
  value,
  onChange,
  placeholder = 'انتخاب تاریخ...',
  label,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // پارس کردن مقدار ورودی (مثلاً 1405/08/02)
  const parseValue = (val: string) => {
    const clean = faToEn(val || '').trim();
    const parts = clean.split(/[\/\-\.]/);
    if (parts.length === 3) {
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10) - 1;
      const d = parseInt(parts[2], 10);
      if (!isNaN(y) && !isNaN(m) && !isNaN(d) && y > 1300 && m >= 0 && m < 12 && d >= 1 && d <= 31) {
        return { y, m, d };
      }
    }
    // پیش‌فرض به سال و ماه داده‌های مرجع (۱۴۰۵ یا ۱۴۰۴)
    return { y: 1405, m: 7, d: 2 }; // آبان ۱۴۰۵
  };

  const parsed = parseValue(value);
  const [viewYear, setViewYear] = useState<number>(parsed.y);
  const [viewMonth, setViewMonth] = useState<number>(parsed.m);

  // همگام‌سازی سال و ماه جاری هنگام تغییر value از بیرون
  useEffect(() => {
    if (value) {
      const p = parseValue(value);
      setViewYear(p.y);
      setViewMonth(p.m);
    }
  }, [value]);

  // بستن پاپ‌اوور در کلیک خارج از کامپوننت
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpen]);

  const daysCount = getDaysInMonth(viewYear, viewMonth);

  const handlePrevMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(y => y - 1);
    } else {
      setViewMonth(m => m - 1);
    }
  };

  const handleNextMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(y => y + 1);
    } else {
      setViewMonth(m => m + 1);
    }
  };

  const handleSelectDay = (day: number) => {
    const mStr = String(viewMonth + 1).padStart(2, '0');
    const dStr = String(day).padStart(2, '0');
    const formatted = `${viewYear}/${mStr}/${dStr}`;
    onChange(formatted);
    setIsOpen(false);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange('');
    setIsOpen(false);
  };

  const handleQuickToday = (e: React.MouseEvent) => {
    e.stopPropagation();
    // پیش‌فرض روز جاری از تراکنش‌های اخیر (مثلاً 1405/08/02)
    onChange('1405/08/02');
    setViewYear(1405);
    setViewMonth(7);
    setIsOpen(false);
  };

  const isCurrentSelection = (day: number) => {
    if (!value) return false;
    const clean = faToEn(value);
    const mStr = String(viewMonth + 1).padStart(2, '0');
    const dStr = String(day).padStart(2, '0');
    return clean === `${viewYear}/${mStr}/${dStr}`;
  };

  return (
    <div className={`relative inline-block ${className}`} ref={containerRef}>
      {label && <label className="block text-[11px] text-slate-400 mb-1">{label}</label>}

      {/* فیلد ورودی تاریخ با قابلیت کلیک جهت باز شدن تقویم */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 bg-[#0d1117] border border-[#303844] hover:border-amber-500/70 rounded-xl px-2.5 py-1.5 text-xs cursor-pointer transition-all shadow-sm group"
        title="جهت انتخاب تاریخ از تقویم کلیک کنید"
      >
        <Calendar className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
        <input
          type="text"
          value={value}
          readOnly
          placeholder={placeholder}
          className="w-24 sm:w-28 bg-transparent text-amber-300 font-mono text-center text-xs focus:outline-none cursor-pointer placeholder:text-slate-500"
        />
        {value ? (
          <button
            type="button"
            onClick={handleClear}
            className="text-slate-500 hover:text-rose-400 p-0.5 rounded transition-colors"
            title="پاک کردن"
          >
            <X className="w-3 h-3" />
          </button>
        ) : null}
      </div>

      {/* تقویم پاپ‌اوور کوچک و شیک */}
      {isOpen && (
        <div className="absolute z-50 mt-1 right-0 sm:right-auto sm:left-0 w-64 rounded-2xl bg-gradient-to-b from-[#181d26] to-[#0f131a] border border-[#384252] shadow-2xl p-3.5 text-slate-200 animate-in fade-in zoom-in-95 duration-150">
          
          {/* هدر تقویم: سال، ماه و ناوبری */}
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#2b3442]">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="ماه قبل"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5 text-xs font-bold text-white">
              {/* سلکتور ماه */}
              <select
                value={viewMonth}
                onChange={e => setViewMonth(parseInt(e.target.value, 10))}
                className="bg-[#0f141c] border border-[#384252] rounded-lg px-2 py-0.5 text-xs text-amber-300 focus:outline-none cursor-pointer"
              >
                {PERSIAN_MONTHS.map((mName, idx) => (
                  <option key={idx} value={idx}>{mName}</option>
                ))}
              </select>

              {/* سلکتور سال */}
              <select
                value={viewYear}
                onChange={e => setViewYear(parseInt(e.target.value, 10))}
                className="bg-[#0f141c] border border-[#384252] rounded-lg px-2 py-0.5 text-xs font-mono text-amber-300 focus:outline-none cursor-pointer"
              >
                {[1402, 1403, 1404, 1405, 1406, 1407].map(yr => (
                  <option key={yr} value={yr}>{enToFa(yr)}</option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="ماه بعد"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* روزهای هفته */}
          <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-[#8f9ba8] pb-1.5">
            {WEEK_DAYS.map((wd, i) => (
              <div key={i} className={i === 6 ? 'text-rose-400' : ''}>{wd}</div>
            ))}
          </div>

          {/* شبکه روزهای ماه */}
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: daysCount }).map((_, i) => {
              const day = i + 1;
              const isSelected = isCurrentSelection(day);

              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleSelectDay(day)}
                  className={`h-7 rounded-lg text-xs font-mono font-bold flex items-center justify-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-tr from-amber-500 to-orange-600 text-white shadow-md shadow-amber-900/40 ring-1 ring-amber-400'
                      : 'text-slate-300 hover:bg-[#252d3a] hover:text-white'
                  }`}
                >
                  {enToFa(day)}
                </button>
              );
            })}
          </div>

          {/* دکمه‌های اقدام سریع پایین تقویم */}
          <div className="pt-2.5 mt-2.5 border-t border-[#2b3442] flex items-center justify-between text-[10.5px]">
            <button
              type="button"
              onClick={handleQuickToday}
              className="text-amber-400 hover:text-amber-300 font-bold transition-colors cursor-pointer"
            >
              امروز (۲ آبان)
            </button>

            <button
              type="button"
              onClick={() => handleSelectDay(1)}
              className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors cursor-pointer"
            >
              اول ماه
            </button>

            <button
              type="button"
              onClick={handleClear}
              className="text-rose-400 hover:text-rose-300 font-medium transition-colors cursor-pointer"
            >
              پاک کردن
            </button>
          </div>

        </div>
      )}
    </div>
  );
};
