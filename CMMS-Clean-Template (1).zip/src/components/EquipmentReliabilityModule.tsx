import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  ShieldCheck,
  Calendar,
  Clock,
  Printer,
  TrendingUp,
  Activity,
  Search,
  FileText,
  BarChart2,
  RefreshCw,
  X
} from 'lucide-react';
import { COMPANY_LOGO_WHITEBG } from '../data/auditImages';
import defaultPlantEquipment from '../data/plantEquipment.json';
import { computeMinutesBetweenShamsiDateTimes, extractShamsiDateAndTime } from '../data/dateTimeUtils';
import { usePrintSettings } from '../data/printSettings';

export type TimeScaleUnit = 'hour' | 'day' | 'week';

interface EquipmentReliabilityModuleProps {
  requestsList?: any[];
}

interface NormalizedEquipment {
  code: string;
  name: string;
  group: string;
  location: string;
  priority?: string;
}

const toFaDigits = (n: number | string): string => {
  if (n === null || n === undefined) return '';
  return String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)]);
};

const toEnDigits = (s: string): string => {
  return String(s || '')
    .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
    .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584));
};

export function getTodayShamsiDate(): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    const parts = formatter.formatToParts(new Date());
    const y = parts.find(p => p.type === 'year')?.value || '1405';
    const m = parts.find(p => p.type === 'month')?.value || '08';
    const d = parts.find(p => p.type === 'day')?.value || '22';
    return `${y}/${m}/${d}`;
  } catch {
    return '1405/08/22';
  }
}

export function parseJalaliDays(shamsiDate: string): number {
  try {
    const clean = toEnDigits(shamsiDate || '').trim();
    const parts = clean.split(/[/-]/).map(p => parseInt(p.trim(), 10));
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      const [y, m, d] = parts;
      let days = y * 365.25;
      if (m <= 6) {
        days += (m - 1) * 31;
      } else {
        days += 6 * 31 + (m - 7) * 30;
      }
      days += d;
      return days;
    }
  } catch {}
  return 0;
}

export function addDaysToShamsi(shamsiDate: string, daysToAdd: number): string {
  try {
    const clean = toEnDigits(shamsiDate || '').trim();
    const parts = clean.split('/').map(p => parseInt(p.trim(), 10));
    if (parts.length !== 3 || isNaN(parts[0])) return shamsiDate;
    let [y, m, d] = parts;
    let totalD = d + daysToAdd;

    while (totalD > (m <= 6 ? 31 : 30)) {
      const maxDays = m <= 6 ? 31 : 30;
      totalD -= maxDays;
      m++;
      if (m > 12) {
        m = 1;
        y++;
      }
    }
    while (totalD < 1) {
      m--;
      if (m < 1) {
        m = 12;
        y--;
      }
      const prevMax = m <= 6 ? 31 : 30;
      totalD += prevMax;
    }
    const mm = m < 10 ? `0${m}` : `${m}`;
    const dd = totalD < 10 ? `0${totalD}` : `${totalD}`;
    return `${y}/${mm}/${dd}`;
  } catch {
    return shamsiDate;
  }
}

const loadAuthoritativeEquipments = (): NormalizedEquipment[] => {
  const map = new Map<string, NormalizedEquipment>();

  const normalizeAndSet = (rawList: any[]) => {
    rawList.forEach((eq: any) => {
      if (!eq) return;
      const code = String(eq.id || eq.code || '').trim();
      const name = String(eq.name || eq.title || '').trim();
      if (!code && !name) return;
      const key = code || name;
      map.set(key, {
        code: key,
        name: name || key,
        group: String(eq.family || eq.group || eq.category || '').trim(),
        location: String(eq.location || eq.zone || '').trim(),
        priority: String(eq.priority || '').trim()
      });
    });
  };

  try {
    const savedV13 = localStorage.getItem('pm_studio_equipments_v13');
    if (savedV13) {
      const parsed = JSON.parse(savedV13);
      if (Array.isArray(parsed) && parsed.length > 0) {
        normalizeAndSet(parsed);
      } else {
        normalizeAndSet(defaultPlantEquipment as any[]);
      }
    } else {
      normalizeAndSet(defaultPlantEquipment as any[]);
    }
  } catch {
    normalizeAndSet(defaultPlantEquipment as any[]);
  }

  // پشتیبانی از تجهیزات دستی ثبت‌شده در نسخه‌های دیگر ذخیره‌سازی
  ['portal_equipments_v9', 'portal_pm_equipments_v3'].forEach(storageKey => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach((eq: any) => {
            const c = String(eq?.code || eq?.id || '').trim();
            if (c && !map.has(c)) {
              map.set(c, {
                code: c,
                name: String(eq.name || eq.title || c).trim(),
                group: String(eq.family || eq.group || eq.category || '').trim(),
                location: String(eq.location || eq.zone || '').trim()
              });
            }
          });
        }
      }
    } catch {}
  });

  return Array.from(map.values());
};

export const EquipmentReliabilityModule: React.FC<EquipmentReliabilityModuleProps> = ({
  requestsList = []
}) => {
  const printSettings = usePrintSettings();
  const todayShamsi = useMemo(() => getTodayShamsiDate(), []);

  // تقویم پیش‌فرض به روز (پایان: امروز، شروع: ۳۰ روز پیش از امروز) با قابلیت تنظیم دلخواه
  const [endDate, setEndDate] = useState<string>(todayShamsi);
  const [startDate, setStartDate] = useState<string>(() => addDaysToShamsi(todayShamsi, -30));
  const [activeDatePreset, setActiveDatePreset] = useState<'30days' | '90days' | '180days' | 'yearToDate' | 'custom'>('30days');

  // لیست زنده ۲۵۲ تجهیز واقعی مدیریت تجهیزات + همگام‌سازی خودکار هنگام افزودن/ویرایش/حذف
  const [liveEquipments, setLiveEquipments] = useState<NormalizedEquipment[]>(() => loadAuthoritativeEquipments());

  useEffect(() => {
    const syncEquipments = (e?: any) => {
      if (e?.detail && Array.isArray(e.detail)) {
        const next: NormalizedEquipment[] = e.detail
          .filter((eq: any) => eq && (eq.id || eq.code))
          .map((eq: any) => ({
            code: String(eq.id || eq.code).trim(),
            name: String(eq.name || eq.title || eq.id || eq.code).trim(),
            group: String(eq.family || eq.group || eq.category || '').trim(),
            location: String(eq.location || eq.zone || '').trim(),
            priority: String(eq.priority || '').trim()
          }));
        setLiveEquipments(next);
      } else {
        setLiveEquipments(loadAuthoritativeEquipments());
      }
    };

    const handleStorage = (e: StorageEvent) => {
      if (!e.key || e.key === 'pm_studio_equipments_v13') {
        syncEquipments();
      }
    };

    window.addEventListener('factory_equipments_updated', syncEquipments);
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('factory_equipments_updated', syncEquipments);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  const [equipmentCode, setEquipmentCode] = useState<string>(() => {
    const initial = loadAuthoritativeEquipments();
    return initial[0]?.code || '';
  });
  const [equipmentSearchQuery, setEquipmentSearchQuery] = useState<string>('');
  const [isSearchDropdownOpen, setIsSearchDropdownOpen] = useState<boolean>(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const [timeUnit, setTimeUnit] = useState<TimeScaleUnit>('hour');

  useEffect(() => {
    if (liveEquipments.length > 0 && !liveEquipments.some(e => e.code === equipmentCode)) {
      setEquipmentCode(liveEquipments[0].code);
    }
  }, [liveEquipments, equipmentCode]);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const filteredAvailableEquipments = useMemo(() => {
    const q = equipmentSearchQuery.trim().toLowerCase();
    if (!q) return liveEquipments;
    return liveEquipments.filter(e =>
      e.code.toLowerCase().includes(q) ||
      e.name.toLowerCase().includes(q) ||
      e.group.toLowerCase().includes(q) ||
      e.location.toLowerCase().includes(q)
    );
  }, [liveEquipments, equipmentSearchQuery]);

  const selectedEquipment = useMemo(() => {
    return (
      liveEquipments.find(e => e.code === equipmentCode) || {
        code: equipmentCode || '—',
        name: 'انتخاب نشده',
        group: '',
        location: ''
      }
    );
  }, [liveEquipments, equipmentCode]);

  const handleApplyPreset = (preset: '30days' | '90days' | '180days' | 'yearToDate' | 'custom') => {
    setActiveDatePreset(preset);
    const today = getTodayShamsiDate();
    setEndDate(today);
    if (preset === '30days') {
      setStartDate(addDaysToShamsi(today, -30));
    } else if (preset === '90days') {
      setStartDate(addDaysToShamsi(today, -90));
    } else if (preset === '180days') {
      setStartDate(addDaysToShamsi(today, -180));
    } else if (preset === 'yearToDate') {
      const y = today.split('/')[0] || '1405';
      setStartDate(`${y}/01/01`);
    }
  };

  const periodDays = useMemo(() => {
    const dStart = parseJalaliDays(startDate);
    const dEnd = parseJalaliDays(endDate);
    const diff = Math.round(dEnd - dStart + 1);
    return diff > 0 ? diff : 30;
  }, [startDate, endDate]);

  const totalPeriodHours = periodDays * 24;

  // تجمیع کلیه درخواست کارها و دستور کارهای واقعی ثبت‌شده در سیستم
  const allWorkEvents = useMemo(() => {
    const map = new Map<string, any>();
    const addItems = (arr: any[]) => {
      arr.forEach((item: any) => {
        if (!item) return;
        const key = String(item.code || item.id || `${item.title || ''}-${item.created || item.date || ''}`);
        if (!map.has(key)) {
          map.set(key, item);
        }
      });
    };

    addItems(Array.isArray(requestsList) ? requestsList : []);
    ['portal_pm_work_requests_v3', 'technicalServiceWorkRequests', 'pm_studio_work_orders_v15'].forEach(storageKey => {
      try {
        const raw = localStorage.getItem(storageKey);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) addItems(parsed);
        }
      } catch {}
    });

    return Array.from(map.values());
  }, [requestsList]);

  // فیلتر رویدادهای واقعی منطبق با تجهیز انتخابی و بازه تاریخ
  const matchingRequests = useMemo(() => {
    if (!equipmentCode) return [];
    const dStart = parseJalaliDays(startDate);
    const dEnd = parseJalaliDays(endDate);
    const normCode = equipmentCode.trim().toLowerCase();

    return allWorkEvents.filter((r: any) => {
      const rCode = String(r.equipmentCode || r.eqCode || '').trim().toLowerCase();
      const rEqName = String(r.equipmentName || r.eqName || '').trim().toLowerCase();
      const rTitle = String(r.title || r.failureTitle || '').toLowerCase();
      const rDesc = String(r.description || r.actionDetails || '').toLowerCase();
      const selectedList: string[] = Array.isArray(r.selectedEquipments) ? r.selectedEquipments.map((s: any) => String(s).trim().toLowerCase()) : [];

      const matchEq =
        (rCode && rCode === normCode) ||
        selectedList.includes(normCode) ||
        (rTitle.includes(normCode) && normCode.length >= 4) ||
        (rDesc.includes(normCode) && normCode.length >= 4) ||
        (selectedEquipment.name && rEqName === selectedEquipment.name.toLowerCase() && !rCode);

      if (!matchEq) return false;

      const statusNorm = String(r.status || '').trim();
      if (statusNorm === 'لغو' || statusNorm === 'لغو شده' || statusNorm === 'cancelled') {
        return false;
      }

      const rDateRaw = toEnDigits(String(r.woStartDate || r.woStartTime || r.requestTime || r.created || r.date || r.woDate || r.createdDate || ''));
      const dateMatch = rDateRaw.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
      if (!dateMatch) return true;

      const dReq = parseJalaliDays(`${dateMatch[1]}/${dateMatch[2]}/${dateMatch[3]}`);
      if (dReq > 0 && dStart > 0 && dEnd > 0) {
        return dReq >= dStart && dReq <= dEnd;
      }
      return true;
    });
  }, [allWorkEvents, equipmentCode, selectedEquipment.name, startDate, endDate]);

  const getEventDowntimeMinutes = (r: any): number => {
    const explicitDt = Number(r?.equipmentDowntimeMinutes || r?.downtimeMinutes || 0);
    if (explicitDt > 0) return explicitDt;

    if (r?.woStartDate && r?.woEndDate && (r?.woStartTimeOnly || r?.woStartTime) && (r?.woEndTimeOnly || r?.woEndTime)) {
      const s = extractShamsiDateAndTime(`${r.woStartDate} ${r.woStartTimeOnly || r.woStartTime}`, r.woStartDate, '08:00');
      const e = extractShamsiDateAndTime(`${r.woEndDate} ${r.woEndTimeOnly || r.woEndTime}`, r.woEndDate, '09:00');
      const computed = computeMinutesBetweenShamsiDateTimes(s.date, s.time, e.date, e.time);
      if (computed > 0) return computed;
    } else if (r?.woStartTime && r?.woEndTime) {
      const s = extractShamsiDateAndTime(r.woStartTime, '', '');
      const e = extractShamsiDateAndTime(r.woEndTime, s.date, '');
      if (s.date && s.time && e.date && e.time) {
        const computed = computeMinutesBetweenShamsiDateTimes(s.date, s.time, e.date, e.time);
        if (computed > 0) return computed;
      }
    }

    return Math.max(1, Number(r?.durationMinutes || r?.durationMin || (r?.estimatedHours ? Number(r.estimatedHours) * 60 : 0) || 60));
  };

  const unitFactor = useMemo(() => {
    if (timeUnit === 'day') return 24;
    if (timeUnit === 'week') return 24 * 7;
    return 1;
  }, [timeUnit]);

  const unitLabel = useMemo(() => {
    if (timeUnit === 'day') return 'روز';
    if (timeUnit === 'week') return 'هفته';
    return 'ساعت';
  }, [timeUnit]);

  // محاسبه دقیق و بدون داده‌سازی مصنوعی شاخص‌های قابلیت اطمینان
  const reliabilityMetrics = useMemo(() => {
    const failureCount = matchingRequests.length;

    if (failureCount === 0) {
      return {
        failureCount: 0,
        totalDowntimeHours: 0,
        uptimeHours: totalPeriodHours,
        mttrHours: 0,
        mtbfHours: 0,
        mttfHours: 0,
        mttrScaled: 0,
        mtbfScaled: 0,
        mttfScaled: 0,
        totalDowntimeScaled: 0,
        availabilityPercent: 100,
        unitLabel
      };
    }

    const totalDowntimeMinutes = matchingRequests.reduce((sum, r: any) => {
      return sum + getEventDowntimeMinutes(r);
    }, 0);

    const totalDowntimeHours = totalDowntimeMinutes / 60;
    const uptimeHours = Math.max(0, totalPeriodHours - totalDowntimeHours);
    const mttrHours = totalDowntimeHours / failureCount;
    const mttfHours = uptimeHours / failureCount;
    const mtbfHours = totalPeriodHours / failureCount;

    const availabilityPercent = totalPeriodHours > 0
      ? Math.min(100, Math.max(0, (uptimeHours / totalPeriodHours) * 100))
      : 100;

    return {
      failureCount,
      totalDowntimeHours,
      uptimeHours,
      mttrHours,
      mtbfHours,
      mttfHours,
      mttrScaled: Math.round((mttrHours / unitFactor) * 100) / 100,
      mtbfScaled: Math.round((mtbfHours / unitFactor) * 100) / 100,
      mttfScaled: Math.round((mttfHours / unitFactor) * 100) / 100,
      totalDowntimeScaled: Math.round((totalDowntimeHours / unitFactor) * 100) / 100,
      availabilityPercent: Math.round(availabilityPercent * 10) / 10,
      unitLabel
    };
  }, [matchingRequests, totalPeriodHours, unitFactor, unitLabel]);

  // تولید نقاط نمودار روند خطی صرفاً بر اساس داده‌های واقعی (در صورت نبود داده، آرایه خالی برمی‌گردد)
  const trendLinePoints = useMemo(() => {
    if (matchingRequests.length === 0) {
      return [];
    }

    const dStart = parseJalaliDays(startDate);
    const numPoints = Math.min(10, Math.max(4, Math.min(periodDays, 10)));
    const stepDays = Math.max(1, Math.ceil(periodDays / numPoints));

    const eventsWithDay = matchingRequests.map((r: any) => {
      const rDateRaw = toEnDigits(String(r.woStartDate || r.woStartTime || r.requestTime || r.created || r.date || r.woDate || r.createdDate || ''));
      const dateMatch = rDateRaw.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
      const eventDay = dateMatch ? parseJalaliDays(`${dateMatch[1]}/${dateMatch[2]}/${dateMatch[3]}`) : dStart;
      const durMin = getEventDowntimeMinutes(r);
      return { eventDay: eventDay || dStart, durHours: Math.max(1 / 60, durMin / 60) };
    });

    const points: Array<{
      dateLabel: string;
      mtbf: number;
      mttf: number;
      mttr: number;
    }> = [];

    let curOffset = 0;
    for (let i = 0; i < numPoints && curOffset < periodDays; i++) {
      const nextOffset = i === numPoints - 1 ? periodDays : Math.min(periodDays, curOffset + stepDays);
      const d1 = addDaysToShamsi(startDate, curOffset);
      const d2 = addDaysToShamsi(startDate, Math.max(curOffset + 1, nextOffset));
      const windowEndDay = dStart + Math.max(1, nextOffset);

      const cumEvents = eventsWithDay.filter(ev => ev.eventDay <= windowEndDay);
      const cumFailures = cumEvents.length;
      const cumElapsedHours = Math.max(24, nextOffset * 24);
      const cumDowntimeHours = cumEvents.reduce((s, ev) => s + ev.durHours, 0);

      let ptMtbf = 0;
      let ptMttf = 0;
      let ptMttr = 0;

      if (cumFailures > 0) {
        ptMttr = (cumDowntimeHours / cumFailures) / unitFactor;
        const cumUptime = Math.max(0, cumElapsedHours - cumDowntimeHours);
        ptMttf = (cumUptime / cumFailures) / unitFactor;
        ptMtbf = (cumElapsedHours / cumFailures) / unitFactor;
      }

      points.push({
        dateLabel: `${d1} - ${d2}`,
        mtbf: Math.round(ptMtbf * 100) / 100,
        mttf: Math.round(ptMttf * 100) / 100,
        mttr: Math.round(ptMttr * 100) / 100
      });

      curOffset = nextOffset;
    }

    return points;
  }, [matchingRequests, startDate, periodDays, unitFactor]);

  // مقیاس پویا و منطقی محور عمودی متناسب با واحد انتخابی و داده‌های واقعی
  const yAxisConfig = useMemo(() => {
    const rawMax = Math.max(
      0,
      ...trendLinePoints.map(p => Math.max(p.mtbf, p.mttf, p.mttr)),
      reliabilityMetrics.mtbfScaled,
      reliabilityMetrics.mttfScaled
    );

    let maxY = 100;
    if (rawMax <= 0) {
      maxY = timeUnit === 'week' ? 10 : timeUnit === 'day' ? 30 : 800;
    } else if (rawMax <= 5) {
      maxY = 5;
    } else if (rawMax <= 10) {
      maxY = 10;
    } else if (rawMax <= 25) {
      maxY = Math.ceil(rawMax / 5) * 5;
    } else if (rawMax <= 100) {
      maxY = Math.ceil(rawMax / 20) * 20;
    } else {
      maxY = Math.ceil((rawMax * 1.15) / 100) * 100;
    }

    const tickCount = 5;
    const ticks = Array.from({ length: tickCount + 1 }, (_, i) => Math.round(((maxY * i) / tickCount) * 10) / 10);
    return { maxY, ticks };
  }, [trendLinePoints, reliabilityMetrics, timeUnit]);

  const handlePrint = () => {
    const el = document.getElementById('cmms-reliability-print-area');
    if (!el) {
      window.print();
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head>
        <meta charset="utf-8" />
        <title>${printSettings.reliabilityReport.docTitle} - ${selectedEquipment.code} (${printSettings.reliabilityReport.docCode})</title>
        <style>
          @page { size: A4 portrait; margin: 8mm; }
          body { font-family: Tahoma, 'Vazirmatn', system-ui, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 12px; }
          * { box-sizing: border-box; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 10px; font-size: 11px; }
          th, td { border: 1px solid #475569; padding: 6px 9px; text-align: right; }
          th { background: #f1f5f9; font-weight: bold; }
          .text-center { text-align: center; }
          .font-mono { font-family: monospace; }
          .font-bold { font-weight: bold; }
          .no-print { display: none !important; }
          @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 12px; text-align: left;">
          <button id="directPrintBtn" style="background:#2563eb; color:#ffffff; border:none; padding:8px 20px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px;">ارسال مستقیم به چاپگر (Print)</button>
          <button onclick="window.close()" style="background:#64748b; color:#ffffff; border:none; padding:8px 14px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px; margin-right:6px;">بستن</button>
        </div>
        ${el.innerHTML}
        <script>
          const btn = document.getElementById('directPrintBtn');
          if (btn) {
            btn.addEventListener('click', function() { window.print(); });
          }
          window.focus();
          setTimeout(function() {
            window.print();
          }, 350);
        </script>
      </body>
      </html>
    `;

    let winOpened = false;
    try {
      const printWin = window.open('', '_blank', 'width=950,height=800,top=50,left=50');
      if (printWin) {
        winOpened = true;
        printWin.document.open();
        printWin.document.write(htmlContent);
        printWin.document.close();
        printWin.focus();
      }
    } catch {}

    if (!winOpened) {
      try {
        let iframe = document.getElementById('reliability-print-iframe') as HTMLIFrameElement | null;
        if (iframe) iframe.remove();
        iframe = document.createElement('iframe');
        iframe.id = 'reliability-print-iframe';
        iframe.style.position = 'fixed';
        iframe.style.top = '-9999px';
        iframe.style.left = '-9999px';
        document.body.appendChild(iframe);
        const fDoc = iframe.contentWindow?.document;
        if (fDoc) {
          fDoc.open();
          fDoc.write(htmlContent);
          fDoc.close();
          setTimeout(() => {
            iframe?.contentWindow?.focus();
            iframe?.contentWindow?.print();
          }, 400);
        }
      } catch {
        window.print();
      }
    }
  };

  return (
    <div className="space-y-6 select-text text-right font-sans">

      {/* هدر کنترل فیلترها با لایه z-index بالا تا منوی سرچ سریع همیشه روی سایر کارت‌ها باز شود */}
      <div className="relative z-[70] p-4 sm:p-5 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 backdrop-blur-md shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-3 border-b border-indigo-900/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <ShieldCheck size={20} />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                ارزیابی قابلیت اطمینان و شاخص‌های فنی تجهیز
              </h3>
              <p className="text-xs text-slate-400">
                محاسبه MTBF ،MTTR ،MTTF و ضریب دسترسی بر اساس سوابق واقعی توقف و تعمیرات
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-[#0c162e] p-1 rounded-xl border border-indigo-500/30">
              <button
                type="button"
                onClick={() => setTimeUnit('hour')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timeUnit === 'hour'
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                ساعت
              </button>
              <button
                type="button"
                onClick={() => setTimeUnit('day')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timeUnit === 'day'
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                روز
              </button>
              <button
                type="button"
                onClick={() => setTimeUnit('week')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timeUnit === 'week'
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                هفته
              </button>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg transition-all cursor-pointer"
            >
              <Printer size={14} />
              <span>چاپ و پرینت رسمی</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5 pt-1">
          {/* سرچ سریع تجهیز متصل به لیست زنده مدیریت تجهیزات */}
          <div className="md:col-span-5 relative z-[90]" ref={searchContainerRef}>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>جستجو و انتخاب سریع تجهیز (مدیریت تجهیزات):</span>
              <span className="text-[10px] text-cyan-400 font-mono">({toFaDigits(liveEquipments.length)} تجهیز)</span>
            </label>
            <div className="relative">
              <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={equipmentSearchQuery}
                onFocus={() => setIsSearchDropdownOpen(true)}
                onClick={() => setIsSearchDropdownOpen(true)}
                onChange={e => {
                  setEquipmentSearchQuery(e.target.value);
                  setIsSearchDropdownOpen(true);
                }}
                placeholder={`${selectedEquipment.name} (${selectedEquipment.code}) — جستجوی کد، نام یا خانواده...`}
                className="w-full bg-[#0c162e] border border-indigo-500/40 rounded-xl pr-8 pl-8 py-2 text-xs text-white placeholder-slate-400 outline-none focus:border-cyan-400"
              />
              {equipmentSearchQuery && (
                <button
                  type="button"
                  onClick={() => setEquipmentSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 cursor-pointer"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {isSearchDropdownOpen && (
              <div className="absolute top-full right-0 left-0 mt-1.5 max-h-72 overflow-y-auto bg-[#070e22] border border-cyan-500/50 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.9)] z-[150] divide-y divide-indigo-900/40">
                {filteredAvailableEquipments.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400">
                    تجهیزی با این عبارت یافت نشد.
                  </div>
                ) : (
                  filteredAvailableEquipments.map(eq => (
                    <div
                      key={eq.code}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        setEquipmentCode(eq.code);
                        setEquipmentSearchQuery('');
                        setIsSearchDropdownOpen(false);
                      }}
                      className={`p-2.5 hover:bg-indigo-600/25 cursor-pointer transition-colors flex items-center justify-between gap-2 text-xs ${
                        equipmentCode === eq.code ? 'bg-indigo-900/50 font-bold' : ''
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-white truncate font-medium">{eq.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {eq.group ? <>خانواده: <span className="text-cyan-400">{eq.group}</span></> : null}
                          {eq.group && eq.location ? ' | ' : ''}
                          {eq.location ? `مکان: ${eq.location}` : ''}
                        </div>
                      </div>
                      <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-cyan-950/90 text-cyan-300 border border-cyan-500/30 shrink-0">
                        {eq.code}
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              تاریخ شروع بازه:
            </label>
            <div className="relative">
              <Calendar size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={startDate}
                onChange={e => {
                  setStartDate(e.target.value);
                  setActiveDatePreset('custom');
                }}
                placeholder="1405/01/01"
                className="w-full bg-[#0c162e] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-2 text-xs text-white font-mono outline-none focus:border-cyan-400 text-center"
              />
            </div>
          </div>

          <div className="md:col-span-4">
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>تاریخ پایان بازه:</span>
              <span className="text-[10px] text-emerald-400 font-mono">امروز: {todayShamsi}</span>
            </label>
            <div className="relative">
              <Calendar size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={endDate}
                onChange={e => {
                  setEndDate(e.target.value);
                  setActiveDatePreset('custom');
                }}
                placeholder={todayShamsi}
                className="w-full bg-[#0c162e] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-2 text-xs text-white font-mono outline-none focus:border-cyan-400 text-center"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-indigo-900/30 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-slate-400 text-[11px]">بازه سریع:</span>
            <button
              type="button"
              onClick={() => handleApplyPreset('30days')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                activeDatePreset === '30days' ? 'bg-indigo-600 text-white' : 'bg-[#0c162e] text-slate-300 hover:text-white'
              }`}
            >
              ۳۰ روز اخیر
            </button>
            <button
              type="button"
              onClick={() => handleApplyPreset('90days')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                activeDatePreset === '90days' ? 'bg-indigo-600 text-white' : 'bg-[#0c162e] text-slate-300 hover:text-white'
              }`}
            >
              ۳ ماه اخیر (فصلی)
            </button>
            <button
              type="button"
              onClick={() => handleApplyPreset('180days')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                activeDatePreset === '180days' ? 'bg-indigo-600 text-white' : 'bg-[#0c162e] text-slate-300 hover:text-white'
              }`}
            >
              ۶ ماه اخیر
            </button>
            <button
              type="button"
              onClick={() => handleApplyPreset('yearToDate')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                activeDatePreset === 'yearToDate' ? 'bg-indigo-600 text-white' : 'bg-[#0c162e] text-slate-300 hover:text-white'
              }`}
            >
              از ابتدای سال تا امروز
            </button>
          </div>

          <div className="text-slate-400 font-mono text-[11px]">
            تجهیز انتخابی: <strong className="text-white font-sans">{selectedEquipment.name}</strong> ({selectedEquipment.code})
            {selectedEquipment.group ? <> | خانواده: <strong className="text-cyan-300 font-sans">{selectedEquipment.group}</strong></> : null}
            {' '}| طول دوره: <strong className="text-emerald-400">{toFaDigits(periodDays)}</strong> روز
          </div>
        </div>
      </div>

      {/* کارت‌های شاخص‌های کلیدی عددی */}
      <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-blue-500/30 backdrop-blur-md shadow-lg space-y-1.5">
          <div className="flex items-center justify-between text-xs text-blue-400">
            <span className="font-bold">MTBF (میانگین بین خرابی‌ها)</span>
            <Activity size={15} />
          </div>
          <div className="flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl sm:text-3xl font-black text-blue-300">
              {reliabilityMetrics.failureCount > 0 ? toFaDigits(reliabilityMetrics.mtbfScaled) : '—'}
            </span>
            {reliabilityMetrics.failureCount > 0 && (
              <span className="text-xs text-blue-400/80 font-sans">
                {reliabilityMetrics.unitLabel}
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400">
            {reliabilityMetrics.failureCount > 0 ? 'فاصله میانگین بین هر دو توقف' : 'خرابی در این بازه ثبت نشده'}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-emerald-500/30 backdrop-blur-md shadow-lg space-y-1.5">
          <div className="flex items-center justify-between text-xs text-emerald-400">
            <span className="font-bold">MTTF (زمان کارکرد تا خرابی)</span>
            <Clock size={15} />
          </div>
          <div className="flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl sm:text-3xl font-black text-emerald-300">
              {reliabilityMetrics.failureCount > 0 ? toFaDigits(reliabilityMetrics.mttfScaled) : '—'}
            </span>
            {reliabilityMetrics.failureCount > 0 && (
              <span className="text-xs text-emerald-400/80 font-sans">
                {reliabilityMetrics.unitLabel}
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400">
            {reliabilityMetrics.failureCount > 0 ? 'ساعات خالص کارکرد تا خرابی' : 'خرابی در این بازه ثبت نشده'}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-amber-500/30 backdrop-blur-md shadow-lg space-y-1.5">
          <div className="flex items-center justify-between text-xs text-amber-400">
            <span className="font-bold">MTTR (میانگین زمان تعمیر)</span>
            <RefreshCw size={15} />
          </div>
          <div className="flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl sm:text-3xl font-black text-amber-300">
              {toFaDigits(reliabilityMetrics.mttrScaled)}
            </span>
            <span className="text-xs text-amber-400/80 font-sans">
              {reliabilityMetrics.unitLabel}
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            مدت زمان رفع عیب و راه‌اندازی
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-purple-500/30 backdrop-blur-md shadow-lg space-y-1.5">
          <div className="flex items-center justify-between text-xs text-purple-400">
            <span className="font-bold">ضریب دسترسی (Availability)</span>
            <TrendingUp size={15} />
          </div>
          <div className="flex items-baseline gap-1.5 font-mono">
            <span className="text-2xl sm:text-3xl font-black text-purple-300">
              {toFaDigits(reliabilityMetrics.availabilityPercent)}٪
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            آمادگی بهره‌برداری خط تولید
          </div>
        </div>
      </div>

      {/* نمودار خطی قابلیت اطمینان (فقط بر اساس داده‌های واقعی؛ در نبود داده محور خالی نمایش داده می‌شود) */}
      <div className="relative z-10 p-5 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 backdrop-blur-md shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-indigo-900/40">
          <div className="flex items-center gap-2">
            <BarChart2 size={16} className="text-cyan-400" />
            <h4 className="text-sm font-bold text-white">
              نمودار روند خطی قابلیت اطمینان (بر حسب {reliabilityMetrics.unitLabel})
            </h4>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full border-2 border-blue-500 bg-[#070e22] inline-block"></span>
              <span className="text-blue-300 font-bold font-mono">MTBF</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full border-2 border-emerald-500 bg-[#070e22] inline-block"></span>
              <span className="text-emerald-300 font-bold font-mono">MTTF</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full border-2 border-amber-500 bg-[#070e22] inline-block"></span>
              <span className="text-amber-300 font-bold font-mono">MTTR</span>
            </div>
          </div>
        </div>

        <div className="w-full overflow-x-auto pt-2 pb-1">
          <div className="min-w-[700px] h-72 sm:h-80 w-full bg-[#040817]/80 rounded-xl p-3 border border-indigo-950 relative">
            <svg viewBox="0 0 880 265" className="w-full h-full select-none">
              {yAxisConfig.ticks.map(val => {
                const y = 198 - (val / yAxisConfig.maxY) * 168;
                return (
                  <g key={val}>
                    <line
                      x1="54"
                      y1={y}
                      x2="862"
                      y2={y}
                      stroke="#1e293b"
                      strokeWidth="1"
                      strokeDasharray={val === 0 ? 'none' : '2 3'}
                    />
                    <text x="46" y={y + 3} textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                      {val}
                    </text>
                  </g>
                );
              })}

              <line x1="54" y1="198" x2="862" y2="198" stroke="#334155" strokeWidth="1.5" />

              {trendLinePoints.length === 0 ? (
                <g>
                  <rect x="220" y="92" width="440" height="44" rx="10" fill="#0f172a" stroke="#334155" strokeDasharray="4 3" />
                  <text x="440" y="118" textAnchor="middle" fill="#94a3b8" fontSize="12" fontWeight="bold">
                    داده‌ای برای رسم نمودار در این بازه زمانی ثبت نشده است
                  </text>
                </g>
              ) : (
                (() => {
                  const totalPoints = trendLinePoints.length;
                  const getX = (idx: number) => {
                    if (totalPoints === 1) return 450;
                    return 78 + (idx / (totalPoints - 1)) * 765;
                  };
                  const getY = (val: number) => {
                    const clamped = Math.max(0, Math.min(yAxisConfig.maxY, val));
                    return 198 - (clamped / yAxisConfig.maxY) * 168;
                  };

                  const mtbfPath = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mtbf)}`).join(' ');
                  const mttfPath = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mttf)}`).join(' ');
                  const mttrPath = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mttr)}`).join(' ');

                  return (
                    <g>
                      <path d={mtbfPath} fill="none" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                      <path d={mttfPath} fill="none" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                      <path d={mttrPath} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

                      {trendLinePoints.map((p, idx) => {
                        const cx = getX(idx);
                        return (
                          <g key={idx}>
                            <line x1={cx} y1="198" x2={cx} y2="203" stroke="#64748b" strokeWidth="1" />
                            <text
                              x={cx}
                              y="212"
                              transform={`rotate(-90, ${cx}, 212)`}
                              textAnchor="end"
                              fill="#94a3b8"
                              fontSize="8.5"
                              fontFamily="monospace"
                            >
                              {p.dateLabel}
                            </text>
                            <circle cx={cx} cy={getY(p.mtbf)} r="4" fill="#070e22" stroke="#3b82f6" strokeWidth="2" />
                            <circle cx={cx} cy={getY(p.mttf)} r="4" fill="#070e22" stroke="#22c55e" strokeWidth="2" />
                            <circle cx={cx} cy={getY(p.mttr)} r="4" fill="#070e22" stroke="#f59e0b" strokeWidth="2" />
                          </g>
                        );
                      })}
                    </g>
                  );
                })()
              )}
            </svg>
          </div>
        </div>
      </div>

      {/* سوابق توقف و خرابی‌های ثبت‌شده */}
      <div className="relative z-10 p-4 sm:p-5 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 backdrop-blur-md shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
            <FileText size={15} className="text-cyan-400" />
            <span>سوابق توقف و خرابی‌های ثبت‌شده در این بازه ({toFaDigits(matchingRequests.length)} مورد)</span>
          </h4>
          <span className="text-xs text-slate-400 font-mono">
            کل زمان توقف: {toFaDigits(reliabilityMetrics.totalDowntimeScaled)} {reliabilityMetrics.unitLabel}
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-indigo-500/20">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                <th className="p-3">شماره / کد</th>
                <th className="p-3">تاریخ وقوع</th>
                <th className="p-3">شرح اشکال و اقدام</th>
                <th className="p-3 text-center">زمان توقف (دقیقه)</th>
                <th className="p-3 text-center">تکنسین مسئول</th>
                <th className="p-3 text-center">وضعیت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#333538]/50">
              {matchingRequests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    هیچ توقف یا خرابی ثبت‌شده‌ای برای این تجهیز در بازه انتخابی یافت نشد.
                  </td>
                </tr>
              ) : (
                matchingRequests.map((req: any, idx: number) => (
                  <tr key={req.code || req.id || idx} className="hover:bg-[#112042]/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-cyan-300">{req.code || req.id || `WR-${idx + 1}`}</td>
                    <td className="p-3 font-mono text-slate-300">{req.woStartTime || req.created || req.requestTime || req.date || req.woDate || '—'}</td>
                    <td className="p-3 font-medium text-white max-w-xs truncate">{req.failureTitle || req.title || req.description || '—'}</td>
                    <td className="p-3 text-center font-mono text-amber-300">{getEventDowntimeMinutes(req)}</td>
                    <td className="p-3 text-center text-slate-300">{req.technician || req.assignedTo || '—'}</td>
                    <td className="p-3 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                        {req.status || 'ثبت‌شده'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* بخش نامرئی اختصاصی پرینت با لوگوی رسمی و نمودار واقعی */}
      <div id="cmms-reliability-print-area" className="hidden">
        <div style={{ padding: '8px', background: '#ffffff', color: '#0f172a', direction: 'rtl', fontFamily: 'Tahoma, sans-serif' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #0f172a', paddingBottom: '10px', marginBottom: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <img
                src={COMPANY_LOGO_WHITEBG}
                alt="لوگو سامانه"
                style={{ height: '52px', width: 'auto', objectFit: 'contain' }}
              />
              <div>
                <h2 style={{ margin: '0 0 3px 0', fontSize: '15px', fontWeight: 'bold', color: '#0f172a' }}>
                  {printSettings.reliabilityReport.docTitle}
                </h2>
                <div style={{ fontSize: '11px', color: '#475569' }}>
                  شاخص‌های نگهداری و تعمیرات (MTTR - MTBF - MTTF)
                </div>
              </div>
            </div>
            <div style={{ textAlign: 'left', fontFamily: 'monospace', fontSize: '11px', color: '#334155', lineHeight: '1.5' }}>
              <div>کد سند: <strong>{printSettings.reliabilityReport.docCode}</strong></div>
              <div>تاریخ گزارش: <span>{new Date().toLocaleDateString('fa-IR')}</span></div>
              <div>واحد: <span>نگهداری و تعمیرات</span></div>
            </div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '14px', fontSize: '11px' }}>
            <tbody>
              <tr style={{ background: '#f8fafc' }}>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold', width: '18%' }}>کد تجهیز:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontFamily: 'monospace', fontWeight: 'bold' }}>{selectedEquipment.code}</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold', width: '18%' }}>نام تجهیز:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px' }}>{selectedEquipment.name}</td>
              </tr>
              <tr>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold' }}>تاریخ شروع بازه:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontFamily: 'monospace' }}>{startDate}</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold' }}>تاریخ پایان بازه:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontFamily: 'monospace' }}>{endDate}</td>
              </tr>
              <tr style={{ background: '#f8fafc' }}>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold' }}>طول دوره بررسی:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px' }}>{periodDays} روز ({totalPeriodHours} ساعت)</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold' }}>تعداد حوادث خرابی:</td>
                <td style={{ border: '1px solid #cbd5e1', padding: '5px 8px', fontWeight: 'bold', color: '#b91c1c' }}>{reliabilityMetrics.failureCount} مورد</td>
              </tr>
            </tbody>
          </table>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', marginBottom: '14px' }}>
            <div style={{ border: '1.5px solid #2563eb', borderRadius: '8px', padding: '8px', textAlign: 'center', background: '#eff6ff' }}>
              <div style={{ fontSize: '10px', color: '#1d4ed8', fontWeight: 'bold', marginBottom: '2px' }}>MTBF (میانگین بین خرابی‌ها)</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#1e40af', fontFamily: 'monospace' }}>
                {reliabilityMetrics.failureCount > 0 ? `${toFaDigits(reliabilityMetrics.mtbfScaled)} ${reliabilityMetrics.unitLabel}` : '—'}
              </div>
            </div>

            <div style={{ border: '1.5px solid #059669', borderRadius: '8px', padding: '8px', textAlign: 'center', background: '#ecfdf5' }}>
              <div style={{ fontSize: '10px', color: '#047857', fontWeight: 'bold', marginBottom: '2px' }}>MTTF (زمان کارکرد تا خرابی)</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#065f46', fontFamily: 'monospace' }}>
                {reliabilityMetrics.failureCount > 0 ? `${toFaDigits(reliabilityMetrics.mttfScaled)} ${reliabilityMetrics.unitLabel}` : '—'}
              </div>
            </div>

            <div style={{ border: '1.5px solid #d97706', borderRadius: '8px', padding: '8px', textAlign: 'center', background: '#fffbeb' }}>
              <div style={{ fontSize: '10px', color: '#b45309', fontWeight: 'bold', marginBottom: '2px' }}>MTTR (میانگین زمان تعمیر)</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#92400e', fontFamily: 'monospace' }}>
                {toFaDigits(reliabilityMetrics.mttrScaled)} {reliabilityMetrics.unitLabel}
              </div>
            </div>

            <div style={{ border: '1.5px solid #7c3aed', borderRadius: '8px', padding: '8px', textAlign: 'center', background: '#faf5ff' }}>
              <div style={{ fontSize: '10px', color: '#6d28d9', fontWeight: 'bold', marginBottom: '2px' }}>ضریب دسترسی (Availability)</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#5b21b6', fontFamily: 'monospace' }}>
                {toFaDigits(reliabilityMetrics.availabilityPercent)}٪
              </div>
            </div>
          </div>

          <div style={{ border: '1px solid #cbd5e1', borderRadius: '8px', padding: '10px', marginBottom: '14px', background: '#f8fafc' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#0f172a' }}>
                نمودار روند خطی شاخص‌های قابلیت اطمینان (بر حسب {reliabilityMetrics.unitLabel}):
              </div>
              <div style={{ display: 'flex', gap: '10px', fontSize: '10px', fontWeight: 'bold' }}>
                <span style={{ color: '#2563eb' }}>● MTBF</span>
                <span style={{ color: '#059669' }}>● MTTF</span>
                <span style={{ color: '#d97706' }}>● MTTR</span>
              </div>
            </div>

            <div style={{ width: '100%', height: '185px' }}>
              <svg viewBox="0 0 820 190" style={{ width: '100%', height: '100%' }}>
                {yAxisConfig.ticks.map(v => {
                  const y = 142 - (v / yAxisConfig.maxY) * 120;
                  return (
                    <g key={v}>
                      <line x1="45" y1={y} x2="800" y2={y} stroke="#cbd5e1" strokeWidth="0.8" strokeDasharray={v === 0 ? 'none' : '2 2'} />
                      <text x="38" y={y + 3} textAnchor="end" fill="#64748b" fontSize="8" fontFamily="monospace">
                        {v}
                      </text>
                    </g>
                  );
                })}
                <line x1="45" y1="142" x2="800" y2="142" stroke="#475569" strokeWidth="1" />

                {trendLinePoints.length === 0 ? (
                  <g>
                    <rect x="210" y="65" width="400" height="32" rx="6" fill="#ffffff" stroke="#cbd5e1" strokeDasharray="3 2" />
                    <text x="410" y="85" textAnchor="middle" fill="#64748b" fontSize="10" fontWeight="bold">
                      داده‌ای برای رسم نمودار در این بازه زمانی ثبت نشده است
                    </text>
                  </g>
                ) : (
                  (() => {
                    const totalPoints = trendLinePoints.length;
                    const getX = (idx: number) => totalPoints === 1 ? 420 : 65 + (idx / (totalPoints - 1)) * 715;
                    const getY = (val: number) => 142 - (Math.min(yAxisConfig.maxY, val) / yAxisConfig.maxY) * 120;

                    const pMtbf = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mtbf)}`).join(' ');
                    const pMttf = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mttf)}`).join(' ');
                    const pMttr = trendLinePoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx)} ${getY(p.mttr)}`).join(' ');

                    return (
                      <g>
                        <path d={pMtbf} fill="none" stroke="#2563eb" strokeWidth="2" />
                        <path d={pMttf} fill="none" stroke="#059669" strokeWidth="2" />
                        <path d={pMttr} fill="none" stroke="#d97706" strokeWidth="2" />

                        {trendLinePoints.map((p, idx) => {
                          const cx = getX(idx);
                          return (
                            <g key={idx}>
                              <text
                                x={cx}
                                y="150"
                                transform={`rotate(-90, ${cx}, 150)`}
                                textAnchor="end"
                                fill="#475569"
                                fontSize="6.5"
                                fontFamily="monospace"
                              >
                                {p.dateLabel}
                              </text>
                              <circle cx={cx} cy={getY(p.mtbf)} r="3" fill="#ffffff" stroke="#2563eb" strokeWidth="1.5" />
                              <circle cx={cx} cy={getY(p.mttf)} r="3" fill="#ffffff" stroke="#059669" strokeWidth="1.5" />
                              <circle cx={cx} cy={getY(p.mttr)} r="3" fill="#ffffff" stroke="#d97706" strokeWidth="1.5" />
                            </g>
                          );
                        })}
                      </g>
                    );
                  })()
                )}
              </svg>
            </div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px' }}>
            <thead>
              <tr style={{ background: '#f1f5f9' }}>
                <th style={{ border: '1px solid #94a3b8', padding: '5px' }}>ردیف</th>
                <th style={{ border: '1px solid #94a3b8', padding: '5px' }}>کد دستور کار</th>
                <th style={{ border: '1px solid #94a3b8', padding: '5px' }}>تاریخ</th>
                <th style={{ border: '1px solid #94a3b8', padding: '5px' }}>شرح خرابی</th>
                <th style={{ border: '1px solid #94a3b8', padding: '5px', textAlign: 'center' }}>زمان توقف (دقیقه)</th>
                <th style={{ border: '1px solid #94a3b8', padding: '5px', textAlign: 'center' }}>تکنسین</th>
              </tr>
            </thead>
            <tbody>
              {matchingRequests.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ border: '1px solid #cbd5e1', padding: '7px', textAlign: 'center', color: '#64748b' }}>
                    فاقد خرابی ثبت‌شده در بازه مشخص‌شده
                  </td>
                </tr>
              ) : (
                matchingRequests.map((r: any, i: number) => (
                  <tr key={r.code || r.id || i}>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px', textAlign: 'center' }}>{i + 1}</td>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px', fontFamily: 'monospace' }}>{r.code || r.id || `WR-${i + 1}`}</td>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px', fontFamily: 'monospace' }}>{r.woStartTime || r.created || r.requestTime || r.date || r.woDate || '—'}</td>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px' }}>{r.failureTitle || r.title || r.description || '—'}</td>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px', textAlign: 'center', fontFamily: 'monospace' }}>{getEventDowntimeMinutes(r)}</td>
                    <td style={{ border: '1px solid #cbd5e1', padding: '4px 6px', textAlign: 'center' }}>{r.technician || r.assignedTo || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
