import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ChevronUp, 
  ChevronDown, 
  Check, 
  AlertTriangle, 
  Edit3, 
  X, 
  User, 
  MapPin, 
  Camera, 
  CheckCircle,
  Layers,
  Wrench
} from 'lucide-react';
import { EquipmentItem } from '../data/portalData';
import { ProductionOperator } from '../data/operatorsData';

interface EquipmentVerticalCarousel3DProps {
  equipments: EquipmentItem[];
  productionOperators: ProductionOperator[];
  categoryName: string;
  onQuickConfirmConforming: (eq: EquipmentItem) => void;
  onInlineSubmitNonConforming: (eq: EquipmentItem) => void;
  onUpdateEquipmentOperator: (eqId: string, newOperator: string) => void;
  onSaveEquipmentCode: (eqId: string, newCode: string) => void;
  onRemoveFromCategory: (eqId: string) => void;
  editingEquipmentCodeId: string | null;
  editingEquipmentCodeValue: string;
  setEditingEquipmentCodeId: (id: string | null) => void;
  setEditingEquipmentCodeValue: (val: string) => void;
  inlineExpandedDefectsEqId: string | null;
  setInlineExpandedDefectsEqId: (id: string | null) => void;
  inlineInspectionDefectsMap: Record<string, string[]>;
  setInlineInspectionDefectsMap: React.Dispatch<React.SetStateAction<Record<string, string[]>>>;
  inlineInspectionNotesMap: Record<string, string>;
  setInlineInspectionNotesMap: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  inlineInspectionPhotosMap: Record<string, string | null>;
  setInlineInspectionPhotosMap: React.Dispatch<React.SetStateAction<Record<string, string | null>>>;
  inlineInspectionAutoWoMap: Record<string, boolean>;
  setInlineInspectionAutoWoMap: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  onPhotoChange: (eqId: string, e: React.ChangeEvent<HTMLInputElement>) => void;
  onPhotoLightbox: (photo: string) => void;
  toFaDigits: (str: string | number) => string;
}

export function EquipmentVerticalCarousel3D({
  equipments,
  productionOperators,
  categoryName,
  onQuickConfirmConforming,
  onInlineSubmitNonConforming,
  onUpdateEquipmentOperator,
  onSaveEquipmentCode,
  onRemoveFromCategory,
  editingEquipmentCodeId,
  editingEquipmentCodeValue,
  setEditingEquipmentCodeId,
  setEditingEquipmentCodeValue,
  inlineExpandedDefectsEqId,
  setInlineExpandedDefectsEqId,
  inlineInspectionDefectsMap,
  setInlineInspectionDefectsMap,
  inlineInspectionNotesMap,
  setInlineInspectionNotesMap,
  inlineInspectionPhotosMap,
  setInlineInspectionPhotosMap,
  inlineInspectionAutoWoMap,
  setInlineInspectionAutoWoMap,
  onPhotoChange,
  onPhotoLightbox,
  toFaDigits
}: EquipmentVerticalCarousel3DProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isLiveAutoRoll, setIsLiveAutoRoll] = useState(true);
  const rollDirectionRef = useRef<'down' | 'up'>('down');
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const startYRef = useRef(0);
  const accumulatedDiffRef = useRef(0);
  const lastWheelTimeRef = useRef(0);

  const len = equipments.length;

  // اطمینان از قرار داشتن شاخص در محدوده مجاز هنگام فیلتر شدن
  useEffect(() => {
    if (activeIndex >= len && len > 0) {
      setActiveIndex(len - 1);
    }
  }, [len, activeIndex]);

  const handleNext = useCallback(() => {
    if (len === 0) return;
    setActiveIndex(prev => (prev < len - 1 ? prev + 1 : 0));
  }, [len]);

  const handlePrev = useCallback(() => {
    if (len === 0) return;
    setActiveIndex(prev => (prev > 0 ? prev - 1 : len - 1));
  }, [len]);

  // چرخش زنده خودکار رولی تجهیزات از بالا به پایین و برعکس (Bi-directional Live Auto-Roll)
  useEffect(() => {
    if (!isLiveAutoRoll || len <= 1) return;

    const interval = setInterval(() => {
      setActiveIndex(prev => {
        if (rollDirectionRef.current === 'down') {
          if (prev < len - 1) {
            return prev + 1;
          } else {
            rollDirectionRef.current = 'up';
            return Math.max(0, prev - 1);
          }
        } else {
          if (prev > 0) {
            return prev - 1;
          } else {
            rollDirectionRef.current = 'down';
            return Math.min(len - 1, prev + 1);
          }
        }
      });
    }, 3200);

    return () => clearInterval(interval);
  }, [isLiveAutoRoll, len]);

  // ۱. رول با غلتک ماوس (Desktop Wheel)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const now = Date.now();
      if (now - lastWheelTimeRef.current < 150) return;

      if (Math.abs(e.deltaY) > 8) {
        lastWheelTimeRef.current = now;
        if (e.deltaY > 0) {
          handleNext();
        } else {
          handlePrev();
        }
      }
    };

    container.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', onWheel);
    };
  }, [handleNext, handlePrev]);

  // ۲. کنترل لمسی حرفه‌ای مخصوص کار با انگشت در گوشی‌های موبایل (Touch Gestures)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      isDraggingRef.current = true;
      startYRef.current = e.touches[0].clientY;
      accumulatedDiffRef.current = 0;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || e.touches.length !== 1) return;
      const currentY = e.touches[0].clientY;
      const diff = currentY - startYRef.current;
      accumulatedDiffRef.current += diff;
      startYRef.current = currentY;

      // جلوگیری از اسکرول صفحه در هنگام کشیدن انگشت روی رول
      if (Math.abs(accumulatedDiffRef.current) > 8) {
        e.preventDefault();
      }

      // چرخش رول با هر ۳۰ پیکسل حرکت انگشت
      const threshold = 32;
      if (accumulatedDiffRef.current > threshold) {
        handlePrev();
        accumulatedDiffRef.current = 0;
      } else if (accumulatedDiffRef.current < -threshold) {
        handleNext();
        accumulatedDiffRef.current = 0;
      }
    };

    const onTouchEnd = () => {
      isDraggingRef.current = false;
      accumulatedDiffRef.current = 0;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: false });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd);
    container.addEventListener('touchcancel', onTouchEnd);

    return () => {
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [handleNext, handlePrev]);

  // ۳. درگ ماوس روی دسکتاپ
  const handleMouseDown = (e: React.MouseEvent) => {
    // اگر روی فیلد input، select یا دکمه کلیک شده درگ آغاز نشود
    const target = e.target as HTMLElement;
    if (target.closest('input') || target.closest('select') || target.closest('button')) {
      return;
    }
    isDraggingRef.current = true;
    startYRef.current = e.clientY;
    accumulatedDiffRef.current = 0;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const diff = e.clientY - startYRef.current;
    accumulatedDiffRef.current += diff;
    startYRef.current = e.clientY;

    const threshold = 35;
    if (accumulatedDiffRef.current > threshold) {
      handlePrev();
      accumulatedDiffRef.current = 0;
    } else if (accumulatedDiffRef.current < -threshold) {
      handleNext();
      accumulatedDiffRef.current = 0;
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
    accumulatedDiffRef.current = 0;
  };

  // ۴. کنترل با کلیدهای کیبورد
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      handleNext();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      handlePrev();
    }
  };

  if (len === 0) return null;

  const visibleSlots = [-2, -1, 0, 1, 2];

  return (
    <section
      ref={containerRef}
      id="carousel-container"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="max-w-4xl mx-auto w-full flex-1 flex flex-col justify-center perspective relative h-[500px] select-none no-select outline-none rounded-3xl bg-slate-950/80 backdrop-blur-md border border-slate-800 shadow-2xl overflow-hidden py-4 cursor-grab active:cursor-grabbing touch-none"
    >
      {/* هاله نور پس‌زمینه زمردی متمرکز */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-96 h-40 bg-emerald-500/20 rounded-full blur-3xl" />
      </div>

      {/* پیام راهنما مطابق کد کاربر */}
      <div className="absolute top-4 inset-x-0 text-center text-xs text-slate-500 z-10 pointer-events-none">
        چرخش استوانه‌ای با غلتک ماوس، کشیدن لمسی یا کلیدهای کیبورد (⬆️/⬇️)
      </div>

      {/* نوار کنترل بالای رول */}
      <div className="absolute top-3 left-4 z-40 flex items-center gap-2 bg-slate-900/90 px-3 py-1 rounded-full border border-slate-800 text-xs font-mono text-slate-300 shadow-md">
        <span>دستگاه {toFaDigits(activeIndex + 1)}</span>
        <span className="text-slate-600">/</span>
        <span className="text-slate-400">{toFaDigits(len)}</span>

        {/* دکمه وضعیت چرخش زنده خودکار */}
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setIsLiveAutoRoll(prev => !prev); }}
          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-sans font-bold transition-all cursor-pointer ${
            isLiveAutoRoll 
              ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/50 shadow-sm animate-pulse' 
              : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
          }`}
          title="پخش خودکار زنده تجهیزات از بالا به پایین و برعکس"
        >
          <span className={`w-1.5 h-1.5 rounded-full ${isLiveAutoRoll ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
          <span>{isLiveAutoRoll ? 'رول زنده ↕' : 'متوقف'}</span>
        </button>

        <div className="flex items-center gap-1 mr-1 pr-1 border-r border-slate-700">
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            className="p-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="دستگاه قبلی (بالا)"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            className="p-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="دستگاه بعدی (پایین)"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ماسک گرادیانت عمق استوانه‌ای */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-slate-950 via-slate-950/80 to-transparent z-20" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent z-20" />

      {/* صحنه رول ۵ کارتی استوانه‌ای با انیمیشن حرکت عقب و جلو */}
      <div id="cards-wrapper" className="w-full relative h-[400px] flex justify-center items-center mt-8 preserve-3d px-3 sm:px-6">
        {equipments.map((eq, itemIdx) => {
          // محاسبه فاصله دایره‌ای از کارت فعال
          let diff = itemIdx - activeIndex;
          while (diff > len / 2) diff -= len;
          while (diff < -len / 2) diff += len;

          const isCenter = diff === 0;
          const isVisible = Math.abs(diff) <= 2;
          const isExpanded = inlineExpandedDefectsEqId === eq.id;
          const currentDefects = inlineInspectionDefectsMap[eq.id] || [];
          const currentNotes = inlineInspectionNotesMap[eq.id] || '';
          const currentPhoto = inlineInspectionPhotosMap[eq.id] || null;
          const currentAutoWo = inlineInspectionAutoWoMap[eq.id] ?? true;

          // پارامترهای استوانه رول
          let translateY = 0;
          let scale = 1;
          let opacity = 1;
          let zIndex = 30;
          let rotateX = 0;
          let translateZ = 0;

          if (diff === 0) {
            translateY = 0;
            scale = 1;
            opacity = 1;
            zIndex = 30;
            rotateX = 0;
            translateZ = 0;
          } else if (diff === -1) {
            translateY = -92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = 10;
            translateZ = -45;
          } else if (diff === 1) {
            translateY = 92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = -10;
            translateZ = -45;
          } else if (diff === -2) {
            translateY = -170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = 18;
            translateZ = -95;
          } else if (diff === 2) {
            translateY = 170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = -18;
            translateZ = -95;
          } else {
            // کارت‌های دورتر به نرمی به پشت استوانه می‌روند
            translateY = diff < 0 ? -240 : 240;
            scale = 0.60;
            opacity = 0;
            zIndex = 5;
            rotateX = diff < 0 ? 25 : -25;
            translateZ = -140;
          }

          return (
            <div
              key={eq.id}
              onClick={() => {
                if (!isCenter) {
                  setActiveIndex(itemIdx);
                }
              }}
              style={{
                transform: `translateY(${translateY}px) translateZ(${translateZ}px) rotateX(${rotateX}deg) scale(${scale})`,
                opacity,
                zIndex,
                pointerEvents: isVisible ? 'auto' : 'none',
                transition: 'transform 600ms cubic-bezier(0.22, 1, 0.36, 1), opacity 600ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 600ms ease, border-color 600ms ease, background-color 600ms ease'
              }}
              className={`carousel-card absolute w-full max-w-2xl preserve-3d rounded-2xl p-4 border text-right will-change-transform ${
                isCenter
                  ? 'bg-slate-900/95 backdrop-blur-md border-2 border-emerald-500 shadow-[0_0_35px_rgba(16,185,129,0.30)] ring-2 ring-emerald-500/50 z-30'
                  : 'bg-slate-900/80 backdrop-blur-sm border border-slate-800 text-slate-400 shadow-none hover:border-slate-700 cursor-pointer'
              }`}
            >
              {/* ردیف اول: کد دستگاه + نام دستگاه + دکمه خروج از دسته */}
              <div className={`flex items-center justify-between gap-2 pb-2 border-b ${isCenter ? 'border-emerald-900/40' : 'border-slate-800/80'}`}>
                <div className="flex items-center gap-2 min-w-0">
                  {editingEquipmentCodeId === eq.id ? (
                    <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-cyan-400">
                      <input
                        type="text"
                        value={editingEquipmentCodeValue}
                        onChange={e => setEditingEquipmentCodeValue(e.target.value)}
                        autoFocus
                        onKeyDown={e => {
                          if (e.key === 'Enter') onSaveEquipmentCode(eq.id, editingEquipmentCodeValue);
                          if (e.key === 'Escape') setEditingEquipmentCodeId(null);
                        }}
                        className="w-24 bg-slate-950 border border-cyan-500 rounded-lg px-2 py-0.5 text-xs text-cyan-200 font-mono font-bold uppercase"
                      />
                      <button
                        type="button"
                        onClick={() => onSaveEquipmentCode(eq.id, editingEquipmentCodeValue)}
                        className="p-1 rounded bg-emerald-600 text-white cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingEquipmentCodeId(null)}
                        className="p-1 rounded bg-slate-800 text-slate-300 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    isCenter ? (
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono text-xs sm:text-sm font-black text-emerald-300 bg-emerald-950/90 px-3 py-1 rounded-xl border border-emerald-500/50 shadow-inner">
                          کد: {eq.code}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingEquipmentCodeId(eq.id);
                            setEditingEquipmentCodeValue(eq.code);
                          }}
                          className="p-1 rounded-lg bg-emerald-950/80 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 cursor-pointer"
                          title="ویرایش کد تجهیز"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono text-xs font-semibold text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-xl border border-slate-700/60 shadow-none">
                          کد: {eq.code}
                        </span>
                      </div>
                    )
                  )}

                  <span className={`text-xs sm:text-sm truncate max-w-[140px] sm:max-w-[220px] ${
                    isCenter ? 'font-bold text-white' : 'font-medium text-slate-400'
                  }`}>
                    {eq.name}
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                    isCenter
                      ? (eq.status === 'سالم'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                          : 'bg-rose-950 text-rose-300 border-rose-500/40')
                      : 'bg-slate-800/80 text-slate-400 border-slate-700/50'
                  }`}>
                    {eq.status === 'سالم' ? 'سالم ✓' : 'نیازمند رسیدگی ⚠️'}
                  </span>

                  {isCenter && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveFromCategory(eq.id);
                      }}
                      className="p-1 px-2 rounded-xl bg-slate-900/80 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-800 text-[10px] flex items-center gap-1 cursor-pointer transition-colors"
                      title="خروج این تجهیز از دسته"
                    >
                      <X className="w-3 h-3" />
                      <span className="hidden sm:inline">خروج از دسته</span>
                    </button>
                  )}
                </div>
              </div>

              {/* ردیف دوم: انتخابگر اپراتور + مکان سالن */}
              <div className="py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5 flex-1 min-w-[200px]">
                  <User className={`w-3.5 h-3.5 shrink-0 ${isCenter ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span className={`text-[11px] shrink-0 font-bold ${isCenter ? 'text-emerald-200' : 'text-slate-400'}`}>اپراتور:</span>
                  {isCenter ? (
                    <select
                      value={eq.inspector || ''}
                      onChange={e => onUpdateEquipmentOperator(eq.id, e.target.value)}
                      className="bg-[#0b1612] border border-emerald-800/60 rounded-xl px-2.5 py-1 text-xs text-white font-bold focus:outline-none focus:border-emerald-400 cursor-pointer flex-1"
                    >
                      <option value="" className="bg-slate-900 text-slate-400">--- انتخاب اپراتور ---</option>
                      {productionOperators.map(op => (
                        <option key={op.id} value={op.name} className="bg-slate-900 text-white">
                          {op.name} {op.personnelCode ? `(${toFaDigits(op.personnelCode)})` : ''}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-xs text-slate-400 font-medium truncate">
                      {eq.inspector || 'تعیین‌نشده'}
                    </span>
                  )}
                </div>

                <div className={`flex items-center gap-1 text-[11px] shrink-0 ${isCenter ? 'text-emerald-300/80' : 'text-slate-500'}`}>
                  <MapPin className={`w-3 h-3 ${isCenter ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span>{eq.hall}</span>
                </div>
              </div>

              {/* ردیف سوم: دکمه‌های چک‌لیست درجا (فقط در کارت فعال مرکز با دکمه اقدام فیروزه‌ای) */}
              {isCenter && (
                <div className="pt-2 border-t border-emerald-900/40 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickConfirmConforming(eq);
                      }}
                      className="py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white text-xs font-black shadow-lg shadow-cyan-950/60 transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-cyan-400/50"
                    >
                      <Check className="w-4 h-4 text-cyan-200" />
                      <span>✓ تأیید سلامت</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInlineExpandedDefectsEqId(isExpanded ? null : eq.id);
                      }}
                      className={`py-2 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                        isExpanded
                          ? 'bg-rose-700 text-white border-rose-400'
                          : 'bg-rose-950/70 hover:bg-rose-900/80 text-rose-300 border-rose-500/50'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4 text-rose-300" />
                      <span>{isExpanded ? 'بستن فرم' : '⚠️ عدم انطباق'}</span>
                    </button>
                  </div>

                  {/* فرم کشویی عدم انطباق */}
                  {isExpanded && (
                    <div className="p-3 rounded-2xl bg-slate-950 border border-rose-500/50 space-y-2.5 animate-in fade-in">
                      <div className="text-[11px] text-rose-300 font-bold flex items-center gap-1">
                        <span>موارد عدم انطباق را مشخص فرمایید:</span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                        {['نشتی روغن', 'فشار غیرعادی', 'لرزش / صدا', 'خرابی تجهیز', 'عدم نظافت', 'سایر ایرادات'].map((defect) => {
                          const isChecked = currentDefects.includes(defect);
                          return (
                            <label key={defect} className="flex items-center gap-1.5 cursor-pointer text-slate-200">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setInlineInspectionDefectsMap(prev => ({
                                    ...prev,
                                    [eq.id]: checked
                                      ? [...(prev[eq.id] || []), defect]
                                      : (prev[eq.id] || []).filter(d => d !== defect)
                                  }));
                                }}
                                className="w-3.5 h-3.5 accent-rose-500"
                              />
                              <span>{defect}</span>
                            </label>
                          );
                        })}
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-1">
                        <label className="text-[11px] text-cyan-300 flex items-center gap-1 cursor-pointer">
                          <Camera className="w-3.5 h-3.5" />
                          <span>عکس‌برداری با گوشی</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={e => onPhotoChange(eq.id, e)}
                            className="hidden"
                          />
                        </label>

                        <button
                          type="button"
                          onClick={() => onInlineSubmitNonConforming(eq)}
                          className="py-1 px-3 rounded-lg bg-gradient-to-r from-red-600 to-rose-700 text-white font-bold text-xs"
                        >
                          ✓ ثبت عدم انطباق
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
