import defaultAssetFamilies from '../data/assetFamilies.json';
import defaultPlantEquipment from '../data/plantEquipment.json';
import defaultFactoryLocations from '../data/factoryLocations.json';
import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import TimeInput24 from './TimeInput24';
import { 
  Home, 
  Settings, 
  Wrench, 
  BarChart2, 
  Bell, 
  Search, 
  Menu, 
  X, 
  Check, 
  AlertTriangle, 
  Clock, 
  CheckCircle2,
  Calendar as CalendarIcon,
  MoreVertical,
  MoreHorizontal,
  XCircle,
  FileText,
  Zap,
  ChevronLeft,
  ChevronRight,
  User,
  Tag,
  Wind,
  Activity,
  Eye,
  Printer,
  CheckSquare,
  Square,
  Plus,
  Trash2,
  Pencil,
  Layers,
  Download,
  AlarmClock,
  Users,
  ChevronDown,
  ChevronUp,
  Filter,
  Package,
  TrendingUp,
  TrendingDown,
  PieChart,
  ShieldCheck,
  ArrowRight,
  Upload,
  RefreshCw,
  HardDrive,
  MapPin,
  Building2,
  FolderTree,
  PlusCircle,
  CornerDownLeft,
  Cpu,
  Disc,
  RotateCw,
  Play,
  Sparkles,
  FlaskConical,
  FileSpreadsheet,
  Calendar,
  ClipboardList
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  UnifiedSparePart,
  SparePartCategory,
  SparePartSource,
  SparePartFilterSource,
  getUnifiedSpareParts,
  saveUnifiedSpareParts,
  addOrUpdateSparePart,
  adjustSparePartStock,
  deleteSparePart,
  subscribeToSpareParts
} from '../data/sparePartsData';
import { UnifiedSparePartsManager } from './UnifiedSparePartsManager';
import { AssetClassDetailView } from './AssetClassDetailView';
import { usePrintSettings } from '../data/printSettings';
import {
  syncDuePmWorkOrders,
  AutoPmWoLookupEntry,
  resolveLatestDuePmOccurrence,
  getTodayShamsiDateStringPm,
  diffShamsiDaysPm,
  loadAutoPmWorkOrders,
  saveAutoPmWorkOrders,
  isItemArchivedCheck,
  buildAutoPmLookupMaps,
  getGroupFamilyMaintenanceActivities,
  PmGroupFamilyActivityOption,
  reconcilePmTechniciansList,
  syncAndReconcilePmTechStorage
} from '../data/pmAutoWorkOrders';
import { PmWorkOrderThreeTabModal } from './PmWorkOrderThreeTabModal';

export interface PMStudioProps {
  onBackToPortal: () => void;
  onGoToTechnical?: () => void;
  technicians?: string[];
  technicianPhotos?: Record<string, string>;
  systemTheme?: 'dark' | 'light';
  workRequests?: any[];
  onAddWorkRequest?: (wr: any) => void;
  onDeleteTechnician?: (name: string) => void;
}

export interface PMWorkSessionItem {
  id: string;
  startDate: string;
  endDate: string;
  startTime: string;
  endTime: string;
}

export function calculateSessionHours(startTime: string, endTime: string): number {
  try {
    const [sH, sM] = (startTime || '08:00').split(':').map(Number);
    const [eH, eM] = (endTime || '11:00').split(':').map(Number);
    if (!isNaN(sH) && !isNaN(eH)) {
      const diffMin = (eH * 60 + (eM || 0)) - (sH * 60 + (sM || 0));
      if (diffMin > 0) {
        return Math.round((diffMin / 60) * 10) / 10;
      }
    }
  } catch {}
  return 3;
}

export interface PMWorkOrderPartItem {
  id: string;
  name: string;
  quantity: number;
}

export interface PMWorkOrderSheetData {
  id: string;
  groupId: string;
  groupName: string;
  title: string;
  activityTitle: string;
  activities: string[];
  checkedActivities: string[];
  selectedEquipments: string[];
  allGroupEquipments: { id: string; name: string }[];
  technician: string;
  coTechnicians: string[];
  woDate: string;
  woEndDate?: string;
  workDaysCount?: number;
  dailyHours?: number;
  woStartTime?: string;
  woEndTime?: string;
  workSessions?: PMWorkSessionItem[];
  mechanicalParts?: PMWorkOrderPartItem[];
  electricalParts?: PMWorkOrderPartItem[];
  sparePartsUsed?: string;
  showExtraDetails?: boolean;
  notes?: string;
  status: 'در حال اقدام' | 'انجام شد';
}

export const toFaDigits = (n: number | string): string => {
  if (n === null || n === undefined) return '';
  return String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)]);
};

// دریافت تاریخ جاری شمسی به فرمت YYYY/MM/DD
export function getTodayShamsiString(): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    const parts = formatter.formatToParts(new Date());
    const y = parts.find(p => p.type === 'year')?.value || '1405';
    const m = parts.find(p => p.type === 'month')?.value || '08';
    const d = parts.find(p => p.type === 'day')?.value || '15';
    return `${y}/${m}/${d}`;
  } catch {
    return '1405/08/15';
  }
}

// تبدیل تاریخ خورشیدی به میلادی با دقت بالا جهت استخراج روز هفته
export function jalaliToGregorian(jy: number, jm: number, jd: number): Date {
  let gy = (jy <= 979) ? 621 : 1600;
  const jYear = jy - ((jy <= 979) ? 0 : 979);
  let days = (365 * jYear) + (Math.floor(jYear / 33) * 8) + Math.floor(((jYear % 33) + 3) / 4) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  gy += Math.floor((days - 1) / 365);
  if (days > 365) days = (days - 1) % 365;
  const gd = days + 1;
  const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 0; gm < 13; gm++) {
    const v = sal_a[gm];
    if (gd <= v) break;
  }
  return new Date(gy, gm - 1, gd);
}

// تشخیص سال کبیسه خورشیدی
export function isJalaliLeapYear(jy: number): boolean {
  return (((jy - 474) % 2820 + 474) * 682) % 2816 < 682;
}

// تعداد روزهای ماه خورشیدی
export function getDaysInJalaliMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaliLeapYear(jy) ? 30 : 29;
}

// محاسبه ایندکس اولین روز ماه در هفته فارسی (۰ = شنبه، ۱ = یکشنبه، ...، ۶ = جمعه)
export function getPersianFirstDayOfMonth(jy: number, jm: number): number {
  try {
    const gDate = jalaliToGregorian(jy, jm, 1);
    // روز هفته میلادی: 0=یکشنبه, 1=دوشنبه, ..., 6=شنبه
    // در هفته فارسی: شنبه=0, یکشنبه=1, ..., جمعه=6
    return (gDate.getDay() + 1) % 7;
  } catch {
    return 0;
  }
}

export const PERSIAN_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

// محاسبه تعداد ماه‌های بین دو تاریخ خورشیدی
export function calcMonthsBetweenShamsi(startDate: string, endDate: string): number {
  try {
    const sParts = (startDate || '1405/08/20').split('/').map(p => parseInt(p.trim(), 10));
    const eParts = (endDate || '1406/08/20').split('/').map(p => parseInt(p.trim(), 10));
    if (sParts.length !== 3 || eParts.length !== 3 || isNaN(sParts[0]) || isNaN(eParts[0])) return 12;
    const startMonths = sParts[0] * 12 + (sParts[1] - 1);
    const endMonths = eParts[0] * 12 + (eParts[1] - 1);
    const diff = endMonths - startMonths;
    return diff > 0 ? diff : 1;
  } catch {
    return 12;
  }
}

// توابع محاسباتی تقویم خورشیدی جهت زمان‌بندی تجمعی PM
export function addShamsiMonths(shamsiDate: string, monthsToAdd: number): string {
  try {
    const parts = (shamsiDate || '1405/08/20').split('/').map(p => parseInt(p.trim(), 10));
    if (parts.length !== 3 || isNaN(parts[0]) || isNaN(parts[1]) || isNaN(parts[2])) {
      return shamsiDate;
    }
    let [year, month, day] = parts;
    const totalMonths = (year * 12 + (month - 1)) + monthsToAdd;
    const newYear = Math.floor(totalMonths / 12);
    const newMonth = (totalMonths % 12) + 1;
    let maxDays = 30;
    if (newMonth <= 6) maxDays = 31;
    else if (newMonth <= 11) maxDays = 30;
    else maxDays = 29;
    const newDay = Math.min(day, maxDays);
    return `${newYear}/${String(newMonth).padStart(2, '0')}/${String(newDay).padStart(2, '0')}`;
  } catch {
    return shamsiDate;
  }
}

export function addShamsiDays(shamsiDate: string, daysToAdd: number): string {
  try {
    const parts = (shamsiDate || '1405/08/20').split('/').map(p => parseInt(p.trim(), 10));
    if (parts.length !== 3 || isNaN(parts[0]) || isNaN(parts[1]) || isNaN(parts[2])) {
      return shamsiDate;
    }
    let [year, month, day] = parts;
    let remaining = daysToAdd;
    while (remaining > 0) {
      const daysInMonth = month <= 6 ? 31 : month <= 11 ? 30 : 29;
      if (day + remaining <= daysInMonth) {
        day += remaining;
        remaining = 0;
      } else {
        remaining -= (daysInMonth - day + 1);
        day = 1;
        month += 1;
        if (month > 12) {
          month = 1;
          year += 1;
        }
      }
    }
    return `${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
  } catch {
    return shamsiDate;
  }
}

// پیکربندی ۹ گروه اصلی تجهیزات کارخانه
export interface PMGroupConfig {
  id: string;
  name: string;
  enName: string;
  prefixes: string[];
  keywords: string[];
  iconType: 'cpu' | 'wrench' | 'rotate' | 'layers' | 'disc' | 'zap' | 'flask' | 'activity' | 'wind';
  color: string;
  badgeBg: string;
  description: string;
}

export const PM_9_GROUPS: PMGroupConfig[] = [
  { id: 'tornos', name: 'تورنوس', enName: 'Tornos', prefixes: ['TUTN'], keywords: ['تورنوس', 'tornos'], iconType: 'cpu', color: 'from-amber-500 to-orange-600', badgeBg: 'bg-amber-500/15 text-amber-300 border-amber-500/30', description: 'تراش‌های سویسی تورنوس سری Deco و EvoDECO' },
  { id: 'milling', name: 'فرز', enName: 'Milling', prefixes: ['MICN', 'FR'], keywords: ['فرز', 'milling', 'feeler', 'hartford'], iconType: 'wrench', color: 'from-blue-500 to-indigo-600', badgeBg: 'bg-blue-500/15 text-blue-300 border-blue-500/30', description: 'فرزهای CNC ۳ الی ۵ محور و سنترهای عمودی' },
  { id: 'lathe', name: 'تراش', enName: 'Lathe', prefixes: ['TUTL', 'TULT', 'TUCT'], keywords: ['تراش', 'lathe', 'تبریز'], iconType: 'rotate', color: 'from-cyan-500 to-teal-600', badgeBg: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30', description: 'تراش‌های منوآل و CNC تراشکاری دقیق قطعات' },
  { id: 'syntec', name: 'سینتک', enName: 'Syntec', prefixes: ['SY'], keywords: ['سینتک', 'syntec'], iconType: 'layers', color: 'from-emerald-500 to-green-600', badgeBg: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', description: 'ماشین‌آلات دقیق مجهز به کنترلرهای پیشرفته سینتک' },
  { id: 'mayer', name: 'مایر', enName: 'Mayer', prefixes: ['TUMA'], keywords: ['مایر', 'mayer'], iconType: 'disc', color: 'from-purple-500 to-violet-600', badgeBg: 'bg-purple-500/15 text-purple-300 border-purple-500/30', description: 'تراش‌ها و خطوط تولید تخصصی برند مایر' },
  { id: 'wirecut', name: 'وایرکات', enName: 'Wirecut', prefixes: ['WICN'], keywords: ['وایرکات', 'wirecut', 'dk77'], iconType: 'zap', color: 'from-rose-500 to-pink-600', badgeBg: 'bg-rose-500/15 text-rose-300 border-rose-500/30', description: 'وایرکات‌های تخلیه الکتریکی اسپارک و برش سیمی دقیق' },
  { id: 'lab', name: 'آزمایشگاه', enName: 'Laboratory', prefixes: ['LAB', 'QC'], keywords: ['آزمایشگاه', 'تست', 'کوانتومتر', 'سختی', 'زبری', 'میکروسکوپ', 'lab'], iconType: 'flask', color: 'from-sky-500 to-indigo-600', badgeBg: 'bg-sky-500/15 text-sky-300 border-sky-500/30', description: 'تجهیزات تست، کالیبراسیون و آزمایشگاه کنترل کیفیت' },
  { id: 'press', name: 'پرس', enName: 'Press', prefixes: ['PR', 'PRHY'], keywords: ['پرس', 'press', 'هیدرولیک'], iconType: 'activity', color: 'from-orange-500 to-red-600', badgeBg: 'bg-orange-500/15 text-orange-300 border-orange-500/30', description: 'پرس‌های هیدرولیکی، لنگ ضربه‌ای و فرم‌دهی قطعات' },
  { id: 'facilities', name: 'تاسیسات', enName: 'Facilities', prefixes: ['FAC', 'UT', 'CMP', 'CHL'], keywords: ['تاسیسات', 'کمپرسور', 'چیلر', 'دیزل', 'بویلر', 'ژنراتور', 'موتورخانه', 'هواساز', 'پمپ'], iconType: 'wind', color: 'from-teal-500 to-emerald-600', badgeBg: 'bg-teal-500/15 text-teal-300 border-teal-500/30', description: 'کمپرسورهای هوا، چیلرها، بوستر پمپ و دیزل ژنراتور' },
];

export interface PMGroupActivityItem {
  id: string;
  code?: string;
  groupId: string;
  title: string;
  frequencyType: 'custom' | 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual';
  frequencyLabel: string;
  customDays?: number;
  estimatedHours: number;
  partsRequired?: string;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
  executionWindowDays?: number;
  isScheduled?: boolean;
}

// بانک فعالیت‌های اولیه استاندارد به تفکیک دوره‌های تناوب برای ۹ گروه
export const DEFAULT_PM_ACTIVITIES_BY_GROUP: Record<string, PMGroupActivityItem[]> = {
  tornos: [
    { id: 'act-tor-1', groupId: 'tornos', title: 'بررسی فشار روغن هیدرولیک و خنک‌کننده راهنما بوش', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-tor-2', groupId: 'tornos', title: 'بازبینی تمیزی مسیر تخلیه براده و پینچر', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-tor-3', groupId: 'tornos', title: 'آچارکشی کلت‌ها، تعویض فیلتر روغن هیدرولیک و بررسی لقی بال‌اسکرو Z', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-tor-bimonthly', groupId: 'tornos', title: 'بازرسی سیستم روانکاری مرکزی، شستشوی توری مکش روغن و رگلاژ تسمه اسپیندل فرعی', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-tor-4', groupId: 'tornos', title: 'تست دقت ابعادی تکرارپذیری و روانکاری بلبرینگ‌های اسپیندل سویسی', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-tor-5', groupId: 'tornos', title: 'تعویض کامل روغن هیدرولیک ISO VG32 و سرویس کامل سیستم بوش راهنما', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-tor-6', groupId: 'tornos', title: 'اورهال کامل سیستم هیدرواستاتیک و کالیبراسیون لیزری تمام محورها', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  milling: [
    { id: 'act-mil-1', groupId: 'milling', title: 'بررسی فشار هوای تعویض ابزار (ATC) و سطح روغن گیج خودکار', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-mil-2', groupId: 'milling', title: 'نظافت تانک آب‌صابون، روانکاری ریل‌های خطی X/Y/Z و تست اینترلاک', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-mil-bimonthly', groupId: 'milling', title: 'کنترل بالانس دینامیکی محورها، بررسی فشار هوای کلمپ و تمیزکاری مسیر تعویض ابزار', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-mil-3', groupId: 'milling', title: 'تست و تنظیم لقی (Backlash) محورها و بررسی تسمه اسپیندل و خنک‌کن روغن', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-mil-4', groupId: 'milling', title: 'تراز مجدد میز کار و بررسی پمپ پرفشار Coolant Through Spindle (CTS)', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-mil-5', groupId: 'milling', title: 'تست بالبار (Ballbar Test) خطای دایروی و لرزش‌سنجی یاتاقان اسپیندل', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  lathe: [
    { id: 'act-lat-1', groupId: 'lathe', title: 'بررسی گیج فشار روغن هدباکس و روانکاری گایدهای دستی و اتوماتیک', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-lat-2', groupId: 'lathe', title: 'بررسی لقی سه‌نظام، تنظیم کلاچ هیدرولیک و چک کردن تسمه‌های محرک', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-lat-bimonthly', groupId: 'lathe', title: 'بازرسی سفتی پیچ‌های فونداسیون، تست لقی بوش‌های هدباکس و روانکاری ماردون تراشکاری', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-lat-3', groupId: 'lathe', title: 'بررسی هم‌راستایی مرغک و تارت و تعویض فیلترهای مدار مایع خنک‌کار', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-lat-4', groupId: 'lathe', title: 'تعویض روغن واسکازین گیربکس و هدباکس و تست گشتاور موتور تارت', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-lat-5', groupId: 'lathe', title: 'بازرسی کامل بلبرینگ‌های اسپیندل و کالیبراسیون تعامد محور X نسبت به Z', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  syntec: [
    { id: 'act-syn-1', groupId: 'syntec', title: 'بررسی ولتاژ درایوها و تمیزی فن‌های خنک‌کننده کنترلر سینتک', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-syn-2', groupId: 'syntec', title: 'پشتیبان‌گیری از پارامترهای کنترلر سینتک و روانکاری سروو موتورها', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-syn-bimonthly', groupId: 'syntec', title: 'تست ارتینگ بدنه تابلو کنترلر، بازرسی فن‌های خنک‌کننده سروودرایوها و نظافت محفظه', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-syn-3', groupId: 'syntec', title: 'تست میکروسوئیچ‌های لیمیت و سنسورهای هوم و نویز فیلتر پالس‌های انکودر', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-syn-4', groupId: 'syntec', title: 'آچارکشی ترمینال‌های تابلو برق کنترلر و تست رله‌های خروجی PLC', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-syn-5', groupId: 'syntec', title: 'کالیبراسیون دقت حرکتی و تعویض باتری‌های پشتیبان حافظه PLC سینتک', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  mayer: [
    { id: 'act-may-1', groupId: 'mayer', title: 'کنترل سطح روغن روانکاری بارفیدر و تمیزی تارت ماشین مایر', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-may-2', groupId: 'mayer', title: 'بررسی سیستم بارفیدر اتوماتیک و رگلاژ گریپر قطعه‌گیر', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-may-bimonthly', groupId: 'mayer', title: 'بررسی لقی پینچر، تعویض نازل‌های خنک‌کننده پرفشار و آچارکشی ریل‌های راهنما', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-may-3', groupId: 'mayer', title: 'تست دقت چرخش مکانیزم تارت و لقی مهره بال‌اسکرو', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-may-4', groupId: 'mayer', title: 'فیلتراسیون عمیق روغن برش و سرویس سنسورهای موقعیت‌سنج مایر', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-may-5', groupId: 'mayer', title: 'کالیبراسیون محورهای دورانی و تعویض بلبرینگ‌های دینامیکی اسپیندل', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  wirecut: [
    { id: 'act-wir-1', groupId: 'wirecut', title: 'بررسی کشش سیم مولیبدن/برنجی و سختی آب دیونیزه مخزن', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-wir-2', groupId: 'wirecut', title: 'تعویض رزین دیونیزاسیون، نظافت نازل‌های پاشش و غلطک‌های راهنمای سیم', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-wir-bimonthly', groupId: 'wirecut', title: 'سرویس فیدرهای برق مولیبدن، بررسی شفت‌های کشش سیم و کالیبراسیون سنسور آب', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-wir-3', groupId: 'wirecut', title: 'تست مقاومت اهمی فیدر برق رسانا و کالیبراسیون ژنراتور پالس اسپارک', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-wir-4', groupId: 'wirecut', title: 'تعویض فیلترهای میکرونی آب و تست دقت برش زوایای تپر (Taper)', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-wir-5', groupId: 'wirecut', title: 'سرویس اساسی موتور درام سیم و کالیبراسیون اپتیک محورهای U و V', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  lab: [
    { id: 'act-lab-1', groupId: 'lab', title: 'کالیبراسیون صفر گیج‌ها و نظافت استیج‌های اپتیکال با ایزوپروپیل الکل', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-lab-2', groupId: 'lab', title: 'تست نمونه مرجع (Reference Sample) و بررسی دمای استاندارد اتاق تست', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-lab-bimonthly', groupId: 'lab', title: 'آزمون تکرارپذیری میکرومترها و استیج‌های نوری، تست عملکرد سیستم تهویه تمیز', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-lab-3', groupId: 'lab', title: 'کالیبراسیون دوره‌ای سختی‌سنج و زبری‌سنج و تست خلوص گاز آرگون کوانتومتر', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-lab-4', groupId: 'lab', title: 'صحه‌گذاری لودسل‌های تست کشش و فشار و به‌روزرسانی بانک خطاهای آنالیز', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-lab-5', groupId: 'lab', title: 'اخذ گواهی کالیبراسیون رسمی ISO 17025 و تعویض لامپ‌های اسپکترومتری', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  press: [
    { id: 'act-prs-1', groupId: 'press', title: 'بازرسی فشار مدار هیدرولیک و عدم نشتی شیرهای پروپوشنال', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-prs-2', groupId: 'press', title: 'تست پرده نوری ایمنی (Light Curtain) و بررسی ترمز کلاچ پنوماتیک', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-prs-bimonthly', groupId: 'press', title: 'بررسی شیرهای تخلیه سریع، فیلتراسیون ذرات روغن هیدرولیک و کالیبراسیون فشارشکن', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-prs-3', groupId: 'press', title: 'اندازه‌گیری توازی میز پرس با رم (Parallelism) و فیلتراسیون روغن هیدرولیک', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-prs-4', groupId: 'press', title: 'تعویض فیلترهای کارتریجی، تست تناژ بحرانی و بررسی سفتی ستون‌های راهنما', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-prs-5', groupId: 'press', title: 'آزمون ذرات مغناطیسی (MT) ترک‌یابی بدنه پرس و اورهال پمپ هیدرولیک اصلی', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ],
  facilities: [
    { id: 'act-fac-1', groupId: 'facilities', title: 'بررسی دمای خروجی کمپرسور و تخلیه اتوماتیک آب تله درایر تبریدی', frequencyType: 'custom', customDays: 3, frequencyLabel: '۳ روزه سفارشی', estimatedHours: 0.5, isActive: true },
    { id: 'act-fac-2', groupId: 'facilities', title: 'تعویض پیش‌فیلترهای هواساز و تست باتری و روشن‌شدن دیزل ژنراتور اضطراری', frequencyType: 'monthly', frequencyLabel: 'ماهانه (۳۰ روز)', estimatedHours: 2, isActive: true },
    { id: 'act-fac-bimonthly', groupId: 'facilities', title: 'بازبینی شیرهای اطمینان کمپرسور، تست سنسورهای فشار خط لوله و گریس‌کاری بوستر پمپ‌ها', frequencyType: 'bimonthly', frequencyLabel: 'دوماهه (۶۰ روز)', estimatedHours: 2.5, isActive: true },
    { id: 'act-fac-3', groupId: 'facilities', title: 'بررسی اسیدیته آب چیلر و گریس‌کاری یاتاقان فن‌های سانتریفیوژ', frequencyType: 'quarterly', frequencyLabel: '۳ ماهه (۹۰ روز)', estimatedHours: 3, isActive: true },
    { id: 'act-fac-4', groupId: 'facilities', title: 'تعویض روغن اسکرو کمپرسور و سپراتور روغن و رسوب‌زدایی کندانسور چیلر', frequencyType: 'biannual', frequencyLabel: '۶ ماهه (۱۸۰ روز)', estimatedHours: 4, isActive: true },
    { id: 'act-fac-5', groupId: 'facilities', title: 'اورهال مشعل بویلر و تست رله‌های حفاظتی تابلوی فشار متوسط برق', frequencyType: 'annual', frequencyLabel: 'سالانه (۳۶۵ روز)', estimatedHours: 6, isActive: true }
  ]
};

export const FALLBACK_GROUP_EQUIPMENTS: Record<string, any[]> = {
  tornos: [],
  milling: [],
  lathe: [],
  syntec: [],
  mayer: [],
  wirecut: [],
  lab: [],
  press: [],
  facilities: [],
};

// فهرست اولیه تکنسین‌های خدمات فنی کارخانه جهت یکپارچه‌سازی کامل با PM
const DEFAULT_SERVICES_TECHS: any[] = [];

export default function PMStudio({ onBackToPortal, onGoToTechnical, technicians, technicianPhotos, systemTheme, workRequests, onAddWorkRequest, onDeleteTechnician }: PMStudioProps) {
  const printSettings = usePrintSettings();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'workOrders' | 'schedule' | 'equipment' | 'locations' | 'inventory' | 'reports' | 'settings'>('dashboard');
  const [equipmentSearch, setEquipmentSearch] = useState('');
  const [workOrderTab, setWorkOrderTab] = useState<'open' | 'archived'>('open');
  const [pmWoSearch, setPmWoSearch] = useState('');

  // لیست سیاه تکنسین‌های حذف‌شده جهت جلوگیری قطعی از بازگشت
  const [deletedTechNames, setDeletedTechNames] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem('pm_studio_deleted_techs_v2');
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  // --- Technicians (همگام با تکنسین‌های خدمات فنی) ---
  const [expandedTech, setExpandedTech] = useState<number | null>(1);
  const [techniciansList, setTechniciansList] = useState<any[]>(() => {
    let rawDeleted: string[] = [];
    try {
      const s = localStorage.getItem('pm_studio_deleted_techs_v2');
      if (s) rawDeleted = JSON.parse(s);
    } catch {}

    try {
      const isSynced = localStorage.getItem('pm_studio_techs_v6_synced');
      if (!isSynced) {
        localStorage.setItem('pm_studio_techs_v6_synced', 'true');
        const filteredDefaults = reconcilePmTechniciansList(
          DEFAULT_SERVICES_TECHS.filter(t => !rawDeleted.includes(t.name))
        );
        localStorage.setItem('pm_studio_techs_v5', JSON.stringify(filteredDefaults));
        return filteredDefaults;
      }
      const saved = localStorage.getItem('pm_studio_techs_v5');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const cleaned = reconcilePmTechniciansList(
            parsed.filter((t: any) => !rawDeleted.includes(t.name))
          );
          localStorage.setItem('pm_studio_techs_v5', JSON.stringify(cleaned));
          return cleaned;
        }
      }
    } catch {}
    return reconcilePmTechniciansList(DEFAULT_SERVICES_TECHS.filter(t => !rawDeleted.includes(t.name)));
  });

  // ادغام و به‌روزرسانی زنده تکنسین‌ها از خدمات فنی با احترام کامل به حذف‌شده‌ها و تفکیک قطعی ساعات PM
  useEffect(() => {
    if (technicians && Array.isArray(technicians) && technicians.length > 0) {
      setTechniciansList(prev => {
        const existingNames = new Set(prev.map(t => t.name));
        const updated = [...prev];
        let maxId = prev.reduce((max, t) => Math.max(max, t.id || 0), 0);

        technicians.forEach(name => {
          // هرگز تکنسین‌های حذف‌شده توسط کاربر مجدداً افزوده نمی‌شوند
          if (deletedTechNames.includes(name)) return;
          if (!existingNames.has(name)) {
            maxId++;
            updated.push({
              id: maxId,
              name,
              role: '',
              image: technicianPhotos?.[name] || null,
              status: 'available',
              completedTasks: 0,
              workHours: 0,
              lastAction: 'آماده ثبت فعالیت'
            });
            existingNames.add(name);
          }
        });

        if (technicianPhotos) {
          updated.forEach(t => {
            if (technicianPhotos[t.name] && !t.image) {
              t.image = technicianPhotos[t.name];
            }
          });
        }

        const reconciled = reconcilePmTechniciansList(updated);
        try {
          localStorage.setItem('pm_studio_techs_v5', JSON.stringify(reconciled));
        } catch {}
        return reconciled;
      });
    }
  }, [technicians, technicianPhotos, deletedTechNames]);

  // بازمحاسبه خودکار آمار تکنسین‌های PM هنگام تغییر دستورکارهای PM یا درخواست کارها
  useEffect(() => {
    const refreshPmTechHours = () => {
      setTechniciansList(prev => {
        const reconciled = reconcilePmTechniciansList(prev);
        try {
          localStorage.setItem('pm_studio_techs_v5', JSON.stringify(reconciled));
        } catch {}
        return reconciled;
      });
    };
    window.addEventListener('pm_tech_hours_reconcile', refreshPmTechHours);
    window.addEventListener('pm_auto_work_orders_updated', refreshPmTechHours);
    return () => {
      window.removeEventListener('pm_tech_hours_reconcile', refreshPmTechHours);
      window.removeEventListener('pm_auto_work_orders_updated', refreshPmTechHours);
    };
  }, []);

  const [selectedTechForProfile, setSelectedTechForProfile] = useState<any | null>(null);
  const [techToDelete, setTechToDelete] = useState<any | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isTechModalOpen, setIsTechModalOpen] = useState(false);
  const [newTechData, setNewTechData] = useState({ name: '', role: '', image: null as string | null });

  // تابع حذف قطعی تکنسین
  const handleDeleteTechnician = (id: number, name: string) => {
    // ۱. ثبت دائم در لیست سیاه
    setDeletedTechNames(prev => {
      const next = Array.from(new Set([...prev, name]));
      try {
        localStorage.setItem('pm_studio_deleted_techs_v2', JSON.stringify(next));
      } catch {}
      return next;
    });

    // ۲. حذف از لیست تکنسین‌های PM
    setTechniciansList(prev => {
      const next = prev.filter(t => t.id !== id && t.name !== name);
      try {
        localStorage.setItem('pm_studio_techs_v5', JSON.stringify(next));
      } catch {}
      return next;
    });

    // ۳. همگام‌سازی و حذف در والد پرتال
    if (onDeleteTechnician) {
      onDeleteTechnician(name);
    }

    if (expandedTech === id) {
      setExpandedTech(null);
    }
    setTechToDelete(null);
    setSelectedTechForProfile(null);
    setShowDeleteConfirm(false);
    setBatchSuccessToast(`✓ تکنسین «${name}» برای همیشه از سیستم حذف گردید.`);
    setTimeout(() => setBatchSuccessToast(null), 3500);
  };

  // --- Equipment & Families ---
  const [equipmentPage, setEquipmentPage] = useState(1);
  const [equipmentList, setEquipmentList] = useState<any[]>(() => {
    try {
      const isLoaded = localStorage.getItem('pm_studio_eq_v13_loaded');
      if (!isLoaded) {
        localStorage.setItem('pm_studio_eq_v13_loaded', 'true');
        localStorage.setItem('pm_studio_equipments_v13', JSON.stringify(defaultPlantEquipment));
        return defaultPlantEquipment;
      }
      const saved = localStorage.getItem('pm_studio_equipments_v13');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultPlantEquipment;
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_equipments_v13', JSON.stringify(equipmentList));
      window.dispatchEvent(new CustomEvent('factory_equipments_updated', { detail: equipmentList }));
    } catch {}
  }, [equipmentList]);
  const [isEqModalOpen, setIsEqModalOpen] = useState(false);
  const [isEditingEq, setIsEditingEq] = useState(false);
  const [eqFormData, setEqFormData] = useState({ id: '', name: '', family: '', location: '', priority: 'سطح C' });

  const [equipmentTab, setEquipmentTab] = useState<'list' | 'families'>('list');
  const [familyPage, setFamilyPage] = useState(1);
  const [familyList, setFamilyList] = useState<any[]>(() => {
    try {
      const isLoaded = localStorage.getItem('pm_studio_families_v9_loaded');
      if (!isLoaded) {
        localStorage.setItem('pm_studio_families_v9_loaded', 'true');
        localStorage.setItem('pm_studio_families_v9', JSON.stringify(defaultAssetFamilies));
        return defaultAssetFamilies;
      }
      const saved = localStorage.getItem('pm_studio_families_v9');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultAssetFamilies;
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_families_v9', JSON.stringify(familyList));
    } catch {}
  }, [familyList]);
  const [isFamModalOpen, setIsFamModalOpen] = useState(false);
  const [isEditingFam, setIsEditingFam] = useState(false);
  const [famFormData, setFamFormData] = useState({ id: '', name: '', group: '' });
  const [selectedFamilyForDetail, setSelectedFamilyForDetail] = useState<any | null>(null);

  // --- Locations & Sub-systems (S01 to S08) ---
  const [locationsList, setLocationsList] = useState<any[]>(() => {
    try {
      const isLoaded = localStorage.getItem('pm_studio_locations_v2_loaded');
      if (!isLoaded) {
        localStorage.setItem('pm_studio_locations_v2_loaded', 'true');
        localStorage.setItem('pm_studio_locations_v2', JSON.stringify(defaultFactoryLocations));
        return defaultFactoryLocations;
      }
      const saved = localStorage.getItem('pm_studio_locations_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultFactoryLocations;
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_locations_v2', JSON.stringify(locationsList));
    } catch {}
  }, [locationsList]);

  // Locations are collapsed by default; click to expand and view subsystems
  const [expandedLocations, setExpandedLocations] = useState<Record<string, boolean>>({});
  const [locationSearch, setLocationSearch] = useState('');
  const [newSubLocInputs, setNewSubLocInputs] = useState<Record<string, string>>({});
  const [isLocModalOpen, setIsLocModalOpen] = useState(false);
  const [isEditingLoc, setIsEditingLoc] = useState(false);
  const [locFormData, setLocFormData] = useState({ id: '', code: '', name: '', description: '' });
  const [selectedLocationFilter, setSelectedLocationFilter] = useState('all');
  const [locDeleteConfirm, setLocDeleteConfirm] = useState<{ id: string; name: string } | null>(null);

  const toggleLocationExpand = (locId: string) => {
    setExpandedLocations(prev => ({ ...prev, [locId]: !prev[locId] }));
  };

  const handleAddSubLocation = (locId: string) => {
    const textVal = (newSubLocInputs[locId] || '').trim();
    if (!textVal) return;
    setLocationsList(prev => prev.map(loc => {
      if (loc.id === locId) {
        const subList = loc.subLocations || [];
        // prevent duplicate
        if (subList.some((s: any) => s.name === textVal)) return loc;
        return {
          ...loc,
          subLocations: [
            ...subList,
            { id: `${locId}-${Date.now().toString().slice(-4)}`, name: textVal }
          ]
        };
      }
      return loc;
    }));
    setNewSubLocInputs(prev => ({ ...prev, [locId]: '' }));
  };

  const handleDeleteSubLocation = (locId: string, subId: string) => {
    setLocationsList(prev => prev.map(loc => {
      if (loc.id === locId) {
        return {
          ...loc,
          subLocations: (loc.subLocations || []).filter((s: any) => s.id !== subId)
        };
      }
      return loc;
    }));
  };

  const handleSaveLocation = () => {
    if (!locFormData.name.trim() || !locFormData.code.trim()) return;
    const cleanCode = locFormData.code.trim().toUpperCase();
    if (isEditingLoc) {
      setLocationsList(prev => prev.map(l => l.id === locFormData.id ? { ...l, code: cleanCode, name: locFormData.name.trim(), description: locFormData.description.trim() } : l));
    } else {
      const newLoc = {
        id: cleanCode,
        code: cleanCode,
        name: locFormData.name.trim(),
        description: locFormData.description.trim(),
        subLocations: []
      };
      setLocationsList(prev => [...prev, newLoc]);
      setExpandedLocations(prev => ({ ...prev, [cleanCode]: true }));
    }
    setIsLocModalOpen(false);
  };

  const handleDeleteLocation = (locId: string) => {
    setLocationsList(prev => prev.filter(l => l.id !== locId));
    setLocDeleteConfirm(null);
  };

  // --- Work Orders (صفر شده کامل: دستورکارهای باز و بایگانی ۰ و کاملاً خام طبق درخواست) ---
  const [workOrders, setWorkOrders] = useState<any[]>(() => {
    try {
      const isClean = localStorage.getItem('pm_studio_clean_orders_v15');
      if (!isClean) {
        localStorage.setItem('pm_studio_clean_orders_v15', 'true');
        localStorage.removeItem('pm_studio_work_orders_v2');
        localStorage.removeItem('pm_studio_work_orders_v5');
        localStorage.setItem('pm_studio_work_orders_v15', '[]');
        return [];
      }
      const saved = localStorage.getItem('pm_studio_work_orders_v15');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_work_orders_v15', JSON.stringify(workOrders));
    } catch {}
  }, [workOrders]);

  // --- Planning & Schedules (کاملاً خام و پاکسازی شده طبق درخواست کاربر) ---
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [planModalTab, setPlanModalTab] = useState<'single' | 'batch'>('batch');
  const [pmPlans, setPmPlans] = useState<any[]>(() => {
    try {
      const isClean = localStorage.getItem('pm_studio_clean_plans_v15');
      if (!isClean) {
        localStorage.setItem('pm_studio_clean_plans_v15', 'true');
        localStorage.removeItem('pm_studio_plans_v2');
        localStorage.removeItem('pm_studio_plans_v7');
        localStorage.setItem('pm_studio_plans_v15', '[]');
        return [];
      }
      const saved = localStorage.getItem('pm_studio_plans_v15');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_plans_v15', JSON.stringify(pmPlans));
    } catch {}
  }, [pmPlans]);

  // --- سیستم پیشرفته برنامه‌ریزی ۹ گروه تجهیزات و زمان‌بندی تجمعی ---
  const [pmScheduleTab, setPmScheduleTab] = useState<'groups' | 'calendar' | 'orders'>('groups');
  const [selectedPmGroupId, setSelectedPmGroupId] = useState<string>('tornos');
  const [groupEqSearch, setGroupEqSearch] = useState<string>('');
  
  // تقویم پیشرفته، دقیق و پویای شمسی تا ۵ سال آینده (۱۴۰۳ الی ۱۴۱۰)
  const currentShamsiToday = (() => {
    try {
      const parts = new Intl.DateTimeFormat('en-US-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(new Date());
      const y = parseInt(parts.find(p => p.type === 'year')?.value || '1405', 10);
      const m = parseInt(parts.find(p => p.type === 'month')?.value || '8', 10);
      const d = parseInt(parts.find(p => p.type === 'day')?.value || '15', 10);
      return { year: y, month: m, day: d };
    } catch {
      return { year: 1405, month: 8, day: 15 };
    }
  })();

  const [calendarYear, setCalendarYear] = useState<number>(currentShamsiToday.year);
  const [calendarMonth, setCalendarMonth] = useState<number>(currentShamsiToday.month);

  interface ScheduledCalendarEvent {
    groupId: string;
    groupName: string;
    periodKey: string;
    periodLabel: string;
    act: PMGroupActivityItem;
    acts: PMGroupActivityItem[];
  }

  const [hoveredCalendarDay, setHoveredCalendarDay] = useState<{
    day: number;
    events: ScheduledCalendarEvent[];
    top: number;
    left: number;
    placement: 'bottom' | 'top';
  } | null>(null);
  const calPopoverTimerRef = useRef<number | null>(null);
  const calPopoverRef = useRef<HTMLDivElement | null>(null);

  const clearCalPopoverTimer = () => {
    if (calPopoverTimerRef.current !== null) {
      window.clearTimeout(calPopoverTimerRef.current);
      calPopoverTimerRef.current = null;
    }
  };

  const scheduleCloseCalPopover = () => {
    clearCalPopoverTimer();
    calPopoverTimerRef.current = window.setTimeout(() => {
      setHoveredCalendarDay(null);
    }, 150);
  };

  useEffect(() => {
    setHoveredCalendarDay(null);
  }, [calendarYear, calendarMonth]);

  useEffect(() => {
    const handleCloseOnScroll = (ev: Event) => {
      if (calPopoverRef.current && ev.target instanceof Node && calPopoverRef.current.contains(ev.target)) {
        return;
      }
      setHoveredCalendarDay(null);
    };
    window.addEventListener('scroll', handleCloseOnScroll, true);
    window.addEventListener('resize', handleCloseOnScroll);
    return () => {
      window.removeEventListener('scroll', handleCloseOnScroll, true);
      window.removeEventListener('resize', handleCloseOnScroll);
      clearCalPopoverTimer();
    };
  }, []);

  const handlePrevMonth = () => {
    if (calendarMonth === 1) {
      if (calendarYear > 1400) {
        setCalendarYear(y => y - 1);
        setCalendarMonth(12);
      }
    } else {
      setCalendarMonth(m => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (calendarMonth === 12) {
      if (calendarYear < 1415) {
        setCalendarYear(y => y + 1);
        setCalendarMonth(1);
      }
    } else {
      setCalendarMonth(m => m + 1);
    }
  };

  const handleGoToToday = () => {
    setCalendarYear(currentShamsiToday.year);
    setCalendarMonth(currentShamsiToday.month);
  };

  // بانک فعالیت‌های گروه‌ها با تاریخ شروع، پایان و بازه انجام
  const [groupActivities, setGroupActivities] = useState<Record<string, PMGroupActivityItem[]>>(() => {
    try {
      const saved = 
        localStorage.getItem('pm_studio_group_acts_v6') ||
        localStorage.getItem('pm_studio_group_acts_v5') ||
        localStorage.getItem('pm_studio_group_acts_v4') ||
        localStorage.getItem('pm_studio_group_acts_v3') ||
        localStorage.getItem('pm_studio_group_acts_v2') ||
        localStorage.getItem('pm_studio_group_acts_v1');
      if (saved) {
        const parsed: Record<string, PMGroupActivityItem[]> = JSON.parse(saved);
        if (parsed && Object.keys(parsed).length > 0) {
          return parsed;
        }
      }
    } catch {}

    const enriched: Record<string, PMGroupActivityItem[]> = {};
    Object.keys(DEFAULT_PM_ACTIVITIES_BY_GROUP).forEach(k => {
      enriched[k] = DEFAULT_PM_ACTIVITIES_BY_GROUP[k].map(a => {
        // طبق دستور دقیق کاربر (مورد ۳): فقط برای تورنوس فعالیت ماهانه در تقویم فعال است
        const isScheduled = false;
        return {
          ...a,
          startDate: '1405/08/15',
          endDate: '1405/08/18',
          executionWindowDays: a.executionWindowDays || a.customDays || 3,
          isScheduled
        };
      });
    });
    return enriched;
  });

  const [autoPmStatusMap, setAutoPmStatusMap] = useState<Record<string, AutoPmWoLookupEntry>>({});
  const [autoPmWorkOrders, setAutoPmWorkOrders] = useState<any[]>(() => loadAutoPmWorkOrders());
  const [activeThreeTabPmOrder, setActiveThreeTabPmOrder] = useState<any | null>(null);
  const [autoOpenedWoNotice, setAutoOpenedWoNotice] = useState<{ codes: string[]; count: number } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(groupActivities));
      fetch('/api/portal/sync-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pmGroupActivities: groupActivities })
      }).catch(() => {});
    } catch {}
  }, [groupActivities]);

  // ذخیره زمان‌بندی یکپارچه در سطح هر دوره (گروه + دوره) برای اعمال خودکار روی همه فعالیت‌های فعلی و آینده
  const [periodSchedules, setPeriodSchedules] = useState<
    Record<string, { startDate: string; endDate: string; executionWindowDays: number; isScheduled: boolean; updatedByUser?: boolean }>
  >(() => {
    const initial: Record<string, { startDate: string; endDate: string; executionWindowDays: number; isScheduled: boolean; updatedByUser?: boolean }> = {};
    try {
      const saved = localStorage.getItem('pm_studio_period_schedules_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          Object.assign(initial, parsed);
        }
      }
    } catch {}

    // اگر برای دوره‌ای قبلاً دستور کار باز صادر شده و کاربر تاریخ جدیدی تنظیم نکرده، تاریخ بازه همان دستور کار باز ملاک است
    const openOrdersByGp: Record<string, any[]> = {};
    (autoPmWorkOrders || []).forEach((o: any) => {
      if (!o || isItemArchivedCheck(o) || !o.pmGroupId || !o.pmPeriodKey) return;
      const key = `${o.pmGroupId}::${o.pmPeriodKey}`;
      if (!openOrdersByGp[key]) openOrdersByGp[key] = [];
      openOrdersByGp[key].push(o);
    });
    Object.entries(openOrdersByGp).forEach(([key, orders]) => {
      if (initial[key]?.updatedByUser) return;
      const sorted = [...orders].sort((a, b) =>
        String(a.pmDueDate || a.woStartDate || '').localeCompare(String(b.pmDueDate || b.woStartDate || ''))
      );
      const anchor = sorted[0];
      const baseStart = String(anchor?.pmDueDate || anchor?.woStartDate || '').trim();
      if (!baseStart) return;
      const baseEnd = String(anchor?.woEndDate || '').trim();
      const diff = baseEnd ? diffShamsiDaysPm(baseStart, baseEnd) : 0;
      const wDays = diff > 0 && diff <= 60 ? diff : 3;
      initial[key] = {
        startDate: baseStart,
        endDate: baseEnd || addShamsiDays(baseStart, wDays),
        executionWindowDays: wDays,
        isScheduled: true
      };
    });

    Object.entries(groupActivities).forEach(([gId, acts]) => {
      acts.forEach(a => {
        if (a.isScheduled && a.startDate) {
          const key = `${gId}::${a.frequencyType}`;
          if (!initial[key]) {
            const wDays = a.executionWindowDays || a.customDays || 3;
            initial[key] = {
              startDate: a.startDate,
              endDate: a.endDate || addShamsiDays(a.startDate, wDays),
              executionWindowDays: wDays,
              isScheduled: true
            };
          }
        }
      });
    });
    return initial;
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_period_schedules_v1', JSON.stringify(periodSchedules));
    } catch {}
  }, [periodSchedules]);

  // اصلاح یکپارچه فعالیت‌هایی که قبلاً هنگام حذف/افزودن به اشتباه تاریخ امروز گرفته بودند در حالی که دوره دستور کار باز قبلی دارد
  useEffect(() => {
    const todayStr = getTodayShamsiDateStringPm();
    let changed = false;
    const nextGroups: Record<string, PMGroupActivityItem[]> = { ...groupActivities };

    Object.entries(groupActivities).forEach(([gId, acts]) => {
      if (!Array.isArray(acts) || acts.length === 0) return;
      let groupDirty = false;
      const updatedActs = acts.map(act => {
        const key = `${gId}::${act.frequencyType}`;
        const ps = periodSchedules[key];
        if (!ps || ps.updatedByUser || !ps.isScheduled || !ps.startDate) return act;
        const gap = Math.abs(diffShamsiDaysPm(ps.startDate, act.startDate || ''));
        if (act.startDate === todayStr && ps.startDate !== todayStr && gap < 25) {
          groupDirty = true;
          changed = true;
          return {
            ...act,
            startDate: ps.startDate,
            endDate: ps.endDate,
            executionWindowDays: ps.executionWindowDays,
            isScheduled: true
          };
        }
        return act;
      });
      if (groupDirty) {
        nextGroups[gId] = updatedActs;
      }
    });

    if (changed) {
      setGroupActivities(nextGroups);
    }
  }, [periodSchedules]);

  const getPeriodSchedule = (groupId: string, periodKey: string) => {
    const mapKey = `${groupId}::${periodKey}`;
    if (periodSchedules[mapKey]) return periodSchedules[mapKey];
    const openMatch = (autoPmWorkOrders || [])
      .filter((o: any) => o?.pmGroupId === groupId && o?.pmPeriodKey === periodKey && !isItemArchivedCheck(o) && (o?.pmDueDate || o?.woStartDate))
      .sort((a, b) => String(a.pmDueDate || a.woStartDate || '').localeCompare(String(b.pmDueDate || b.woStartDate || '')))[0];
    if (openMatch) {
      const baseStart = String(openMatch.pmDueDate || openMatch.woStartDate || '').trim();
      const baseEnd = String(openMatch.woEndDate || '').trim();
      const diff = baseEnd ? diffShamsiDaysPm(baseStart, baseEnd) : 0;
      const wDays = diff > 0 && diff <= 60 ? diff : 3;
      return {
        startDate: baseStart,
        endDate: baseEnd || addShamsiDays(baseStart, wDays),
        executionWindowDays: wDays,
        isScheduled: true
      };
    }
    const firstScheduled = (groupActivities[groupId] || []).find(
      a => a.frequencyType === periodKey && a.isScheduled && a.startDate
    );
    if (!firstScheduled || !firstScheduled.startDate) return null;
    const wDays = firstScheduled.executionWindowDays || firstScheduled.customDays || 3;
    return {
      startDate: firstScheduled.startDate,
      endDate: firstScheduled.endDate || addShamsiDays(firstScheduled.startDate, wDays),
      executionWindowDays: wDays,
      isScheduled: true
    };
  };

  // مودال اختصاصی تنظیم تاریخ و بازه انجام در سطح کل دوره (مثلاً ماهانه همه با هم - مورد ۴)
  const [periodToSchedule, setPeriodToSchedule] = useState<{
    groupId: string;
    groupName: string;
    periodKey: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom';
    periodTitle: string;
    periodLabel: string;
    count: number;
    startDate: string;
    executionWindowDays: number;
    endDate: string;
    isScheduled: boolean;
  } | null>(null);

  // صفحه و آکاردئون عمودی برنامه‌ریزی ۹ گروه تجهیزات (پیش‌فرض: تمام گروه‌ها بسته هستند)
  const [activeCategoryGroupId, setActiveCategoryGroupId] = useState<string | null>(null);
  const [expandedScheduleGroup, setExpandedScheduleGroup] = useState<string | null>(null);
  
  // وضعیت نمایش / مخفی‌سازی تجهیزات داخل هر گروه (پیش‌فرض: مخفی با سه نقطه)
  const [expandedGroupEquipmentMap, setExpandedGroupEquipmentMap] = useState<Record<string, boolean>>({});

  const toggleGroupEquipmentVisibility = (groupId: string) => {
    setExpandedGroupEquipmentMap(prev => ({
      ...prev,
      [groupId]: !prev[groupId]
    }));
  };

  const [openPeriodMap, setOpenPeriodMap] = useState<Record<string, boolean>>({
    monthly: false,
    bimonthly: false,
    quarterly: false,
    biannual: false,
    annual: false,
    custom: false
  });

  const togglePeriodAccordion = (periodKey: string) => {
    setOpenPeriodMap(prev => ({
      ...prev,
      [periodKey]: !prev[periodKey]
    }));
  };
  const [activePeriodTab, setActivePeriodTab] = useState<'monthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'>('monthly');

  // فرم افزودن تجهیز جدید به دسته انتخاب‌شده
  const [isAddEqToCatModalOpen, setIsAddEqToCatModalOpen] = useState(false);
  const [newGroupEqForm, setNewGroupEqForm] = useState({
    id: '',
    name: '',
    location: '',
    family: '',
    priority: 'سطح B'
  });

  const handleAddEquipmentToCategory = (groupId: string) => {
    if (!newGroupEqForm.id.trim() || !newGroupEqForm.name.trim()) {
      alert('لطفاً کد تجهیز و نام آن را وارد نمایید.');
      return;
    }
    const grp = PM_9_GROUPS.find(g => g.id === groupId);
    const newEq = {
      id: newGroupEqForm.id.trim().toUpperCase(),
      name: newGroupEqForm.name.trim(),
      family: newGroupEqForm.family.trim() || (grp ? grp.name : 'عمومی'),
      location: newGroupEqForm.location.trim() || 'سالن تولید',
      priority: newGroupEqForm.priority || 'سطح B'
    };
    setEquipmentList(prev => [newEq, ...prev]);
    setIsAddEqToCatModalOpen(false);
    setNewGroupEqForm({ id: '', name: '', location: '', family: '', priority: 'سطح B' });
    setBatchSuccessToast(`✓ تجهیز جدید «${newEq.name} (${newEq.id})» با موفقیت به دسته ${grp?.name || ''} اضافه شد.`);
    setTimeout(() => setBatchSuccessToast(null), 4000);
  };

  // تجهیزات انتخاب شده به تفکیک گروه
  const [selectedEquipMap, setSelectedEquipMap] = useState<Record<string, string[]>>({});

  // تجهیزات فعال و تخصیص‌یافته به تفکیک گروه (با قابلیت حذف با برداشتن تیک و افزودن با جستجو از هر دسته)
  const [groupAssignedEquipMap, setGroupAssignedEquipMap] = useState<Record<string, string[]>>(() => {
    try {
      const saved = localStorage.getItem('pm_studio_group_assigned_eq_v3');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_group_assigned_eq_v3', JSON.stringify(groupAssignedEquipMap));
    } catch {}
  }, [groupAssignedEquipMap]);

  useEffect(() => {
    const runSync = () => {
      try {
        const res = syncDuePmWorkOrders({
          groupActivities,
          equipments: equipmentList,
          groupAssignedEquipMap,
          periodSchedules
        });
        setAutoPmStatusMap(res.statusByGroupPeriod);
        setAutoPmWorkOrders(res.allPmOrders);
        if (res.createdItems.length > 0) {
          setAutoOpenedWoNotice({
            codes: res.createdItems.map(i => i.woCode || i.code),
            count: res.createdItems.length
          });
        }
      } catch {}
    };

    runSync();
    const timer = window.setInterval(runSync, 20000);
    const onFocus = () => runSync();
    const onUpdated = () => {
      try {
        const res = syncDuePmWorkOrders({
          groupActivities,
          equipments: equipmentList,
          groupAssignedEquipMap,
          periodSchedules,
          silent: true
        });
        setAutoPmStatusMap(res.statusByGroupPeriod);
        setAutoPmWorkOrders(res.allPmOrders);
      } catch {}
    };

    window.addEventListener('focus', onFocus);
    window.addEventListener('pm_auto_work_orders_updated', onUpdated as EventListener);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('pm_auto_work_orders_updated', onUpdated as EventListener);
    };
  }, [groupActivities, equipmentList, groupAssignedEquipMap, periodSchedules]);

  const handleOpenThreeTabOrderByCode = (codeOrWoCode: string) => {
    const clean = String(codeOrWoCode || '').trim().toUpperCase();
    const res = syncDuePmWorkOrders({
      groupActivities,
      equipments: equipmentList,
      groupAssignedEquipMap,
      periodSchedules,
      silent: true
    });
    setAutoPmStatusMap(res.statusByGroupPeriod);
    setAutoPmWorkOrders(res.allPmOrders);
    const found = res.allPmOrders.find(
      (o: any) =>
        String(o?.code || '').trim().toUpperCase() === clean ||
        String(o?.woCode || '').trim().toUpperCase() === clean ||
        String(o?.workOrderCode || '').trim().toUpperCase() === clean
    );
    if (found) {
      setActiveThreeTabPmOrder(found);
    }
  };

  const handleOpenThreeTabPmWorkOrder = (groupId: string, act?: PMGroupActivityItem, targetPeriodKey?: string) => {
    const periodKey = targetPeriodKey || act?.frequencyType || 'monthly';
    const res = syncDuePmWorkOrders({
      groupActivities,
      equipments: equipmentList,
      groupAssignedEquipMap,
      periodSchedules
    });
    setAutoPmStatusMap(res.statusByGroupPeriod);
    setAutoPmWorkOrders(res.allPmOrders);
    const gpKey = `${groupId}::${periodKey}`;
    const todayStr = getTodayShamsiDateStringPm();
    const actOcc = act ? resolveLatestDuePmOccurrence(act, todayStr) : null;
    const sourceKey = actOcc ? `${groupId}::${periodKey}::${actOcc}` : '';
    const matchedEntry = (sourceKey && res.statusBySourceKey[sourceKey]) || res.statusByGroupPeriod[gpKey];
    const matchedOrder = matchedEntry
      ? res.allPmOrders.find(
          (o: any) =>
            o?.pmSourceKey === matchedEntry.sourceKey ||
            o?.code === matchedEntry.code ||
            o?.woCode === matchedEntry.woCode
        )
      : undefined;

    if (matchedOrder) {
      setActiveThreeTabPmOrder(matchedOrder);
      return;
    }
    handleOpenPmWorkOrder(groupId, act, targetPeriodKey);
  };

  // مودال افزودن تجهیز از هر دسته به گروه
  const [addEquipmentModalGroup, setAddEquipmentModalGroup] = useState<{ id: string; name: string } | null>(null);
  const [addEqModalSearch, setAddEqModalSearch] = useState('');
  const [addEqModalCategoryFilter, setAddEqModalCategoryFilter] = useState('همه');

  // متغیرهای فرم افزودن فعالیت با تاریخ شروع، تاریخ پایان و بازه انجام
  const [isAddActModalOpen, setIsAddActModalOpen] = useState(false);
  const [familyDataVersion, setFamilyDataVersion] = useState(0);
  const [actModalFamSearch, setActModalFamSearch] = useState('');
  const [isActModalFamDropdownOpen, setIsActModalFamDropdownOpen] = useState(false);
  const actModalFamDropdownRef = useRef<HTMLDivElement>(null);
  const [periodQuickSearchMap, setPeriodQuickSearchMap] = useState<Record<string, string>>({});
  const [openPeriodQuickDropdown, setOpenPeriodQuickDropdown] = useState<string | null>(null);

  useEffect(() => {
    const onAssetClassUpdated = () => setFamilyDataVersion(v => v + 1);
    const onOutsideClick = (ev: MouseEvent) => {
      if (actModalFamDropdownRef.current && !actModalFamDropdownRef.current.contains(ev.target as Node)) {
        setIsActModalFamDropdownOpen(false);
      }
      const targetEl = ev.target as HTMLElement | null;
      if (!targetEl?.closest('[data-pm-period-quick-search]')) {
        setOpenPeriodQuickDropdown(null);
      }
    };
    window.addEventListener('asset_class_data_updated', onAssetClassUpdated as EventListener);
    document.addEventListener('mousedown', onOutsideClick);
    return () => {
      window.removeEventListener('asset_class_data_updated', onAssetClassUpdated as EventListener);
      document.removeEventListener('mousedown', onOutsideClick);
    };
  }, []);

  const [newActForm, setNewActForm] = useState({
    code: '',
    title: '',
    frequencyType: 'monthly' as 'custom' | 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual',
    customDays: 3,
    estimatedHours: 1,
    partsRequired: '',
    startDate: getTodayShamsiString(),
    endDate: addShamsiDays(getTodayShamsiString(), 3),
    executionWindowDays: 3
  });

  // وضعیت برگه فوق‌العاده خلوت دستور کار PM
  const [activePmWorkOrderSheet, setActivePmWorkOrderSheet] = useState<PMWorkOrderSheetData | null>(null);

  // متغیرهای موتور زمان‌بندی تجمعی
  const [cumulCustomOrderCode, setCumulCustomOrderCode] = useState<string>('WO-1405');
  const [cumulStartDate, setCumulStartDate] = useState<string>('1405/08/20');
  const [cumulEndDate, setCumulEndDate] = useState<string>('1406/08/20');
  const [cumulIncludeCustomDays, setCumulIncludeCustomDays] = useState<boolean>(true);

  // متغیرهای ورود فعالیت‌ها با اکسل / نرم‌افزار قبلی
  const [isExcelActModalOpen, setIsExcelActModalOpen] = useState(false);
  const [excelTargetPeriod, setExcelTargetPeriod] = useState<'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'>('monthly');
  const [excelLockToTargetPeriod, setExcelLockToTargetPeriod] = useState<boolean>(true);
  const [excelPasteText, setExcelPasteText] = useState('');
  const [excelParsedActivities, setExcelParsedActivities] = useState<any[]>([]);
  const [excelErrorMsg, setExcelErrorMsg] = useState<string | null>(null);
  const [excelWorkbookSheets, setExcelWorkbookSheets] = useState<Array<{ name: string; grid: any[][] }>>([]);
  const [excelSelectedSheet, setExcelSelectedSheet] = useState<string>('');

  // پاکسازی و خام‌سازی کلیه برنامه‌ها طبق درخواست کاربر
  const handleResetAllPlansAndOrders = () => {
    if (window.confirm('آیا مطمئن هستید که می‌خواهید کلیه برنامه‌ریزی‌ها و دستورکارهای پیشگیرانه را پاک کنید؟ تمام برنامه‌ها صفر و خام خواهند شد.')) {
      setPmPlans([]);
      setWorkOrders([]);
      try {
        localStorage.setItem('pm_studio_plans_v15', '[]');
        localStorage.setItem('pm_studio_work_orders_v15', '[]');
      } catch {}
      setBatchSuccessToast('✓ کلیه برنامه‌ریزی‌ها و دستورکارهای پیشگیرانه پاکسازی شدند و سیستم به حالت کاملاً خام بازگشت.');
      setTimeout(() => setBatchSuccessToast(null), 5000);
    }
  };

  // دریافت تجهیزات مرتبط با یک گروه از ۹ گروه
  const getGroupEquipments = (groupId: string): any[] => {
    const grp = PM_9_GROUPS.find(g => g.id === groupId);
    if (!grp) return [];
    const matched = equipmentList.filter(eq => {
      const idUpper = (eq.id || '').toUpperCase();
      const nameLower = (eq.name || '').toLowerCase();
      const famLower = (eq.family || '').toLowerCase();
      const locLower = (eq.location || '').toLowerCase();
      const matchPrefix = grp.prefixes.some(p => idUpper.startsWith(p));
      const matchKeyword = grp.keywords.some(k => nameLower.includes(k) || famLower.includes(k) || locLower.includes(k));
      return matchPrefix || matchKeyword;
    });

    if (matched.length > 0) return matched;
    return FALLBACK_GROUP_EQUIPMENTS[groupId] || [];
  };

  // دریافت تجهیزات فعال هر گروه (سفارشی‌شده با افزودن یا حذف تجهیزات)
  const getGroupActiveEquipments = (groupId: string): any[] => {
    const defaultEqs = getGroupEquipments(groupId);
    const assignedIds = groupAssignedEquipMap[groupId];
    if (assignedIds === undefined) {
      return defaultEqs;
    }
    return assignedIds.map(id => {
      const foundInAll = equipmentList.find(e => e.id === id);
      if (foundInAll) return foundInAll;
      const foundInDef = defaultEqs.find(e => e.id === id);
      if (foundInDef) return foundInDef;
      return { id, name: `تجهیز ${id}`, location: 'سالن تولید', family: '', priority: 'سطح B' };
    });
  };

  // حذف خودکار تجهیز از لیست با برداشتن تیک
  const handleRemoveEquipmentFromGroup = (groupId: string, eqId: string) => {
    const currentActive = getGroupActiveEquipments(groupId);
    const nextIds = currentActive.map(e => e.id).filter(id => id !== eqId);
    setGroupAssignedEquipMap(prev => ({
      ...prev,
      [groupId]: nextIds
    }));
  };

  // افزودن تجهیز از هر دسته‌ای به این گروه
  const handleAddEquipmentToGroup = (groupId: string, eqId: string) => {
    const currentActive = getGroupActiveEquipments(groupId);
    if (currentActive.some(e => e.id === eqId)) return;
    const nextIds = [...currentActive.map(e => e.id), eqId];
    setGroupAssignedEquipMap(prev => ({
      ...prev,
      [groupId]: nextIds
    }));
  };

  // چک کردن انتخاب بودن یک تجهیز در گروه
  const isEquipSelectedInGroup = (groupId: string, eqId: string): boolean => {
    const selectedList = selectedEquipMap[groupId];
    if (selectedList === undefined) return true; // به طور پیش‌فرض همه تیک خورده‌اند
    return selectedList.includes(eqId);
  };

  // تاگل انتخاب یک تجهیز در گروه
  const toggleEquipInGroup = (groupId: string, eqId: string) => {
    const allEqs = getGroupEquipments(groupId);
    const currentSelected = selectedEquipMap[groupId] !== undefined 
      ? selectedEquipMap[groupId] 
      : allEqs.map(e => e.id);
    
    if (currentSelected.includes(eqId)) {
      setSelectedEquipMap(prev => ({
        ...prev,
        [groupId]: currentSelected.filter(id => id !== eqId)
      }));
    } else {
      setSelectedEquipMap(prev => ({
        ...prev,
        [groupId]: [...currentSelected, eqId]
      }));
    }
  };

  // انتخاب همه / عدم انتخاب در گروه
  const toggleAllEquipInGroup = (groupId: string) => {
    const allEqs = getGroupEquipments(groupId);
    const currentSelected = selectedEquipMap[groupId] !== undefined 
      ? selectedEquipMap[groupId] 
      : allEqs.map(e => e.id);

    if (currentSelected.length === allEqs.length) {
      // لغو انتخاب همه
      setSelectedEquipMap(prev => ({ ...prev, [groupId]: [] }));
    } else {
      // انتخاب همه
      setSelectedEquipMap(prev => ({ ...prev, [groupId]: allEqs.map(e => e.id) }));
    }
  };

  // افزودن فعالیت جدید به گروه
  const handleAddCustomActivityToGroup = (groupId: string) => {
    if (!newActForm.title.trim()) {
      alert('لطفاً عنوان فعالیت را وارد فرمایید.');
      return;
    }
    const freqLabels: Record<string, string> = {
      custom: `${newActForm.customDays || 3} روزه سفارشی`,
      monthly: 'ماهانه (۳۰ روز)',
      bimonthly: 'دوماهه (۶۰ روز)',
      quarterly: '۳ ماهه (۹۰ روز)',
      biannual: '۶ ماهه (۱۸۰ روز)',
      annual: 'سالانه (۳۶۵ روز)'
    };
    const periodSched = getPeriodSchedule(groupId, newActForm.frequencyType);
    const sDate = periodSched?.startDate || newActForm.startDate || getTodayShamsiString();
    const winDays = periodSched?.executionWindowDays || newActForm.executionWindowDays || 3;
    const eDate = periodSched?.endDate || newActForm.endDate || addShamsiDays(sDate, winDays);
    const isPeriodScheduled = Boolean(periodSched?.isScheduled);

    const newAct: PMGroupActivityItem = {
      id: `act-${groupId}-${Date.now()}`,
      code: newActForm.code.trim() || undefined,
      groupId,
      title: newActForm.title.trim(),
      frequencyType: newActForm.frequencyType,
      frequencyLabel: freqLabels[newActForm.frequencyType] || `${newActForm.customDays} روزه`,
      customDays: newActForm.frequencyType === 'custom' ? (newActForm.customDays || 3) : undefined,
      estimatedHours: newActForm.estimatedHours || 1,
      partsRequired: newActForm.partsRequired.trim() || undefined,
      isActive: true,
      startDate: sDate,
      endDate: eDate,
      executionWindowDays: winDays,
      isScheduled: isPeriodScheduled
    };

    setGroupActivities(prev => {
      const next = {
        ...prev,
        [groupId]: [...(prev[groupId] || []), newAct]
      };
      try {
        localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(next));
        fetch('/api/portal/sync-state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pmGroupActivities: next })
        }).catch(() => {});
      } catch {}
      return next;
    });

    // حفظ دوره تناوب فعلی برای ادامه ثبت در همان تب و باز نگه داشتن آکاردئون هدف
    setOpenPeriodMap(prev => ({
      ...prev,
      [newAct.frequencyType]: true
    }));
    setNewActForm(prev => ({
      ...prev,
      code: '',
      title: '',
      partsRequired: '',
      startDate: getTodayShamsiString(),
      endDate: addShamsiDays(getTodayShamsiString(), 3),
      executionWindowDays: 3
    }));
    setActModalFamSearch('');
    setIsActModalFamDropdownOpen(false);
    setIsAddActModalOpen(false);
    setBatchSuccessToast(
      isPeriodScheduled
        ? `✓ فعالیت «${newAct.title}» در دوره ${newAct.frequencyLabel} با زمان‌بندی یکپارچه دوره (${sDate} تا ${eDate}) ثبت شد.`
        : `✓ فعالیت «${newAct.title}» در دوره ${newAct.frequencyLabel} ثبت شد.`
    );
    setTimeout(() => setBatchSuccessToast(null), 4000);
  };

  // افزودن سریع یا بروزرسانی کد فعالیت پیشگیرانه مستقیماً از فعالیت‌های ثبت‌شده در خانواده تجهیز همان گروه
  const handleQuickAddFamilyActivityToPeriod = (
    groupId: string,
    periodKey: 'custom' | 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual',
    famAct: PmGroupFamilyActivityOption
  ) => {
    const freqLabels: Record<string, string> = {
      custom: '۳ روزه سفارشی',
      monthly: 'ماهانه (۳۰ روز)',
      bimonthly: 'دوماهه (۶۰ روز)',
      quarterly: '۳ ماهه (۹۰ روز)',
      biannual: '۶ ماهه (۱۸۰ روز)',
      annual: 'سالانه (۳۶۵ روز)'
    };
    const normTitle = (v: string) =>
      String(v || '').replace(/ي/g, 'ی').replace(/ى/g, 'ی').replace(/ك/g, 'ک').replace(/\u200c/g, '').trim().toLowerCase();

    const curGroupActs = groupActivities[groupId] || [];
    const periodSched = getPeriodSchedule(groupId, periodKey);
    const existingMatch = curGroupActs.find(
      a => a.frequencyType === periodKey && normTitle(a.title) === normTitle(famAct.title)
    );

    if (existingMatch) {
      if ((existingMatch.code || '').trim() === (famAct.code || '').trim()) {
        setOpenPeriodQuickDropdown(null);
        setBatchSuccessToast(`فعالیت «${famAct.title}» با کد «${famAct.code || '—'}» هم‌اکنون در این دوره ثبت شده است.`);
        setTimeout(() => setBatchSuccessToast(null), 3500);
        return;
      }
      setGroupActivities(prev => {
        const next = {
          ...prev,
          [groupId]: (prev[groupId] || []).map(a =>
            a.id === existingMatch.id ? { ...a, code: famAct.code || a.code } : a
          )
        };
        try {
          localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(next));
          fetch('/api/portal/sync-state', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pmGroupActivities: next })
          }).catch(() => {});
        } catch {}
        return next;
      });
      setOpenPeriodQuickDropdown(null);
      setPeriodQuickSearchMap(prev => ({ ...prev, [`${groupId}::${periodKey}`]: '' }));
      setBatchSuccessToast(`✓ کد فعالیت «${famAct.title}» به «${famAct.code}» اصلاح و بروزرسانی شد.`);
      setTimeout(() => setBatchSuccessToast(null), 4000);
      return;
    }

    const sDate = periodSched?.startDate || getTodayShamsiString();
    const winDays = periodSched?.executionWindowDays || 3;
    const eDate = periodSched?.endDate || addShamsiDays(sDate, winDays);
    const isPeriodScheduled = Boolean(periodSched?.isScheduled);

    const newAct: PMGroupActivityItem = {
      id: `act-${groupId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      code: famAct.code || undefined,
      groupId,
      title: famAct.title,
      frequencyType: periodKey,
      frequencyLabel: freqLabels[periodKey] || 'دوره‌ای',
      customDays: periodKey === 'custom' ? 3 : undefined,
      estimatedHours: 1,
      isActive: true,
      startDate: sDate,
      endDate: eDate,
      executionWindowDays: winDays,
      isScheduled: isPeriodScheduled
    };

    setGroupActivities(prev => {
      const next = {
        ...prev,
        [groupId]: [...(prev[groupId] || []), newAct]
      };
      try {
        localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(next));
        fetch('/api/portal/sync-state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pmGroupActivities: next })
        }).catch(() => {});
      } catch {}
      return next;
    });

    setOpenPeriodMap(prev => ({ ...prev, [periodKey]: true }));
    setOpenPeriodQuickDropdown(null);
    setPeriodQuickSearchMap(prev => ({ ...prev, [`${groupId}::${periodKey}`]: '' }));
    setBatchSuccessToast(`✓ فعالیت «${newAct.title}»${newAct.code ? ` با کد «${newAct.code}»` : ''} به دوره ${newAct.frequencyLabel} اضافه شد.`);
    setTimeout(() => setBatchSuccessToast(null), 4000);
  };

  // باز کردن برگه دستور کار PM (فوق‌العاده خلوت با انتخاب تجهیزات گروه و فعالیت‌های اختصاصی دوره تناوب)
  const handleOpenPmWorkOrder = (groupId: string, act?: PMGroupActivityItem, targetPeriodKey?: string) => {
    const grp = PM_9_GROUPS.find(g => g.id === groupId);
    const allEqs = getGroupActiveEquipments(groupId);
    const groupActs = groupActivities[groupId] || [];
    const grpName = grp ? grp.name : groupId;
    const period = targetPeriodKey || act?.frequencyType || 'monthly';
    
    const freqLabels: Record<string, string> = {
      monthly: 'ماهانه',
      bimonthly: 'دوماهه',
      quarterly: '۳ ماهه',
      biannual: '۶ ماهه',
      annual: 'سالانه',
      custom: 'سفارشی'
    };
    const pLabel = freqLabels[period] || 'دوره‌ای';

    // کدهای تمام تجهیزات این گروه به طور خودکار استخراج می‌شوند
    const allEqIds = allEqs.map(e => e.id);

    // طبق دستور دقیق کاربر (مورد ۵): برای هر دوره تناوب (مثلاً ماهانه یا ۳ ماهه) درخواست کار جدا با فعالیت‌های همان دوره
    const periodActs = groupActs.filter(a => a.frequencyType === period);
    const actsToUse = periodActs.length > 0 ? periodActs : (act ? [act] : groupActs);
    const relatedActs = actsToUse.map(a => a.title);
    const defaultTitle = `سرویس پیشگیرانه ${pLabel} گروه ${grpName}`;

    const periodSched = getPeriodSchedule(groupId, period);
    const sDate = periodSched?.startDate || act?.startDate || getTodayShamsiString();
    const wDays = periodSched?.executionWindowDays || act?.executionWindowDays || 3;
    const eDate = periodSched?.endDate || act?.endDate || addShamsiDays(sDate, wDays);
    const dHrs = act?.estimatedHours || 3;

    const initialSessions: PMWorkSessionItem[] = [
      {
        id: `sess-${Date.now()}-1`,
        startDate: sDate,
        endDate: sDate,
        startTime: '08:00',
        endTime: '11:00'
      }
    ];

    const partsReq = (act?.partsRequired || '').trim();
    const initMech: PMWorkOrderPartItem[] = [];
    const initElec: PMWorkOrderPartItem[] = [];
    if (partsReq) {
      const isElec = /برق|سنسور|فیوز|رله|کابل|کنتاکتور|کلید|میکروسوئیچ|الکتر|سیم/i.test(partsReq);
      if (isElec) {
        initElec.push({ id: `el-${Date.now()}`, name: partsReq, quantity: 1 });
      } else {
        initMech.push({ id: `mc-${Date.now()}`, name: partsReq, quantity: 1 });
      }
    }

    setActivePmWorkOrderSheet({
      id: `PM-WO-${Date.now().toString().slice(-6)}`,
      groupId,
      groupName: grpName,
      title: defaultTitle,
      activityTitle: defaultTitle,
      allGroupEquipments: allEqs.map(e => ({ id: e.id, name: e.name })),
      selectedEquipments: allEqIds, // پیش‌فرض همه تجهیزات تیک دارند
      activities: relatedActs.length > 0 ? relatedActs : [defaultTitle],
      // طبق دستور کاربر: دستور کار که باز میشه فعالیت‌ها همه تیک خورده باشن
      checkedActivities: relatedActs.length > 0 ? [...relatedActs] : [defaultTitle],
      technician: (techniciansList && techniciansList.length > 0) ? techniciansList[0]?.name : '',
      coTechnicians: [],
      woDate: sDate,
      woEndDate: eDate,
      workDaysCount: wDays,
      dailyHours: dHrs,
      woStartTime: '08:00',
      woEndTime: '11:00',
      workSessions: initialSessions,
      mechanicalParts: initMech,
      electricalParts: initElec,
      sparePartsUsed: act?.partsRequired || '',
      showExtraDetails: false,
      notes: '',
      status: 'در حال اقدام'
    });
  };

  // ثبت اتمام و بستن دستور کار PM و ثبت سابقه تکنسین با احتساب کارکرد چندروزه بر اساس نوبت‌های کاری
  const handleClosePmWorkOrder = () => {
    if (!activePmWorkOrderSheet) return;
    if (activePmWorkOrderSheet.selectedEquipments.length === 0) {
      alert('لطفاً حداقل یک تجهیز که PM روی آن اجرا شده است را انتخاب فرمایید.');
      return;
    }
    if (!activePmWorkOrderSheet.technician) {
      alert('لطفاً تکنسین مجری را انتخاب فرمایید.');
      return;
    }

    // محاسبه دقیق مجموع ساعات کارکرد از نوبت‌ها و روزهای کاری ثبت‌شده (مورد اول کاربر)
    const sessions = (activePmWorkOrderSheet.workSessions && activePmWorkOrderSheet.workSessions.length > 0)
      ? activePmWorkOrderSheet.workSessions
      : [{
          id: 'sess-def',
          startDate: activePmWorkOrderSheet.woDate,
          endDate: activePmWorkOrderSheet.woEndDate || activePmWorkOrderSheet.woDate,
          startTime: activePmWorkOrderSheet.woStartTime || '08:00',
          endTime: activePmWorkOrderSheet.woEndTime || '11:00'
        }];

    let totalDurationMinutes = 0;
    const sessionDetailsList: string[] = [];

    sessions.forEach((s, idx) => {
      const hrs = calculateSessionHours(s.startTime, s.endTime);
      totalDurationMinutes += Math.round(hrs * 60);
      sessionDetailsList.push(`روز ${idx + 1}: ${s.startDate} تا ${s.endDate} (از ${s.startTime} الی ${s.endTime} - ${hrs} ساعت)`);
    });

    const workHoursAdded = Math.round((totalDurationMinutes / 60) * 10) / 10;
    const daysCount = sessions.length;
    const firstDate = sessions[0]?.startDate || activePmWorkOrderSheet.woDate;
    const lastDate = sessions[sessions.length - 1]?.endDate || firstDate;

    const allInvolvedTechs = [
      activePmWorkOrderSheet.technician,
      ...activePmWorkOrderSheet.coTechnicians
    ];

    // ۱. ثبت سابقه و ساعات کار برای تکنسین‌های مجری
    setTechniciansList(prev => {
      const updated = prev.map(t => {
        if (allInvolvedTechs.includes(t.name)) {
          return {
            ...t,
            completedTasks: (t.completedTasks || 0) + 1,
            workHours: Math.round(((t.workHours || 0) + workHoursAdded) * 10) / 10,
            lastAction: `اتمام PM گروه ${activePmWorkOrderSheet.groupName} (${daysCount} نوبت کاری)`
          };
        }
        return t;
      });
      try {
        localStorage.setItem('pm_studio_techs_v5', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // ۲. ثبت دستور کار در کارتابل اصلی خدمات فنی (صفحه اصلی)
    const orderCode = activePmWorkOrderSheet.id;
    
    // استخراج تفکیک‌شده لوازم یدکی مکانیکی و برقی همراه با تعداد
    const mechList = (activePmWorkOrderSheet.mechanicalParts || [])
      .filter(p => p.name && p.name.trim() !== '')
      .map(p => `${p.name.trim()} (${toFaDigits(p.quantity || 1)} عدد)`);

    const elecList = (activePmWorkOrderSheet.electricalParts || [])
      .filter(p => p.name && p.name.trim() !== '')
      .map(p => `${p.name.trim()} (${toFaDigits(p.quantity || 1)} عدد)`);

    const partsLines: string[] = [];
    if (mechList.length > 0) {
      partsLines.push(`⚙️ مکانیکی: ${mechList.join('، ')}`);
    }
    if (elecList.length > 0) {
      partsLines.push(`⚡ برقی: ${elecList.join('، ')}`);
    }

    let partsInfo = '';
    if (partsLines.length > 0) {
      partsInfo = `\nلوازم یدکی مصرفی:\n${partsLines.join('\n')}`;
    } else if (activePmWorkOrderSheet.sparePartsUsed && activePmWorkOrderSheet.sparePartsUsed.trim()) {
      partsInfo = `\nلوازم یدکی و قطعات مصرفی: ${activePmWorkOrderSheet.sparePartsUsed.trim()}`;
    }

    const newWorkReq = {
      code: orderCode,
      workOrderCode: orderCode,
      place: `گروه ${activePmWorkOrderSheet.groupName}`,
      created: `${firstDate} تا ${lastDate}`,
      title: `درخواست کار PM: ${activePmWorkOrderSheet.activityTitle}`,
      requestType: 'PM', // کاملاً مجزا از درخواست خدمات فنی و اولویت‌های کارت
      priority: 'عادی',
      description: `تجهیزات PM شده: ${activePmWorkOrderSheet.selectedEquipments.join('، ')}\nفعالیت‌های تکمیل‌شده:\n${activePmWorkOrderSheet.checkedActivities.join('\n')}${partsInfo}\nبرنامه روزهای کارکرد:\n${sessionDetailsList.join('\n')}\nمجموع کارکرد: ${workHoursAdded} ساعت (${daysCount} روز کاری)${activePmWorkOrderSheet.notes ? '\nیادداشت: ' + activePmWorkOrderSheet.notes : ''}`,
      status: 'انجام شد' as const,
      technician: activePmWorkOrderSheet.technician,
      coTechnicians: activePmWorkOrderSheet.coTechnicians,
      mechanicalParts: activePmWorkOrderSheet.mechanicalParts || [],
      electricalParts: activePmWorkOrderSheet.electricalParts || [],
      sparePartsUsed: partsLines.join(' | ') || activePmWorkOrderSheet.sparePartsUsed || '',
      complexityLevel: 'معمولی' as const,
      operationType: 'نگهداری و تعمیرات پیشگیرانه (PM)',
      actionDetails: `اجرای چک‌لیست سرویس PM گروه ${activePmWorkOrderSheet.groupName} روی ${activePmWorkOrderSheet.selectedEquipments.length} دستگاه به مدت ${daysCount} روز کاری (${workHoursAdded} ساعت کارکرد)`,
      woDate: `${firstDate} تا ${lastDate}`,
      durationMinutes: totalDurationMinutes,
      completedAt: `${lastDate} ${sessions[sessions.length - 1]?.endTime || '16:00'}`,
      completedTimestamp: Date.now()
    };

    if (onAddWorkRequest) {
      onAddWorkRequest(newWorkReq);
    } else {
      try {
        const saved = localStorage.getItem('technicalServiceWorkRequests');
        const list = saved ? JSON.parse(saved) : [];
        localStorage.setItem('technicalServiceWorkRequests', JSON.stringify([newWorkReq, ...list]));
      } catch {}
    }

    // ۳. ثبت در دستورکارهای PM داخلی
    const internalWo: any = {
      id: orderCode,
      title: `PM ${activePmWorkOrderSheet.groupName} - ${activePmWorkOrderSheet.activityTitle}`,
      equipment: activePmWorkOrderSheet.selectedEquipments.join('، '),
      priority: 'عادی',
      status: 'انجام شد',
      dueDate: `${firstDate} الی ${lastDate} (${daysCount} روز کاری)`,
      assignedTo: allInvolvedTechs.join(' و '),
      estimatedHours: workHoursAdded,
      actualHours: workHoursAdded,
      tasks: activePmWorkOrderSheet.checkedActivities.map((t, idx) => ({ id: idx + 1, text: t, done: true })),
      createdAt: `${firstDate}`,
      completedAt: `${lastDate}`
    };

    setWorkOrders(prev => {
      const nextOrders = [internalWo, ...prev];
      try {
        localStorage.setItem('pm_studio_work_orders_v15', JSON.stringify(nextOrders));
        setTechniciansList(curr => {
          const reconciled = reconcilePmTechniciansList(curr, { pmWorkOrders: nextOrders });
          try {
            localStorage.setItem('pm_studio_techs_v5', JSON.stringify(reconciled));
          } catch {}
          return reconciled;
        });
      } catch {}
      return nextOrders;
    });

    setBatchSuccessToast(`✓ دستور کار PM (${orderCode}) با موفقیت بسته شد و سابقه ${toFaDigits(workHoursAdded)} ساعت کارکرد (${toFaDigits(daysCount)} روز کاری) برای ${allInvolvedTechs.join(' و ')} ثبت گردید.`);
    setTimeout(() => setBatchSuccessToast(null), 5000);
    setActivePmWorkOrderSheet(null);
  };

  // فعال/غیرفعال کردن یک فعالیت
  const handleToggleActivityItem = (groupId: string, actId: string) => {
    setGroupActivities(prev => ({
      ...prev,
      [groupId]: (prev[groupId] || []).map(a => a.id === actId ? { ...a, isActive: !a.isActive } : a)
    }));
  };

  // حذف یک فعالیت (با حفظ زمان‌بندی فعلی دوره تا فعالیت‌های جایگزین دقیقاً در همان بازه قبلی بمانند)
  const handleDeleteActivityItem = (groupId: string, actId: string) => {
    const targetAct = (groupActivities[groupId] || []).find(a => a.id === actId);
    if (targetAct && targetAct.isScheduled && targetAct.startDate) {
      const mapKey = `${groupId}::${targetAct.frequencyType}`;
      setPeriodSchedules(prevSched => {
        if (prevSched[mapKey]) return prevSched;
        const wDays = targetAct.executionWindowDays || targetAct.customDays || 3;
        return {
          ...prevSched,
          [mapKey]: {
            startDate: targetAct.startDate!,
            endDate: targetAct.endDate || addShamsiDays(targetAct.startDate!, wDays),
            executionWindowDays: wDays,
            isScheduled: true
          }
        };
      });
    }
    setGroupActivities(prev => {
      const next = {
        ...prev,
        [groupId]: (prev[groupId] || []).filter(a => a.id !== actId)
      };
      try {
        localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(next));
        fetch('/api/portal/sync-state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pmGroupActivities: next })
        }).catch(() => {});
      } catch {}
      return next;
    });
  };

  // توابع کمکی ورود فعالیت‌ها با اکسل
  const handleDownloadExcelActTemplate = () => {
    try {
      const sampleData = [
        {
          'کد فعالیت': 'ACT-01',
          'عنوان فعالیت': 'آچارکشی کلت‌ها و تعویض فیلتر روغن هیدرولیک',
          'دوره تناوب': 'ماهانه',
          'مدت زمان (ساعت)': 2,
          'قطعات و ابزار': 'فیلتر هیدرولیک، روغن VG32'
        },
        {
          'کد فعالیت': 'ACT-02',
          'عنوان فعالیت': 'تست دقت ابعادی تکرارپذیری و روانکاری بلبرینگ‌ها',
          'دوره تناوب': '۳ ماهه',
          'مدت زمان (ساعت)': 3,
          'قطعات و ابزار': 'گیج میکرومتر، گریس مخصوص'
        },
        {
          'کد فعالیت': 'ACT-03',
          'عنوان فعالیت': 'تعویض کامل روغن هیدرولیک و سرویس سیستم بوش',
          'دوره تناوب': '۶ ماهه',
          'مدت زمان (ساعت)': 4,
          'قطعات و ابزار': 'روغن هیدرولیک ۲۰ لیتری'
        },
        {
          'کد فعالیت': 'ACT-04',
          'عنوان فعالیت': 'اورهال کامل و کالیبراسیون لیزری تمام محورها',
          'دوره تناوب': 'سالانه',
          'مدت زمان (ساعت)': 6,
          'قطعات و ابزار': 'کیت اورهال کامل'
        },
        {
          'کد فعالیت': 'ACT-05',
          'عنوان فعالیت': 'بررسی فشار روغن و تمیزی مسیر تخلیه براده',
          'دوره تناوب': '۳ روزه',
          'مدت زمان (ساعت)': 0.5,
          'قطعات و ابزار': ''
        }
      ];
      const ws = XLSX.utils.json_to_sheet(sampleData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'فعالیت‌های PM');
      XLSX.writeFile(wb, 'قالب_اکسل_فعالیت_های_PM.xlsx');
    } catch (err: any) {
      alert('خطا در دانلود قالب اکسل: ' + (err?.message || ''));
    }
  };

  const getPeriodDescriptor = (type: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'): { type: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'; label: string; days?: number } => {
    switch (type) {
      case 'bimonthly': return { type: 'bimonthly', label: 'دوماهه (۶۰ روز)', days: 60 };
      case 'quarterly': return { type: 'quarterly', label: '۳ ماهه (۹۰ روز)', days: 90 };
      case 'biannual': return { type: 'biannual', label: '۶ ماهه (۱۸۰ روز)', days: 180 };
      case 'annual': return { type: 'annual', label: 'سالانه (۳۶۵ روز)', days: 365 };
      case 'custom': return { type: 'custom', label: '۳ روزه سفارشی', days: 3 };
      default: return { type: 'monthly', label: 'ماهانه (۳۰ روز)', days: 30 };
    }
  };

  const toAsciiDigitsClean = (val: any) =>
    String(val ?? '')
      .replace(/[\u200B-\u200F\uFEFF]/g, '')
      .replace(/\u200C/g, ' ')
      .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
      .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584))
      .replace(/ي/g, 'ی')
      .replace(/ى/g, 'ی')
      .replace(/ك/g, 'ک')
      .replace(/\s+/g, ' ')
      .trim();

  const parseFrequencyString = (
    str: any,
    defaultType: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom' = 'monthly'
  ): { type: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'; label: string; days?: number } => {
    const raw = String(str || '').trim();
    if (!raw) {
      return getPeriodDescriptor(defaultType);
    }
    const s = toAsciiDigitsClean(raw).toLowerCase();

    if (
      s.includes('سال') ||
      /\b36[05]\b/.test(s) ||
      s.includes('annual') ||
      s.includes('yearly') ||
      s.includes('year') ||
      /\b1\s*y\b/.test(s) ||
      /\b12\s*ماه/.test(s) ||
      (defaultType === 'annual' && s === '1')
    ) {
      return { type: 'annual', label: 'سالانه (۳۶۵ روز)', days: 365 };
    }
    if (/\b6\s*ماه/.test(s) || s === '6' || s.includes('شش') || s.includes('نیم') || /\b180\b/.test(s) || s.includes('biannual')) {
      return { type: 'biannual', label: '۶ ماهه (۱۸۰ روز)', days: 180 };
    }
    if (/\b3\s*ماه/.test(s) || s === '3' || s.includes('سه') || s.includes('فصل') || /\b90\b/.test(s) || s.includes('quarterly') || s === 'q') {
      return { type: 'quarterly', label: '۳ ماهه (۹۰ روز)', days: 90 };
    }
    if (/\b2\s*ماه/.test(s) || s === '2' || s.includes('دوماه') || s.includes('دو ماه') || /\b60\b/.test(s) || s.includes('bimonthly')) {
      return { type: 'bimonthly', label: 'دوماهه (۶۰ روز)', days: 60 };
    }
    if (/\b1\s*ماه/.test(s) || s === '1' || s === '30' || /\b30\s*روز/.test(s) || s.includes('ماهانه') || s.includes('monthly')) {
      return { type: 'monthly', label: 'ماهانه (۳۰ روز)', days: 30 };
    }
    if (s.includes('سفارش') || s === 'custom' || s.includes('روز') || s.includes('هفته')) {
      const matchDays = s.match(/\d+/);
      let days = matchDays ? parseInt(matchDays[0], 10) : 3;
      if (s.includes('هفته') && matchDays) days = days * 7;
      else if (s.includes('هفته')) days = 7;
      if (days === 30) return { type: 'monthly', label: 'ماهانه (۳۰ روز)', days: 30 };
      if (days === 60) return { type: 'bimonthly', label: 'دوماهه (۶۰ روز)', days: 60 };
      if (days === 90) return { type: 'quarterly', label: '۳ ماهه (۹۰ روز)', days: 90 };
      if (days === 180) return { type: 'biannual', label: '۶ ماهه (۱۸۰ روز)', days: 180 };
      if (days === 365 || days === 360) return { type: 'annual', label: 'سالانه (۳۶۵ روز)', days: 365 };
      return { type: 'custom', label: `${days} روزه سفارشی`, days };
    }
    const numMatch = s.match(/^\d+$/);
    if (numMatch) {
      const days = parseInt(numMatch[0], 10);
      if (days === 30) return { type: 'monthly', label: 'ماهانه (۳۰ روز)', days: 30 };
      if (days === 60) return { type: 'bimonthly', label: 'دوماهه (۶۰ روز)', days: 60 };
      if (days === 90) return { type: 'quarterly', label: '۳ ماهه (۹۰ روز)', days: 90 };
      if (days === 180) return { type: 'biannual', label: '۶ ماهه (۱۸۰ روز)', days: 180 };
      if (days === 365 || days === 360) return { type: 'annual', label: 'سالانه (۳۶۵ روز)', days: 365 };
      return { type: 'custom', label: `${days} روزه سفارشی`, days };
    }
    return getPeriodDescriptor(defaultType);
  };

  const normalizePmExcelHeader = (val: any) => toAsciiDigitsClean(val).toLowerCase();

  const isPmRowNumberHeader = (h: string) => {
    const c = h.replace(/[\s_\-:]/g, '');
    return c === 'ردیف' || c === 'شماره' || c === 'شمارهردیف' || c === 'row' || c === 'radif' || c === 'no' || c === '#' || c === 'index' || c === 'sr' || c === 'sno';
  };

  const isEquipmentMetaHeader = (h: string) => {
    const c = h.replace(/[\s_\-:]/g, '');
    return (
      c.includes('نامدستگاه') ||
      c.includes('نامتجهیز') ||
      c.includes('نامگروه') ||
      c.includes('نامماشین') ||
      c.includes('کددستگاه') ||
      c.includes('کدتجهیز') ||
      c.includes('کدماشین') ||
      c === 'دستگاه' ||
      c === 'تجهیز' ||
      c === 'گروه' ||
      c === 'واحد' ||
      c === 'مکان' ||
      c === 'سالن' ||
      c.includes('equipmentname') ||
      c.includes('equipmentcode') ||
      c.includes('machinename')
    );
  };

  const isLikelyFrequencyCell = (val: string) => {
    const s = toAsciiDigitsClean(val).toLowerCase();
    if (!s || s.length > 26) return false;
    // اگر جمله طولانی توصیفی با فعل/کارهای فنی باشد دوره تناوب نیست
    if (/تعویض|بازرسی|بازبینی|آچارکشی|تنظیم|نظافت|شستشو|شست‌وشو|تست|روانکاری|اورهال|کالیبراسیون|کنترل|تمیز|گیریس|گریس|روغن|فیلتر|محور|اسپیندل|بلبرینگ/.test(s)) {
      return false;
    }
    return (
      /^(یک\s*ساله|سالانه|سالیانه|هر\s*سال|هر\s*یک\s*سال|1\s*ساله|12\s*ماهه?|ماهانه|یک\s*ماهه|1\s*ماهه?|دو\s*ماهه|دوماهه|2\s*ماهه?|سه\s*ماهه|3\s*ماهه?|شش\s*ماهه|6\s*ماهه?|نیم\s*سالانه|فصلی|هفتگی|روزانه|سفارشی|\d+\s*(روزه?|ماهه?|ساله?|هفته)|annual|yearly|monthly|quarterly|biannual|bimonthly|custom|1y|y)$/i.test(s)
    );
  };

  const looksLikeRowIndexCell = (val: string) => {
    const s = toAsciiDigitsClean(val);
    return /^\d{1,3}$/.test(s);
  };

  const looksLikeActivityCodeToken = (val: string) => {
    const s = toAsciiDigitsClean(val);
    if (!s || s.length > 24) return false;
    if (isLikelyFrequencyCell(s)) return false;
    return /^[a-zA-Z0-9\-_/.]+$/.test(s);
  };

  const parseHoursValue = (val: string): number => {
    const s = toAsciiDigitsClean(val).replace(/,/g, '.').replace(/[^\d.]/g, '');
    const n = parseFloat(s);
    return !isNaN(n) && n > 0 ? n : 1;
  };

  const parsePmActivitiesGrid = (
    rawGrid: any[][],
    defaultPeriod: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom',
    isLocked: boolean,
    idPrefix: string
  ) => {
    const nonEmptyRows = rawGrid.filter(r =>
      Array.isArray(r) && r.some(c => String(c ?? '').trim() !== '')
    );
    if (nonEmptyRows.length === 0) return [];

    let headerRowIdx = -1;
    let codeColIdx = -1;
    let titleColIdx = -1;
    let freqColIdx = -1;
    let hoursColIdx = -1;
    let partsColIdx = -1;
    let bestHeaderScore = -1;

    const maxNonEmptyColsInSheet = Math.max(
      ...nonEmptyRows.slice(0, 15).map(r => r.filter(c => String(c ?? '').trim() !== '').length)
    );

    for (let r = 0; r < Math.min(nonEmptyRows.length, 15); r++) {
      const rowNorm = nonEmptyRows[r].map(normalizePmExcelHeader);
      const nonEmptyInRow = rowNorm.filter(Boolean).length;

      // جلوگیری از اشتباه گرفتن ردیف عنوان/بنر تک‌سلولی بالای شیت به جای سطر هدر جدول
      if (nonEmptyInRow === 1 && maxNonEmptyColsInSheet >= 2) {
        continue;
      }
      if (nonEmptyInRow === 1 && nonEmptyRows.length > 1) {
        const single = rowNorm.find(Boolean) || '';
        const isExactSingleHeader = ['عنوان', 'فعالیت', 'شرح', 'شرح فعالیت', 'عنوان فعالیت', 'title', 'activity', 'description'].includes(single);
        if (!isExactSingleHeader) continue;
      }

      let cIdx = rowNorm.findIndex(
        h => h && !isPmRowNumberHeader(h) && !isEquipmentMetaHeader(h) && (h.includes('کد فعالیت') || h.includes('کد آیتم') || h.includes('activity code') || h.includes('act code'))
      );
      if (cIdx === -1) {
        cIdx = rowNorm.findIndex(
          h =>
            h &&
            !isPmRowNumberHeader(h) &&
            !isEquipmentMetaHeader(h) &&
            (h === 'کد' || h === 'code' || h === 'id' || h.includes('کد') || h.includes('code') || h.includes('شناسه'))
        );
      }

      const isTitleKeyword = (h: string, strict: boolean) => {
        if (!h || isPmRowNumberHeader(h) || isEquipmentMetaHeader(h)) return false;
        if (
          h.includes('عنوان فعالیت') ||
          h.includes('شرح فعالیت') ||
          h.includes('نام فعالیت') ||
          h.includes('نوع فعالیت') ||
          h.includes('شرح کار') ||
          h.includes('شرح عملیات') ||
          h.includes('عنوان') ||
          h.includes('شرح') ||
          h.includes('فعالیت') ||
          h.includes('چک لیست') ||
          h.includes('چک‌لیست') ||
          h.includes('اقدام') ||
          h.includes('موضوع') ||
          h.includes('توضیح') ||
          h.includes('آیتم') ||
          h.includes('سرویس') ||
          h.includes('activity') ||
          h.includes('task') ||
          h.includes('description') ||
          h.includes('title') ||
          h.includes('action') ||
          h.includes('item')
        ) {
          return true;
        }
        if (!strict && (h.includes('نام') || h.includes('name'))) return true;
        return false;
      };

      let tIdx = rowNorm.findIndex((h, idx) => idx !== cIdx && isTitleKeyword(h, true));
      if (tIdx === -1) {
        tIdx = rowNorm.findIndex((h, idx) => idx !== cIdx && isTitleKeyword(h, false));
      }

      const fIdx = rowNorm.findIndex(
        (h, idx) =>
          idx !== cIdx &&
          idx !== tIdx &&
          h &&
          (h.includes('تناوب') || h.includes('دوره') || h.includes('پریود') || h.includes('بازه') || h.includes('تکرار') || h.includes('frequency') || h.includes('period') || h.includes('interval') || h.includes('cycle') || h.includes('freq'))
      );
      const hIdx = rowNorm.findIndex(
        (h, idx) =>
          idx !== cIdx &&
          idx !== tIdx &&
          idx !== fIdx &&
          h &&
          (h.includes('ساعت') || h.includes('مدت') || h.includes('نفر') || h.includes('زمان') || h.includes('hour') || h.includes('duration'))
      );
      const pIdx = rowNorm.findIndex(
        (h, idx) =>
          idx !== cIdx &&
          idx !== tIdx &&
          idx !== fIdx &&
          idx !== hIdx &&
          h &&
          (h.includes('قطعات') || h.includes('قطعه') || h.includes('ابزار') || h.includes('لوازم') || h.includes('مواد') || h.includes('مصرفی') || h.includes('part') || h.includes('tool') || h.includes('spare'))
      );

      const score =
        (tIdx !== -1 ? 4 : 0) +
        (fIdx !== -1 ? 2 : 0) +
        (cIdx !== -1 ? 2 : 0) +
        (hIdx !== -1 ? 1 : 0) +
        (pIdx !== -1 ? 1 : 0);

      if (score > bestHeaderScore && (tIdx !== -1 || (fIdx !== -1 && (cIdx !== -1 || hIdx !== -1)))) {
        bestHeaderScore = score;
        headerRowIdx = r;
        codeColIdx = cIdx;
        titleColIdx = tIdx !== -1 ? tIdx : rowNorm.findIndex((h, idx) => idx !== cIdx && idx !== fIdx && idx !== hIdx && idx !== pIdx && h !== '' && !isPmRowNumberHeader(h) && !isEquipmentMetaHeader(h));
        freqColIdx = fIdx;
        hoursColIdx = hIdx;
        partsColIdx = pIdx;
      }
    }

    const isHeaderRow = headerRowIdx !== -1;
    const startIdx = isHeaderRow ? headerRowIdx + 1 : 0;
    const parsed: any[] = [];

    for (let rIdx = startIdx; rIdx < nonEmptyRows.length; rIdx++) {
      const row = nonEmptyRows[rIdx];
      let rawCode = '';
      let rawTitle = '';
      let freqStr = '';
      let hoursRaw = '';
      let partsRaw = '';

      if (isHeaderRow) {
        rawCode = codeColIdx >= 0 ? String(row[codeColIdx] ?? '').replace(/\r?\n/g, ' ').trim() : '';
        rawTitle = titleColIdx >= 0 ? String(row[titleColIdx] ?? '').replace(/\r?\n/g, ' ').trim() : '';
        freqStr = freqColIdx >= 0 ? String(row[freqColIdx] ?? '').trim() : '';
        hoursRaw = hoursColIdx >= 0 ? String(row[hoursColIdx] ?? '').trim() : '';
        partsRaw = partsColIdx >= 0 ? String(row[partsColIdx] ?? '').replace(/\r?\n/g, ' ').trim() : '';

        // اگر به دلیل Merge شدن سلول‌ها ستون عنوان خالی بود ولی ستون دیگری متن فعالیت دارد، آن را نجات می‌دهیم
        if (!rawTitle) {
          const fallbackCandidate = row
            .map((cell, cIdx) => ({ val: String(cell ?? '').replace(/\r?\n/g, ' ').trim(), cIdx }))
            .filter(item =>
              item.val &&
              item.cIdx !== codeColIdx &&
              item.cIdx !== freqColIdx &&
              item.cIdx !== hoursColIdx &&
              item.cIdx !== partsColIdx &&
              !looksLikeRowIndexCell(item.val) &&
              !isLikelyFrequencyCell(item.val) &&
              !/^[\-—_.,]+$/.test(item.val)
            )
            .sort((a, b) => b.val.length - a.val.length)[0];
          if (fallbackCandidate) {
            rawTitle = fallbackCandidate.val;
          }
        }
      } else {
        // حالت بدون سطر هدر: پاکسازی ستون‌های خالی ابتدا و نادیده گرفتن شماره ردیف (1, 2, 3...)
        const cells = row
          .map(c => String(c ?? '').replace(/\r?\n/g, ' ').trim())
          .filter(Boolean);

        if (cells.length === 0) continue;

        let idxOffset = 0;
        if (cells.length >= 2 && looksLikeRowIndexCell(cells[0])) {
          idxOffset = 1;
        }
        const activeCells = cells.slice(idxOffset);
        if (activeCells.length === 0) continue;

        if (activeCells.length === 1) {
          rawTitle = activeCells[0];
        } else {
          const used = new Set<number>();

          // ۱. پیدا کردن سلول دوره تناوب (مثلاً «یک ساله» یا «سالانه» و نه عنوان طولانی فعالیت)
          const fPos = activeCells.findIndex(c => isLikelyFrequencyCell(c));
          if (fPos !== -1) {
            freqStr = activeCells[fPos];
            used.add(fPos);
          }

          // ۲. پیدا کردن سلول کد فعالیت (مثل ACT-01 یا PM-12) وقتی در ستون دیگری متن توضیحی هست
          const cPos = activeCells.findIndex(
            (c, i) => !used.has(i) && looksLikeActivityCodeToken(c) && !/^\d+(\.\d+)?$/.test(toAsciiDigitsClean(c))
          );
          if (cPos !== -1 && activeCells.some((c, i) => !used.has(i) && i !== cPos && !looksLikeActivityCodeToken(c))) {
            rawCode = activeCells[cPos];
            used.add(cPos);
          }

          // ۳. پیدا کردن ساعت اجرا (عدد خالص یا همراه «ساعت»)
          const hPos = activeCells.findIndex((c, i) => {
            if (used.has(i)) return false;
            const clean = toAsciiDigitsClean(c);
            return /^\d+(\.\d+)?(\s*(ساعت|h|hr|hrs))?$/i.test(clean);
          });

          // ۴. پیدا کردن عنوان اصلی فعالیت (طولانی‌ترین سلول متنی غیر از دوره/کد/ساعت)
          const textCandidates = activeCells
            .map((val, i) => ({ val, i }))
            .filter(item => !used.has(item.i) && item.i !== hPos);

          if (textCandidates.length > 0) {
            rawTitle = textCandidates[0].val;
            used.add(textCandidates[0].i);
            if (hPos !== -1) {
              hoursRaw = activeCells[hPos];
              used.add(hPos);
            }
            const rest = activeCells.filter((_, i) => !used.has(i));
            if (rest.length > 0) {
              partsRaw = rest.join('، ');
            }
          } else if (hPos !== -1) {
            rawTitle = activeCells[hPos];
          }
        }
      }

      if (!rawTitle && !rawCode) continue;
      if (!rawTitle && rawCode) {
        rawTitle = rawCode;
        rawCode = '';
      }
      if (/^[\-—_.,\s]+$/.test(rawTitle)) continue;
      // رد کردن سطر تکرار شده هدر وسط جدول
      const titleNorm = normalizePmExcelHeader(rawTitle);
      if (['عنوان فعالیت', 'شرح فعالیت', 'نام فعالیت', 'عنوان', 'فعالیت'].includes(titleNorm) && isLikelyFrequencyCell(freqStr) === false && (!hoursRaw || normalizePmExcelHeader(hoursRaw).includes('ساعت'))) {
        continue;
      }

      const hours = parseHoursValue(hoursRaw);
      const freq = isLocked
        ? getPeriodDescriptor(defaultPeriod)
        : parseFrequencyString(freqStr, defaultPeriod);

      parsed.push({
        id: `${idPrefix}-${Date.now()}-${rIdx}-${Math.random().toString(36).slice(2, 6)}`,
        code: rawCode || undefined,
        title: rawTitle,
        frequencyType: freq.type,
        frequencyLabel: freq.label,
        customDays: freq.days,
        estimatedHours: hours,
        partsRequired: partsRaw || undefined,
        isActive: true
      });
    }

    return parsed;
  };

  const scoreSheetForContext = (
    sheetName: string,
    groupId: string | null,
    targetPeriod: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom'
  ) => {
    const s = toAsciiDigitsClean(sheetName).toLowerCase();
    let score = 0;
    const grp = PM_9_GROUPS.find(g => g.id === groupId);
    if (grp) {
      if (s.includes(grp.name.toLowerCase()) || s.includes(grp.enName.toLowerCase())) {
        score += 10;
      }
    }
    if (targetPeriod === 'annual' && (s.includes('سال') || s.includes('annual') || s.includes('365') || s.includes('12 ماه'))) score += 8;
    if (targetPeriod === 'biannual' && (s.includes('6') || s.includes('شش') || s.includes('نیم') || s.includes('biannual'))) score += 8;
    if (targetPeriod === 'quarterly' && (s.includes('3') || s.includes('سه') || s.includes('فصل') || s.includes('quarterly'))) score += 8;
    if (targetPeriod === 'bimonthly' && (s.includes('2') || s.includes('دوماه') || s.includes('دو ماه') || s.includes('bimonthly'))) score += 8;
    if (targetPeriod === 'monthly' && (s.includes('ماهانه') || s.includes('monthly') || s.includes('30'))) score += 8;
    return score;
  };

  const handleSelectExcelSheet = (
    sheetName: string,
    sheetsSource?: Array<{ name: string; grid: any[][] }>,
    overridePeriod?: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom',
    overrideLock?: boolean
  ) => {
    const sheets = sheetsSource || excelWorkbookSheets;
    const target = sheets.find(s => s.name === sheetName);
    if (!target) return;
    setExcelSelectedSheet(sheetName);
    const period = overridePeriod || excelTargetPeriod;
    const locked = overrideLock !== undefined ? overrideLock : excelLockToTargetPeriod;
    const res = parsePmActivitiesGrid(target.grid, period, locked, 'act-xl');
    setExcelParsedActivities(res);
    if (res.length === 0) {
      setExcelErrorMsg(`در برگه «${sheetName}» فعالیت معتبری یافت نشد. در صورت نیاز برگه دیگری را انتخاب کنید یا ستون «عنوان فعالیت» را بررسی نمایید.`);
    } else {
      setExcelErrorMsg(null);
    }
  };

  const handleExcelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fileNameLower = file.name.toLowerCase();
    const isTextDelimited = fileNameLower.endsWith('.csv') || fileNameLower.endsWith('.txt') || fileNameLower.endsWith('.tsv');
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) {
          setExcelErrorMsg('فایل اکسل خالی یا غیرقابل خواندن است.');
          return;
        }
        let wb: XLSX.WorkBook;
        if (isTextDelimited && buffer instanceof ArrayBuffer) {
          const bytes = new Uint8Array(buffer);
          let text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
          if (text.includes('\uFFFD')) {
            try {
              text = new TextDecoder('windows-1256').decode(bytes);
            } catch {}
          }
          wb = XLSX.read(text, { type: 'string' });
        } else {
          wb = XLSX.read(buffer, { type: 'array' });
        }

        const extractedSheets: Array<{ name: string; grid: any[][] }> = wb.SheetNames.map(wsname => {
          const ws = wb.Sheets[wsname];
          const grid: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }) as any[][];
          return { name: wsname, grid };
        }).filter(sh => sh.grid.some(r => Array.isArray(r) && r.some(c => String(c ?? '').trim() !== '')));

        if (extractedSheets.length === 0) {
          setExcelWorkbookSheets([]);
          setExcelSelectedSheet('');
          setExcelParsedActivities([]);
          setExcelErrorMsg('فایل اکسل انتخاب‌شده هیچ سطر دارای داده‌ای ندارد.');
          return;
        }

        setExcelWorkbookSheets(extractedSheets);

        // انتخاب هوشمند بهترین شیت (با اولویت نام گروه مثل تورنوس یا دوره مثل سالانه)
        const sortedSheets = [...extractedSheets].sort(
          (a, b) =>
            scoreSheetForContext(b.name, activeCategoryGroupId, excelTargetPeriod) -
            scoreSheetForContext(a.name, activeCategoryGroupId, excelTargetPeriod)
        );

        let chosenSheet = sortedSheets[0];
        let parsed: any[] = [];
        for (const sh of sortedSheets) {
          const res = parsePmActivitiesGrid(sh.grid, excelTargetPeriod, excelLockToTargetPeriod, 'act-xl');
          if (res.length > 0) {
            chosenSheet = sh;
            parsed = res;
            break;
          }
        }

        setExcelSelectedSheet(chosenSheet.name);
        if (parsed.length === 0) {
          setExcelParsedActivities([]);
          setExcelErrorMsg('هیچ فعالیت معتبری در فایل اکسل یافت نشد. مطمئن شوید ستون عنوان فعالیت در فایل پر شده باشد.');
          return;
        }
        setExcelParsedActivities(parsed);
        setExcelErrorMsg(null);
      } catch (err: any) {
        setExcelErrorMsg('خطا در پردازش فایل اکسل: ' + (err?.message || 'فرمت نامعتبر'));
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const handleParsePastedExcelText = (
    text: string,
    overridePeriod?: 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom',
    overrideLock?: boolean
  ) => {
    setExcelPasteText(text);
    const defaultPeriod = overridePeriod || excelTargetPeriod;
    const isLocked = overrideLock !== undefined ? overrideLock : excelLockToTargetPeriod;
    if (!text.trim()) {
      if (excelWorkbookSheets.length > 0 && excelSelectedSheet) {
        handleSelectExcelSheet(excelSelectedSheet, excelWorkbookSheets, defaultPeriod, isLocked);
      } else {
        setExcelParsedActivities([]);
      }
      return;
    }
    try {
      const grid = text
        .trim()
        .split(/\r?\n/)
        .map(line => (line.includes('\t') ? line.split('\t') : line.split(',')));
      const parsed = parsePmActivitiesGrid(grid, defaultPeriod, isLocked, 'act-paste');
      setExcelParsedActivities(parsed);
      setExcelErrorMsg(parsed.length === 0 ? 'متن وارد شده به عنوان فعالیت معتبر شناسایی نشد.' : null);
    } catch (err: any) {
      setExcelErrorMsg('خطا در خواندن متن کپی‌شده: ' + (err?.message || ''));
    }
  };

  const handleImportParsedActivitiesToGroup = (groupId: string) => {
    if (excelParsedActivities.length === 0) {
      setExcelErrorMsg('هیچ فعالیتی برای افزودن یافت نشد.');
      return;
    }
    const todayShamsi = getTodayShamsiString();
    const defaultEndShamsi = addShamsiDays(todayShamsi, 3);
    const enrichedActivities: PMGroupActivityItem[] = excelParsedActivities.map((act, i) => {
      const pKey = act.frequencyType || excelTargetPeriod || 'monthly';
      const periodSched = getPeriodSchedule(groupId, pKey);
      return {
        ...act,
        id: act.id || `act-${groupId}-${Date.now()}-${i}`,
        groupId,
        isActive: true,
        startDate: periodSched?.startDate || act.startDate || todayShamsi,
        endDate: periodSched?.endDate || act.endDate || defaultEndShamsi,
        executionWindowDays: periodSched?.executionWindowDays || act.executionWindowDays || 3,
        isScheduled: periodSched ? periodSched.isScheduled : Boolean(act.isScheduled)
      };
    });

    const openUpdates: Record<string, boolean> = {};
    enrichedActivities.forEach(a => {
      if (a.frequencyType) openUpdates[a.frequencyType] = true;
    });

    setGroupActivities(prev => {
      const next = {
        ...prev,
        [groupId]: [...(prev[groupId] || []), ...enrichedActivities]
      };
      try {
        localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(next));
        fetch('/api/portal/sync-state', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pmGroupActivities: next })
        }).catch(() => {});
      } catch {}
      return next;
    });
    setExpandedScheduleGroup(groupId);
    setOpenPeriodMap(prev => ({ ...prev, ...openUpdates }));
    setBatchSuccessToast(`✓ تعداد ${enrichedActivities.length} فعالیت با موفقیت از اکسل به گروه افزوده شد.`);
    setTimeout(() => setBatchSuccessToast(null), 4000);
    setIsExcelActModalOpen(false);
    setExcelParsedActivities([]);
    setExcelPasteText('');
    setExcelWorkbookSheets([]);
    setExcelSelectedSheet('');
  };

  // اجرای موتور زمان‌بندی تجمعی برای گروه انتخاب‌شده
  const handleGenerateCumulativePMSchedule = (groupId: string) => {
    const group = PM_9_GROUPS.find(g => g.id === groupId);
    if (!group) return;

    const allGroupEqs = getGroupEquipments(groupId);
    const selectedIds = selectedEquipMap[groupId] !== undefined 
      ? selectedEquipMap[groupId] 
      : allGroupEqs.map(e => e.id);
    const targetEquipments = allGroupEqs.filter(e => selectedIds.includes(e.id));

    if (targetEquipments.length === 0) {
      alert('لطفاً حداقل یک تجهیز از این بخش را برای زمان‌بندی انتخاب نمایید.');
      return;
    }

    const groupActs = (groupActivities[groupId] || []).filter(a => a.isActive);
    if (groupActs.length === 0) {
      alert('حداقل یک فعالیت فعال برای صدور برنامه در این بخش مورد نیاز است.');
      return;
    }

    const monthlyActs = groupActs.filter(a => a.frequencyType === 'monthly');
    const quarterlyActs = groupActs.filter(a => a.frequencyType === 'quarterly');
    const biannualActs = groupActs.filter(a => a.frequencyType === 'biannual');
    const annualActs = groupActs.filter(a => a.frequencyType === 'annual');
    const customActs = groupActs.filter(a => a.frequencyType === 'custom');

    const newPlans: any[] = [];
    const newOrders: any[] = [];
    const startDate = cumulStartDate || '1405/08/20';
    const endDate = cumulEndDate || '1406/08/20';
    const totalMonths = calcMonthsBetweenShamsi(startDate, endDate);
    const baseCustomCode = (cumulCustomOrderCode || 'WO-1405').trim();

    targetEquipments.forEach((eq, eqIdx) => {
      const shortEq = (eq.id || eq.name).substring(0, 6).toUpperCase().replace(/[^A-Z0-9]/g, '');

      // چرخه تجمعی ماه‌ها از تاریخ شروع تا تاریخ پایان بر اساس قانون اعلامی کاربر:
      // ماهانه در هر ماه اجرا می‌شود.
      // سررسید ۳ ماهه -> فعالیت‌های ۳ ماهه به فعالیت‌های ماهانه اضافه می‌شود.
      // سررسید ۶ ماهه -> فعالیت‌های ۶ ماهه به ۳ ماهه و ماهانه اضافه می‌شود.
      // سررسید سالانه -> تمام سطوح فعالیت (ماهانه + ۳ ماهه + ۶ ماهه + سالانه) با هم تجمیع می‌شوند.
      for (let m = 1; m <= totalMonths; m++) {
        const dueDate = addShamsiMonths(startDate, m);
        let accumulatedActs: PMGroupActivityItem[] = [];
        let tierLabel = '';

        if (m % 12 === 0) {
          accumulatedActs = [...monthlyActs, ...quarterlyActs, ...biannualActs, ...annualActs];
          tierLabel = 'سالانه (تجمعی: ماهانه + ۳ ماهه + ۶ ماهه + سالانه)';
        } else if (m % 6 === 0) {
          accumulatedActs = [...monthlyActs, ...quarterlyActs, ...biannualActs];
          tierLabel = '۶ ماهه (تجمعی: ماهانه + ۳ ماهه + ۶ ماهه)';
        } else if (m % 3 === 0) {
          accumulatedActs = [...monthlyActs, ...quarterlyActs];
          tierLabel = '۳ ماهه (تجمعی: ماهانه + ۳ ماهه)';
        } else {
          accumulatedActs = [...monthlyActs];
          tierLabel = 'ماهانه ادواری';
        }

        if (accumulatedActs.length > 0) {
          const totalHours = accumulatedActs.reduce((s, a) => s + (a.estimatedHours || 1), 0);
          const planId = `PM-${shortEq}-M${String(m).padStart(2, '0')}-${eqIdx + 1}`;
          const orderCode = `${baseCustomCode}-${shortEq}-M${String(m).padStart(2, '0')}`;

          newPlans.push({
            id: planId,
            title: `برنامه PM ${eq.name} (${tierLabel}) - دوره ${m}`,
            equipment: `${eq.name} (${eq.id})`,
            equipmentId: eq.id,
            equipmentCode: eq.id,
            department: 'نگهداری و تعمیرات پیشگیرانه',
            type: 'برنامه‌ریزی زمانی تجمعی',
            cDays: m * 30,
            cHours: 0,
            dDays: 0,
            dHours: totalHours,
            frequency: tierLabel,
            activities: accumulatedActs.map(a => a.title),
            activitiesCount: accumulatedActs.length,
            monthIndex: m,
            isCumulative: m % 3 === 0
          });

          // هر فعالیت یک کد سیستمی می‌گیرد و کد کامل تشکیل می‌شود
          const activitiesWithCodes = accumulatedActs.map((a, aIdx) => {
            const actCode = a.code || `ACT-${String(aIdx + 1).padStart(2, '0')}`;
            const fullCode = `${orderCode}/${actCode}`;
            return {
              code: actCode,
              fullCode: fullCode,
              title: a.title,
              frequency: a.frequencyLabel,
              done: false
            };
          });

          newOrders.push({
            id: orderCode,
            customOrderCode: baseCustomCode,
            equipment: eq.name,
            equipmentCode: eq.id,
            title: `سرویس ${tierLabel}: ${eq.name}`,
            dueDate: dueDate,
            assignedTo: 'در انتظار اعزام و ثبت مجریان',
            assignedTechs: [],
            priority: m % 6 === 0 ? 'بحرانی' : m % 3 === 0 ? 'مهم' : 'عادی',
            status: 'pending',
            createdDate: startDate,
            planRef: planId,
            activities: activitiesWithCodes,
            estimatedHours: totalHours,
            category: group.name
          });
        }
      }

      // فعالیت‌های سفارشی کوتاه‌مدت (مثلاً ۳ روزه)
      if (cumulIncludeCustomDays && customActs.length > 0) {
        customActs.forEach((cAct, cIdx) => {
          const stepDays = Math.max(1, cAct.customDays || 3);
          const maxOcc = Math.min(10, Math.floor(30 / stepDays));
          for (let occ = 1; occ <= maxOcc; occ++) {
            const occDueDate = addShamsiDays(startDate, occ * stepDays);
            const customPlanId = `PM-${shortEq}-CUS${stepDays}D-${occ}-${eqIdx + 1}`;
            const customOrderCode = `${baseCustomCode}-${shortEq}-D${stepDays}-${occ}`;
            const actCode = cAct.code || `ACT-${String(cIdx + 1).padStart(2, '0')}`;
            const fullCode = `${customOrderCode}/${actCode}`;
            
            newPlans.push({
              id: customPlanId,
              title: `برنامه دوره‌ای ${cAct.title} (${eq.name}) - هر ${stepDays} روز`,
              equipment: `${eq.name} (${eq.id})`,
              equipmentId: eq.id,
              equipmentCode: eq.id,
              department: 'نگهداری و تعمیرات پیشگیرانه',
              type: `دوره تناوب سفارشی (${stepDays} روزه)`,
              cDays: stepDays,
              cHours: 0,
              dDays: 0,
              dHours: cAct.estimatedHours || 1,
              frequency: `${stepDays} روزه سفارشی`,
              activities: [cAct.title],
              activitiesCount: 1,
              monthIndex: 0,
              isCumulative: false
            });

            newOrders.push({
              id: customOrderCode,
              customOrderCode: baseCustomCode,
              equipment: eq.name,
              equipmentCode: eq.id,
              title: `سرویس دوره‌ای (${stepDays} روزه): ${cAct.title} (${eq.name})`,
              dueDate: occDueDate,
              assignedTo: 'در انتظار اعزام و ثبت مجریان',
              assignedTechs: [],
              priority: 'عادی',
              status: 'pending',
              createdDate: startDate,
              planRef: customPlanId,
              activities: [{
                code: actCode,
                fullCode: fullCode,
                title: cAct.title,
                frequency: `${stepDays} روزه`,
                done: false
              }],
              estimatedHours: cAct.estimatedHours || 1,
              category: group.name
            });
          }
        });
      }
    });

    const updatedPlans = [...newPlans, ...pmPlans];
    const updatedOrders = [...newOrders, ...workOrders];

    setPmPlans(updatedPlans);
    setWorkOrders(updatedOrders);
    try {
      localStorage.setItem('pm_studio_plans_v15', JSON.stringify(updatedPlans));
      localStorage.setItem('pm_studio_work_orders_v15', JSON.stringify(updatedOrders));
    } catch {}

    setBatchSuccessToast(`✓ با موفقیت تعداد ${newOrders.length} دستورکار تجمعی برای ${targetEquipments.length} تجهیز با کد پایه «${baseCustomCode}» صادر گردید (از تاریخ ${startDate} تا ${endDate}).`);
    setTimeout(() => setBatchSuccessToast(null), 7000);
    setPmScheduleTab('orders');
  };
  const [singlePlanData, setSinglePlanData] = useState({
    id: '', title: '', equipment: '', department: 'نگهداری و تعمیرات', type: 'برنامه ریزی زمانی', cDays: 30, cHours: 0, dDays: 0, dHours: 2, frequency: 'یک ماهه'
  });
  const [batchFormData, setBatchFormData] = useState({
    equipment: '', frequencies: { monthly: true, quarterly: true, biannual: false, annual: false }, department: 'نگهداری و تعمیرات', type: 'برنامه ریزی زمانی'
  });
  // متغیرهای وضعیت برای انتخاب چندگانه و سرچ گروهی تجهیزات در برنامه‌ریزی PM (درخواست کاربر)
  const [batchSelectedEqIds, setBatchSelectedEqIds] = useState<string[]>([]);
  const [batchEqSearch, setBatchEqSearch] = useState<string>('');
  const [batchLocationFilter, setBatchLocationFilter] = useState<string>('all');
  const [batchFamilyFilter, setBatchFamilyFilter] = useState<string>('all');
  const [batchAssignedTech, setBatchAssignedTech] = useState<string>('');
  const [batchSuccessToast, setBatchSuccessToast] = useState<string | null>(null);

  const [isPlanDetailsModalOpen, setIsPlanDetailsModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [planDetailsTab, setPlanDetailsTab] = useState<'details' | 'equipment' | 'activities'>('details');

  // --- Inventory (سامانه یکپارچه انبار قطعات کارخانه - مشترک PM و خدمات فنی) ---
  const [inventoryList, setInventoryList] = useState<UnifiedSparePart[]>(() => getUnifiedSpareParts());
  const [inventorySourceFilter, setInventorySourceFilter] = useState<SparePartFilterSource>('all');
  const [inventoryCategoryFilter, setInventoryCategoryFilter] = useState<string>('all');
  const [inventorySearch, setInventorySearch] = useState('');
  const [isAddInventoryModalOpen, setIsAddInventoryModalOpen] = useState(false);
  const [newPmPartForm, setNewPmPartForm] = useState({
    name: '',
    category: 'مکانیکی' as SparePartCategory,
    source: 'pm' as SparePartSource,
    stock: 5,
    minStock: 2,
    unit: 'عدد',
    price: '',
    eqFamily: 'پرس‌های هیدرولیک',
    location: '',
    notes: ''
  });

  // اشتراک در بروزرسانی‌های انبار یکپارچه جهت همگام‌سازی لحظه‌ای با خدمات فنی
  useEffect(() => {
    const unsub = subscribeToSpareParts(parts => {
      setInventoryList(parts);
    });
    return () => unsub();
  }, []);

  const handlePmStockChange = (id: string, delta: number) => {
    const updated = adjustSparePartStock(id, delta);
    setInventoryList(updated);
  };

  const handlePmDeletePart = (id: string) => {
    if (window.confirm('آیا از حذف این قطعه یدکی از انبار اطمینان دارید؟')) {
      const updated = deleteSparePart(id);
      setInventoryList(updated);
    }
  };

  const handleCreatePmPart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPmPartForm.name.trim()) return;
    addOrUpdateSparePart({
      name: newPmPartForm.name.trim(),
      category: newPmPartForm.category,
      source: newPmPartForm.source,
      stock: Math.max(0, Number(newPmPartForm.stock) || 0),
      minStock: Math.max(0, Number(newPmPartForm.minStock) || 0),
      unit: newPmPartForm.unit.trim() || 'عدد',
      price: newPmPartForm.price.trim() || '—',
      eqFamily: newPmPartForm.eqFamily.trim() || (newPmPartForm.source === 'pm' ? 'تجهیزات PM' : 'خدمات فنی'),
      location: newPmPartForm.location.trim() || 'انبار مرکزی PM',
      notes: newPmPartForm.notes.trim() || ''
    });
    setIsAddInventoryModalOpen(false);
    setNewPmPartForm({
      name: '',
      category: 'مکانیکی',
      source: 'pm',
      stock: 5,
      minStock: 2,
      unit: 'عدد',
      price: '',
      eqFamily: 'پرس‌های هیدرولیک',
      location: '',
      notes: ''
    });
  };

  const exportPmInventoryToCsv = () => {
    try {
      const filtered = inventoryList.filter(item => {
        if (inventorySourceFilter !== 'all' && item.source !== inventorySourceFilter) return false;
        if (inventoryCategoryFilter !== 'all' && item.category !== inventoryCategoryFilter) return false;
        if (inventorySearch.trim()) {
          const q = inventorySearch.trim().toLowerCase();
          return item.name.toLowerCase().includes(q) || (item.code || '').toLowerCase().includes(q) || (item.eqFamily || '').toLowerCase().includes(q);
        }
        return true;
      });

      const headers = ['ردیف', 'شناسه قطعه', 'نام قطعه یدکی', 'منبع / بخش', 'گروه', 'موجودی', 'حداقل سفارش', 'واحد', 'وضعیت', 'قیمت (تومان)', 'خانواده مرتبط', 'محل انبار'];
      const rows = filtered.map((item, idx) => {
        const src = item.source === 'pm' ? 'نگهداری پیشگیرانه PM' : item.source === 'technical' ? 'خدمات فنی' : 'مشترک';
        const st = item.stock === 0 ? 'ناموجود' : item.stock <= item.minStock ? 'رو به اتمام' : 'موجودی کافی';
        return [
          idx + 1,
          `"${item.code || item.id}"`,
          `"${item.name}"`,
          `"${src}"`,
          `"${item.category}"`,
          item.stock,
          item.minStock,
          `"${item.unit}"`,
          `"${st}"`,
          `"${item.price || '—'}"`,
          `"${item.eqFamily || '—'}"`,
          `"${item.location || '—'}"`
        ];
      });

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pm_inventory_${inventorySourceFilter}_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    }
  };

  // --- Execution & Report ---
  const [isExecutionModalOpen, setIsExecutionModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [executionData, setExecutionData] = useState({
    startDate: '', startTime: '', endDate: '', endTime: '', status: 'completed',
    activities: [] as Array<{ code?: string; fullCode?: string; text: string; done: boolean; title?: string }>,
    personnel: [] as string[],
    parts: [] as string[],
    handover: { receiver: '', approved: true },
    notes: ''
  });

  // --- Reports ---
  const [reportTab, setReportTab] = useState<'dashboard' | 'activities'>('dashboard');
  const [activitiesReportTab, setActivitiesReportTab] = useState<'general' | 'detailed'>('general');
  const [reportSearchQuery, setReportSearchQuery] = useState('');

  // Auto-Save to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('pm_studio_techs_v2', JSON.stringify(techniciansList));
      localStorage.setItem('pm_studio_equipments_v13', JSON.stringify(equipmentList));
      localStorage.setItem('pm_studio_families_v2', JSON.stringify(familyList));
      localStorage.setItem('pm_studio_work_orders_v2', JSON.stringify(workOrders));
      localStorage.setItem('pm_studio_plans_v2', JSON.stringify(pmPlans));
    } catch {}
  }, [techniciansList, equipmentList, familyList, workOrders, pmPlans]);

  // Handlers
  const openExecutionModal = (order: any) => {
    setSelectedOrder(order);
    const now = new Date();
    const today = new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
    const time = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' }).format(now);
    
    // کدهای سیستمی فعالیت‌ها و کد کامل
    const acts = (order.activities && order.activities.length > 0)
      ? order.activities.map((a: any, idx: number) => ({
          code: a.code || `ACT-${String(idx + 1).padStart(2, '0')}`,
          fullCode: a.fullCode || `${order.id}/ACT-${String(idx + 1).padStart(2, '0')}`,
          text: a.title || a.text || 'سرویس و بازرسی دوره‌ای',
          done: a.done !== undefined ? a.done : true
        }))
      : (order.plannedActivities ? JSON.parse(JSON.stringify(order.plannedActivities)) : [
          { code: 'ACT-01', fullCode: `${order.id}/ACT-01`, text: 'بازدید چشمی و کنترل گیج‌ها', done: true },
          { code: 'ACT-02', fullCode: `${order.id}/ACT-02`, text: 'روانکاری و سرویس دوره‌ای', done: true },
          { code: 'ACT-03', fullCode: `${order.id}/ACT-03`, text: 'تست عملکردی نهایی و تحویل دستگاه', done: true }
        ]);

    const existingTechs = Array.isArray(order.assignedTechs) && order.assignedTechs.length > 0
      ? order.assignedTechs
      : (order.assignedTo && !order.assignedTo.includes('در انتظار') ? [order.assignedTo] : []);

    setExecutionData({
      startDate: order.dueDate || today,
      startTime: '08:00',
      endDate: order.dueDate || today,
      endTime: time,
      status: 'completed',
      activities: acts,
      personnel: existingTechs,
      parts: [],
      handover: { receiver: 'سرپرست تولید', approved: true },
      notes: ''
    });
    setIsExecutionModalOpen(true);
  };

  const submitExecution = () => {
    if (selectedOrder) {
      const actualStart = `${executionData.startDate} ${executionData.startTime}`;
      const actualEnd = `${executionData.endDate} ${executionData.endTime}`;
      const techsText = executionData.personnel.length > 0 ? executionData.personnel.join('، ') : 'تکنسین ثبت نشده';

      setWorkOrders(orders => orders.map(order => 
        order.id === selectedOrder.id 
          ? { 
              ...order, 
              status: 'completed', 
              actualStartDate: actualStart,
              actualEndDate: actualEnd,
              completedDate: actualEnd,
              assignedTechs: executionData.personnel,
              assignedTo: techsText,
              activities: executionData.activities.map(a => ({
                code: a.code,
                fullCode: a.fullCode,
                title: a.text,
                done: a.done
              })),
              executionDetails: executionData 
            } 
          : order
      ));

      setBatchSuccessToast(`✓ دستورکار «${selectedOrder.id}» با موفقیت ثبت و بسته شد.`);
      setTimeout(() => setBatchSuccessToast(null), 5000);
    }
    setIsExecutionModalOpen(false);
    setSelectedOrder(null);
  };

  const openReportModal = (order: any) => {
    setSelectedOrder(order);
    setIsReportModalOpen(true);
  };

  const saveTechnician = () => {
    if (!newTechData.name.trim()) return;
    const newTech = { 
      id: Date.now(), 
      name: newTechData.name.trim(), 
      role: newTechData.role || 'تکنسین نگهداری و تعمیرات', 
      image: newTechData.image, 
      status: 'available', 
      completedTasks: 0, 
      workHours: 0, 
      lastAction: 'تازه اضافه شده' 
    };
    setTechniciansList([...techniciansList, newTech]);
    setIsTechModalOpen(false);
  };

  const saveEquipment = () => {
    if (!eqFormData.id.trim() || !eqFormData.name.trim()) return;
    if (isEditingEq) {
      setEquipmentList(list => list.map(eq => eq.id === eqFormData.id ? eqFormData : eq));
    } else {
      setEquipmentList(list => [...list, eqFormData]);
    }
    setIsEqModalOpen(false);
  };

  const deleteEquipment = (id: string) => setEquipmentList(list => list.filter(eq => eq.id !== id));

  const saveFamily = () => {
    if (!famFormData.id.trim() || !famFormData.name.trim()) return;
    if (isEditingFam) {
      setFamilyList(list => list.map(f => f.id === famFormData.id ? famFormData : f));
    } else {
      setFamilyList(list => [...list, famFormData]);
    }
    setIsFamModalOpen(false);
  };

  const deleteFamily = (id: string) => setFamilyList(list => list.filter(f => f.id !== id));

  const saveSinglePlan = () => {
    if (!singlePlanData.id.trim() || !singlePlanData.title.trim()) return;
    setPmPlans([...pmPlans, singlePlanData]);
    setIsPlanModalOpen(false);
    setSinglePlanData({ id: '', title: '', equipment: '', department: 'نگهداری و تعمیرات', type: 'برنامه ریزی زمانی', cDays: 30, cHours: 0, dDays: 0, dHours: 2, frequency: 'یک ماهه' });
  };

  const generateBatchPlans = () => {
    // استخراج لیست تجهیزات هدف (چندتایی یا تکی)
    let targetEquipments: any[] = [];
    if (batchSelectedEqIds.length > 0) {
      targetEquipments = equipmentList.filter(eq => batchSelectedEqIds.includes(eq.id));
    } else if (batchFormData.equipment) {
      const found = equipmentList.find(eq => eq.name === batchFormData.equipment || eq.id === batchFormData.equipment);
      if (found) targetEquipments = [found];
      else targetEquipments = [{ id: 'EQ-01', name: batchFormData.equipment, location: 'سالن تولید', family: 'عمومی' }];
    }

    if (targetEquipments.length === 0) {
      alert('لطفاً حداقل یک تجهیز را از لیست جستجو تیک بزنید یا انتخاب فرمایید.');
      return;
    }

    const hasAnyFreq = Object.values(batchFormData.frequencies).some(Boolean);
    if (!hasAnyFreq) {
      alert('لطفاً حداقل یک دوره تناوب (مثلاً یک ماهه یا سه ماهه) را انتخاب کنید.');
      return;
    }

    const newPlans: any[] = [];
    const newWorkOrders: any[] = [];
    const freqMap: Record<string, { label: string; code: string; days: number; hours: number }> = { 
      monthly: { label: 'یک ماهه', code: '01', days: 30, hours: 2 }, 
      quarterly: { label: 'سه ماهه', code: '03', days: 90, hours: 3 }, 
      biannual: { label: 'شش ماهه', code: '06', days: 180, hours: 4 }, 
      annual: { label: 'سالانه', code: '12', days: 365, hours: 6 } 
    };

    targetEquipments.forEach((eq, eqIdx) => {
      Object.entries(batchFormData.frequencies).forEach(([key, isChecked]) => {
        if (isChecked) {
          const freqInfo = freqMap[key];
          const shortEqName = (eq.id || eq.name).substring(0, 5).toUpperCase().replace(/[^A-Z0-9]/g, '');
          const randNum = Math.floor(Math.random() * 90) + 10;
          const planId = `PM-${shortEqName || 'EQ'}${freqInfo.code}-${randNum}-${eqIdx + 1}`;
          
          newPlans.push({ 
            id: planId, 
            title: `برنامه پیشگیرانه ${eq.name} (${freqInfo.label})`, 
            equipment: `${eq.name} (${eq.id})`,
            equipmentId: eq.id,
            equipmentCode: eq.id,
            department: batchFormData.department, 
            type: batchFormData.type, 
            cDays: freqInfo.days, 
            cHours: 0, 
            dDays: 0, 
            dHours: freqInfo.hours,
            frequency: freqInfo.label
          });

          // همچنین صدور بلادرنگ دستورکار نگهداری پیشگیرانه در جدول دستورکارهای باز
          const nextDayNum = Math.min(30, 10 + ((newPlans.length * 2) % 20));
          const assignedTechnician = batchAssignedTech || (techniciansList.length > 0 ? techniciansList[newPlans.length % techniciansList.length]?.name : '');
          
          newWorkOrders.push({
            id: `WO-${planId}`,
            equipment: eq.name,
            equipmentCode: eq.id,
            title: `سرویس ادواری و بازرسی پیشگیرانه: ${eq.name} (${freqInfo.label})`,
            dueDate: `1405/08/${String(nextDayNum).padStart(2, '0')}`,
            assignedTo: assignedTechnician,
            priority: eq.priority === 'سطح A' ? 'بحرانی' : eq.priority === 'سطح B' ? 'مهم' : 'عادی',
            status: 'pending',
            createdDate: '1405/08/12',
            planRef: planId
          });
        }
      });
    });

    const updatedPlans = [...newPlans, ...pmPlans];
    const updatedOrders = [...newWorkOrders, ...workOrders];

    setPmPlans(updatedPlans);
    setWorkOrders(updatedOrders);
    try {
      localStorage.setItem('pm_studio_plans_v15', JSON.stringify(updatedPlans));
      localStorage.setItem('pm_studio_work_orders_v15', JSON.stringify(updatedOrders));
    } catch {}

    setBatchSuccessToast(`✓ با موفقیت تعداد ${newPlans.length} برنامه PM و دستورکار پیشگیرانه برای ${targetEquipments.length} تجهیز انتخاب‌شده صادر و زمان‌بندی گردید.`);
    setTimeout(() => setBatchSuccessToast(null), 6000);

    setIsPlanModalOpen(false);
    setBatchSelectedEqIds([]);
    setBatchEqSearch('');
    setBatchFormData({ equipment: '', frequencies: { monthly: true, quarterly: true, biannual: false, annual: false }, department: 'نگهداری و تعمیرات', type: 'برنامه ریزی زمانی' });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': 
        return <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_10px_rgba(16,185,129,0.2)]"><CheckCircle2 size={13}/> انجام شده</span>;
      case 'overdue': 
        return <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30 shadow-[0_0_10px_rgba(244,63,94,0.2)]"><AlertTriangle size={13}/> سررسید شده</span>;
      case 'failed': 
        return <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-orange-500/10 text-orange-400 border border-orange-500/30"><XCircle size={13}/> عدم انطباق</span>;
      default: 
        return <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30"><Clock size={13}/> در انتظار</span>;
    }
  };

  const renderCalendarDays = () => {
    const days = [];
    const weekDays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    weekDays.forEach(day => days.push(<div key={`h-${day}`} className="text-center text-xs font-bold text-slate-500 py-1.5">{day}</div>));
    
    // تعداد روزهای خالی اول ماه بر اساس تقویم واقعی و دقیق خورشیدی
    const emptyCount = getPersianFirstDayOfMonth(calendarYear, calendarMonth);
    for (let i = 0; i < emptyCount; i++) {
      days.push(<div key={`e-${i}`} className="p-1"></div>);
    }

    const daysInMonth = getDaysInJalaliMonth(calendarYear, calendarMonth);
    const isCurrentMonth = (calendarYear === currentShamsiToday.year && calendarMonth === currentShamsiToday.month);
    const todayNum = isCurrentMonth ? currentShamsiToday.day : -1;

    // استخراج روزهای دارای برنامه PM برای نمایش خلاصه در تقویم
    const scheduledDaysMap: Record<number, ScheduledCalendarEvent[]> = {};

    Object.entries(groupActivities).forEach(([gId, actList]) => {
      const grp = PM_9_GROUPS.find(g => g.id === gId);
      const grpDisplayName = grp ? grp.name : gId;

      actList.forEach(act => {
        if (!act.isActive || !act.isScheduled || !act.startDate) return;
        const dateStr = act.startDate || '1405/08/15';
        const parts = dateStr.split('/').map(p => parseInt(p.trim(), 10));
        if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
          const [sYear, sMonth, sDay] = parts;

          let matches = false;
          if (sYear === calendarYear && sMonth === calendarMonth) {
            matches = true;
          } else if (calendarYear > sYear || (calendarYear === sYear && calendarMonth >= sMonth)) {
            const diffMonths = (calendarYear - sYear) * 12 + (calendarMonth - sMonth);
            const freqInterval = act.frequencyType === 'monthly' ? 1
              : act.frequencyType === 'bimonthly' ? 2
              : act.frequencyType === 'quarterly' ? 3
              : act.frequencyType === 'biannual' ? 6
              : act.frequencyType === 'annual' ? 12
              : 0;
            if (freqInterval > 0 && diffMonths % freqInterval === 0) {
              matches = true;
            }
          }

          if (matches && sDay >= 1 && sDay <= daysInMonth) {
            const cleanFreq = act.frequencyLabel
              ? act.frequencyLabel.split('(')[0].trim()
              : (act.frequencyType === 'monthly' ? 'ماهانه' 
                 : act.frequencyType === 'bimonthly' ? 'دوماهه'
                 : act.frequencyType === 'quarterly' ? '۳ ماهه' 
                 : act.frequencyType === 'biannual' ? '۶ ماهه' 
                 : 'سالانه');

            if (!scheduledDaysMap[sDay]) {
              scheduledDaysMap[sDay] = [];
            }
            const existingEv = scheduledDaysMap[sDay].find(
              e => e.groupId === gId && e.periodKey === act.frequencyType
            );
            if (existingEv) {
              if (!existingEv.acts.some(a => a.id === act.id)) {
                existingEv.acts.push(act);
              }
            } else {
              scheduledDaysMap[sDay].push({
                groupId: gId,
                groupName: grpDisplayName,
                periodKey: act.frequencyType,
                periodLabel: cleanFreq,
                act,
                acts: [act]
              });
            }
          }
        }
      });
    });

    for (let i = 1; i <= daysInMonth; i++) {
      const dayEvents = scheduledDaysMap[i] || [];
      const hasSchedule = dayEvents.length > 0;
      const isToday = i === todayNum;
      let dayClass = "relative flex items-center justify-center h-8 w-8 mx-auto rounded-xl text-xs font-bold transition-all duration-300 z-10 ";
      let containerClass = "p-0.5 relative group cursor-pointer flex items-center justify-center";
      let glowEffect = null;
      
      if (hasSchedule) {
        dayClass += "bg-rose-500/20 text-rose-300 border border-rose-500/60 hover:bg-rose-500/35 shadow-[0_0_12px_rgba(244,63,94,0.4)]";
        glowEffect = <div className="absolute inset-0.5 rounded-xl bg-rose-500/25 blur-md -z-10 group-hover:bg-rose-500/50 transition-all animate-pulse"></div>;
      } else {
        dayClass += "text-slate-400 hover:bg-[#101d3b] hover:text-slate-200 border border-transparent";
      }

      if (isToday) {
        dayClass += " ring-2 ring-purple-500 ring-offset-2 ring-offset-[#070e22] bg-purple-500/30 text-purple-200 border-purple-500 shadow-[0_0_14px_rgba(168,85,247,0.6)]";
        glowEffect = <div className="absolute inset-0.5 rounded-xl bg-purple-500/35 blur-md -z-10 group-hover:bg-purple-500/60 transition-all"></div>;
      }

      days.push(
        <div 
          key={`d-${i}`} 
          className={containerClass}
          onMouseEnter={(e) => {
            if (!hasSchedule) return;
            clearCalPopoverTimer();
            const rect = e.currentTarget.getBoundingClientRect();
            const popoverWidth = 256;
            const centerX = rect.left + rect.width / 2;
            const clampedLeft = Math.max(
              12,
              Math.min(window.innerWidth - popoverWidth - 12, centerX - popoverWidth / 2)
            );
            const spaceBelow = window.innerHeight - rect.bottom;
            const placement: 'bottom' | 'top' = spaceBelow >= 190 || rect.top < 190 ? 'bottom' : 'top';
            const top = placement === 'bottom' ? rect.bottom + 8 : rect.top - 8;
            setHoveredCalendarDay({
              day: i,
              events: dayEvents,
              top,
              left: clampedLeft,
              placement,
            });
          }}
          onMouseLeave={() => {
            if (hasSchedule) scheduleCloseCalPopover();
          }}
          onClick={() => {
            if (dayEvents.length === 1) {
              setHoveredCalendarDay(null);
              handleOpenThreeTabPmWorkOrder(dayEvents[0].groupId, dayEvents[0].act, dayEvents[0].periodKey);
            }
          }}
        >
          {glowEffect}
          <div className={dayClass}>{toFaDigits(i)}</div>
        </div>
      );
    }
    return days;
  };

  return (
    <div dir="rtl" className={`flex h-screen overflow-hidden text-[#E6EDF3] font-sans antialiased relative bg-transparent ${
      systemTheme === 'light' ? 'text-slate-800' : 'text-[#E6EDF3]'
    }`}>
      {/* پس‌زمینه اختصاصی ارسالی کاربر با لود فوق‌سریع و تعویض آنی بدون لگ */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 select-none bg-[#050608]">
        {/* لایه تم تیره: عکس مشکی نقره‌ای شیک ارسالی کاربر */}
        <div 
          className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-300 ease-in-out section-bg-dark ${
            systemTheme === 'dark' ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
          style={{ 
            backgroundImage: `url('/assets/aistudio/bg-silver-dark.webp')`,
            backgroundColor: '#08090d'
          }}
        />
        {/* لایه تم روشن: عکس سفید نقره‌ای شیک ارسالی کاربر */}
        <div 
          className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-300 ease-in-out section-bg-light ${
            systemTheme === 'light' ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
          style={{ 
            backgroundImage: `url('/assets/aistudio/bg-silver-light.webp')`,
            backgroundColor: '#f8fafc'
          }}
        />
      </div>
      
      {/* ========================================== */}
      {/* --- Overlay (لایه تاریک‌کننده پس‌زمینه) --- */}
      {/* ========================================== */}
      <div 
        className={`fixed inset-0 bg-black/70 z-40 transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} 
        onClick={() => setIsSidebarOpen(false)} 
      />

      {/* دکمه شناور لبه راست جهت باز کردن سریع نوار ابزار PM */}
      <button
        type="button"
        onClick={() => setIsSidebarOpen(true)}
        className="fixed right-0 top-1/2 -translate-y-1/2 z-40 bg-gradient-to-l from-purple-700 via-indigo-600 to-purple-600 text-white py-4 px-2.5 rounded-l-2xl shadow-2xl shadow-purple-950/90 border-t border-b border-l border-purple-400/60 hover:px-3.5 hover:shadow-purple-500/40 transition-all flex flex-col items-center gap-2 group cursor-pointer"
        title="باز کردن نوار ابزار PM"
      >
        <Menu className="w-5 h-5 group-hover:scale-110 transition-transform text-white" />
        <span className="text-[11px] font-black tracking-wider [writing-mode:vertical-rl] rotate-180 text-purple-100">
          نوار ابزار PM
        </span>
        <span className="w-2 h-2 rounded-full bg-purple-300 animate-pulse shadow-[0_0_8px_#c084fc]"></span>
      </button>

{/* ========================================== */}
      {/* --- Sidebar Container (بدنه اصلی منو) --- */}
      {/* ========================================== */}
      <aside 
        className={`fixed inset-y-0 right-0 z-50 w-64 bg-[#0a1228]/95 backdrop-blur-xl border-l border-indigo-500/25 transition-transform transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'} flex flex-col justify-between shadow-2xl`}
      >
        <div>
          {/* --- Sidebar Header (هدر و لوگو) --- */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-indigo-900/40">
            <div className="flex items-center gap-3">
              {/* آیکون درخشان لوگو */}
              <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]">
                <Activity size={18} fill="currentColor" />
              </div>
              <span className="text-lg font-bold text-slate-100 tracking-wide">PM Studio</span>
            </div>
            
            {/* دکمه بستن منو (ضربدر) */}
            <button 
              className="text-slate-400 hover:text-rose-400 transition-colors bg-[#070e22] p-1.5 rounded-md border border-indigo-500/30 cursor-pointer" 
              onClick={() => setIsSidebarOpen(false)}
              title="بستن منو"
            >
              <X size={18} />
            </button>
          </div>
          
          {/* --- Navigation Links (لینک‌های منو) --- */}
          <nav className="p-4 space-y-1">
            {[
              { id: 'dashboard', name: 'داشبورد هوشمند', icon: Home },
              {
                id: 'workOrders',
                name: 'دستورکارهای PM',
                icon: ClipboardList,
                badge: autoPmWorkOrders.filter(o => !isItemArchivedCheck(o)).length
              },
              { id: 'schedule', name: 'برنامه‌ریزی PM', icon: CalendarIcon },
              { id: 'equipment', name: 'مدیریت تجهیزات', icon: Wrench },
              { id: 'locations', name: 'مدیریت مکان‌ها', icon: MapPin },
              { id: 'inventory', name: 'انبار قطعات', icon: Package },
              { id: 'reports', name: 'گزارش‌گیری تحلیلی', icon: BarChart2 },
              { id: 'settings', name: 'تنظیمات', icon: Settings },
            ].map((item: any) => {
              const isActive = activeView === item.id;
              return (
                <button 
                  key={item.id} 
                  onClick={() => { 
                    setActiveView(item.id as any); 
                    setSelectedFamilyForDetail(null);
                    setIsSidebarOpen(false); // بستن خودکار منو پس از انتخاب
                  }} 
                  className={`w-full flex items-center justify-between gap-3 px-4 py-3 rounded-lg transition-all duration-200 outline-none text-right cursor-pointer
                    ${isActive 
                      ? 'bg-[#132448] text-purple-400 font-medium border border-purple-500/40 shadow-sm' 
                      : 'text-slate-400 hover:bg-[#112042] hover:text-slate-200 border border-transparent'
                    }`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon 
                      size={18} 
                      className={isActive ? "drop-shadow-[0_0_8px_rgba(168,85,247,0.6)]" : ""} 
                    />
                    <span className="text-sm">{item.name}</span>
                  </div>
                  {typeof item.badge === 'number' && item.badge > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-cyan-600/30 border border-cyan-500/40 text-cyan-200 text-[11px] font-mono font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* --- Sidebar Footer (پاورقی منو) --- */}
        <div className="w-full p-4 border-t border-indigo-900/40 bg-[#070e22]/95 backdrop-blur-md space-y-3">
          <button
            type="button"
            onClick={onBackToPortal}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 hover:text-white border border-purple-500/30 text-xs font-bold transition-all cursor-pointer shadow-md"
          >
            <ArrowRight size={14} />
            <span>بازگشت به پرتال اصلی</span>
          </button>
          <div className="flex items-center gap-3 px-2 pt-1 border-t border-indigo-900/30">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-700 to-purple-600 flex items-center justify-center font-medium text-sm text-white border border-purple-400/40 shadow-inner">
              م
            </div>
            <div className="flex flex-col text-right">
              <span className="text-xs font-bold text-slate-200">مدیر سیستم</span>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                آنلاین
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* --- Main Content Area --- */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-transparent relative z-10">
        {/* Top Header */}
        <header className="h-16 bg-[#0c162e]/60 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-4 sm:px-6 z-10 shrink-0">
          <div className="flex-1 flex items-center justify-start gap-4">
            <button 
              type="button"
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-purple-200 hover:text-white transition-all cursor-pointer border border-purple-500/40 bg-purple-600/25 hover:bg-purple-600/40 shadow-md shadow-purple-950/40 group" 
              onClick={() => setIsSidebarOpen(true)}
              title="باز کردن نوار ابزار PM"
            >
              <Menu size={18} className="text-purple-300 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold">نوار ابزار PM</span>
            </button>

            {/* دکمه‌های ناوبری هوشمند بازگشت به فهرست ۹ گروه و بازگشت به داشبورد در کنار دکمه نوار ابزار تا با دکمه وسط صفحه تداخل نکنند */}
            {activeCategoryGroupId !== null ? (
              <button
                type="button"
                onClick={() => setActiveCategoryGroupId(null)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 hover:text-white border border-purple-500/40 text-xs font-bold transition-all cursor-pointer shadow-md"
                title="بازگشت به فهرست ۹ گروه تجهیزات"
              >
                <ArrowRight size={14} />
                <span>بازگشت به لیست ۹ گروه</span>
              </button>
            ) : activeView !== 'dashboard' ? (
              <button
                type="button"
                onClick={() => {
                  setActiveView('dashboard');
                  setActiveCategoryGroupId(null);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 hover:text-white border border-purple-500/40 text-xs font-bold transition-all cursor-pointer shadow-md"
                title="بازگشت به داشبورد اصلی PM"
              >
                <ArrowRight size={14} />
                <span>بازگشت به داشبورد PM</span>
              </button>
            ) : null}
          </div>

          <div className="flex-1"></div>
          
          <div className="flex items-center justify-end gap-3">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center font-bold text-xs text-white border border-purple-400/50 shadow-md">
              PM
            </div>
          </div>
        </header>

        {/* Tab Views Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            
            {/* ======================================================== */}
            {/* VIEW 1: DASHBOARD (activeView === 'dashboard')           */}
            {/* ======================================================== */}
            {activeView === 'dashboard' && (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 z-10 relative">
                  
                  {/* بخش تیم تکنسین‌ها */}
                  <div className="lg:col-span-2 bg-[#0c162e]/40 backdrop-blur-md rounded-2xl border border-white/10 flex flex-col shadow-[0_8px_30px_rgba(0,0,0,0.3)] overflow-hidden">
                    <div className="p-5 sm:p-6 border-b border-white/10 bg-[#070e22]/25 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-xl border border-purple-500/20 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                          <Users size={22} />
                        </div>
                        <div>
                          <h3 className="text-base font-bold text-slate-200">تیم تکنسین‌های فنی</h3>
                          <p className="text-xs text-slate-400 mt-0.5">پایش آنلاین وضعیت پرسنل فنی و آمار کارکرد</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5">
                        <div className="bg-[#070e22]/40 backdrop-blur-sm border border-white/10 text-slate-300 px-3 py-1.5 rounded-lg text-xs font-bold">
                          {techniciansList.length} تکنسین
                        </div>
                        <button 
                          onClick={() => { setNewTechData({ name: '', role: '', image: null }); setIsTechModalOpen(true); }} 
                          className="flex items-center gap-1.5 bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all border border-purple-500/30 hover:border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.1)] cursor-pointer"
                        >
                          <Plus size={15} /> 
                          <span>افزودن تکنسین</span>
                        </button>
                      </div>
                    </div>

                    <div className="p-4 flex-1 overflow-y-auto space-y-3" style={{ maxHeight: '420px' }}>
                      {techniciansList.length === 0 ? (
                        <div className="py-16 text-center flex flex-col items-center gap-3">
                          <div className="p-4 bg-[#070e22]/90 rounded-full border border-indigo-500/20">
                            <Users size={32} className="text-slate-600" />
                          </div>
                          <div className="text-slate-400 text-xs">هیچ تکنسینی در سیستم ثبت نشده است.</div>
                        </div>
                      ) : (
                        techniciansList.map((tech) => {
                          const isBusy = tech.status === 'busy';
                          return (
                            <div 
                              key={tech.id} 
                              onClick={() => setSelectedTechForProfile(tech)}
                              className="bg-[#0c162e]/30 backdrop-blur-sm border border-white/10 hover:border-purple-500/50 hover:bg-[#0c162e]/45 transition-all duration-300 rounded-xl overflow-hidden hover:shadow-[0_0_15px_rgba(168,85,247,0.15)] cursor-pointer group"
                            >
                              <div className="p-3.5 sm:p-4 flex flex-col xl:flex-row items-center justify-between gap-3 sm:gap-4">
                                <div className="flex items-center gap-3.5 w-full xl:w-1/4">
                                  <div className="relative shrink-0">
                                    <div className="w-11 h-11 rounded-full bg-gradient-to-br from-indigo-900 to-purple-900 border-2 border-purple-500/30 flex items-center justify-center text-slate-200 font-bold text-sm overflow-hidden shadow-md">
                                      {tech.image ? (
                                        <img src={tech.image} alt={tech.name} className="w-full h-full object-cover" />
                                      ) : (
                                        tech.name.charAt(0)
                                      )}
                                    </div>
                                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#070e22] ${isBusy ? 'bg-purple-500 animate-pulse' : 'bg-emerald-500'}`}></div>
                                  </div>
                                  <div className="overflow-hidden">
                                    <h4 className="text-xs sm:text-sm font-bold text-slate-200 group-hover:text-purple-300 transition-colors truncate">{tech.name}</h4>
                                  </div>
                                </div>

                                <div className="flex items-center justify-between w-full xl:w-2/4 px-2 sm:px-4 text-xs">
                                  <div className="text-center space-y-0.5 w-1/3">
                                    <div className="text-slate-500 text-[10px]">تکمیل شده:</div>
                                    <div className="text-slate-200 font-bold">{tech.completedTasks} کار</div>
                                  </div>
                                  <div className="text-center space-y-0.5 w-1/3 border-r border-indigo-900/40 pr-2 sm:pr-4">
                                    <div className="text-slate-500 text-[10px]">ساعت کارکرد:</div>
                                    <div className="text-purple-400 font-bold drop-shadow-[0_0_5px_rgba(168,85,247,0.3)]">{tech.workHours} ساعت</div>
                                  </div>
                                  <div className="text-center space-y-0.5 w-1/3 border-r border-indigo-900/40 pr-2 sm:pr-4">
                                    <div className="text-slate-500 text-[10px]">آخرین اقدام:</div>
                                    <div className="text-slate-300 text-[11px] truncate">{tech.lastAction}</div>
                                  </div>
                                </div>

                                <div className="flex items-center justify-end gap-2 w-full xl:w-auto shrink-0">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedTechForProfile(tech);
                                    }}
                                    className="p-2 rounded-lg bg-purple-600/20 hover:bg-purple-600/35 border border-purple-500/40 text-purple-300 hover:text-white transition-all cursor-pointer"
                                    title="مشاهده پروفایل و کارکرد"
                                  >
                                    <Eye size={16} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* تقویم فنری هوشمند رومیزی */}
                  <div className="lg:col-span-1 bg-[#0c162e]/40 backdrop-blur-md rounded-2xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.3)] flex flex-col relative z-20 overflow-visible h-full min-h-[460px]">
                    {/* حلقه‌های فلزی فنری بالای تقویم */}
                    <div className="absolute top-0 inset-x-0 h-4 flex justify-around px-8 z-20">
                      {[1, 2, 3, 4, 5].map(i => (
                        <div key={i} className="w-3 h-7 bg-gradient-to-b from-gray-300 via-gray-100 to-gray-500 rounded-full shadow-[0_2px_5px_rgba(0,0,0,0.9)] -mt-2.5 border border-gray-600 flex items-center justify-center">
                          <div className="w-1 h-full bg-black/25 rounded-full"></div>
                        </div>
                      ))}
                    </div>

                    <div className="p-4 pb-3 bg-[#070e22]/25 border-b border-white/10 text-center pt-7 rounded-t-2xl relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-b from-purple-500/10 to-transparent pointer-events-none"></div>
                      
                      {/* ردیف اول: عنوان و دکمه بازگشت به امروز */}
                      <div className="flex items-center justify-between relative z-10 px-1 mb-2">
                        <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1.5">
                          <Calendar size={13} className="text-purple-400" />
                          <span>تقویم سرویس‌های پیشگیرانه</span>
                        </span>
                        
                        <button
                          type="button"
                          onClick={handleGoToToday}
                          className="text-[10px] bg-purple-500/20 hover:bg-purple-500/35 text-purple-300 hover:text-white px-2 py-0.5 rounded-full border border-purple-500/30 transition-all cursor-pointer font-bold"
                          title="بازگشت به تاریخ امروز"
                        >
                          امروز: {toFaDigits(currentShamsiToday.day)} {PERSIAN_MONTH_NAMES[currentShamsiToday.month - 1]}
                        </button>
                      </div>

                      {/* ردیف دوم: کنترلرهای سال و ماه دقیق خورشیدی تا ۵ سال آینده */}
                      <div className="flex items-center justify-between relative z-10 px-1 gap-1">
                        {/* دکمه ماه بعد */}
                        <button
                          type="button"
                          onClick={handleNextMonth}
                          className="w-7 h-7 rounded-lg bg-[#0c162e] hover:bg-purple-600/30 border border-indigo-500/30 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm"
                          title="ماه بعد"
                        >
                          <ChevronRight size={16} />
                        </button>

                        <div className="flex items-center gap-1.5 flex-1 justify-center">
                          {/* انتخاب ماه */}
                          <select
                            value={calendarMonth}
                            onChange={(e) => setCalendarMonth(parseInt(e.target.value, 10))}
                            className="bg-[#0c162e] border border-indigo-500/30 text-purple-300 font-bold text-xs rounded-lg px-2 py-1 outline-none focus:border-purple-500 cursor-pointer text-center"
                          >
                            {PERSIAN_MONTH_NAMES.map((mName, mIdx) => (
                              <option key={mIdx + 1} value={mIdx + 1}>
                                {mName}
                              </option>
                            ))}
                          </select>

                          {/* انتخاب سال تا ۵ سال آینده (۱۴۰۳ تا ۱۴۱۰) */}
                          <select
                            value={calendarYear}
                            onChange={(e) => setCalendarYear(parseInt(e.target.value, 10))}
                            className="bg-[#0c162e] border border-indigo-500/30 text-slate-100 font-bold font-mono text-xs rounded-lg px-2 py-1 outline-none focus:border-purple-500 cursor-pointer text-center"
                          >
                            {[1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410].map((y) => (
                              <option key={y} value={y}>
                                {toFaDigits(y)}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* دکمه ماه قبل */}
                        <button
                          type="button"
                          onClick={handlePrevMonth}
                          className="w-7 h-7 rounded-lg bg-[#0c162e] hover:bg-purple-600/30 border border-indigo-500/30 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm"
                          title="ماه قبل"
                        >
                          <ChevronLeft size={16} />
                        </button>
                      </div>
                    </div>

                    <div className="p-3.5 flex-1 bg-[#0c162e]/30 backdrop-blur-sm flex flex-col justify-between">
                      <div className="grid grid-cols-7 gap-1">
                        {renderCalendarDays()}
                      </div>

                      <div className="mt-3 pt-3 border-t border-indigo-900/40 text-[11px] text-slate-400 flex items-center justify-between px-1">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_6px_#f43f5e]"></span>
                          <span>روزهای دارای برنامه PM</span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shadow-[0_0_6px_#a855f7]"></span>
                          <span>روز جاری</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* جدول دستورکارها (تب‌بندی شده: باز / بایگانی) */}
                {(() => {
                  const openAutoOrders = autoPmWorkOrders.filter(o => !isItemArchivedCheck(o));
                  const archivedAutoOrders = autoPmWorkOrders.filter(o => isItemArchivedCheck(o));
                  const openLegacyOrders = workOrders.filter(o => ['pending', 'overdue'].includes(o.status));
                  const archivedLegacyOrders = workOrders.filter(o => ['completed', 'failed'].includes(o.status));
                  const activeAutoOrders = workOrderTab === 'open' ? openAutoOrders : archivedAutoOrders;
                  const activeLegacyOrders = workOrderTab === 'open' ? openLegacyOrders : archivedLegacyOrders;

                  return (
                    <div className="bg-[#0c162e]/40 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.3)] mt-8">
                      <div className="p-4 sm:p-5 border-b border-white/10 bg-[#070e22]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex flex-wrap items-center gap-3">
                          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                            <FileText size={18} className="text-purple-400" />
                            <span>دستورکارهای نگهداری پیشگیرانه</span>
                          </h3>
                          <div className="flex items-center gap-1 bg-[#070e22]/40 backdrop-blur-sm p-1 rounded-xl border border-white/10">
                            <button 
                              onClick={() => setWorkOrderTab('open')} 
                              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                workOrderTab === 'open' 
                                  ? 'bg-[#132448] text-purple-400 shadow-sm border border-indigo-500/20' 
                                  : 'text-slate-500 hover:text-slate-300'
                              }`}
                            >
                              دستورکارهای باز ({openAutoOrders.length + openLegacyOrders.length})
                            </button>
                            <button 
                              onClick={() => setWorkOrderTab('archived')} 
                              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                workOrderTab === 'archived' 
                                  ? 'bg-[#132448] text-emerald-400 shadow-sm border border-indigo-500/20' 
                                  : 'text-slate-500 hover:text-slate-300'
                              }`}
                            >
                              بایگانی و تکمیل‌شده ({archivedAutoOrders.length + archivedLegacyOrders.length})
                            </button>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setActiveView('workOrders')}
                          className="px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/35 text-cyan-200 border border-cyan-500/30 text-xs font-bold transition-all cursor-pointer"
                        >
                          نمای کامل کارتابل دستورکارهای PM
                        </button>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-right whitespace-nowrap text-xs">
                          <thead>
                            <tr className="bg-[#070e22]/90/80 text-slate-400 border-b border-indigo-900/40">
                              <th className="px-5 py-3.5 font-bold">کد دستور کار / درخواست</th>
                              <th className="px-5 py-3.5 font-bold">تجهیز / ماشین‌آلات</th>
                              <th className="px-5 py-3.5 font-bold">شرح فعالیت</th>
                              <th className="px-5 py-3.5 font-bold">سررسید / مجری</th>
                              <th className="px-5 py-3.5 font-bold">وضعیت</th>
                              <th className="px-5 py-3.5 font-bold text-center">عملیات</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#333538]/50">
                            {activeAutoOrders.map((order: any) => {
                              const woNum = order.woCode || order.workOrderCode || order.code;
                              const isArchived = isItemArchivedCheck(order);
                              return (
                                <tr key={order.id} className="hover:bg-[#112042]/50 transition-colors">
                                  <td className="px-5 py-4">
                                    <span className="font-mono font-bold text-cyan-300 block">{woNum}</span>
                                    <span className="text-[10px] text-purple-300 font-mono block">
                                      درخواست: {order.code}
                                    </span>
                                  </td>
                                  <td className="px-5 py-4">
                                    <span className="font-bold text-slate-200 block">{order.equipmentName}</span>
                                    <span className="text-[10px] text-slate-500 font-mono">{order.equipmentCode}</span>
                                  </td>
                                  <td className="px-5 py-4 max-w-xs">
                                    <span className="text-slate-200 block font-medium truncate">{order.failureTitle}</span>
                                    <span className="text-[10px] text-cyan-300 font-mono">
                                      {Array.isArray(order.woActivities) ? order.woActivities.length : 0} فعالیت برنامه‌ریزی‌شده ({order.pmPeriodLabel || 'دوره‌ای'})
                                    </span>
                                  </td>
                                  <td className="px-5 py-4">
                                    <span className="text-slate-300 block font-mono">{order.pmDueDate || order.woStartDate}</span>
                                    <span className={`text-[11px] block mt-0.5 ${order.technician ? 'text-emerald-400 font-bold' : 'text-amber-400/80'}`}>
                                      {order.technician || 'در انتظار اعزام'}
                                    </span>
                                  </td>
                                  <td className="px-5 py-4">
                                    <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border ${
                                      order.status === 'انجام شد' || order.status === 'انجام شده'
                                        ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
                                        : order.status === 'لغو' || order.status === 'لغو شده'
                                        ? 'bg-rose-950/70 text-rose-300 border-rose-500/40'
                                        : 'bg-cyan-950/70 text-cyan-200 border-cyan-500/40'
                                    }`}>
                                      {order.status === 'انجام شد' ? 'انجام شده' : (order.status || 'در انتظار دستور برنامه ریزی')}
                                    </span>
                                  </td>
                                  <td className="px-5 py-4 text-center">
                                    <button
                                      type="button"
                                      onClick={() => setActiveThreeTabPmOrder(order)}
                                      className={`p-2 rounded-xl transition-all cursor-pointer shadow-sm mx-auto inline-flex items-center justify-center border ${
                                        isArchived
                                          ? 'bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 hover:text-white border-emerald-500/30'
                                          : 'bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-200 hover:text-white border-cyan-500/40'
                                      }`}
                                      title={isArchived ? 'مشاهده و چاپ دستور کار' : 'مشاهده و باز کردن دستور کار'}
                                    >
                                      <Eye size={16} />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                            {activeLegacyOrders.map((order) => (
                              <tr key={order.id} className="hover:bg-[#112042]/50 transition-colors">
                                <td className="px-5 py-4">
                                  <span className="font-mono font-bold text-purple-300 block">{order.id}</span>
                                  {order.customOrderCode && (
                                    <span className="text-[10px] text-slate-400 font-mono">کد پایه: {order.customOrderCode}</span>
                                  )}
                                </td>
                                <td className="px-5 py-4">
                                  <span className="font-bold text-slate-200 block">{order.equipment}</span>
                                  <span className="text-[10px] text-slate-500 font-mono">{order.equipmentCode}</span>
                                </td>
                                <td className="px-5 py-4 max-w-xs">
                                  <span className="text-slate-200 block font-medium truncate">{order.title}</span>
                                  <span className="text-[10px] text-purple-300 font-mono">
                                    {order.activities?.length || 1} فعالیت با کد اختصاصی
                                  </span>
                                </td>
                                <td className="px-5 py-4">
                                  <span className="text-slate-300 block font-mono">{order.dueDate}</span>
                                  <span className={`text-[11px] block mt-0.5 ${
                                    order.assignedTo?.includes('در انتظار') 
                                      ? 'text-amber-400/80 font-normal' 
                                      : 'text-emerald-400 font-bold'
                                  }`}>
                                    {order.assignedTo || 'در انتظار اعزام'}
                                  </span>
                                </td>
                                <td className="px-5 py-4">{getStatusBadge(order.status)}</td>
                                <td className="px-5 py-4 text-center">
                                  {workOrderTab === 'open' ? (
                                    <button
                                      onClick={() => openExecutionModal(order)}
                                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/25 hover:bg-purple-600/45 text-purple-200 hover:text-white border border-purple-500/40 text-xs font-bold transition-all cursor-pointer shadow-sm mx-auto"
                                      title="ثبت شروع و پایان، انتخاب تکنسین‌های اعزامی و بستن دستورکار"
                                    >
                                      <Check size={14} />
                                      <span>ثبت اجرا و بستن</span>
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => openReportModal(order)}
                                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 hover:text-white border border-emerald-500/30 text-xs font-bold transition-all cursor-pointer mx-auto"
                                      title="مشاهده گزارش نهایی"
                                    >
                                      <Eye size={14} />
                                      <span>مشاهده گزارش</span>
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                            {activeAutoOrders.length === 0 && activeLegacyOrders.length === 0 && (
                              <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                                  دستورکاری در این بخش یافت نشد.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })()}
              </>
            )}

            {/* ======================================================== */}
            {/* VIEW: PM WORK ORDERS (activeView === 'workOrders')       */}
            {/* ======================================================== */}
            {activeView === 'workOrders' && (() => {
              const q = pmWoSearch.trim().toLowerCase();
              const openAuto = autoPmWorkOrders.filter(o => !isItemArchivedCheck(o));
              const archivedAuto = autoPmWorkOrders.filter(o => isItemArchivedCheck(o));
              const currentList = (workOrderTab === 'open' ? openAuto : archivedAuto).filter((o: any) => {
                if (!q) return true;
                return (
                  String(o.woCode || '').toLowerCase().includes(q) ||
                  String(o.code || '').toLowerCase().includes(q) ||
                  String(o.equipmentName || '').toLowerCase().includes(q) ||
                  String(o.equipmentCode || '').toLowerCase().includes(q) ||
                  String(o.failureTitle || '').toLowerCase().includes(q) ||
                  String(o.pmGroupName || '').toLowerCase().includes(q)
                );
              });

              return (
                <div className="space-y-6 animate-in fade-in duration-300">
                  <div className="p-5 rounded-2xl bg-[#0c162e]/55 backdrop-blur-md border border-indigo-500/30 flex flex-wrap items-center justify-between gap-4 shadow-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white flex items-center justify-center shadow-md">
                        <ClipboardList size={22} />
                      </div>
                      <div>
                        <h2 className="text-base font-black text-white">کارتابل دستورکارهای نگهداری پیشگیرانه (PM)</h2>
                        <p className="text-xs text-slate-400 mt-0.5">
                          دستورکارهای صادرشده خودکار در تاریخ سررسید PM با کد درخواست <span className="font-mono text-purple-300">PMWR</span> و کد دستور کار <span className="font-mono text-cyan-300">PMWO</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <div className="relative">
                        <Search size={14} className="text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="text"
                          value={pmWoSearch}
                          onChange={e => setPmWoSearch(e.target.value)}
                          placeholder="جستجو با کد PMWO / PMWR / تجهیز..."
                          className="bg-[#070e22] border border-indigo-500/30 rounded-xl pr-9 pl-3 py-2 text-xs text-white outline-none focus:border-cyan-400 w-64"
                        />
                      </div>
                      <div className="flex items-center gap-1 bg-[#070e22] p-1 rounded-xl border border-indigo-500/25">
                        <button
                          type="button"
                          onClick={() => setWorkOrderTab('open')}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                            workOrderTab === 'open' ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          باز ({openAuto.length})
                        </button>
                        <button
                          type="button"
                          onClick={() => setWorkOrderTab('archived')}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                            workOrderTab === 'archived' ? 'bg-emerald-600/30 text-emerald-200 border border-emerald-500/40' : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          بایگانی ({archivedAuto.length})
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#0c162e]/45 backdrop-blur-md rounded-2xl border border-indigo-500/25 overflow-hidden shadow-xl">
                    <div className="overflow-x-auto">
                      <table className="w-full text-right whitespace-nowrap text-xs">
                        <thead>
                          <tr className="bg-[#070e22]/90 text-slate-400 border-b border-indigo-900/40">
                            <th className="px-4 py-3.5 font-bold">کد دستور کار (PMWO)</th>
                            <th className="px-4 py-3.5 font-bold">کد درخواست (PMWR)</th>
                            <th className="px-4 py-3.5 font-bold">گروه / تجهیز</th>
                            <th className="px-4 py-3.5 font-bold">عنوان سرویس و فعالیت‌ها</th>
                            <th className="px-4 py-3.5 font-bold">تاریخ سررسید</th>
                            <th className="px-4 py-3.5 font-bold">تکنسین</th>
                            <th className="px-4 py-3.5 font-bold">وضعیت</th>
                            <th className="px-4 py-3.5 font-bold text-center">فرم ۳ صفحه‌ای</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/70">
                          {currentList.map((order: any) => {
                            const isArchived = isItemArchivedCheck(order);
                            const woNum = order.woCode || order.workOrderCode || order.code;
                            return (
                              <tr key={order.id} className="hover:bg-[#112042]/60 transition-colors">
                                <td className="px-4 py-3.5">
                                  <span className="font-mono font-bold text-cyan-300 px-2.5 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/35">
                                    {woNum}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5">
                                  <span className="font-mono font-bold text-purple-300 px-2.5 py-1 rounded-lg bg-purple-950/60 border border-purple-500/35">
                                    {order.code}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5">
                                  <span className="font-bold text-slate-100 block">{order.equipmentName}</span>
                                  <span className="text-[10px] text-slate-400 font-mono">{order.equipmentCode} • {order.locationName}</span>
                                </td>
                                <td className="px-4 py-3.5 max-w-xs">
                                  <span className="font-bold text-slate-200 block truncate">{order.failureTitle}</span>
                                  <span className="text-[10px] text-cyan-300 font-mono">
                                    {Array.isArray(order.woActivities) ? order.woActivities.length : 0} فعالیت برنامه‌ریزی‌شده
                                  </span>
                                </td>
                                <td className="px-4 py-3.5 font-mono text-slate-200">{order.pmDueDate || order.woStartDate}</td>
                                <td className="px-4 py-3.5">
                                  <span className={order.technician ? 'text-emerald-300 font-bold' : 'text-amber-300/80'}>
                                    {order.technician || 'در انتظار تخصیص'}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5">
                                  <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border ${
                                    order.status === 'انجام شد' || order.status === 'انجام شده'
                                      ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
                                      : order.status === 'لغو' || order.status === 'لغو شده'
                                      ? 'bg-rose-950/70 text-rose-300 border-rose-500/40'
                                      : 'bg-cyan-950/70 text-cyan-200 border-cyan-500/40'
                                  }`}>
                                    {order.status === 'انجام شد' ? 'انجام شده' : (order.status || 'در انتظار دستور برنامه ریزی')}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5 text-center">
                                  <button
                                    type="button"
                                    onClick={() => setActiveThreeTabPmOrder(order)}
                                    className={`p-2 rounded-xl transition-all cursor-pointer shadow-sm inline-flex items-center justify-center border ${
                                      isArchived
                                        ? 'bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 hover:text-white border-emerald-500/30'
                                        : 'bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-200 hover:text-white border-cyan-500/40'
                                    }`}
                                    title={isArchived ? 'مشاهده و چاپ دستور کار' : 'مشاهده و باز کردن دستور کار'}
                                  >
                                    <Eye size={16} />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                          {currentList.length === 0 && (
                            <tr>
                              <td colSpan={8} className="px-6 py-12 text-center text-slate-500">
                                دستور کاری در این بخش یافت نشد.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* ======================================================== */}
            {/* VIEW 2: SCHEDULE (activeView === 'schedule')             */}
            {/* ======================================================== */}
            {activeView === 'schedule' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                {autoOpenedWoNotice && autoOpenedWoNotice.codes.length > 0 && (
                  <div className="p-4 bg-cyan-500/15 border border-cyan-500/40 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-cyan-100 shadow-lg animate-in fade-in">
                    <div className="flex items-center gap-2.5 font-bold">
                      <CheckCircle2 size={18} className="text-cyan-400 shrink-0" />
                      <span>
                        دستور کار PM سررسیدشده در بخش نگهداری پیشگیرانه با کد{' '}
                        <span className="font-mono px-2 py-0.5 rounded bg-cyan-950/90 text-cyan-200 border border-cyan-500/40 mx-1">
                          {autoOpenedWoNotice.codes.join('، ')}
                        </span>
                        به‌صورت خودکار صادر شد.
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpenThreeTabOrderByCode(autoOpenedWoNotice.codes[0])}
                        className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-[11px] shadow cursor-pointer"
                      >
                        باز کردن دستور کار {autoOpenedWoNotice.codes[0]}
                      </button>
                      <button
                        type="button"
                        onClick={() => setAutoOpenedWoNotice(null)}
                        className="text-cyan-300/70 hover:text-cyan-100 cursor-pointer"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                )}

                {/* اعلان موفقیت‌آمیز بودن عملیات */}
                {batchSuccessToast && (
                  <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-xs text-emerald-200 shadow-lg animate-in fade-in">
                    <div className="flex items-center gap-2.5 font-bold">
                      <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                      <span>{batchSuccessToast}</span>
                    </div>
                    <button onClick={() => setBatchSuccessToast(null)} className="text-emerald-400/70 hover:text-emerald-200 cursor-pointer">
                      <X size={16} />
                    </button>
                  </div>
                )}

                {/* ======================================================= */}
                {/* برنامه‌ریزی ۹ گروه تجهیزات به صورت آکاردئون عمودی جمع‌وجور */}
                {/* ======================================================= */}
                <div className="space-y-2">
                  {PM_9_GROUPS.map((grp) => {
                    const isExpanded = expandedScheduleGroup === grp.id;
                    const allGroupEqs = getGroupActiveEquipments(grp.id);
                    const curActivities = groupActivities[grp.id] || [];

                    // دسته‌بندی دوره‌ای فعالیت‌ها
                    const monthlyActs = curActivities.filter(a => a.frequencyType === 'monthly');
                    const bimonthlyActs = curActivities.filter(a => a.frequencyType === 'bimonthly');
                    const quarterlyActs = curActivities.filter(a => a.frequencyType === 'quarterly');
                    const biannualActs = curActivities.filter(a => a.frequencyType === 'biannual');
                    const annualActs = curActivities.filter(a => a.frequencyType === 'annual');
                    const customActs = curActivities.filter(a => a.frequencyType === 'custom');

                    return (
                      <div 
                        key={grp.id}
                        className={`bg-[#0c162e]/55 backdrop-blur-md rounded-xl border transition-all duration-300 overflow-hidden shadow-sm ${
                          isExpanded ? 'border-purple-500/50 shadow-[0_0_20px_rgba(168,85,247,0.12)] ring-1 ring-purple-500/30' : 'border-indigo-500/20 hover:border-indigo-500/40'
                        }`}
                      >
                        {/* هدر آکاردئون هر گروه - جمع‌وجور، بدون کد تجهیز، بدون توضیحات، بدون آیکون */}
                        <div
                          onClick={() => {
                            if (isExpanded) {
                              setExpandedScheduleGroup(null);
                              setActiveCategoryGroupId(null);
                            } else {
                              setExpandedScheduleGroup(grp.id);
                              setSelectedPmGroupId(grp.id);
                              setActiveCategoryGroupId(grp.id);
                            }
                          }}
                          className={`py-2.5 px-4 flex items-center justify-between gap-3 cursor-pointer select-none transition-colors ${
                            isExpanded ? 'bg-[#0f1d3d]/65 border-b border-indigo-900/40' : 'hover:bg-[#112042]/40'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                              <span>{grp.name}</span>
                            </h3>
                            <span className="text-xs text-slate-400 font-mono">({grp.enName})</span>
                          </div>

                          <div className="flex items-center gap-2.5 shrink-0">
                            <span className="px-2.5 py-0.5 rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/20 text-xs font-bold">
                              {allGroupEqs.length} دستگاه
                            </span>
                            <span className="px-2.5 py-0.5 rounded-lg bg-purple-500/10 text-purple-300 border border-purple-500/20 text-xs font-bold">
                              {curActivities.length} فعالیت PM
                            </span>
                            <div className={`w-7 h-7 rounded-lg bg-[#070e22] border border-indigo-500/30 flex items-center justify-center text-slate-300 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-purple-400' : ''}`}>
                              <ChevronDown size={15} />
                            </div>
                          </div>
                        </div>

                        {/* بدنه آکاردئون گروه باز شده */}
                        {isExpanded && (
                          <div className="p-4 sm:p-6 space-y-6 bg-[#070e22]/35 backdrop-blur-sm animate-in fade-in duration-200">
                            
                            {/* بخش مشخصات تجهیزات - کاملاً تمیز، بدون توضیحات اضافه، حذف با برداشتن تیک و افزودن با دکمه + */}
                            {(() => {
                              const isEqVisible = !!expandedGroupEquipmentMap[grp.id];
                              return (
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <button
                                        type="button"
                                        onClick={() => toggleGroupEquipmentVisibility(grp.id)}
                                        className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/60 hover:border-slate-600 text-xs font-bold transition-all cursor-pointer shadow-sm backdrop-blur-sm"
                                        title="مشخصات تجهیزات"
                                      >
                                        <span>مشخصات تجهیزات</span>
                                        <span className="text-[11px] font-mono font-medium text-cyan-400">({toFaDigits(allGroupEqs.length)} دستگاه)</span>
                                        <ChevronDown size={14} className={`transition-transform duration-200 text-slate-400 ${isEqVisible ? 'rotate-180 text-cyan-400' : ''}`} />
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          setAddEquipmentModalGroup({ id: grp.id, name: grp.name });
                                          setAddEqModalSearch('');
                                          setAddEqModalCategoryFilter('همه');
                                        }}
                                        className="flex items-center justify-center w-8 h-8 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/35 text-cyan-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400/50 transition-all cursor-pointer shadow-sm"
                                        title="افزودن تجهیز از هر دسته به این لیست"
                                      >
                                        <Plus size={16} />
                                      </button>
                                    </div>
                                  </div>

                                  {isEqVisible && (
                                    <>
                                      {allGroupEqs.length === 0 ? (
                                        <div className="p-4 text-center text-xs text-slate-500 rounded-xl border border-dashed border-slate-800/80 bg-slate-950/40">
                                          موردی در این لیست وجود ندارد. با کلیک روی + تجهیز اضافه کنید.
                                        </div>
                                      ) : (
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[300px] overflow-y-auto pr-1 animate-in fade-in duration-200">
                                          {allGroupEqs.map(eq => {
                                            return (
                                              <div
                                                key={eq.id}
                                                className="p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 bg-slate-900/60 backdrop-blur-sm border-cyan-500/40 text-slate-200 shadow-sm hover:border-cyan-400/60"
                                              >
                                                <div className="flex items-center gap-2.5 min-w-0">
                                                  <input
                                                    type="checkbox"
                                                    checked={true}
                                                    onChange={() => handleRemoveEquipmentFromGroup(grp.id, eq.id)}
                                                    className="w-4 h-4 rounded text-cyan-600 bg-slate-900 border-slate-700 accent-cyan-500 cursor-pointer shrink-0"
                                                    title="برداشتن تیک جهت حذف از این لیست"
                                                  />
                                                  <div className="min-w-0">
                                                    <div className="flex items-center gap-1.5">
                                                      <span className="font-mono font-bold text-xs text-cyan-300 bg-slate-900/90 px-1.5 py-0.5 rounded border border-cyan-500/20">{eq.id}</span>
                                                      <span className="text-xs font-bold text-slate-200 truncate">{eq.name}</span>
                                                    </div>
                                                    <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                                                      {eq.location || 'سالن تولید'} • {eq.family}
                                                    </div>
                                                  </div>
                                                </div>
                                                <div className="flex items-center gap-1.5 shrink-0">
                                                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900 text-slate-400 border border-slate-800">
                                                    {eq.priority || 'سطح B'}
                                                  </span>
                                                  <button
                                                    type="button"
                                                    onClick={() => handleRemoveEquipmentFromGroup(grp.id, eq.id)}
                                                    className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-900 transition-colors cursor-pointer"
                                                    title="حذف از لیست"
                                                  >
                                                    <X size={12} />
                                                  </button>
                                                </div>
                                              </div>
                                            );
                                          })}
                                        </div>
                                      )}
                                    </>
                                  )}
                                </div>
                              );
                            })()}

                            {/* بخش ۲: فعالیت‌های نگهداری پیشگیرانه به صورت آکاردئون دوره‌ها */}
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                                  <CheckSquare size={15} className="text-slate-400" />
                                  <span>فعالیت‌های نگهداری و سرویس پیشگیرانه (PM)</span>
                                </h4>
                                <span className="text-[11px] text-slate-500 font-medium">
                                  مجموع {curActivities.length} فعالیت ثبت‌شده
                                </span>
                              </div>

                              {/* لیست دوره‌ها به صورت آکاردئون با ظاهر ملایم و ارگونومیک */}
                              {[
                                { key: 'monthly', title: 'فعالیت‌های ماهانه (۳۰ روزه)', acts: monthlyActs, color: 'bg-blue-400/80', label: 'ماهانه' },
                                { key: 'bimonthly', title: 'فعالیت‌های دوماهه (۶۰ روزه)', acts: bimonthlyActs, color: 'bg-teal-400/80', label: 'دوماهه' },
                                { key: 'quarterly', title: 'فعالیت‌های ۳ ماهه (فصلی - ۹۰ روزه)', acts: quarterlyActs, color: 'bg-purple-400/80', label: '۳ ماهه' },
                                { key: 'biannual', title: 'فعالیت‌های ۶ ماهه (نیم‌سال - ۱۸۰ روزه)', acts: biannualActs, color: 'bg-emerald-400/80', label: '۶ ماهه' },
                                { key: 'annual', title: 'فعالیت‌های سالانه (یک‌ساله - ۳۶۵ روزه)', acts: annualActs, color: 'bg-rose-400/80', label: 'سالانه' },
                                { key: 'custom', title: 'فعالیت‌های دوره‌ای سفارشی (۳ روزه و...)', acts: customActs, color: 'bg-amber-400/80', label: 'سفارشی' }
                              ].map(period => {
                                const isPeriodOpen = Boolean(openPeriodMap[period.key]);
                                return (
                                  <div 
                                    key={period.key}
                                    className="bg-slate-900/50 backdrop-blur-md rounded-xl border border-slate-800/80 hover:border-slate-700/80 transition-colors overflow-hidden"
                                  >
                                    {(() => {
                                      const periodSched = getPeriodSchedule(grp.id, period.key);
                                      const isAnyScheduled = Boolean(periodSched?.isScheduled && periodSched?.startDate);
                                      return (
                                        <div
                                          onClick={() => togglePeriodAccordion(period.key)}
                                          className="p-3 sm:p-3.5 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/40 transition-colors bg-slate-900/60 select-none"
                                        >
                                          <div className="flex items-center gap-2.5">
                                            <span className={`w-2.5 h-2.5 rounded-full ${period.color}`}></span>
                                            <span className="text-xs font-bold text-slate-200">{period.title}</span>
                                            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-400 border border-slate-700/60">
                                              {period.acts.length} فعالیت
                                            </span>
                                          </div>

                                          <div className="flex items-center gap-2">
                                            {isAnyScheduled && periodSched ? (
                                              <span className="px-2 py-0.5 rounded-lg text-[10px] font-medium bg-emerald-950/40 text-emerald-300 border border-emerald-500/25 flex items-center gap-1.5">
                                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                                                <span>
                                                  تقویم: {periodSched.startDate} تا {periodSched.endDate} ({toFaDigits(periodSched.executionWindowDays)} روز)
                                                </span>
                                              </span>
                                            ) : (
                                              <span className="px-2 py-0.5 rounded-lg text-[10px] text-slate-400 bg-slate-800/60 border border-slate-750">
                                                فاقد زمان‌بندی در تقویم
                                              </span>
                                            )}

                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                const sDate = periodSched?.startDate || '1405/08/15';
                                                const wDays = periodSched?.executionWindowDays || 3;
                                                setPeriodToSchedule({
                                                  groupId: grp.id,
                                                  groupName: grp.name,
                                                  periodKey: period.key as any,
                                                  periodTitle: period.title,
                                                  periodLabel: period.label,
                                                  count: period.acts.length,
                                                  startDate: sDate,
                                                  executionWindowDays: wDays,
                                                  endDate: periodSched?.endDate || addShamsiDays(sDate, wDays),
                                                  isScheduled: isAnyScheduled
                                                });
                                              }}
                                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-medium transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                                              title="تنظیم تاریخ شروع و بازه انجام تمام فعالیت‌های این دوره به صورت یکجا"
                                            >
                                              <Calendar size={13} className="text-slate-400" />
                                              <span>تنظیم تاریخ و بازه این دوره</span>
                                            </button>

                                            <div className={`text-slate-400 transition-transform duration-200 ${isPeriodOpen ? 'rotate-180' : ''}`}>
                                              <ChevronDown size={15} />
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })()}

                                    {isPeriodOpen && (
                                      <div className="p-3 sm:p-4 space-y-2.5 border-t border-slate-800/80 bg-slate-950/40">
                                        <div className="flex flex-wrap items-center justify-between gap-2 pb-1.5">
                                          <span className="text-[11px] text-slate-400">
                                            چک‌لیست فعالیت‌های این دوره:
                                          </span>
                                          <div className="flex items-center gap-2">
                                            <button
                                              type="button"
                                              onClick={() => {
                                                setActiveCategoryGroupId(grp.id);
                                                setSelectedPmGroupId(grp.id);
                                                setExcelTargetPeriod(period.key as any);
                                                setExcelLockToTargetPeriod(true);
                                                setExcelErrorMsg(null);
                                                setExcelParsedActivities([]);
                                                setExcelPasteText('');
                                                setExcelWorkbookSheets([]);
                                                setExcelSelectedSheet('');
                                                setIsExcelActModalOpen(true);
                                              }}
                                              className="flex items-center justify-center p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-slate-700 transition-all cursor-pointer"
                                              title="ورود از اکسل"
                                            >
                                              <Upload size={14} />
                                            </button>

                                            <button
                                              type="button"
                                              onClick={() => {
                                                setActiveCategoryGroupId(grp.id);
                                                setSelectedPmGroupId(grp.id);
                                                setActModalFamSearch('');
                                                setIsActModalFamDropdownOpen(false);
                                                setNewActForm({
                                                  code: '',
                                                  title: '',
                                                  frequencyType: period.key as any,
                                                  customDays: 3,
                                                  estimatedHours: 2,
                                                  partsRequired: '',
                                                  startDate: getTodayShamsiString(),
                                                  endDate: addShamsiDays(getTodayShamsiString(), 3),
                                                  executionWindowDays: 3
                                                });
                                                setIsAddActModalOpen(true);
                                              }}
                                              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-medium transition-all cursor-pointer"
                                            >
                                              <Plus size={13} className="text-purple-400" />
                                              <span>+ افزودن به {period.label}</span>
                                            </button>
                                          </div>
                                        </div>

                                        {/* سرچ سریع از فعالیت‌های ثبت‌شده در خانواده تجهیز (فقط خانواده‌های همین گروه) */}
                                        {(() => {
                                          void familyDataVersion;
                                          const quickKey = `${grp.id}::${period.key}`;
                                          const quickQuery = periodQuickSearchMap[quickKey] || '';
                                          const groupFamActs = getGroupFamilyMaintenanceActivities(
                                            grp.id,
                                            familyList,
                                            equipmentList,
                                            groupAssignedEquipMap
                                          );
                                          const normQ = quickQuery
                                            .replace(/ي/g, 'ی')
                                            .replace(/ى/g, 'ی')
                                            .replace(/ك/g, 'ک')
                                            .replace(/\u200c/g, '')
                                            .trim()
                                            .toLowerCase();
                                          const filteredFamActs = !normQ
                                            ? groupFamActs
                                            : groupFamActs.filter(fa => {
                                                const hay = `${fa.code} ${fa.title} ${fa.familyName} ${fa.familyId}`
                                                  .replace(/ي/g, 'ی')
                                                  .replace(/ى/g, 'ی')
                                                  .replace(/ك/g, 'ک')
                                                  .replace(/\u200c/g, '')
                                                  .toLowerCase();
                                                return hay.includes(normQ);
                                              });
                                          const isQuickOpen = openPeriodQuickDropdown === quickKey;
                                          return (
                                            <div className="relative" data-pm-period-quick-search>
                                              <div className="relative flex items-center">
                                                <Search className="w-3.5 h-3.5 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                                                <input
                                                  type="text"
                                                  value={quickQuery}
                                                  onFocus={() => setOpenPeriodQuickDropdown(quickKey)}
                                                  onChange={e => {
                                                    const v = e.target.value;
                                                    setPeriodQuickSearchMap(prev => ({ ...prev, [quickKey]: v }));
                                                    setOpenPeriodQuickDropdown(quickKey);
                                                  }}
                                                  placeholder={`سرچ سریع از فعالیت‌های خانواده ${grp.name} (کد یا عنوان) جهت افزودن به ${period.label}...`}
                                                  className="w-full bg-[#091228] border border-cyan-500/35 rounded-xl pr-9 pl-28 py-2 text-[11.5px] text-white placeholder:text-slate-500 outline-none focus:border-cyan-400 transition-colors"
                                                />
                                                <div className="absolute left-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                                                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                                                    {toFaDigits(groupFamActs.length)} مورد
                                                  </span>
                                                  {quickQuery && (
                                                    <button
                                                      type="button"
                                                      onClick={() => {
                                                        setPeriodQuickSearchMap(prev => ({ ...prev, [quickKey]: '' }));
                                                        setOpenPeriodQuickDropdown(quickKey);
                                                      }}
                                                      className="text-slate-400 hover:text-white cursor-pointer"
                                                      title="پاک کردن"
                                                    >
                                                      <X size={13} />
                                                    </button>
                                                  )}
                                                </div>
                                              </div>

                                              {isQuickOpen && (
                                                <div className="absolute left-0 right-0 mt-1 max-h-56 overflow-y-auto rounded-xl bg-[#09132b] border border-cyan-500/45 shadow-2xl z-40 divide-y divide-slate-800/80">
                                                  {groupFamActs.length === 0 ? (
                                                    <div className="p-3 text-center text-[11px] text-slate-400">
                                                      هنوز فعالیتی برای خانواده‌های «{grp.name}» در بخش خانواده تجهیز ثبت نشده است.
                                                    </div>
                                                  ) : filteredFamActs.length === 0 ? (
                                                    <div className="p-3 text-center text-[11px] text-slate-400">
                                                      موردی در خانواده «{grp.name}» یافت نشد.
                                                    </div>
                                                  ) : (
                                                    filteredFamActs.map(fa => (
                                                      <button
                                                        key={`${fa.familyId}-${fa.id}`}
                                                        type="button"
                                                        onClick={() => handleQuickAddFamilyActivityToPeriod(grp.id, period.key as any, fa)}
                                                        className="w-full px-3 py-2 text-right hover:bg-cyan-900/35 flex items-center justify-between gap-2 text-xs transition-colors cursor-pointer"
                                                      >
                                                        <div className="min-w-0 flex-1">
                                                          <div className="text-slate-100 font-semibold truncate">{fa.title}</div>
                                                          <div className="text-[10px] text-slate-400 truncate mt-0.5">
                                                            خانواده: {fa.familyName} ({fa.familyId})
                                                            {fa.frequency ? ` • ${fa.frequency}` : ''}
                                                          </div>
                                                        </div>
                                                        <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/35 shrink-0">
                                                          {fa.code || 'بدون کد'}
                                                        </span>
                                                      </button>
                                                    ))
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                          );
                                        })()}

                                        <div className="space-y-2">
                                          {period.acts.map((act, actIdx) => (
                                            <div
                                              key={act.id}
                                              className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                                            >
                                              <div className="flex items-start gap-2.5 min-w-0">
                                                <span className="w-5 h-5 rounded-md bg-slate-800 text-slate-400 flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                                                  {actIdx + 1}
                                                </span>
                                                <div className="min-w-0">
                                                  <div className="text-xs font-bold text-slate-200 leading-relaxed flex flex-wrap items-center gap-1.5">
                                                    {act.code && (
                                                      <span className="px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 font-mono text-[10.5px] font-bold">
                                                        {act.code}
                                                      </span>
                                                    )}
                                                    <span>{act.title}</span>
                                                  </div>
                                                  <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[10px] text-slate-400">
                                                    <span className="text-slate-300 font-medium">دوره: {act.frequencyLabel}</span>
                                                    <span className="text-slate-600">•</span>
                                                    <span>زمان: {toFaDigits(act.estimatedHours)} ساعت</span>
                                                    {act.partsRequired && (
                                                      <>
                                                        <span className="text-slate-600">•</span>
                                                        <span className="text-slate-400">قطعات: {act.partsRequired}</span>
                                                      </>
                                                    )}
                                                  </div>
                                                </div>
                                              </div>

                                              <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                                                <button
                                                  type="button"
                                                  onClick={() => handleOpenThreeTabPmWorkOrder(grp.id, act)}
                                                  className="px-2.5 py-1 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 hover:text-emerald-200 border border-emerald-500/30 text-[11px] font-medium transition-all flex items-center gap-1 cursor-pointer shadow-sm"
                                                  title="باز کردن فرم دستور کار PM (۳ صفحه‌ای)"
                                                >
                                                  <Wrench size={13} className="text-emerald-400" />
                                                  <span>
                                                    {autoPmStatusMap[`${grp.id}::${act.frequencyType}`]?.woCode
                                                      ? `دستور کار ${autoPmStatusMap[`${grp.id}::${act.frequencyType}`].woCode}`
                                                      : 'دستور کار PM'}
                                                  </span>
                                                </button>

                                                <button
                                                  type="button"
                                                  onClick={() => handleDeleteActivityItem(grp.id, act.id)}
                                                  className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer rounded-lg hover:bg-slate-800"
                                                  title="حذف این فعالیت"
                                                >
                                                  <Trash2 size={13} />
                                                </button>
                                              </div>
                                            </div>
                                          ))}

                                          {period.acts.length === 0 && (
                                            <div className="py-4 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                                              فعالیتی برای این دوره ثبت نشده است. از دکمه‌های بالا برای افزودن دستی یا ورود از اکسل استفاده فرمایید.
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* مودال افزودن تجهیز جدید به دسته انتخاب‌شده */}
                {isAddEqToCatModalOpen && activeCategoryGroupId && (
                  <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
                    <div className="bg-[#0c162e] border border-purple-500/40 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
                      <div className="p-4 sm:p-5 border-b border-indigo-900/40 flex items-center justify-between bg-[#070e22]/90">
                        <div className="flex items-center gap-2">
                          <Plus size={18} className="text-purple-400" />
                          <h3 className="text-sm font-bold text-slate-200">
                            افزودن تجهیز جدید به دسته {PM_9_GROUPS.find(g => g.id === activeCategoryGroupId)?.name}
                          </h3>
                        </div>
                        <button
                          onClick={() => setIsAddEqToCatModalOpen(false)}
                          className="text-slate-400 hover:text-slate-200 cursor-pointer"
                        >
                          <X size={18} />
                        </button>
                      </div>

                      <div className="p-5 space-y-4 text-xs">
                        <div>
                          <label className="block text-slate-300 font-bold mb-1.5">کد شناسایی تجهیز:</label>
                          <input
                            type="text"
                            value={newGroupEqForm.id}
                            onChange={e => setNewGroupEqForm({ ...newGroupEqForm, id: e.target.value })}
                            placeholder="مثال: TUTL38"
                            className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3.5 py-2.5 text-slate-200 font-mono outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-300 font-bold mb-1.5">نام کامل دستگاه:</label>
                          <input
                            type="text"
                            value={newGroupEqForm.name}
                            onChange={e => setNewGroupEqForm({ ...newGroupEqForm, name: e.target.value })}
                            placeholder="مثال: دستگاه تراش CNC جدید"
                            className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3.5 py-2.5 text-slate-200 outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-300 font-bold mb-1.5">مکان / سالن استقرار:</label>
                          <input
                            type="text"
                            value={newGroupEqForm.location}
                            onChange={e => setNewGroupEqForm({ ...newGroupEqForm, location: e.target.value })}
                            placeholder="مثال: سالن یک_طبقه اول"
                            className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3.5 py-2.5 text-slate-200 outline-none focus:border-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-300 font-bold mb-1.5">سطح اولویت تجهیز:</label>
                          <select
                            value={newGroupEqForm.priority}
                            onChange={e => setNewGroupEqForm({ ...newGroupEqForm, priority: e.target.value })}
                            className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-slate-200 outline-none focus:border-purple-500 cursor-pointer"
                          >
                            <option value="سطح A">سطح A (بسیار بحرانی)</option>
                            <option value="سطح B">سطح B (مهم و دارای اولویت)</option>
                            <option value="سطح C">سطح C (عادی)</option>
                          </select>
                        </div>
                      </div>

                      <div className="p-4 border-t border-indigo-900/40 bg-[#070e22]/80 flex justify-end gap-2.5">
                        <button
                          onClick={() => setIsAddEqToCatModalOpen(false)}
                          className="px-4 py-2 rounded-xl border border-indigo-500/30 text-slate-400 hover:text-slate-200 text-xs font-bold transition-all cursor-pointer"
                        >
                          انصراف
                        </button>
                        <button
                          onClick={() => handleAddEquipmentToCategory(activeCategoryGroupId)}
                          className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg transition-all cursor-pointer"
                        >
                          ثبت تجهیز در این دسته
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* مودال افزودن فعالیت سفارشی به گروه */}
                {isAddActModalOpen && (
                  <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
                    <div className="bg-[#0c162e] border border-purple-500/40 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
                      <div className="p-4 sm:p-5 border-b border-indigo-900/40 flex items-center justify-between bg-[#070e22]/90">
                        <div className="flex items-center gap-2">
                          <Plus size={18} className="text-purple-400" />
                          <h3 className="text-sm font-bold text-slate-200">
                            افزودن فعالیت نگهداری پیشگیرانه جدید
                          </h3>
                        </div>
                        <button
                          onClick={() => setIsAddActModalOpen(false)}
                          className="text-slate-400 hover:text-slate-200 cursor-pointer"
                        >
                          <X size={18} />
                        </button>
                      </div>

                      <div className="p-5 space-y-4 text-xs">
                        {/* سرچ سریع از فعالیت‌های ثبت‌شده در خانواده تجهیز مربوط به گروه فعال */}
                        {(() => {
                          void familyDataVersion;
                          const targetGroupId = activeCategoryGroupId || selectedPmGroupId;
                          const targetGroupName = PM_9_GROUPS.find(g => g.id === targetGroupId)?.name || 'این گروه';
                          const groupFamActs = getGroupFamilyMaintenanceActivities(
                            targetGroupId,
                            familyList,
                            equipmentList,
                            groupAssignedEquipMap
                          );
                          const normQ = actModalFamSearch
                            .replace(/ي/g, 'ی')
                            .replace(/ى/g, 'ی')
                            .replace(/ك/g, 'ک')
                            .replace(/\u200c/g, '')
                            .trim()
                            .toLowerCase();
                          const filteredModalFamActs = !normQ
                            ? groupFamActs
                            : groupFamActs.filter(fa => {
                                const hay = `${fa.code} ${fa.title} ${fa.familyName} ${fa.familyId}`
                                  .replace(/ي/g, 'ی')
                                  .replace(/ى/g, 'ی')
                                  .replace(/ك/g, 'ک')
                                  .replace(/\u200c/g, '')
                                  .toLowerCase();
                                return hay.includes(normQ);
                              });
                          return (
                            <div ref={actModalFamDropdownRef} className="relative p-3 rounded-xl bg-[#070e22]/90 border border-cyan-500/30 space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-cyan-300 font-bold text-[11px] flex items-center gap-1.5">
                                  <Search size={13} className="text-cyan-400" />
                                  <span>انتخاب با سرچ سریع از خانواده تجهیز ({targetGroupName})</span>
                                </label>
                                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                                  {toFaDigits(groupFamActs.length)} فعالیت خانواده
                                </span>
                              </div>
                              <div className="relative">
                                <Search className="w-3.5 h-3.5 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                                <input
                                  type="text"
                                  value={actModalFamSearch}
                                  onFocus={() => setIsActModalFamDropdownOpen(true)}
                                  onChange={e => {
                                    setActModalFamSearch(e.target.value);
                                    setIsActModalFamDropdownOpen(true);
                                  }}
                                  placeholder={`جستجوی سریع با کد یا عنوان در خانواده ${targetGroupName}...`}
                                  className="w-full bg-[#0c162e] border border-cyan-500/40 rounded-xl pr-9 pl-8 py-2 text-xs text-white placeholder:text-slate-500 outline-none focus:border-cyan-400"
                                />
                                {actModalFamSearch && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActModalFamSearch('');
                                      setIsActModalFamDropdownOpen(true);
                                    }}
                                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                                    title="پاک کردن"
                                  >
                                    <X size={13} />
                                  </button>
                                )}
                              </div>

                              {isActModalFamDropdownOpen && (
                                <div className="absolute left-3 right-3 mt-1 max-h-52 overflow-y-auto rounded-xl bg-[#09132b] border border-cyan-500/45 shadow-2xl z-50 divide-y divide-slate-800/80">
                                  {groupFamActs.length === 0 ? (
                                    <div className="p-3 text-center text-[11px] text-slate-400">
                                      هنوز فعالیتی برای خانواده‌های «{targetGroupName}» در بخش خانواده تجهیز ثبت نشده است.
                                    </div>
                                  ) : filteredModalFamActs.length === 0 ? (
                                    <div className="p-3 text-center text-[11px] text-slate-400">
                                      موردی در خانواده «{targetGroupName}» یافت نشد.
                                    </div>
                                  ) : (
                                    filteredModalFamActs.map(fa => (
                                      <button
                                        key={`${fa.familyId}-${fa.id}`}
                                        type="button"
                                        onClick={() => {
                                          setNewActForm(prev => ({
                                            ...prev,
                                            code: fa.code || prev.code,
                                            title: fa.title
                                          }));
                                          setActModalFamSearch(fa.code ? `${fa.code} — ${fa.title}` : fa.title);
                                          setIsActModalFamDropdownOpen(false);
                                        }}
                                        className="w-full px-3 py-2 text-right hover:bg-cyan-900/35 flex items-center justify-between gap-2 text-xs transition-colors cursor-pointer"
                                      >
                                        <div className="min-w-0 flex-1">
                                          <div className="text-white font-semibold truncate">{fa.title}</div>
                                          <div className="text-[10px] text-slate-400 truncate mt-0.5">
                                            خانواده: {fa.familyName} ({fa.familyId})
                                            {fa.frequency ? ` • ${fa.frequency}` : ''}
                                          </div>
                                        </div>
                                        <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/35 shrink-0">
                                          {fa.code || 'بدون کد'}
                                        </span>
                                      </button>
                                    ))
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })()}

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-slate-300 font-bold mb-1.5">
                              کد فعالیت:
                            </label>
                            <input
                              type="text"
                              value={newActForm.code}
                              onChange={e => setNewActForm({ ...newActForm, code: e.target.value })}
                              placeholder="ACT-01"
                              className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3.5 py-2.5 text-cyan-300 font-mono outline-none focus:border-purple-500"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-slate-300 font-bold mb-1.5">
                              عنوان فعالیت / شرح کار:
                            </label>
                            <input
                              type="text"
                              value={newActForm.title}
                              onChange={e => setNewActForm({ ...newActForm, title: e.target.value })}
                              placeholder="مثال: بازرسی فشار روغن، تعویض فیلتر یا روانکاری ریل‌ها..."
                              className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3.5 py-2.5 text-slate-200 outline-none focus:border-purple-500"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="p-4 border-t border-indigo-900/40 bg-[#070e22]/80 flex justify-end gap-2.5">
                        <button
                          onClick={() => setIsAddActModalOpen(false)}
                          className="px-4 py-2 rounded-xl border border-indigo-500/30 text-slate-400 hover:text-slate-200 text-xs font-bold transition-all cursor-pointer"
                        >
                          انصراف
                        </button>
                        <button
                          onClick={() => handleAddCustomActivityToGroup(activeCategoryGroupId || selectedPmGroupId)}
                          className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg transition-all cursor-pointer"
                        >
                          ثبت فعالیت
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ======================================================== */}
            {/* VIEW 3: EQUIPMENT (activeView === 'equipment')           */}
            {/* ======================================================== */}
            {activeView === 'equipment' && (
              selectedFamilyForDetail ? (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-1">
                    <button
                      type="button"
                      onClick={() => setSelectedFamilyForDetail(null)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-purple-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                    >
                      <ArrowRight size={14} />
                      <span>بازگشت به لیست خانواده‌ها</span>
                    </button>
                  </div>
                  <AssetClassDetailView
                    family={selectedFamilyForDetail}
                    onBack={() => setSelectedFamilyForDetail(null)}
                    onUpdateFamily={(updated) => {
                      const updatedList = familyList.map(f => f.id === selectedFamilyForDetail.id ? updated : f);
                      setFamilyList(updatedList);
                      setSelectedFamilyForDetail(updated);
                    }}
                    equipments={equipmentList}
                  />
                </div>
              ) : (
              <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 overflow-hidden shadow-lg flex flex-col min-h-[550px]">
                <div className="p-5 sm:p-6 border-b border-indigo-900/40 flex flex-col lg:flex-row justify-between lg:items-center gap-4 bg-[#070e22]/90/50">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setActiveView('dashboard')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-purple-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
                        title="بازگشت به داشبورد PM"
                      >
                        <ArrowRight size={14} />
                        <span>بازگشت به داشبورد</span>
                      </button>
                      <div>
                        <h2 className="text-base font-bold text-slate-200 flex items-center gap-2">
                          <Wrench size={18} className="text-blue-400" /> 
                          <span>مدیریت تجهیزات و ماشین‌آلات (Equipment Management)</span>
                        </h2>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 bg-[#070e22]/90 p-1 rounded-xl border border-indigo-500/20 w-fit">
                      <button 
                        onClick={() => { setEquipmentTab('list'); setSelectedFamilyForDetail(null); }} 
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          equipmentTab === 'list' ? 'bg-[#132448] text-slate-200 border border-[#484F58]' : 'text-slate-500'
                        }`}
                      >
                        لیست تجهیزات ({equipmentList.length})
                      </button>
                      <button 
                        onClick={() => { setEquipmentTab('families'); setSelectedFamilyForDetail(null); }} 
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          equipmentTab === 'families' ? 'bg-[#132448] text-slate-200 border border-[#484F58]' : 'text-slate-500'
                        }`}
                      >
                        خانواده تجهیزات ({familyList.length})
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
                    <select
                      value={selectedLocationFilter}
                      onChange={e => {
                        setSelectedLocationFilter(e.target.value);
                        setEquipmentPage(1);
                      }}
                      className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-blue-500 cursor-pointer"
                    >
                      <option value="all">📍 همه مکان‌ها (۸ سالن)</option>
                      {locationsList.map(loc => (
                        <option key={loc.id} value={loc.name}>
                          {loc.code} - {loc.name}
                        </option>
                      ))}
                    </select>

                    <div className="relative">
                      <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                        type="text" 
                        value={equipmentSearch}
                        onChange={e => {
                          setEquipmentSearch(e.target.value);
                          setEquipmentPage(1);
                          setFamilyPage(1);
                        }}
                        placeholder="جستجو در کد، نام، خانواده..."
                        className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-200 outline-none focus:border-blue-500 w-full sm:w-56"
                      />
                    </div>
                    <button 
                      onClick={equipmentTab === 'list' ? () => { setEqFormData({ id: '', name: '', family: '', location: '', priority: 'سطح C' }); setIsEditingEq(false); setIsEqModalOpen(true); } : () => { setFamFormData({ id: '', name: '', group: '' }); setIsEditingFam(false); setIsFamModalOpen(true); }} 
                      className="flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                    >
                      <Plus size={15} /> 
                      <span>افزودن {equipmentTab === 'list' ? 'دستگاه جدید' : 'خانواده جدید'}</span>
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto flex-1">
                  {equipmentTab === 'list' ? (() => {
                    const filtered = equipmentList.filter(eq => {
                      if (selectedLocationFilter !== 'all') {
                        if (!eq.location || !eq.location.includes(selectedLocationFilter)) {
                          return false;
                        }
                      }
                      if (!equipmentSearch.trim()) return true;
                      const q = equipmentSearch.toLowerCase().trim();
                      return (
                        (eq.id && eq.id.toLowerCase().includes(q)) ||
                        (eq.name && eq.name.toLowerCase().includes(q)) ||
                        (eq.family && eq.family.toLowerCase().includes(q)) ||
                        (eq.location && eq.location.toLowerCase().includes(q)) ||
                        (eq.priority && eq.priority.toLowerCase().includes(q))
                      );
                    });
                    const perPage = 25;
                    const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
                    const currentPage = Math.min(equipmentPage, totalPages);
                    const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

                    return (
                      <div className="flex flex-col">
                        <table className="w-full text-right whitespace-nowrap text-xs">
                          <thead>
                            <tr className="bg-[#070e22]/90/80 text-slate-400 border-b border-indigo-900/40">
                              <th className="px-5 py-3.5 font-bold">کد تجهیز</th>
                              <th className="px-5 py-3.5 font-bold">نام دستگاه</th>
                              <th className="px-5 py-3.5 font-bold">خانواده</th>
                              <th className="px-5 py-3.5 font-bold">مکان / سالن</th>
                              <th className="px-5 py-3.5 font-bold">اولویت</th>
                              <th className="px-5 py-3.5 font-bold text-center">عملیات</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#333538]/50">
                            {filtered.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="text-center py-12 text-slate-400">
                                  <Wrench size={32} className="mx-auto mb-2 text-slate-600" />
                                  <span className="block text-xs font-bold text-slate-300">هیچ تجهیزی یافت نشد</span>
                                  <span className="text-[11px] text-slate-500">موردی با مشخصات جستجوی شما مطابقت ندارد.</span>
                                </td>
                              </tr>
                            ) : (
                              paginated.map(eq => (
                                <tr key={eq.id} className="hover:bg-[#112042]/50 transition-colors">
                                  <td className="px-5 py-3.5 font-mono font-bold text-blue-300">{eq.id}</td>
                                  <td className="px-5 py-3.5 font-bold text-slate-200">{eq.name}</td>
                                  <td className="px-5 py-3.5 text-slate-300">{eq.family}</td>
                                  <td className="px-5 py-3.5 text-slate-400">{eq.location}</td>
                                  <td className="px-5 py-3.5">
                                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                                      eq.priority === 'سطح A' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' : 
                                      eq.priority === 'سطح B' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                                      'bg-slate-800 text-slate-300'
                                    }`}>{eq.priority}</span>
                                  </td>
                                  <td className="px-5 py-3.5 text-center">
                                    <div className="flex justify-center gap-1.5">
                                      <button 
                                        onClick={() => { setEqFormData(eq); setIsEditingEq(true); setIsEqModalOpen(true); }}
                                        className="p-1.5 text-slate-400 hover:text-blue-300 cursor-pointer"
                                        title="ویرایش تجهیز"
                                      >
                                        <Pencil size={14} />
                                      </button>
                                      <button 
                                        onClick={() => deleteEquipment(eq.id)}
                                        className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                                        title="حذف تجهیز"
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>

                        {/* صفحه‌بندی تجهیزات */}
                        {filtered.length > perPage && (
                          <div className="p-3 border-t border-indigo-900/40 bg-[#070e22]/90 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                            <div>
                              نمایش {((currentPage - 1) * perPage) + 1} تا {Math.min(currentPage * perPage, filtered.length)} از {filtered.length} دستگاه / تجهیز
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                disabled={currentPage <= 1}
                                onClick={() => setEquipmentPage(p => Math.max(1, p - 1))}
                                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 cursor-pointer"
                              >
                                قبلی
                              </button>
                              <span className="font-mono text-blue-300">صفحه {currentPage} از {totalPages}</span>
                              <button
                                type="button"
                                disabled={currentPage >= totalPages}
                                onClick={() => setEquipmentPage(p => Math.min(totalPages, p + 1))}
                                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 cursor-pointer"
                              >
                                بعدی
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })() : (() => {
                      const filtered = familyList.filter(fam => {
                        if (!equipmentSearch.trim()) return true;
                        const q = equipmentSearch.toLowerCase().trim();
                        return (
                          (fam.id && fam.id.toLowerCase().includes(q)) ||
                          (fam.name && fam.name.toLowerCase().includes(q)) ||
                          (fam.group && fam.group.toLowerCase().includes(q))
                        );
                      });
                      const perPage = 25;
                      const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
                      const currentPage = Math.min(familyPage, totalPages);
                      const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

                      return (
                        <div className="flex flex-col">
                          <table className="w-full text-right whitespace-nowrap text-xs">
                            <thead>
                              <tr className="bg-[#070e22]/90/80 text-slate-400 border-b border-indigo-900/40">
                                <th className="px-5 py-3.5 font-bold">کد خانواده</th>
                                <th className="px-5 py-3.5 font-bold">نام خانواده تجهیزات</th>
                                <th className="px-5 py-3.5 font-bold">گروه اصلی</th>
                                <th className="px-5 py-3.5 font-bold text-center">عملیات</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-[#333538]/50">
                              {filtered.length === 0 ? (
                                <tr>
                                  <td colSpan={4} className="text-center py-12 text-slate-400">
                                    <Layers size={32} className="mx-auto mb-2 text-slate-600" />
                                    <span className="block text-xs font-bold text-slate-300">هیچ خانواده تجهیزی یافت نشد</span>
                                    <span className="text-[11px] text-slate-500">موردی با مشخصات جستجوی شما مطابقت ندارد.</span>
                                  </td>
                                </tr>
                              ) : (
                                paginated.map(fam => (
                                  <tr 
                                    key={fam.id} 
                                    onClick={() => setSelectedFamilyForDetail(fam)}
                                    className="hover:bg-[#112042]/50 transition-colors cursor-pointer group"
                                  >
                                    <td className="px-5 py-3.5 font-mono font-bold text-indigo-300 group-hover:text-indigo-200 group-hover:underline">
                                      {fam.id}
                                    </td>
                                    <td className="px-5 py-3.5 font-bold text-slate-200 group-hover:text-cyan-300">
                                      {fam.name}
                                    </td>
                                    <td className="px-5 py-3.5 text-slate-400">{fam.group}</td>
                                    <td className="px-5 py-3.5 text-center" onClick={e => e.stopPropagation()}>
                                      <div className="flex justify-center gap-1.5">
                                        <button 
                                          onClick={() => setSelectedFamilyForDetail(fam)}
                                          className="p-1.5 text-slate-400 hover:text-cyan-300 cursor-pointer"
                                          title="مشاهده صفحه خانواده تجهیز"
                                        >
                                          <Eye size={14} />
                                        </button>
                                        <button 
                                          onClick={() => { setFamFormData(fam); setIsEditingFam(true); setIsFamModalOpen(true); }}
                                          className="p-1.5 text-slate-400 hover:text-blue-300 cursor-pointer"
                                          title="ویرایش خانواده"
                                        >
                                          <Pencil size={14} />
                                        </button>
                                        <button 
                                          onClick={() => deleteFamily(fam.id)}
                                          className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                                          title="حذف خانواده"
                                        >
                                          <Trash2 size={14} />
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>

                          {/* صفحه‌بندی و شمارنده خانواده‌ها */}
                          {filtered.length > perPage && (
                            <div className="p-3 border-t border-indigo-900/40 bg-[#070e22]/90 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                              <div>
                                نمایش {((currentPage - 1) * perPage) + 1} تا {Math.min(currentPage * perPage, filtered.length)} از {filtered.length} خانواده تجهیز
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  disabled={currentPage <= 1}
                                  onClick={() => setFamilyPage(p => Math.max(1, p - 1))}
                                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 cursor-pointer"
                                >
                                  قبلی
                                </button>
                                <span className="font-mono text-purple-300">صفحه {currentPage} از {totalPages}</span>
                                <button
                                  type="button"
                                  disabled={currentPage >= totalPages}
                                  onClick={() => setFamilyPage(p => Math.min(totalPages, p + 1))}
                                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 cursor-pointer"
                                >
                                  بعدی
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })()}
                </div>
              </div>
              )
            )}

            {/* ======================================================== */}
            {/* VIEW: LOCATIONS (activeView === 'locations')              */}
            {/* ======================================================== */}
            {activeView === 'locations' && (
              <div className="space-y-6">
                {/* Header Card */}
                <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 p-5 sm:p-6 shadow-lg flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActiveView('dashboard')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-purple-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
                      title="بازگشت به داشبورد PM"
                    >
                      <ArrowRight size={14} />
                      <span>بازگشت به داشبورد</span>
                    </button>
                    <div>
                      <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                        <MapPin size={18} className="text-emerald-400" />
                        <span>مدیریت مکان‌ها و سالن‌های استقرار (Plant Locations & Zones)</span>
                      </h2>
                      <p className="text-xs text-slate-400 mt-1">
                        سلسله‌مراتب مکان‌ها و سالن‌های اصلی با امکان افزودن زیرسیستم‌ها (طبقات، بخش‌ها و نواحی تحت پوشش)
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                    <div className="relative">
                      <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={locationSearch}
                        onChange={e => setLocationSearch(e.target.value)}
                        placeholder="جستجو در نام، کد یا زیرسیستم..."
                        className="bg-[#070e22]/90 border border-indigo-500/20 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-200 outline-none focus:border-emerald-500 w-full sm:w-60"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const nextNum = locationsList.length + 1;
                        const codeStr = nextNum < 10 ? `S0${nextNum}` : `S${nextNum}`;
                        setLocFormData({ id: '', code: codeStr, name: '', description: '' });
                        setIsEditingLoc(false);
                        setIsLocModalOpen(true);
                      }}
                      className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                    >
                      <Plus size={15} />
                      <span>افزودن مکان / سالن جدید</span>
                    </button>
                  </div>
                </div>

                {/* Stats Summary Banner */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-emerald-500/20 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Building2 size={20} />
                    </div>
                    <div>
                      <div className="text-xl font-bold font-mono text-emerald-300">{locationsList.length}</div>
                      <div className="text-xs text-slate-400">سالن و بخش اصلی ثبت‌شده</div>
                    </div>
                  </div>

                  <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-blue-500/20 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                      <FolderTree size={20} />
                    </div>
                    <div>
                      <div className="text-xl font-mono font-bold text-blue-300">
                        {locationsList.reduce((acc, loc) => acc + (loc.subLocations?.length || 0), 0)}
                      </div>
                      <div className="text-xs text-slate-400">زیرسیستم، طبقه و ناحیه فعال</div>
                    </div>
                  </div>

                  <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-purple-500/20 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <Wrench size={20} />
                    </div>
                    <div>
                      <div className="text-xl font-mono font-bold text-purple-300">
                        {equipmentList.length}
                      </div>
                      <div className="text-xs text-slate-400">دستگاه و تجهیز تحت پوشش مکان‌ها</div>
                    </div>
                  </div>
                </div>

                {/* Locations Tree / Accordion List */}
                <div className="space-y-3">
                  {locationsList
                    .filter(loc => {
                      if (!locationSearch.trim()) return true;
                      const q = locationSearch.toLowerCase().trim();
                      const matchMain = loc.code.toLowerCase().includes(q) || loc.name.toLowerCase().includes(q) || (loc.description && loc.description.toLowerCase().includes(q));
                      const matchSub = (loc.subLocations || []).some((s: any) => s.name.toLowerCase().includes(q));
                      return matchMain || matchSub;
                    })
                    .map(loc => {
                      const isExpanded = !!expandedLocations[loc.id];
                      const assignedEquipments = equipmentList.filter(eq => eq.location && (eq.location.includes(loc.name) || eq.location.includes(loc.code)));
                      const subList = loc.subLocations || [];

                      return (
                        <div key={loc.id} className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 overflow-hidden shadow-lg transition-all">
                          {/* Accordion Header */}
                          <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#070e22]/60 hover:bg-[#112042]/50 transition-colors">
                            <div className="flex items-center gap-3 flex-1 cursor-pointer select-none" onClick={() => toggleLocationExpand(loc.id)}>
                              <button
                                type="button"
                                className="w-8 h-8 rounded-lg bg-[#132448] text-slate-300 hover:text-white flex items-center justify-center border border-indigo-500/30"
                              >
                                {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                              </button>
                              
                              <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 font-mono font-bold text-xs text-emerald-400">
                                {loc.code}
                              </div>

                              <div>
                                <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                                  <span>{loc.name}</span>
                                  <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                                    {subList.length} زیرسیستم
                                  </span>
                                  <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                    {assignedEquipments.length} دستگاه
                                  </span>
                                </div>
                                {loc.description && (
                                  <p className="text-[11px] text-slate-400 mt-0.5">{loc.description}</p>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-2 self-end sm:self-center">
                              <button
                                type="button"
                                onClick={() => {
                                  setLocFormData({
                                    id: loc.id,
                                    code: loc.code,
                                    name: loc.name,
                                    description: loc.description || ''
                                  });
                                  setIsEditingLoc(true);
                                  setIsLocModalOpen(true);
                                }}
                                className="p-1.5 text-slate-400 hover:text-blue-300 cursor-pointer"
                                title="ویرایش مکان"
                              >
                                <Pencil size={15} />
                              </button>
                              <button
                                type="button"
                                onClick={() => setLocDeleteConfirm({ id: loc.id, name: loc.name })}
                                className="p-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                                title="حذف مکان"
                              >
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </div>

                          {/* Accordion Body */}
                          {isExpanded && (
                            <div className="p-5 border-t border-indigo-900/40 bg-[#070e22]/30 space-y-4">
                              {/* Sub-locations section */}
                              <div>
                                <div className="flex items-center justify-between mb-2">
                                  <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                                    <FolderTree size={14} className="text-blue-400" />
                                    <span>زیرسیستم‌ها و بخش‌های زیرمجموعه {loc.name}:</span>
                                  </h4>
                                </div>

                                {/* Tags of sub-locations */}
                                <div className="flex flex-wrap gap-2 mb-3">
                                  {subList.length === 0 ? (
                                    <span className="text-xs text-slate-500 italic">هنوز زیرسیستمی ثبت نشده است. از فرم زیر می‌توانید اضافه کنید.</span>
                                  ) : (
                                    subList.map((sub: any) => {
                                      const subEqCount = equipmentList.filter(eq => eq.location && eq.location.includes(sub.name)).length;
                                      return (
                                        <div
                                          key={sub.id}
                                          className="flex items-center gap-2 bg-[#132448]/90 hover:bg-[#132448] text-slate-200 px-3 py-1.5 rounded-xl border border-indigo-500/30 text-xs shadow-sm transition-colors"
                                        >
                                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                                          <span className="font-bold">{sub.name}</span>
                                          {subEqCount > 0 && (
                                            <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-blue-500/20 text-blue-300 font-mono">
                                              {subEqCount} تجهیز
                                            </span>
                                          )}
                                          <button
                                            type="button"
                                            onClick={() => handleDeleteSubLocation(loc.id, sub.id)}
                                            className="text-slate-400 hover:text-rose-400 ml-1 cursor-pointer transition-colors"
                                            title={`حذف ${sub.name}`}
                                          >
                                            <X size={12} />
                                          </button>
                                        </div>
                                      );
                                    })
                                  )}
                                </div>

                                {/* Quick inline add sub-location */}
                                <div className="flex items-center gap-2 max-w-md pt-1">
                                  <input
                                    type="text"
                                    value={newSubLocInputs[loc.id] || ''}
                                    onChange={e => setNewSubLocInputs({ ...newSubLocInputs, [loc.id]: e.target.value })}
                                    onKeyDown={e => {
                                      if (e.key === 'Enter') {
                                        e.preventDefault();
                                        handleAddSubLocation(loc.id);
                                      }
                                    }}
                                    placeholder={`افزودن زیرسیستم جدید به ${loc.name} (مثال: نیم طبقه)...`}
                                    className="flex-1 bg-[#070e22]/90 border border-indigo-500/20 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none focus:border-blue-500"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleAddSubLocation(loc.id)}
                                    className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white px-3 py-2 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer shrink-0"
                                  >
                                    <Plus size={14} />
                                    <span>افزودن</span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* ======================================================== */}
            {/* VIEW 5: INVENTORY (activeView === 'inventory')           */}
            {/* ======================================================== */}
            {activeView === 'inventory' && (
              <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 overflow-hidden shadow-lg p-4 sm:p-6">
                <UnifiedSparePartsManager
                  technicians={technicians}
                  accentColor="purple"
                  onBack={() => setActiveView('dashboard')}
                />
              </div>
            )}

            {/* ======================================================== */}
            {/* VIEW 5: REPORTS (activeView === 'reports')               */}
            {/* ======================================================== */}
            {activeView === 'reports' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2 bg-[#0c162e]/85 backdrop-blur-xl p-1.5 rounded-2xl border border-indigo-500/20 w-fit">
                    <button 
                      onClick={() => setReportTab('dashboard')} 
                      className={`px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        reportTab === 'dashboard' ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-md' : 'text-slate-400'
                      }`}
                    >
                      داشبورد تحلیلی PM
                    </button>
                    <button 
                      onClick={() => setReportTab('activities')} 
                      className={`px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        reportTab === 'activities' ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-md' : 'text-slate-400'
                      }`}
                    >
                      لیست فعالیت‌ها و فیلترهای پیشرفته
                    </button>
                  </div>

                  <button
                    onClick={() => setActiveView('dashboard')}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0c162e] hover:bg-[#112042] border border-indigo-500/30 text-purple-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm w-fit"
                    title="بازگشت به داشبورد PM"
                  >
                    <ArrowRight size={14} />
                    <span>بازگشت به داشبورد</span>
                  </button>
                </div>

                {reportTab === 'dashboard' ? (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* نمودار ستونی ۶ ماه گذشته */}
                    <div className="lg:col-span-2 bg-[#0c162e]/85 backdrop-blur-xl border border-indigo-500/20 rounded-2xl p-6 shadow-lg space-y-4">
                      <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
                        <h3 className="text-sm font-bold text-slate-200">روند اجرای دستورکارهای پیشگیرانه (۶ ماه گذشته)</h3>
                        <span className="text-xs text-purple-400 font-bold">مجموع ۵۶۵ دستورکار</span>
                      </div>
                      <div className="h-64 flex items-end justify-between px-2 pt-6">
                        {[
                          { m: 'خرداد', p: 80 }, 
                          { m: 'تیر', p: 95 }, 
                          { m: 'مرداد', p: 70 }, 
                          { m: 'شهریور', p: 110 }, 
                          { m: 'مهر', p: 90 }, 
                          { m: 'آبان', p: 125 }
                        ].map((data, i) => (
                          <div key={i} className="flex flex-col items-center gap-2 flex-1 group">
                            <span className="text-[10px] text-purple-300 opacity-0 group-hover:opacity-100 transition-opacity font-bold">
                              {data.p}
                            </span>
                            <div className="w-full flex justify-center gap-1 h-44 items-end relative">
                              <div 
                                className="w-1/2 max-w-[36px] bg-gradient-to-t from-purple-700 to-indigo-500 rounded-t-lg transition-all duration-500 shadow-[0_0_12px_rgba(168,85,247,0.3)] group-hover:brightness-125" 
                                style={{ height: `${((data.p / 140) * 100)}%` }}
                              ></div>
                            </div>
                            <div className="text-xs text-slate-400 font-bold">{data.m}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* شاخص‌های کلیدی KPI */}
                    <div className="bg-[#0c162e]/85 backdrop-blur-xl border border-indigo-500/20 rounded-2xl p-6 shadow-lg space-y-4 flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-slate-200 pb-3 border-b border-indigo-900/40">شاخص‌های بهره‌وری (KPI)</h3>
                        <div className="space-y-4 mt-4 text-xs">
                          <div className="p-3 rounded-xl bg-[#070e22]/90 border border-indigo-500/20">
                            <span className="text-slate-400 text-[11px] block">میانگین زمان بین خرابی (MTBF)</span>
                            <strong className="text-lg font-black text-emerald-400">۳۴۰ ساعت کارکرد</strong>
                          </div>
                          <div className="p-3 rounded-xl bg-[#070e22]/90 border border-indigo-500/20">
                            <span className="text-slate-400 text-[11px] block">درصد انطباق برنامه‌های PM (Compliance)</span>
                            <strong className="text-lg font-black text-purple-400">۹۲.۴٪</strong>
                          </div>
                          <div className="p-3 rounded-xl bg-[#070e22]/90 border border-indigo-500/20">
                            <span className="text-slate-400 text-[11px] block">دستگاه دارای بیشترین سرویس</span>
                            <strong className="text-sm font-bold text-amber-400">پرس هیدرولیک ۱۰۰ تن</strong>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-lg min-h-[500px]">
                    <div className="p-4 bg-[#070e22]/90 border-b border-indigo-900/40 flex flex-wrap items-center justify-between gap-3">
                      <span className="text-xs text-slate-300 font-bold">روبان فیلترهای پیشرفته سوابق (ERP Ribbon)</span>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setActivitiesReportTab('general')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold ${activitiesReportTab === 'general' ? 'bg-[#132448] text-purple-300' : 'text-slate-500'}`}
                        >
                          نمای کلی
                        </button>
                        <button 
                          onClick={() => setActivitiesReportTab('detailed')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold ${activitiesReportTab === 'detailed' ? 'bg-[#132448] text-purple-300' : 'text-slate-500'}`}
                        >
                          نمای تفصیلی
                        </button>
                      </div>
                    </div>
                    <div className="p-8 text-center text-slate-400 text-xs">
                      سوابق تمام فعالیت‌ها آماده گزارش‌گیری و صدور به اکسل می‌باشند.
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ======================================================== */}
            {/* VIEW 6: SETTINGS (activeView === 'settings')             */}
            {/* ======================================================== */}
            {activeView === 'settings' && (
              <div className="bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 p-6 max-w-2xl mx-auto space-y-6">
                <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
                  <h3 className="text-base font-bold text-slate-200 flex items-center gap-2">
                    <Settings size={18} className="text-purple-400" />
                    <span>تنظیمات نگهداری پیشگیرانه PM</span>
                  </h3>
                  <button
                    onClick={() => setActiveView('dashboard')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-purple-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                    title="بازگشت به داشبورد PM"
                  >
                    <ArrowRight size={14} />
                    <span>بازگشت به داشبورد</span>
                  </button>
                </div>
                <div className="space-y-4 text-xs">
                  <div className="p-4 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 flex items-center justify-between">
                    <div>
                      <strong className="text-slate-200 block">پوشش Dark Theme نئونی</strong>
                      <span className="text-slate-400 text-[11px]">پالت رنگی پیش‌فرض استاندارد (#131416 و #1E1F22)</span>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-purple-500/20 text-purple-300 font-bold text-[11px]">فعال</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 flex items-center justify-between">
                    <div>
                      <strong className="text-slate-200 block">ذخیره‌سازی و پایداری داده‌ها</strong>
                      <span className="text-slate-400 text-[11px]">همگام‌سازی دائمی با حافظه دستگاه و سرور مرکزی</span>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[11px]">آنلاین</span>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </main>

      {/* ======================================================== */}
      {/* MODAL 1: افزودن تکنسین (Add Technician)                 */}
      {/* ======================================================== */}
      {isTechModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-md bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl overflow-hidden space-y-4 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Users size={16} className="text-purple-400" />
                <span>افزودن تکنسین فنی جدید</span>
              </h3>
              <button onClick={() => setIsTechModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">نام و نام خانوادگی:</label>
                <input 
                  type="text" 
                  value={newTechData.name} 
                  onChange={e => setNewTechData({ ...newTechData, name: e.target.value })} 
                  placeholder="مثال: رضا احمدی" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-purple-500" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">نقش و تخصص:</label>
                <input 
                  type="text" 
                  value={newTechData.role} 
                  onChange={e => setNewTechData({ ...newTechData, role: e.target.value })} 
                  placeholder="مثال: تکنسین برق صنعتی" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-purple-500" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">تصویر پروفایل (اختیاری):</label>
                <input 
                  type="file" 
                  accept="image/*"
                  onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = ev => setNewTechData({ ...newTechData, image: ev.target?.result as string });
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2 text-slate-400 text-xs" 
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button onClick={() => setIsTechModalOpen(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                انصراف
              </button>
              <button onClick={saveTechnician} className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md cursor-pointer">
                ثبت تکنسین
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 2: افزودن/ویرایش تجهیز (Add / Edit Equipment)       */}
      {/* ======================================================== */}
      {isEqModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-md bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Wrench size={16} className="text-blue-400" />
                <span>{isEditingEq ? 'ویرایش اطلاعات دستگاه' : 'افزودن دستگاه جدید'}</span>
              </h3>
              <button onClick={() => setIsEqModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">کد تجهیز (یکتا):</label>
                <input 
                  type="text" 
                  value={eqFormData.id} 
                  disabled={isEditingEq}
                  onChange={e => setEqFormData({ ...eqFormData, id: e.target.value })} 
                  placeholder="مثال: TUTN03" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-blue-500 font-mono disabled:opacity-50" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">نام دستگاه:</label>
                <input 
                  type="text" 
                  value={eqFormData.name} 
                  onChange={e => setEqFormData({ ...eqFormData, name: e.target.value })} 
                  placeholder="مثال: تورنوس سوئیسی Tornos DE-20 #3" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-blue-500" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">خانواده تجهیز (با پیشنهاد خودکار Datalist):</label>
                <input 
                  type="text" 
                  list="family-suggestions"
                  value={eqFormData.family} 
                  onChange={e => setEqFormData({ ...eqFormData, family: e.target.value })} 
                  placeholder="انتخاب یا تایپ خانواده..." 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-blue-500" 
                />
                <datalist id="family-suggestions">
                  {familyList.map(fam => (
                    <option key={fam.id} value={fam.name} />
                  ))}
                </datalist>
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-400 block">مکان و سالن استقرار (تحت نظر مکان‌های ثبت‌شده):</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select 
                    value={(() => {
                      const matched = locationsList.find(l => eqFormData.location && (eqFormData.location.includes(l.name) || eqFormData.location.includes(l.code)));
                      return matched ? matched.name : '';
                    })()}
                    onChange={e => {
                      const chosenName = e.target.value;
                      if (!chosenName) return;
                      setEqFormData({ ...eqFormData, location: chosenName });
                    }}
                    className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2 text-slate-200 outline-none focus:border-blue-500 text-xs"
                  >
                    <option value="">-- انتخاب سالن اصلی --</option>
                    {locationsList.map(loc => (
                      <option key={loc.id} value={loc.name}>
                        {loc.code} - {loc.name}
                      </option>
                    ))}
                  </select>

                  <select 
                    value={(() => {
                      const matchedLoc = locationsList.find(l => eqFormData.location && (eqFormData.location.includes(l.name) || eqFormData.location.includes(l.code)));
                      if (!matchedLoc || !matchedLoc.subLocations) return '';
                      const matchedSub = matchedLoc.subLocations.find((s: any) => eqFormData.location.includes(s.name));
                      return matchedSub ? matchedSub.name : '';
                    })()}
                    onChange={e => {
                      const subVal = e.target.value;
                      const matchedLoc = locationsList.find(l => eqFormData.location && (eqFormData.location.includes(l.name) || eqFormData.location.includes(l.code)));
                      const baseName = matchedLoc ? matchedLoc.name : (locationsList[0]?.name || 'سالن یک');
                      if (!subVal) {
                        setEqFormData({ ...eqFormData, location: baseName });
                      } else {
                        setEqFormData({ ...eqFormData, location: `${baseName}_${subVal}` });
                      }
                    }}
                    className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2 text-slate-200 outline-none focus:border-blue-500 text-xs"
                  >
                    <option value="">-- زیرسیستم / بخش --</option>
                    {(() => {
                      const matchedLoc = locationsList.find(l => eqFormData.location && (eqFormData.location.includes(l.name) || eqFormData.location.includes(l.code)));
                      const subs = matchedLoc ? (matchedLoc.subLocations || []) : [];
                      return subs.map((sub: any) => (
                        <option key={sub.id} value={sub.name}>{sub.name}</option>
                      ));
                    })()}
                  </select>
                </div>
                <input 
                  type="text" 
                  value={eqFormData.location} 
                  onChange={e => setEqFormData({ ...eqFormData, location: e.target.value })} 
                  placeholder="مسیر دقیق مکان استقرار (مثال: سالن یک_نیم طبقه)" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-blue-500 text-xs font-mono" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">سطح اولویت تجهیز:</label>
                <select
                  value={eqFormData.priority}
                  onChange={e => setEqFormData({ ...eqFormData, priority: e.target.value })}
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none"
                >
                  <option value="سطح A">سطح A (حیاتی و گلوگاه خط تولید)</option>
                  <option value="سطح B">سطح B (مهم و دارای جایگزین محدود)</option>
                  <option value="سطح C">سطح C (عادی)</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button onClick={() => setIsEqModalOpen(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                انصراف
              </button>
              <button onClick={saveEquipment} className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer">
                {isEditingEq ? 'ذخیره تغییرات' : 'ثبت دستگاه'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 3: افزودن/ویرایش خانواده تجهیزات                    */}
      {/* ======================================================== */}
      {isFamModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-sm bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Layers size={16} className="text-blue-400" />
                <span>{isEditingFam ? 'ویرایش خانواده تجهیز' : 'افزودن خانواده تجهیز جدید'}</span>
              </h3>
              <button onClick={() => setIsFamModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">کد خانواده:</label>
                <input 
                  type="text" 
                  value={famFormData.id} 
                  disabled={isEditingFam}
                  onChange={e => setFamFormData({ ...famFormData, id: e.target.value })} 
                  placeholder="مثال: FAM-CNC" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none font-mono disabled:opacity-50" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">نام خانواده:</label>
                <input 
                  type="text" 
                  value={famFormData.name} 
                  onChange={e => setFamFormData({ ...famFormData, name: e.target.value })} 
                  placeholder="مثال: ماشین‌آلات برش لیزر" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none" 
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">گروه اصلی:</label>
                <input 
                  type="text" 
                  value={famFormData.group} 
                  onChange={e => setFamFormData({ ...famFormData, group: e.target.value })} 
                  placeholder="مثال: تولیدی" 
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none" 
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button onClick={() => setIsFamModalOpen(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                انصراف
              </button>
              <button onClick={saveFamily} className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer">
                {isEditingFam ? 'ذخیره' : 'ثبت'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 4: برنامه‌ریزی و تولید گروهی PM (Plan & Batch Gen)  */}
      {/* ======================================================== */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className={`w-full ${planModalTab === 'batch' ? 'max-w-4xl' : 'max-w-lg'} max-h-[92vh] overflow-y-auto bg-[#0c162e]/95 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-5 sm:p-6 space-y-4`}>
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <div className="flex items-center gap-2">
                <CalendarIcon size={18} className="text-purple-400" />
                <h3 className="text-sm font-bold text-slate-200">برنامه‌ریزی دستورکار پیشگیرانه (PM Planning)</h3>
              </div>
              <button onClick={() => setIsPlanModalOpen(false)} className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800">
                <X size={18} />
              </button>
            </div>

            {/* گزینش تب: تکی یا تولید گروهی */}
            <div className="flex items-center gap-1 bg-[#070e22]/90 p-1 rounded-xl border border-indigo-500/20">
              <button
                type="button"
                onClick={() => setPlanModalTab('batch')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  planModalTab === 'batch' ? 'bg-[#132448] text-purple-400 border border-purple-500/40' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                تولید گروهی و چندتایی (Batch Generation) 🚀
              </button>
              <button
                type="button"
                onClick={() => setPlanModalTab('single')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  planModalTab === 'single' ? 'bg-[#132448] text-purple-400 border border-purple-500/40' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                ثبت تک برنامه (Single)
              </button>
            </div>

            {planModalTab === 'batch' ? (() => {
              const q = batchEqSearch.trim().toLowerCase();
              const filteredEquipments = equipmentList.filter(eq => {
                const matchesSearch = !q || 
                  (eq.name && eq.name.toLowerCase().includes(q)) || 
                  (eq.id && eq.id.toLowerCase().includes(q)) || 
                  (eq.location && eq.location.toLowerCase().includes(q)) || 
                  (eq.family && eq.family.toLowerCase().includes(q));
                const matchesLoc = batchLocationFilter === 'all' || eq.location === batchLocationFilter;
                const matchesFam = batchFamilyFilter === 'all' || eq.family === batchFamilyFilter;
                return matchesSearch && matchesLoc && matchesFam;
              });

              const uniqueLocs = Array.from(new Set(equipmentList.map(e => e.location).filter(Boolean)));
              const uniqueFams = Array.from(new Set(equipmentList.map(e => e.family).filter(Boolean)));
              const activeFreqCount = Object.values(batchFormData.frequencies).filter(Boolean).length;
              const totalEstimatedOrders = batchSelectedEqIds.length * activeFreqCount;

              const toggleEq = (id: string) => {
                setBatchSelectedEqIds(prev => 
                  prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
                );
              };

              const selectFirst20 = () => {
                const first20 = filteredEquipments.slice(0, 20).map(e => e.id);
                setBatchSelectedEqIds(prev => Array.from(new Set([...prev, ...first20])));
              };

              const selectAllFiltered = () => {
                const allIds = filteredEquipments.map(e => e.id);
                setBatchSelectedEqIds(prev => Array.from(new Set([...prev, ...allIds])));
              };

              const selectAllLathes = () => {
                const latheIds = equipmentList.filter(e => 
                  (e.id && (e.id.toUpperCase().includes('TUTL') || e.id.toUpperCase().includes('TULT'))) ||
                  (e.name && e.name.includes('تراش'))
                ).map(e => e.id);
                setBatchSelectedEqIds(prev => Array.from(new Set([...prev, ...latheIds])));
              };

              const selectAllTornos = () => {
                const tornoIds = equipmentList.filter(e => 
                  (e.id && e.id.toUpperCase().includes('TUTN')) ||
                  (e.name && e.name.includes('تورنوس'))
                ).map(e => e.id);
                setBatchSelectedEqIds(prev => Array.from(new Set([...prev, ...tornoIds])));
              };

              return (
                <div className="space-y-4 text-xs">
                  {/* ردیف فیلتر و جستجوی تجهیزات */}
                  <div className="bg-[#070e22]/90 p-3 rounded-xl border border-indigo-500/20 space-y-2.5">
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <div className="relative flex-1">
                        <Search size={14} className="absolute right-3 top-2.5 text-slate-500" />
                        <input
                          type="text"
                          value={batchEqSearch}
                          onChange={e => setBatchEqSearch(e.target.value)}
                          placeholder="جستجوی تجهیز با کد یا نام (مانند TUTL, تراش, تورنوس, پرس...)"
                          className="w-full bg-[#0c162e] border border-indigo-500/20 rounded-xl pr-9 pl-3 py-2 text-slate-200 outline-none focus:border-purple-500 text-xs placeholder:text-slate-600"
                        />
                        {batchEqSearch && (
                          <button onClick={() => setBatchEqSearch('')} className="absolute left-2.5 top-2.5 text-slate-500 hover:text-slate-300">
                            <X size={13} />
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <select
                          value={batchLocationFilter}
                          onChange={e => setBatchLocationFilter(e.target.value)}
                          className="bg-[#0c162e] border border-indigo-500/20 rounded-xl px-2.5 py-2 text-slate-300 outline-none text-xs"
                        >
                          <option value="all">همه مکان‌ها</option>
                          {uniqueLocs.map(loc => (
                            <option key={loc} value={loc}>{loc}</option>
                          ))}
                        </select>

                        <select
                          value={batchFamilyFilter}
                          onChange={e => setBatchFamilyFilter(e.target.value)}
                          className="bg-[#0c162e] border border-indigo-500/20 rounded-xl px-2.5 py-2 text-slate-300 outline-none text-xs"
                        >
                          <option value="all">همه خانواده‌ها</option>
                          {uniqueFams.map(fam => (
                            <option key={fam} value={fam}>{fam}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* دکمه‌های انتخاب سریع (درخواست مستقیم کاربر: تیک زدن ۲۰ تا باهم و تفکیک سریع) */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <span className="text-[11px] text-slate-400 font-bold ml-1">انتخاب سریع:</span>
                      
                      <button
                        type="button"
                        onClick={selectFirst20}
                        className="px-2.5 py-1 rounded-lg bg-purple-600/25 hover:bg-purple-600/40 text-purple-300 border border-purple-500/40 text-[11px] font-bold transition-all cursor-pointer shadow-sm"
                        title="انتخاب ۲۰ تجهیز ابتدایی لیست فیلترشده"
                      >
                        + انتخاب ۲۰ تجهیز اول
                      </button>

                      <button
                        type="button"
                        onClick={selectAllLathes}
                        className="px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/35 text-blue-300 border border-blue-500/30 text-[11px] font-bold transition-all cursor-pointer"
                        title="انتخاب تمام ماشین‌آلات تراش با کد TUTL یا نام تراش"
                      >
                        + تمام تراش‌ها (TUTL)
                      </button>

                      <button
                        type="button"
                        onClick={selectAllTornos}
                        className="px-2.5 py-1 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/35 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold transition-all cursor-pointer"
                        title="انتخاب تمام ماشین‌آلات تورنوس با کد TUTN"
                      >
                        + تمام تورنوس‌ها (TUTN)
                      </button>

                      <button
                        type="button"
                        onClick={selectAllFiltered}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-indigo-500/20 text-[11px] font-bold transition-all cursor-pointer"
                      >
                        انتخاب همه ({filteredEquipments.length})
                      </button>

                      {batchSelectedEqIds.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setBatchSelectedEqIds([])}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-[11px] font-bold transition-all cursor-pointer mr-auto"
                        >
                          ✕ لغو انتخاب‌ها
                        </button>
                      )}
                    </div>
                  </div>

                  {/* نوار وضعیت شمارش انتخاب‌شده‌ها */}
                  <div className="flex items-center justify-between px-1">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-bold">تجهیزات هدف:</span>
                      <span className={`px-2.5 py-0.5 rounded-full font-mono font-bold text-xs ${
                        batchSelectedEqIds.length > 0 ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' : 'bg-slate-800 text-slate-500'
                      }`}>
                        {batchSelectedEqIds.length} تجهیز تیک خورده
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500">
                      نمایش {filteredEquipments.length} از {equipmentList.length} تجهیز کل مجموعه
                    </span>
                  </div>

                  {/* جعبه پیمایش لیست تجهیزات با چک‌باکس */}
                  <div className="max-h-56 overflow-y-auto space-y-1.5 border border-indigo-500/20 rounded-xl p-2 bg-[#070e22]/60 divide-y divide-indigo-900/30">
                    {filteredEquipments.length === 0 ? (
                      <div className="py-8 text-center text-slate-500 text-xs">
                        تجهیزی منطبق با عبارت جستجو یا فیلترهای انتخابی یافت نشد.
                      </div>
                    ) : (
                      filteredEquipments.map(eq => {
                        const isSelected = batchSelectedEqIds.includes(eq.id);
                        return (
                          <div
                            key={eq.id}
                            onClick={() => toggleEq(eq.id)}
                            className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-all ${
                              isSelected 
                                ? 'bg-purple-950/40 border border-purple-500/50 text-white' 
                                : 'hover:bg-[#132448]/40 text-slate-300 border border-transparent'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}} // handled by parent onClick
                                className="accent-purple-600 rounded w-4 h-4 cursor-pointer"
                              />
                              <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-900 text-purple-300 text-[11px] border border-indigo-500/20">
                                {eq.id}
                              </span>
                              <span className="font-bold text-xs">{eq.name}</span>
                            </div>

                            <div className="flex items-center gap-2 text-[10px]">
                              {eq.location && (
                                <span className="px-2 py-0.5 rounded-md bg-slate-900/80 text-slate-400 border border-indigo-900/40">
                                  {eq.location}
                                </span>
                              )}
                              {eq.family && (
                                <span className="px-2 py-0.5 rounded-md bg-indigo-950/40 text-indigo-300 border border-indigo-800/40">
                                  {eq.family}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* تنظیم دوره‌های تناوب و تخصیص تکنسین */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-slate-400 block mb-1.5 font-bold">دوره‌های تناوب مد نظر:</label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { key: 'monthly', label: 'یک ماهه (۳۰ روز)' },
                          { key: 'quarterly', label: 'سه ماهه (۹۰ روز)' },
                          { key: 'biannual', label: 'شش ماهه (۱۸۰ روز)' },
                          { key: 'annual', label: 'سالانه (۳۶۵ روز)' }
                        ].map(f => (
                          <label key={f.key} className="flex items-center gap-2 p-2 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 cursor-pointer hover:border-purple-500/50">
                            <input
                              type="checkbox"
                              checked={(batchFormData.frequencies as any)[f.key]}
                              onChange={e => setBatchFormData({
                                ...batchFormData,
                                frequencies: { ...batchFormData.frequencies, [f.key]: e.target.checked }
                              })}
                              className="accent-purple-600 rounded"
                            />
                            <span className="text-slate-300 text-[11px] font-bold">{f.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-1.5 font-bold">تخصیص تکنسین مجری:</label>
                      <select
                        value={batchAssignedTech}
                        onChange={e => setBatchAssignedTech(e.target.value)}
                        className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-purple-500 text-xs"
                      >
                        <option value="">توزیع هوشمند و خودکار بین همه تکنسین‌ها</option>
                        {techniciansList.map(tech => (
                          <option key={tech.id} value={tech.name}>{tech.name} {tech.role ? `(${tech.role})` : ''}</option>
                        ))}
                      </select>

                      <div className="mt-2 p-2.5 rounded-xl bg-purple-950/20 border border-purple-500/30 text-[11px] text-purple-300/90 leading-relaxed">
                        📊 خلاصه: <strong>{batchSelectedEqIds.length}</strong> تجهیز × <strong>{activeFreqCount}</strong> دوره تناوب = <strong>{totalEstimatedOrders}</strong> برنامه و دستورکار همزمان تولید خواهد شد.
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
                    <button onClick={() => setIsPlanModalOpen(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer">
                      انصراف
                    </button>
                    <button 
                      disabled={batchSelectedEqIds.length === 0 || activeFreqCount === 0} 
                      onClick={generateBatchPlans} 
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-purple-950/60 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all"
                    >
                      ✓ زمان‌بندی و صدور {totalEstimatedOrders > 0 ? `${totalEstimatedOrders} دستورکار برای ` : ''}{batchSelectedEqIds.length} تجهیز
                    </button>
                  </div>
                </div>
              );
            })() : (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">کد برنامه (یکتا):</label>
                  <input
                    type="text"
                    value={singlePlanData.id}
                    onChange={e => setSinglePlanData({ ...singlePlanData, id: e.target.value })}
                    placeholder="مثال: PM-TUTN-01"
                    className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">عنوان برنامه PM:</label>
                  <input
                    type="text"
                    value={singlePlanData.title}
                    onChange={e => setSinglePlanData({ ...singlePlanData, title: e.target.value })}
                    placeholder="مثال: آچارکشی و بازرسی سیستم هیدرولیک"
                    className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">دستگاه مرتبط:</label>
                  <select
                    value={singlePlanData.equipment}
                    onChange={e => setSinglePlanData({ ...singlePlanData, equipment: e.target.value })}
                    className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none"
                  >
                    <option value="">-- انتخاب دستگاه --</option>
                    {equipmentList.map(eq => (
                      <option key={eq.id} value={eq.name}>{eq.name}</option>
                    ))}
                  </select>
                </div>
                <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
                  <button onClick={() => setIsPlanModalOpen(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                    انصراف
                  </button>
                  <button onClick={saveSinglePlan} className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold">
                    ثبت برنامه
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 5: فرم ثبت اجرای دستورکار PM (Execution Modal)       */}
      {/* ======================================================== */}
      {/* ======================================================== */}
      {/* MODAL 5: فرم ثبت اجرای دستورکار PM (Execution Modal)       */}
      {/* ======================================================== */}
      {isExecutionModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-2xl bg-[#0c162e] rounded-2xl border border-indigo-500/30 shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            {/* هدر مودال همراه با نمایش کد دستورکار و کد کامل */}
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
                  <CheckSquare size={18} className="text-purple-400" />
                  <span>ثبت اجرا، اعزام تکنسین‌ها و بستن دستورکار PM</span>
                </h3>
                <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs">
                  <span className="font-mono font-bold text-purple-300 bg-purple-500/15 px-2.5 py-0.5 rounded-lg border border-purple-500/30">
                    کد دستورکار: {selectedOrder.id}
                  </span>
                  <span className="text-slate-400 font-bold">•</span>
                  <span className="text-slate-200 font-bold">{selectedOrder.equipment}</span>
                  {selectedOrder.equipmentCode && (
                    <span className="font-mono text-slate-400">({selectedOrder.equipmentCode})</span>
                  )}
                </div>
              </div>
              <button 
                onClick={() => setIsExecutionModalOpen(false)} 
                className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                title="بستن پنجره"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* تاریخ و ساعت واقعی شروع و پایان دستورکار */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-xl bg-[#070e22] border border-indigo-500/25">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">تاریخ و ساعت شروع دستورکار:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="1405/09/20"
                      value={executionData.startDate}
                      onChange={e => setExecutionData({ ...executionData, startDate: e.target.value })}
                      className="w-2/3 bg-[#0c162e] border border-indigo-500/30 rounded-lg p-2 text-slate-200 text-xs font-mono outline-none focus:border-purple-500"
                    />
                    <input
                      type="text"
                      placeholder="08:00"
                      value={executionData.startTime}
                      onChange={e => setExecutionData({ ...executionData, startTime: e.target.value })}
                      className="w-1/3 bg-[#0c162e] border border-indigo-500/30 rounded-lg p-2 text-slate-200 text-xs font-mono text-center outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">تاریخ و ساعت پایان دستورکار:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="1405/09/20"
                      value={executionData.endDate}
                      onChange={e => setExecutionData({ ...executionData, endDate: e.target.value })}
                      className="w-2/3 bg-[#0c162e] border border-indigo-500/30 rounded-lg p-2 text-slate-200 text-xs font-mono outline-none focus:border-purple-500"
                    />
                    <input
                      type="text"
                      placeholder="11:30"
                      value={executionData.endTime}
                      onChange={e => setExecutionData({ ...executionData, endTime: e.target.value })}
                      className="w-1/3 bg-[#0c162e] border border-indigo-500/30 rounded-lg p-2 text-slate-200 text-xs font-mono text-center outline-none focus:border-purple-500"
                    />
                  </div>
                </div>
              </div>

              {/* انتخاب تکنسین‌های حاضر و مجری (کدام تکنسین‌ها برای این فعالیت رفتند؟) */}
              <div className="p-3.5 rounded-xl bg-[#070e22] border border-indigo-500/25 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-200 font-bold block flex items-center gap-2">
                    <Users size={16} className="text-purple-400" />
                    <span>تکنسین‌های حاضر برای این فعالیت (کدام تکنسین‌ها اعزام شدند؟):</span>
                  </label>
                  <span className="text-[11px] text-purple-300 font-bold">
                    {executionData.personnel.length > 0
                      ? `${executionData.personnel.length} تکنسین انتخاب شده`
                      : 'تکنسین‌های مجری را علامت بزنید'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-36 overflow-y-auto pt-1">
                  {techniciansList.map(t => {
                    const isSelected = executionData.personnel.includes(t.name);
                    return (
                      <label
                        key={t.id}
                        className={`flex items-center gap-2 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-purple-600/30 border-purple-500/70 text-purple-100 font-bold shadow-sm'
                            : 'bg-[#0c162e] border-indigo-900/40 text-slate-400 hover:text-slate-200 hover:border-indigo-500/40'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={e => {
                            const cur = executionData.personnel;
                            const next = e.target.checked
                              ? [...cur, t.name]
                              : cur.filter(n => n !== t.name);
                            setExecutionData({ ...executionData, personnel: next });
                          }}
                          className="w-4 h-4 rounded text-purple-600 bg-slate-900 border-indigo-500/40 accent-purple-600 cursor-pointer"
                        />
                        <span className="truncate">{t.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* چک‌لیست اقدامات همراه با کد سیستمی هر فعالیت و کد کامل دستورکار */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-bold block">
                    چک‌لیست فعالیت‌ها و کدهای کامل دستورکار:
                  </label>
                  <span className="text-[11px] text-slate-400">
                    کد سیستمی + کد کامل برای هر فعالیت ثبت شده است
                  </span>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {executionData.activities.map((act: any, idx: number) => {
                    const actCode = act.code || `ACT-${String(idx + 1).padStart(2, '0')}`;
                    const fullCode = act.fullCode || `${selectedOrder.id}/${actCode}`;
                    return (
                      <label 
                        key={idx} 
                        className="flex items-start gap-3 p-3 rounded-xl bg-[#070e22] border border-indigo-500/20 hover:border-purple-500/40 cursor-pointer transition-all"
                      >
                        <input
                          type="checkbox"
                          checked={act.done}
                          onChange={e => {
                            const updated = [...executionData.activities];
                            updated[idx].done = e.target.checked;
                            setExecutionData({ ...executionData, activities: updated });
                          }}
                          className="w-4 h-4 rounded text-purple-600 bg-slate-900 border-indigo-500/40 accent-purple-600 cursor-pointer mt-1"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              کد فعالیت: {actCode}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              کد کامل دستورکار: {fullCode}
                            </span>
                          </div>
                          <span className={`text-xs block leading-relaxed ${act.done ? 'text-slate-200 font-bold' : 'text-slate-400'}`}>
                            {act.text}
                          </span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* قطعات مصرفی و توضیحات تکمیلی */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">قطعات و ابزار مصرفی (اختیاری):</label>
                  <input
                    type="text"
                    placeholder="مثال: ۱ عدد فیلتر هیدرولیک، روغن VG68"
                    className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">توضیحات و گزارش کار:</label>
                  <input
                    type="text"
                    value={executionData.notes}
                    onChange={e => setExecutionData({ ...executionData, notes: e.target.value })}
                    placeholder="توضیحات اجرای سرویس یا موارد مشاهده‌شده"
                    className="w-full bg-[#070e22] border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* تحویل‌گیرنده و تایید نهایی */}
              <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/20 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="w-full sm:w-1/2">
                  <label className="text-slate-400 text-[11px] block mb-1">تحویل‌گیرنده دستگاه:</label>
                  <input
                    type="text"
                    value={executionData.handover.receiver}
                    onChange={e => setExecutionData({
                      ...executionData,
                      handover: { ...executionData.handover, receiver: e.target.value }
                    })}
                    placeholder="نام مسئول تحویل‌گیرنده (سرپرست خط)"
                    className="w-full bg-[#0c162e] border border-indigo-500/20 rounded-lg p-2 text-slate-200 text-xs outline-none"
                  />
                </div>

                <label className="flex items-center gap-2 cursor-pointer w-full sm:w-1/2 pt-2 sm:pt-0">
                  <input
                    type="checkbox"
                    checked={executionData.handover.approved}
                    onChange={e => setExecutionData({
                      ...executionData,
                      handover: { ...executionData.handover, approved: e.target.checked }
                    })}
                    className="w-4 h-4 rounded text-emerald-600 bg-slate-900 border-indigo-500/30 accent-emerald-600 cursor-pointer"
                  />
                  <span className="text-emerald-400 font-bold text-xs">تجهیز بدون عیب کارکردی تحویل داده شد.</span>
                </label>
              </div>
            </div>

            {/* دکمه‌های اقدام: انصراف یا بستن و تکمیل دستورکار */}
            <div className="flex items-center justify-between pt-3 border-t border-indigo-900/40">
              <button 
                onClick={() => setIsExecutionModalOpen(false)} 
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                انصراف و بازگشت
              </button>

              <button 
                onClick={submitExecution} 
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/60 cursor-pointer transition-all active:scale-[0.98]"
              >
                <Check size={16} />
                <span>✓ ثبت نهایی، اختتام و بستن دستورکار</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL EXCEL IMPORT: ورود فعالیت‌های PM با اکسل            */}
      {/* ======================================================== */}
      {isExcelActModalOpen && activeCategoryGroupId && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in" dir="rtl">
          <div className="w-full max-w-2xl bg-[#0c162e] border border-emerald-500/40 rounded-2xl shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet size={22} className="text-emerald-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-100">
                    ورود دسته‌ای فعالیت‌های PM از فایل اکسل به گروه «{PM_9_GROUPS.find(g => g.id === activeCategoryGroupId)?.name}»
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    می‌توانید فایل اکسل نرم‌افزار قبلی را بارگذاری کنید یا سلول‌ها را مستقیماً کپی و الصاق فرمایید.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsExcelActModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {excelErrorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {excelErrorMsg}
              </div>
            )}

            {/* انتخاب دوره تناوب هدف */}
            <div className="p-3.5 rounded-xl bg-[#070e22] border border-purple-500/30 space-y-2.5 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="font-bold text-purple-200">دوره تناوب هدف:</span>
                <select
                  value={excelTargetPeriod}
                  onChange={e => {
                    const nextP = e.target.value as 'monthly' | 'bimonthly' | 'quarterly' | 'biannual' | 'annual' | 'custom';
                    setExcelTargetPeriod(nextP);
                    if (excelPasteText.trim()) {
                      handleParsePastedExcelText(excelPasteText, nextP, excelLockToTargetPeriod);
                    } else if (excelWorkbookSheets.length > 0 && excelSelectedSheet) {
                      handleSelectExcelSheet(excelSelectedSheet, excelWorkbookSheets, nextP, excelLockToTargetPeriod);
                    } else if (excelParsedActivities.length > 0) {
                      const desc = getPeriodDescriptor(nextP);
                      setExcelParsedActivities(prev => prev.map(a => ({ ...a, frequencyType: desc.type, frequencyLabel: desc.label, customDays: desc.days })));
                    }
                  }}
                  className="bg-[#0c162e] border border-purple-500/40 rounded-lg px-3 py-1.5 text-slate-100 font-bold outline-none focus:border-purple-400 cursor-pointer"
                >
                  <option value="monthly">ماهانه (۳۰ روزه)</option>
                  <option value="bimonthly">دوماهه (۶۰ روزه)</option>
                  <option value="quarterly">۳ ماهه (فصلی - ۹۰ روزه)</option>
                  <option value="biannual">۶ ماهه (نیم‌سال - ۱۸۰ روزه)</option>
                  <option value="annual">سالانه (یک‌ساله - ۳۶۵ روزه)</option>
                  <option value="custom">دوره سفارشی</option>
                </select>
              </div>

              {excelWorkbookSheets.length > 1 && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-indigo-900/40">
                  <span className="font-bold text-cyan-300">برگه (Sheet) انتخاب‌شده از فایل اکسل:</span>
                  <select
                    value={excelSelectedSheet}
                    onChange={e => handleSelectExcelSheet(e.target.value)}
                    className="bg-[#0c162e] border border-cyan-500/40 rounded-lg px-3 py-1.5 text-slate-100 font-bold outline-none focus:border-cyan-400 cursor-pointer"
                  >
                    {excelWorkbookSheets.map(sh => (
                      <option key={sh.name} value={sh.name}>
                        {sh.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <label className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={excelLockToTargetPeriod}
                  onChange={e => {
                    const locked = e.target.checked;
                    setExcelLockToTargetPeriod(locked);
                    if (excelPasteText.trim()) {
                      handleParsePastedExcelText(excelPasteText, excelTargetPeriod, locked);
                    } else if (excelWorkbookSheets.length > 0 && excelSelectedSheet) {
                      handleSelectExcelSheet(excelSelectedSheet, excelWorkbookSheets, excelTargetPeriod, locked);
                    } else if (locked && excelParsedActivities.length > 0) {
                      const desc = getPeriodDescriptor(excelTargetPeriod);
                      setExcelParsedActivities(prev => prev.map(a => ({ ...a, frequencyType: desc.type, frequencyLabel: desc.label, customDays: desc.days })));
                    }
                  }}
                  className="w-3.5 h-3.5 rounded accent-purple-500 cursor-pointer"
                />
                <span>تمامی ردیف‌ها فقط در همین دوره ثبت شوند (عدم اضافه شدن به دوره‌های دیگر)</span>
              </label>
            </div>

            {/* بخش ۱: دریافت فایل قالب یا آپلود فایل */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-xl bg-[#070e22] border border-indigo-500/20 text-xs">
              <div>
                <span className="font-bold text-slate-300 block mb-1">۱. دانلود فایل نمونه آماده:</span>
                <p className="text-[11px] text-slate-400 mb-2">قالب استاندارد شامل ستون‌های عنوان، دوره تناوب، ساعت و قطعات</p>
                <button
                  type="button"
                  onClick={handleDownloadExcelActTemplate}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-bold transition-all cursor-pointer"
                >
                  <Download size={14} />
                  <span>دانلود قالب نمونه اکسل (.xlsx)</span>
                </button>
              </div>

              <div>
                <span className="font-bold text-slate-300 block mb-1">۲. بارگذاری فایل اکسل خود:</span>
                <p className="text-[11px] text-slate-400 mb-2">پشتیبانی از فرمت‌های .xlsx, .xls و .csv</p>
                <label className="inline-flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/35 text-emerald-300 hover:text-white border border-emerald-500/30 text-xs font-bold transition-all cursor-pointer">
                  <Upload size={14} />
                  <span>انتخاب فایل اکسل</span>
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleExcelFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* بخش ۲: الصاق مستقیم از اکسل (Paste) */}
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                ۳. یا کپی و الصاق مستقیم سلول‌های اکسل (Ctrl+V):
              </label>
              <textarea
                rows={3}
                value={excelPasteText}
                onChange={e => handleParsePastedExcelText(e.target.value)}
                placeholder={`ردیف‌های اکسل را انتخاب کرده و اینجا Paste کنید...\nمثال: روانکاری گیربکس\tماهانه\t2\tروغن واسکازین`}
                className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-3 text-slate-200 font-mono text-xs outline-none focus:border-purple-500 resize-none"
              />
            </div>

            {/* پیش‌نمایش ردیف‌های شناخته‌شده */}
            {excelParsedActivities.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>پیش‌نمایش فعالیت‌های خوانده‌شده ({excelParsedActivities.length} ردیف):</span>
                  <span className="text-emerald-400">آماده افزودن به بانک فعالیت‌ها</span>
                </div>
                <div className="max-h-48 overflow-y-auto space-y-1.5 border border-indigo-900/40 rounded-xl p-2 bg-[#070e22]/60">
                  {excelParsedActivities.map((act, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-[#0a142c] border border-indigo-500/20 text-xs">
                      <div className="min-w-0 flex items-center gap-2">
                        <span className="text-purple-400 font-bold font-mono">
                          {act.code ? act.code : `#${idx + 1}`}
                        </span>
                        <span className="text-slate-200 font-bold truncate">{act.title}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {act.frequencyLabel}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">{act.estimatedHours}h</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsExcelActModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-all cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                disabled={excelParsedActivities.length === 0}
                onClick={() => handleImportParsedActivitiesToGroup(activeCategoryGroupId)}
                className={`px-6 py-2 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer ${
                  excelParsedActivities.length > 0
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                ✓ تأیید و افزودن {excelParsedActivities.length} فعالیت به گروه
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 6: مشاهده گزارش نهایی بایگانی (Report Modal)       */}
      {/* ======================================================== */}
      {isReportModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-lg bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <FileText size={16} className="text-emerald-400" />
                <span>{printSettings.pmFinalReport.docTitle}</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-indigo-500/30 text-cyan-300">
                  {printSettings.pmFinalReport.docCode}
                </span>
              </h3>
              <button onClick={() => setIsReportModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">کد دستورکار:</span>
                  <span className="font-mono text-purple-300 font-bold">{selectedOrder.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">تجهیز:</span>
                  <span className="text-slate-200 font-bold">{selectedOrder.equipment}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">تاریخ تکمیل:</span>
                  <span className="text-emerald-400 font-bold">{selectedOrder.completedDate || selectedOrder.dueDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">تکنسین مجری:</span>
                  <span className="text-slate-200 font-bold">{selectedOrder.assignedTo}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                <span>این دستورکار با موفقیت به اتمام رسیده و در سوابق دستگاه ثبت گردید.</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-indigo-900/40">
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-indigo-500/20 text-slate-300 hover:text-white text-xs font-bold cursor-pointer"
              >
                <Printer size={14} />
                <span>چاپ گزارش</span>
              </button>
              <button onClick={() => setIsReportModalOpen(false)} className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold">
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 7: مشاهده جزئیات برنامه PM (Plan Details Modal)    */}
      {/* ======================================================== */}
      {isPlanDetailsModalOpen && selectedPlan && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-xl bg-[#0c162e]/85 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <div>
                <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <Eye size={16} className="text-purple-400" />
                  <span>مشخصات برنامه پیشگیرانه</span>
                </h3>
                <span className="font-mono text-xs text-purple-400 mt-0.5 block">{selectedPlan.id}</span>
              </div>
              <button onClick={() => setIsPlanDetailsModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X size={18} />
              </button>
            </div>

            <div className="flex items-center gap-1 bg-[#070e22]/90 p-1 rounded-xl border border-indigo-500/20">
              <button 
                onClick={() => setPlanDetailsTab('details')}
                className={`flex-1 py-1 rounded-lg text-xs font-bold ${planDetailsTab === 'details' ? 'bg-[#132448] text-purple-300' : 'text-slate-500'}`}
              >
                مشخصات اصلی
              </button>
              <button 
                onClick={() => setPlanDetailsTab('equipment')}
                className={`flex-1 py-1 rounded-lg text-xs font-bold ${planDetailsTab === 'equipment' ? 'bg-[#132448] text-purple-300' : 'text-slate-500'}`}
              >
                دستگاه و واحد
              </button>
              <button 
                onClick={() => setPlanDetailsTab('activities')}
                className={`flex-1 py-1 rounded-lg text-xs font-bold ${planDetailsTab === 'activities' ? 'bg-[#132448] text-purple-300' : 'text-slate-500'}`}
              >
                فعالیت‌ها
              </button>
            </div>

            <div className="p-4 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-xs space-y-2">
              <div className="flex justify-between py-1 border-b border-indigo-900/40/50">
                <span className="text-slate-400">عنوان برنامه:</span>
                <span className="font-bold text-slate-200">{selectedPlan.title}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-indigo-900/40/50">
                <span className="text-slate-400">دستگاه مرتبط:</span>
                <span className="font-bold text-purple-300">{selectedPlan.equipment || '-'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-indigo-900/40/50">
                <span className="text-slate-400">دوره تناوب:</span>
                <span className="text-slate-200 font-bold">{selectedPlan.frequency || `${selectedPlan.cDays} روزه`}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">مدت زمان تخمینی:</span>
                <span className="text-slate-200 font-bold">{selectedPlan.dHours || 2} ساعت</span>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-indigo-900/40">
              <button onClick={() => setIsPlanDetailsModalOpen(false)} className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold">
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

    
      {/* ======================================================== */}
      {/* MODAL: پروفایل و ریز جزئیات کارکرد تکنسین به همراه حذف */}
      {/* ======================================================== */}
      {selectedTechForProfile && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[70] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#0c162e] border border-indigo-500/30 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl shadow-black/80 flex flex-col">
            
            {/* Modal Header */}
            <div className="p-6 border-b border-indigo-900/40 flex items-start justify-between bg-gradient-to-r from-purple-950/40 via-[#0c162e] to-[#0c162e]">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-700 via-purple-700 to-pink-600 p-0.5 shadow-xl shadow-purple-950/60">
                    <div className="w-full h-full rounded-2xl bg-[#0c162e] flex items-center justify-center overflow-hidden">
                      {selectedTechForProfile.image ? (
                        <img src={selectedTechForProfile.image} alt={selectedTechForProfile.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl font-bold text-white">{selectedTechForProfile.name.charAt(0)}</span>
                      )}
                    </div>
                  </div>
                  <span className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[#0c162e] ${selectedTechForProfile.status === 'busy' ? 'bg-purple-500 animate-pulse' : 'bg-emerald-500'}`}></span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-white">{selectedTechForProfile.name}</h3>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/40 font-mono">
                      TC-{selectedTechForProfile.id}
                    </span>
                  </div>
                  
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedTechForProfile(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6 flex-1">
              {/* وضعیت کاری و دکمه تغییر */}
              <div className="p-4 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 block">وضعیت فعلی در شیفت:</span>
                  <span className={`text-sm font-bold ${selectedTechForProfile.status === 'busy' ? 'text-purple-400' : 'text-emerald-400'}`}>
                    {selectedTechForProfile.status === 'busy' ? 'در حال اقدام روی دستورکار' : 'در دسترس جهت تخصیص کار جدید'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newStatus = selectedTechForProfile.status === 'busy' ? 'available' : 'busy';
                    setSelectedTechForProfile({ ...selectedTechForProfile, status: newStatus });
                    setTechniciansList(list => list.map(t => t.id === selectedTechForProfile.id ? { ...t, status: newStatus } : t));
                  }}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/35 border border-indigo-500/30 text-indigo-300 hover:text-white text-xs font-bold transition-all cursor-pointer"
                >
                  تغییر به {selectedTechForProfile.status === 'busy' ? 'در دسترس' : 'در حال اقدام'}
                </button>
              </div>

              {/* KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-right">
                  <span className="text-[11px] text-slate-400 block">دستورکارهای تکمیل‌شده</span>
                  <span className="text-lg font-black text-white mt-1 block">{selectedTechForProfile.completedTasks} کار PM</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-right">
                  <span className="text-[11px] text-slate-400 block">مجموع ساعت کارکرد</span>
                  <span className="text-lg font-black text-purple-400 mt-1 block">{selectedTechForProfile.workHours} ساعت</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 text-right col-span-2 sm:col-span-1">
                  <span className="text-[11px] text-slate-400 block">کیفیت و تموم‌کنندگی</span>
                  <span className="text-lg font-black text-emerald-400 mt-1 block">۱۰۰٪ تاییدشده</span>
                </div>
              </div>

              {/* آخرین اقدام و سوابق */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <Activity size={15} className="text-purple-400" />
                  <span>ریز سوابق و آخرین اقدامات ثبت‌شده:</span>
                </h4>
                <div className="p-4 rounded-xl bg-[#070e22]/90 border border-indigo-500/20 space-y-2 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40">
                    <span className="text-slate-400">آخرین عملیات فنی:</span>
                    <span className="text-slate-200 font-bold">{selectedTechForProfile.lastAction || 'آماده ثبت فعالیت جدید'}</span>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40">
                    <span className="text-slate-400">واحد سازمانی:</span>
                    <span className="text-purple-300 font-bold">نگهداری و تعمیرات پیشگیرانه (PM)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">دستورکارهای در دست اقدام:</span>
                    <span className="text-slate-200 font-bold">
                      {workOrders.filter(w => w.assignedTo === selectedTechForProfile.name && w.status !== 'completed').length} مورد جاری
                    </span>
                  </div>
                </div>
              </div>

              {/* تاییدیه حذف اختصاصی و مطمئن بدون نیاز به پنجره مرورگر */}
              {showDeleteConfirm ? (
                <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-rose-200 text-xs font-bold text-right">
                    <AlertTriangle size={16} className="text-rose-400 shrink-0" />
                    <span>آیا از حذف تکنسین «{selectedTechForProfile.name}» مطمئن هستید؟</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        handleDeleteTechnician(selectedTechForProfile.id, selectedTechForProfile.name);
                        setShowDeleteConfirm(false);
                        setSelectedTechForProfile(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all cursor-pointer shadow-md"
                    >
                      بله، حذف دائم تکنسین
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                    >
                      انصراف
                    </button>
                  </div>
                </div>
              ) : null}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-indigo-900/40 bg-[#070e22]/90 flex items-center justify-between">
              {/* دکمه کوچک سطل آشغال برای حذف تکنسین */}
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-rose-500/30 text-xs font-bold transition-all cursor-pointer"
                title="حذف این تکنسین"
              >
                <Trash2 size={14} />
                <span>حذف تکنسین</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setSelectedTechForProfile(null);
                }}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 9: افزودن/ویرایش مکان اصلی (Add/Edit Location)      */}
      {/* ======================================================== */}
      {isLocModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-md bg-[#0c162e]/90 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <MapPin size={16} className="text-emerald-400" />
                <span>{isEditingLoc ? 'ویرایش سالن / مکان' : 'افزودن سالن / مکان اصلی جدید'}</span>
              </h3>
              <button onClick={() => setIsLocModalOpen(false)} className="text-slate-400 hover:text-slate-200 cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">کد مکان (مانند S01, S02, S09...):</label>
                <input
                  type="text"
                  value={locFormData.code}
                  disabled={isEditingLoc}
                  onChange={e => setLocFormData({ ...locFormData, code: e.target.value })}
                  placeholder="مثال: S09"
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-emerald-500 font-mono disabled:opacity-50"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">نام سالن یا مکان اصلی:</label>
                <input
                  type="text"
                  value={locFormData.name}
                  onChange={e => setLocFormData({ ...locFormData, name: e.target.value })}
                  placeholder="مثال: سالن انبار مرکزی"
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">توضیحات و کاربری (اختیاری):</label>
                <textarea
                  rows={2}
                  value={locFormData.description}
                  onChange={e => setLocFormData({ ...locFormData, description: e.target.value })}
                  placeholder="توضیح مختصر درباره این سالن یا زون..."
                  className="w-full bg-[#070e22]/90 border border-indigo-500/20 rounded-xl p-2.5 text-slate-200 outline-none focus:border-emerald-500 resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsLocModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveLocation}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                {isEditingLoc ? 'ذخیره تغییرات' : 'ثبت مکان'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 10: تایید حذف مکان (Delete Location Confirm)       */}
      {/* ======================================================== */}
      {locDeleteConfirm && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-sm bg-[#0c162e]/95 backdrop-blur-xl rounded-2xl border border-rose-500/30 shadow-2xl p-5 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle size={24} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">آیا از حذف مکان مطمئن هستید؟</h3>
              <p className="text-xs text-slate-400 mt-1">
                مکان <b className="text-rose-300 font-mono">[{locDeleteConfirm.name}]</b> و تمام زیرسیستم‌های آن حذف خواهند شد.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setLocDeleteConfirm(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={() => handleDeleteLocation(locDeleteConfirm.id)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer transition-all shadow-md"
              >
                بله، حذف شود
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال افزودن تجهیز از هر دسته به گروه با قابلیت جستجو       */}
      {/* ======================================================== */}
      {addEquipmentModalGroup && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in" dir="rtl">
          <div className="bg-[#0b1329] border border-slate-700/80 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] my-auto">
            
            {/* سربرگ خلوت */}
            <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-[#070e22]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-600/20 text-cyan-400 flex items-center justify-center">
                  <Plus size={16} />
                </div>
                <h3 className="text-sm font-bold text-white">
                  افزودن تجهیز به لیست {addEquipmentModalGroup.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAddEquipmentModalGroup(null);
                  setAddEqModalSearch('');
                  setAddEqModalCategoryFilter('همه');
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* نوار جستجو و فیلتر دسته‌ها */}
            <div className="p-4 space-y-3 border-b border-slate-800 bg-slate-950/40">
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={addEqModalSearch}
                  onChange={e => setAddEqModalSearch(e.target.value)}
                  placeholder="جستجوی کد تجهیز، نام، سالن یا دسته..."
                  className="w-full pr-9 pl-8 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                  autoFocus
                />
                {addEqModalSearch && (
                  <button
                    type="button"
                    onClick={() => setAddEqModalSearch('')}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              {/* تب‌های دسته‌بندی */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {['همه', 'تورنوس', 'فرز', 'تراش', 'سینتک', 'مایر', 'وایرکات', 'آزمایشگاه', 'پرس', 'تاسیسات'].map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setAddEqModalCategoryFilter(cat)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                      addEqModalCategoryFilter === cat
                        ? 'bg-cyan-600 text-white shadow-sm'
                        : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* لیست تجهیزات قابل افزودن */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {(() => {
                const currentActiveIds = getGroupActiveEquipments(addEquipmentModalGroup.id).map(e => e.id);
                const q = addEqModalSearch.trim().toLowerCase();
                
                const filtered = equipmentList.filter(eq => {
                  if (currentActiveIds.includes(eq.id)) return false;

                  if (addEqModalCategoryFilter !== 'همه') {
                    const matchesCat = (eq.family || '').toLowerCase().includes(addEqModalCategoryFilter.toLowerCase()) ||
                      (eq.name || '').toLowerCase().includes(addEqModalCategoryFilter.toLowerCase());
                    if (!matchesCat) return false;
                  }

                  if (!q) return true;
                  return (
                    (eq.id || '').toLowerCase().includes(q) ||
                    (eq.name || '').toLowerCase().includes(q) ||
                    (eq.location || '').toLowerCase().includes(q) ||
                    (eq.family || '').toLowerCase().includes(q)
                  );
                });

                if (filtered.length === 0) {
                  return (
                    <div className="py-12 text-center text-xs text-slate-500">
                      موردی برای افزودن یافت نشد.
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {filtered.map(eq => (
                      <div
                        key={eq.id}
                        onClick={() => handleAddEquipmentToGroup(addEquipmentModalGroup.id, eq.id)}
                        className="p-2.5 rounded-xl border border-slate-800 bg-slate-900/70 hover:bg-slate-800/90 hover:border-cyan-500/50 transition-all cursor-pointer flex items-center justify-between gap-2.5 group"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-xs text-cyan-300 bg-slate-950 px-1.5 py-0.5 rounded border border-cyan-500/20">{eq.id}</span>
                            <span className="text-xs font-bold text-slate-200 truncate">{eq.name}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                            {eq.location || 'سالن تولید'} • {eq.family}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAddEquipmentToGroup(addEquipmentModalGroup.id, eq.id);
                          }}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600/20 group-hover:bg-cyan-600 text-cyan-300 group-hover:text-white text-xs font-bold transition-all cursor-pointer shrink-0"
                          title="افزودن به این گروه"
                        >
                          <Plus size={13} />
                          <span>افزودن</span>
                        </button>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>

            {/* پاورقی ساده */}
            <div className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  setAddEquipmentModalGroup(null);
                  setAddEqModalSearch('');
                  setAddEqModalCategoryFilter('همه');
                }}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
              >
                بستن
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* برگه‌ فوق‌العاده خلوت دستور کار PM با امکان انتخاب تجهیزات و ثبت سابقه */}
      {/* ======================================================== */}
      {activePmWorkOrderSheet && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-[#0b1329] border border-purple-500/40 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl space-y-0 my-auto text-right" dir="rtl">
            
            {/* سربرگ خلوت و مینیمال */}
            <div className="px-5 py-3.5 border-b border-indigo-900/40 flex items-center justify-between bg-[#070e22]">
              <div className="flex items-center gap-2">
                <Wrench size={16} className="text-purple-400" />
                <h3 className="text-sm font-bold text-slate-100">
                  دستور کار PM — گروه {activePmWorkOrderSheet.groupName}
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {activePmWorkOrderSheet.id}
                </span>
              </div>
              <button
                onClick={() => setActivePmWorkOrderSheet(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              
              {/* ۱. کدهای تمام تجهیزات این دسته جهت انتخاب (کدام دستگاه‌ها PM شدند) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-300">
                    کد تجهیزات انجام‌شده ({toFaDigits(activePmWorkOrderSheet.selectedEquipments.length)} از {toFaDigits(activePmWorkOrderSheet.allGroupEquipments.length)} دستگاه):
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const allIds = activePmWorkOrderSheet.allGroupEquipments.map(e => e.id);
                        const isAll = activePmWorkOrderSheet.selectedEquipments.length === allIds.length;
                        setActivePmWorkOrderSheet({
                          ...activePmWorkOrderSheet,
                          selectedEquipments: isAll ? [] : allIds
                        });
                      }}
                      className="text-[10px] text-purple-300 hover:text-white underline cursor-pointer"
                    >
                      {activePmWorkOrderSheet.selectedEquipments.length === activePmWorkOrderSheet.allGroupEquipments.length ? 'لغو انتخاب همه' : 'انتخاب همه'}
                    </button>
                  </div>
                </div>

                {/* چیپ‌های کد تجهیزات */}
                <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 bg-[#060b18] rounded-xl border border-indigo-900/40">
                  {activePmWorkOrderSheet.allGroupEquipments.map((eq) => {
                    const isSelected = activePmWorkOrderSheet.selectedEquipments.includes(eq.id);
                    return (
                      <button
                        key={eq.id}
                        type="button"
                        onClick={() => {
                          const next = isSelected
                            ? activePmWorkOrderSheet.selectedEquipments.filter(id => id !== eq.id)
                            : [...activePmWorkOrderSheet.selectedEquipments, eq.id];
                          setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, selectedEquipments: next });
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                            : 'bg-slate-800/60 text-slate-400 border border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <span>{isSelected ? '✓' : ''}</span>
                        <span>{eq.id}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* ۲. فعالیت‌های برنامه‌ریزی‌شده */}
              <div className="space-y-1.5">
                <span className="font-bold text-slate-300 text-[11px] block">
                  فعالیت‌های برنامه‌ریزی‌شده:
                </span>
                <div className="space-y-1.5 bg-[#060b18] p-2.5 rounded-xl border border-indigo-900/40 max-h-36 overflow-y-auto">
                  {activePmWorkOrderSheet.activities.map((actTitle, idx) => {
                    const isChecked = activePmWorkOrderSheet.checkedActivities.includes(actTitle);
                    return (
                      <label
                        key={idx}
                        className="flex items-start gap-2 p-1.5 rounded-lg hover:bg-slate-800/40 cursor-pointer text-slate-200"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            const next = isChecked
                              ? activePmWorkOrderSheet.checkedActivities.filter(a => a !== actTitle)
                              : [...activePmWorkOrderSheet.checkedActivities, actTitle];
                            setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, checkedActivities: next });
                          }}
                          className="mt-0.5 rounded border-slate-600 text-purple-600 focus:ring-0"
                        />
                        <span className={`text-[11px] leading-relaxed ${isChecked ? 'text-slate-100 font-semibold' : 'text-slate-400 line-through'}`}>
                          {actTitle}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* ۳. تکنسین‌های مجری */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1 text-[11px]">
                    تکنسین مسئول اصلی:
                  </label>
                  <select
                    value={activePmWorkOrderSheet.technician}
                    onChange={e => setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, technician: e.target.value })}
                    className="w-full bg-[#060b18] border border-indigo-500/30 rounded-xl px-2.5 py-1.5 text-slate-200 outline-none text-xs focus:border-purple-500 cursor-pointer"
                  >
                    {techniciansList.map(t => (
                      <option key={t.id || t.name} value={t.name}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1 text-[11px]">
                    تکنسین‌های همکار:
                  </label>
                  <div className="flex flex-wrap gap-1 max-h-20 overflow-y-auto p-1 bg-[#060b18] rounded-xl border border-indigo-900/40">
                    {techniciansList
                      .filter(t => t.name !== activePmWorkOrderSheet.technician)
                      .map(t => {
                        const isCo = activePmWorkOrderSheet.coTechnicians.includes(t.name);
                        return (
                          <button
                            key={t.id || t.name}
                            type="button"
                            onClick={() => {
                              const next = isCo
                                ? activePmWorkOrderSheet.coTechnicians.filter(n => n !== t.name)
                                : [...activePmWorkOrderSheet.coTechnicians, t.name];
                              setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, coTechnicians: next });
                            }}
                            className={`px-2 py-0.5 rounded text-[10px] transition-all cursor-pointer ${
                              isCo
                                ? 'bg-purple-600 text-white font-bold'
                                : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            {isCo ? '✓ ' : '+ '}{t.name}
                          </button>
                        );
                      })}
                  </div>
                </div>
              </div>

              {/* ۴. نوبت‌ها و روزهای کارکرد (تاریخ شروع، تاریخ پایان، ساعت شروع، ساعت پایان + دکمه افزودن روز بعدی) */}
              <div className="space-y-2.5 bg-[#060b18] p-3 rounded-xl border border-indigo-900/40">
                <div className="flex items-center justify-between pb-2 border-b border-indigo-900/40">
                  <div className="flex items-center gap-2">
                    <Clock size={15} className="text-purple-400" />
                    <span className="font-bold text-slate-200 text-[11px]">
                      ثبت تاریخ و ساعت کارکرد (امکان ثبت چند روزه):
                    </span>
                  </div>
                  
                  {/* دکمه + افزودن روز کاری بعدی */}
                  <button
                    type="button"
                    onClick={() => {
                      const curSessions = activePmWorkOrderSheet.workSessions || [];
                      const last = curSessions[curSessions.length - 1];
                      const nextStart = last ? addShamsiDays(last.endDate || last.startDate, 1) : getTodayShamsiString();
                      const newSess: PMWorkSessionItem = {
                        id: `sess-${Date.now()}-${curSessions.length + 1}`,
                        startDate: nextStart,
                        endDate: nextStart,
                        startTime: last?.startTime || '08:00',
                        endTime: last?.endTime || '11:00'
                      };
                      setActivePmWorkOrderSheet({
                        ...activePmWorkOrderSheet,
                        workSessions: [...curSessions, newSess]
                      });
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold transition-all cursor-pointer shadow-md shadow-purple-950/40"
                    title="افزودن روز کاری / نوبت بعدی (+)"
                  >
                    <Plus size={14} className="stroke-[3]" />
                    <span>افزودن روز کاری بعدی</span>
                  </button>
                </div>

                {/* لیست نوبت‌ها و روزهای ثبت‌شده */}
                <div className="space-y-2 max-h-52 overflow-y-auto pr-0.5">
                  {(activePmWorkOrderSheet.workSessions && activePmWorkOrderSheet.workSessions.length > 0
                    ? activePmWorkOrderSheet.workSessions
                    : [{
                        id: 'sess-def',
                        startDate: activePmWorkOrderSheet.woDate,
                        endDate: activePmWorkOrderSheet.woEndDate || activePmWorkOrderSheet.woDate,
                        startTime: activePmWorkOrderSheet.woStartTime || '08:00',
                        endTime: activePmWorkOrderSheet.woEndTime || '11:00'
                      }]
                  ).map((session, idx, allArr) => {
                    const sessHrs = calculateSessionHours(session.startTime, session.endTime);
                    return (
                      <div
                        key={session.id}
                        className="p-2.5 rounded-xl bg-[#070e22] border border-indigo-500/25 flex flex-wrap items-center gap-2 text-[11px]"
                      >
                        {/* شماره روز */}
                        <div className="flex items-center justify-center w-6 h-6 rounded-lg bg-purple-500/20 text-purple-300 font-bold font-mono text-[11px] shrink-0">
                          {toFaDigits(idx + 1)}
                        </div>

                        {/* تاریخ شروع */}
                        <div className="flex-1 min-w-[105px]">
                          <label className="block text-slate-400 text-[10px] mb-1 font-bold">تاریخ شروع:</label>
                          <input
                            type="text"
                            value={session.startDate}
                            onChange={e => {
                              const val = e.target.value;
                              const cur = activePmWorkOrderSheet.workSessions || allArr;
                              const next = cur.map(s =>
                                s.id === session.id
                                  ? { ...s, startDate: val, endDate: (s.endDate === s.startDate ? val : s.endDate) }
                                  : s
                              );
                              setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, workSessions: next });
                            }}
                            placeholder="1405/08/15"
                            className="w-full bg-[#0b1329] border border-indigo-500/30 rounded-lg px-2 py-1 text-slate-200 outline-none text-[11px] text-center font-mono focus:border-purple-500"
                          />
                        </div>

                        {/* تاریخ پایان */}
                        <div className="flex-1 min-w-[105px]">
                          <label className="block text-slate-400 text-[10px] mb-1 font-bold">تاریخ پایان:</label>
                          <input
                            type="text"
                            value={session.endDate}
                            onChange={e => {
                              const val = e.target.value;
                              const cur = activePmWorkOrderSheet.workSessions || allArr;
                              const next = cur.map(s => (s.id === session.id ? { ...s, endDate: val } : s));
                              setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, workSessions: next });
                            }}
                            placeholder="1405/08/15"
                            className="w-full bg-[#0b1329] border border-indigo-500/30 rounded-lg px-2 py-1 text-slate-200 outline-none text-[11px] text-center font-mono focus:border-purple-500"
                          />
                        </div>

                        {/* ساعت شروع */}
                        <div className="w-[85px]">
                          <label className="block text-slate-400 text-[10px] mb-1 font-bold">ساعت شروع:</label>
                          <TimeInput24
                            value={session.startTime}
                            onChange={val => {
                              const cur = activePmWorkOrderSheet.workSessions || allArr;
                              const next = cur.map(s => (s.id === session.id ? { ...s, startTime: val } : s));
                              setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, workSessions: next });
                            }}
                            className="w-full bg-[#0b1329] border border-indigo-500/30 rounded-lg px-1.5 py-1 text-slate-200 outline-none text-[11px] text-center font-mono focus:border-purple-500"
                          />
                        </div>

                        {/* ساعت پایان */}
                        <div className="w-[85px]">
                          <label className="block text-slate-400 text-[10px] mb-1 font-bold">ساعت پایان:</label>
                          <TimeInput24
                            value={session.endTime}
                            onChange={val => {
                              const cur = activePmWorkOrderSheet.workSessions || allArr;
                              const next = cur.map(s => (s.id === session.id ? { ...s, endTime: val } : s));
                              setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, workSessions: next });
                            }}
                            className="w-full bg-[#0b1329] border border-indigo-500/30 rounded-lg px-1.5 py-1 text-slate-200 outline-none text-[11px] text-center font-mono focus:border-purple-500"
                          />
                        </div>

                        {/* مدت زمان کارکرد این روز */}
                        <div className="pt-3.5 shrink-0">
                          <span
                            className="px-2 py-1 rounded-lg bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[10px] font-mono font-bold block"
                            title="کارکرد این نوبت"
                          >
                            {toFaDigits(sessHrs)} س
                          </span>
                        </div>

                        {/* دکمه حذف روز */}
                        {allArr.length > 1 && (
                          <div className="pt-3.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                const cur = activePmWorkOrderSheet.workSessions || allArr;
                                const next = cur.filter(s => s.id !== session.id);
                                setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, workSessions: next });
                              }}
                              className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
                              title="حذف این روز کاری"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* جمع کل کارکرد */}
                {(() => {
                  const cur = activePmWorkOrderSheet.workSessions || [];
                  const totalHrs = cur.reduce((sum, s) => sum + calculateSessionHours(s.startTime, s.endTime), 0);
                  const count = cur.length || 1;
                  return (
                    <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-indigo-950 px-1 font-bold">
                      <span className="text-slate-300">
                        مجموع کارکرد محاسبه‌شده:
                      </span>
                      <span className="text-emerald-400 font-mono flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 rounded-lg">
                        <span>{toFaDigits(count)} روز کاری</span>
                        <span>•</span>
                        <span>{toFaDigits(Math.round(totalHrs * 10) / 10)} ساعت کارکرد تکنسین</span>
                      </span>
                    </div>
                  );
                })()}
              </div>

              {/* ۵. لوازم یدکی و قطعات مصرفی: تفکیک برقی و مکانیکی همراه با تعداد */}
              <div className="space-y-2 pt-0.5">
                <div className="flex items-center justify-between">
                  <label className="block text-slate-300 font-bold text-[11px] flex items-center gap-1.5">
                    <Package size={13} className="text-purple-400" />
                    <span>لوازم یدکی و قطعات مصرفی:</span>
                  </label>
                  <span className="text-[10px] text-slate-400">
                    تفکیک مکانیکی و برقی • ثبت تعداد مصرفی
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {/* بخش ۱: قطعات مکانیکی */}
                  <div className="p-2.5 rounded-xl bg-[#070e22] border border-blue-500/25 space-y-2">
                    <div className="flex items-center justify-between pb-1.5 border-b border-blue-900/40">
                      <div className="flex items-center gap-1.5 text-blue-300 font-bold text-[11px]">
                        <Wrench size={12} className="text-blue-400" />
                        <span>قطعات مکانیکی</span>
                        {(activePmWorkOrderSheet.mechanicalParts?.length || 0) > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-mono">
                            {toFaDigits(activePmWorkOrderSheet.mechanicalParts?.length || 0)}
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const cur = activePmWorkOrderSheet.mechanicalParts || [];
                          setActivePmWorkOrderSheet({
                            ...activePmWorkOrderSheet,
                            mechanicalParts: [
                              ...cur,
                              { id: `mc-${Date.now()}-${cur.length + 1}`, name: '', quantity: 1 }
                            ]
                          });
                        }}
                        className="px-2 py-0.5 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/40 text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                        title="افزودن قطعه مکانیکی (+)"
                      >
                        <Plus size={11} />
                        <span>افزودن</span>
                      </button>
                    </div>

                    {/* لیست اقلام مکانیکی */}
                    {(!activePmWorkOrderSheet.mechanicalParts || activePmWorkOrderSheet.mechanicalParts.length === 0) ? (
                      <button
                        type="button"
                        onClick={() => {
                          setActivePmWorkOrderSheet({
                            ...activePmWorkOrderSheet,
                            mechanicalParts: [{ id: `mc-${Date.now()}`, name: '', quantity: 1 }]
                          });
                        }}
                        className="w-full py-2 border border-dashed border-blue-900/50 hover:border-blue-500/50 rounded-lg text-slate-500 hover:text-blue-300 text-[10px] flex items-center justify-center gap-1 transition-all cursor-pointer"
                      >
                        <Plus size={11} />
                        <span>ثبت قطعه مکانیکی (اختیاری)</span>
                      </button>
                    ) : (
                      <div className="space-y-1.5 max-h-32 overflow-y-auto pr-0.5">
                        {activePmWorkOrderSheet.mechanicalParts.map((part) => (
                          <div key={part.id} className="flex items-center gap-1.5 bg-[#0b1329] p-1.5 rounded-lg border border-blue-500/20">
                            <input
                              type="text"
                              list="pm-mech-parts-list"
                              value={part.name}
                              onChange={e => {
                                const val = e.target.value;
                                const next = (activePmWorkOrderSheet.mechanicalParts || []).map(p =>
                                  p.id === part.id ? { ...p, name: val } : p
                                );
                                setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, mechanicalParts: next });
                              }}
                              placeholder="نام قطعه (بلبرینگ، فیلتر، اورینگ...)"
                              className="flex-1 min-w-0 bg-transparent text-slate-200 text-[11px] outline-none placeholder-slate-600"
                            />
                            <div className="flex items-center gap-1 bg-[#070e22] px-1.5 py-0.5 rounded border border-blue-500/30 shrink-0">
                              <span className="text-[10px] text-slate-400">تعداد:</span>
                              <input
                                type="number"
                                min={1}
                                max={999}
                                value={part.quantity}
                                onChange={e => {
                                  const q = Math.max(1, parseInt(e.target.value, 10) || 1);
                                  const next = (activePmWorkOrderSheet.mechanicalParts || []).map(p =>
                                    p.id === part.id ? { ...p, quantity: q } : p
                                  );
                                  setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, mechanicalParts: next });
                                }}
                                className="w-10 bg-transparent text-center font-mono text-slate-200 text-xs outline-none"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                const next = (activePmWorkOrderSheet.mechanicalParts || []).filter(p => p.id !== part.id);
                                setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, mechanicalParts: next });
                              }}
                              className="text-slate-500 hover:text-rose-400 p-0.5 transition-colors cursor-pointer shrink-0"
                              title="حذف این قطعه"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* بخش ۲: قطعات برقی */}
                  <div className="p-2.5 rounded-xl bg-[#070e22] border border-amber-500/25 space-y-2">
                    <div className="flex items-center justify-between pb-1.5 border-b border-amber-900/40">
                      <div className="flex items-center gap-1.5 text-amber-300 font-bold text-[11px]">
                        <Zap size={12} className="text-amber-400" />
                        <span>قطعات برقی</span>
                        {(activePmWorkOrderSheet.electricalParts?.length || 0) > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono">
                            {toFaDigits(activePmWorkOrderSheet.electricalParts?.length || 0)}
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const cur = activePmWorkOrderSheet.electricalParts || [];
                          setActivePmWorkOrderSheet({
                            ...activePmWorkOrderSheet,
                            electricalParts: [
                              ...cur,
                              { id: `el-${Date.now()}-${cur.length + 1}`, name: '', quantity: 1 }
                            ]
                          });
                        }}
                        className="px-2 py-0.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                        title="افزودن قطعه برقی (+)"
                      >
                        <Plus size={11} />
                        <span>افزودن</span>
                      </button>
                    </div>

                    {/* لیست اقلام برقی */}
                    {(!activePmWorkOrderSheet.electricalParts || activePmWorkOrderSheet.electricalParts.length === 0) ? (
                      <button
                        type="button"
                        onClick={() => {
                          setActivePmWorkOrderSheet({
                            ...activePmWorkOrderSheet,
                            electricalParts: [{ id: `el-${Date.now()}`, name: '', quantity: 1 }]
                          });
                        }}
                        className="w-full py-2 border border-dashed border-amber-900/50 hover:border-amber-500/50 rounded-lg text-slate-500 hover:text-amber-300 text-[10px] flex items-center justify-center gap-1 transition-all cursor-pointer"
                      >
                        <Plus size={11} />
                        <span>ثبت قطعه برقی (اختیاری)</span>
                      </button>
                    ) : (
                      <div className="space-y-1.5 max-h-32 overflow-y-auto pr-0.5">
                        {activePmWorkOrderSheet.electricalParts.map((part) => (
                          <div key={part.id} className="flex items-center gap-1.5 bg-[#0b1329] p-1.5 rounded-lg border border-amber-500/20">
                            <input
                              type="text"
                              list="pm-elec-parts-list"
                              value={part.name}
                              onChange={e => {
                                const val = e.target.value;
                                const next = (activePmWorkOrderSheet.electricalParts || []).map(p =>
                                  p.id === part.id ? { ...p, name: val } : p
                                );
                                setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, electricalParts: next });
                              }}
                              placeholder="نام قطعه (فیوز، سنسور، رله، کابل...)"
                              className="flex-1 min-w-0 bg-transparent text-slate-200 text-[11px] outline-none placeholder-slate-600"
                            />
                            <div className="flex items-center gap-1 bg-[#070e22] px-1.5 py-0.5 rounded border border-amber-500/30 shrink-0">
                              <span className="text-[10px] text-slate-400">تعداد:</span>
                              <input
                                type="number"
                                min={1}
                                max={999}
                                value={part.quantity}
                                onChange={e => {
                                  const q = Math.max(1, parseInt(e.target.value, 10) || 1);
                                  const next = (activePmWorkOrderSheet.electricalParts || []).map(p =>
                                    p.id === part.id ? { ...p, quantity: q } : p
                                  );
                                  setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, electricalParts: next });
                                }}
                                className="w-10 bg-transparent text-center font-mono text-slate-200 text-xs outline-none"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                const next = (activePmWorkOrderSheet.electricalParts || []).filter(p => p.id !== part.id);
                                setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, electricalParts: next });
                              }}
                              className="text-slate-500 hover:text-rose-400 p-0.5 transition-colors cursor-pointer shrink-0"
                              title="حذف این قطعه"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* فهرست هوشمند قطعات انبار جهت پیشنهاد خودکار */}
                <datalist id="pm-mech-parts-list">
                  {(inventoryList || [])
                    .filter(p => p.category === 'مکانیکی' || p.category === 'هیدرولیک و پنوماتیک' || p.category === 'عمومی و سایر')
                    .map(p => (
                      <option key={p.id} value={p.name} />
                    ))}
                </datalist>
                <datalist id="pm-elec-parts-list">
                  {(inventoryList || [])
                    .filter(p => p.category === 'برقی' || p.category === 'ابزار دقیق')
                    .map(p => (
                      <option key={p.id} value={p.name} />
                    ))}
                </datalist>
              </div>

              {/* ۶. یادداشت اختیاری (به صورت پیش‌فرض مخفی) */}
              <div className="pt-0.5">
                <button
                  type="button"
                  onClick={() => setActivePmWorkOrderSheet({
                    ...activePmWorkOrderSheet,
                    showExtraDetails: !activePmWorkOrderSheet.showExtraDetails
                  })}
                  className="text-[11px] text-slate-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <span>{activePmWorkOrderSheet.showExtraDetails ? '▼ مخفی‌سازی توضیحات اختیاری' : '▶ افزودن توضیحات یا یادداشت اختیاری'}</span>
                </button>
                
                {activePmWorkOrderSheet.showExtraDetails && (
                  <textarea
                    value={activePmWorkOrderSheet.notes}
                    onChange={e => setActivePmWorkOrderSheet({ ...activePmWorkOrderSheet, notes: e.target.value })}
                    placeholder="نکات تکمیلی، توضیحات فنی یا قطعات..."
                    rows={2}
                    className="mt-2 w-full bg-[#060b18] border border-indigo-900/50 rounded-xl p-2.5 text-slate-200 text-xs outline-none focus:border-purple-500 resize-none"
                  />
                )}
              </div>
            </div>

            {/* دکمه ثبت و بستن */}
            <div className="p-4 border-t border-indigo-900/40 bg-[#070e22] flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setActivePmWorkOrderSheet(null)}
                className="px-4 py-2 rounded-xl border border-indigo-500/30 text-slate-400 hover:text-slate-200 text-xs font-bold transition-all cursor-pointer"
              >
                انصراف
              </button>
              {(() => {
                const totalHours = (activePmWorkOrderSheet.workSessions && activePmWorkOrderSheet.workSessions.length > 0)
                  ? activePmWorkOrderSheet.workSessions.reduce((sum, s) => sum + calculateSessionHours(s.startTime, s.endTime), 0)
                  : ((activePmWorkOrderSheet.workDaysCount || 1) * (activePmWorkOrderSheet.dailyHours || 3));
                return (
                  <button
                    type="button"
                    onClick={handleClosePmWorkOrder}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-900/30 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 size={16} />
                    <span>ثبت اتمام و بستن دستور کار PM ({toFaDigits(Math.round(totalHours * 10) / 10)} ساعت)</span>
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال تنظیم تاریخ و بازه انجام برای کل دوره (مورد ۴) */}
      {/* ======================================================== */}
      {periodToSchedule && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0c162e] border border-purple-500/40 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl text-right" dir="rtl">
            <div className="p-4 border-b border-indigo-900/40 flex items-center justify-between bg-[#070e22]">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-purple-400" />
                <h3 className="text-xs font-bold text-slate-100">
                  تنظیم تاریخ و بازه انجام دوره {periodToSchedule.periodLabel} ({periodToSchedule.groupName})
                </h3>
              </div>
              <button
                onClick={() => setPeriodToSchedule(null)}
                className="text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-4 space-y-3.5 text-xs">
              <div className="p-2.5 rounded-xl bg-[#070e22] border border-indigo-500/20 text-slate-300 text-[11px]">
                {periodToSchedule.count > 0 ? (
                  <>
                    این تاریخ شروع و بازه انجام به صورت یکپارچه روی تمامی <b>{toFaDigits(periodToSchedule.count)} فعالیت</b> فعلی و فعالیت‌های جدید دوره <b>{periodToSchedule.periodLabel}</b> در دسته <b>{periodToSchedule.groupName}</b> اعمال خواهد شد.
                  </>
                ) : (
                  <>
                    این تاریخ شروع و بازه انجام به صورت خودکار روی تمام فعالیت‌هایی که به دوره <b>{periodToSchedule.periodLabel}</b> در دسته <b>{periodToSchedule.groupName}</b> اضافه می‌کنید اعمال خواهد شد.
                  </>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1 text-[11px]">تاریخ شروع (شمسی):</label>
                  <input
                    type="text"
                    value={periodToSchedule.startDate}
                    onChange={e => {
                      const s = e.target.value;
                      setPeriodToSchedule({
                        ...periodToSchedule,
                        startDate: s,
                        endDate: addShamsiDays(s, periodToSchedule.executionWindowDays)
                      });
                    }}
                    placeholder="1405/08/15"
                    className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-slate-200 font-mono text-center outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1 text-[11px]">بازه انجام (تعداد روز):</label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={periodToSchedule.executionWindowDays}
                    onChange={e => {
                      const days = Math.max(1, parseInt(e.target.value, 10) || 1);
                      setPeriodToSchedule({
                        ...periodToSchedule,
                        executionWindowDays: days,
                        endDate: addShamsiDays(periodToSchedule.startDate, days)
                      });
                    }}
                    className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-slate-200 font-mono text-center outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1 text-[11px]">تاریخ پایان (محاسبه‌شده):</label>
                <input
                  type="text"
                  value={periodToSchedule.endDate}
                  onChange={e => setPeriodToSchedule({ ...periodToSchedule, endDate: e.target.value })}
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl px-3 py-2 text-slate-200 font-mono text-center outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <div className="p-4 border-t border-indigo-900/40 bg-[#070e22] flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  const { groupId, periodKey, startDate, endDate, executionWindowDays, periodLabel } = periodToSchedule;
                  setPeriodSchedules(prev => ({
                    ...prev,
                    [`${groupId}::${periodKey}`]: {
                      startDate,
                      endDate,
                      executionWindowDays,
                      isScheduled: false,
                      updatedByUser: true
                    }
                  }));
                  setGroupActivities(prev => ({
                    ...prev,
                    [groupId]: (prev[groupId] || []).map(a => a.frequencyType === periodKey ? {
                      ...a,
                      isScheduled: false
                    } : a)
                  }));
                  setPeriodToSchedule(null);
                  setBatchSuccessToast(`✓ زمان‌بندی دوره ${periodLabel} از تقویم حذف گردید.`);
                  setTimeout(() => setBatchSuccessToast(null), 3500);
                }}
                className="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all cursor-pointer"
              >
                لغو زمان‌بندی از تقویم
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPeriodToSchedule(null)}
                  className="px-4 py-2 rounded-xl border border-indigo-500/30 text-slate-400 hover:text-slate-200 text-xs font-bold transition-all cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const { groupId, periodKey, startDate, endDate, executionWindowDays, periodLabel } = periodToSchedule;
                    setPeriodSchedules(prev => ({
                      ...prev,
                      [`${groupId}::${periodKey}`]: {
                        startDate,
                        endDate,
                        executionWindowDays,
                        isScheduled: true,
                        updatedByUser: true
                      }
                    }));
                    setGroupActivities(prev => ({
                      ...prev,
                      [groupId]: (prev[groupId] || []).map(a => a.frequencyType === periodKey ? {
                        ...a,
                        startDate,
                        endDate,
                        executionWindowDays,
                        isScheduled: true
                      } : a)
                    }));
                    setPeriodToSchedule(null);
                    setBatchSuccessToast(`✓ تمام فعالیت‌های دوره ${periodLabel} به صورت یکپارچه برای تاریخ ${startDate} تا ${endDate} (${executionWindowDays} روز) روی تقویم ثبت شد.`);
                    setTimeout(() => setBatchSuccessToast(null), 4000);
                  }}
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg transition-all cursor-pointer"
                >
                  تایید و اعمال روی کل دوره
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* مودال تایید حذف قطعی تکنسین (مورد ۵ کاربر) */}
      {/* ======================================================== */}
      {techToDelete && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in" dir="rtl">
          <div className="bg-[#0c162e] border border-rose-500/40 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl p-5 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto shadow-inner">
              <Trash2 size={22} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">آیا از حذف تکنسین اطمینان دارید؟</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                تکنسین <b className="text-rose-300">«{techToDelete.name}»</b> برای همیشه از سامانه و لیست پرتال حذف خواهد شد و دیگر بازنمی‌گردد.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTechToDelete(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={() => handleDeleteTechnician(techToDelete.id, techToDelete.name)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer transition-all shadow-md"
              >
                بله، برای همیشه حذف شود
              </button>
            </div>
          </div>
        </div>
      )}

      {hoveredCalendarDay && typeof document !== 'undefined' && createPortal(
        <div
          ref={calPopoverRef}
          dir="rtl"
          onMouseEnter={clearCalPopoverTimer}
          onMouseLeave={scheduleCloseCalPopover}
          style={{
            position: 'fixed',
            top: hoveredCalendarDay.top,
            left: hoveredCalendarDay.left,
            width: 256,
            transform: hoveredCalendarDay.placement === 'top' ? 'translateY(-100%)' : 'none',
            zIndex: 9999,
          }}
          className="p-2.5 bg-[#081024] border border-purple-500/60 rounded-xl shadow-[0_18px_45px_rgba(0,0,0,0.95)] space-y-2 text-right"
        >
          <div className="text-[11px] font-bold text-slate-200 pb-1.5 border-b border-indigo-900/50 flex items-center justify-between">
            <span>سررسید PM روز {toFaDigits(hoveredCalendarDay.day)}</span>
            <span className="text-[10px] text-purple-300 font-mono">
              {toFaDigits(hoveredCalendarDay.events.length)} برنامه
            </span>
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto">
            {hoveredCalendarDay.events.map((ev, evIdx) => {
              const evAutoWo = autoPmStatusMap[`${ev.groupId}::${ev.periodKey}`];
              return (
              <div
                key={`${ev.groupId}-${ev.periodKey}-${evIdx}`}
                className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[#0f1a38] border border-slate-700/70"
              >
                <div className="min-w-0">
                  <span className="text-xs font-extrabold text-slate-100 truncate block">
                    {ev.groupName} {ev.periodLabel}
                  </span>
                  {evAutoWo && (
                    <span className="text-[10px] font-mono text-cyan-300 block">
                      {evAutoWo.woCode} ({evAutoWo.code}) {evAutoWo.isArchived ? '• انجام‌شده' : '• باز'}
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setHoveredCalendarDay(null);
                    handleOpenThreeTabPmWorkOrder(ev.groupId, ev.act, ev.periodKey);
                  }}
                  className="py-1 px-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-[10px] shadow transition-all cursor-pointer flex items-center gap-1 shrink-0"
                  title={`باز کردن دستور کار ${ev.groupName} ${ev.periodLabel}`}
                >
                  <Wrench size={11} />
                  <span>{evAutoWo ? evAutoWo.woCode : 'دستور کار'}</span>
                </button>
              </div>
              );
            })}
          </div>
        </div>,
        document.body
      )}

      <PmWorkOrderThreeTabModal
        isOpen={Boolean(activeThreeTabPmOrder)}
        targetOrder={activeThreeTabPmOrder}
        familyList={familyList}
        equipmentList={equipmentList}
        technicians={technicians || []}
        onClose={() => setActiveThreeTabPmOrder(null)}
        onQuickUpdateOrder={(updatedOrder) => {
          const currentList = loadAutoPmWorkOrders();
          const exists = currentList.some((o: any) => o?.id === updatedOrder.id || o?.code === updatedOrder.code);
          const nextOrders = exists
            ? currentList.map((o: any) => (o?.id === updatedOrder.id || o?.code === updatedOrder.code ? updatedOrder : o))
            : [updatedOrder, ...currentList];
          saveAutoPmWorkOrders(nextOrders);
          setAutoPmWorkOrders(nextOrders);
          setAutoPmStatusMap(buildAutoPmLookupMaps(nextOrders).statusByGroupPeriod);
          setActiveThreeTabPmOrder(updatedOrder);
        }}
        onSaveOrder={(updatedOrder) => {
          const currentList = loadAutoPmWorkOrders();
          const exists = currentList.some((o: any) => o?.id === updatedOrder.id || o?.code === updatedOrder.code);
          const nextOrders = exists
            ? currentList.map((o: any) => (o?.id === updatedOrder.id || o?.code === updatedOrder.code ? updatedOrder : o))
            : [updatedOrder, ...currentList];

          saveAutoPmWorkOrders(nextOrders);
          setAutoPmWorkOrders(nextOrders);
          setAutoPmStatusMap(buildAutoPmLookupMaps(nextOrders).statusByGroupPeriod);

          try {
            const reconciled = syncAndReconcilePmTechStorage({ autoPmOrders: nextOrders });
            if (Array.isArray(reconciled) && reconciled.length > 0) {
              setTechniciansList(reconciled.filter((t: any) => !deletedTechNames.includes(t.name)));
            }
          } catch {}

          try {
            window.dispatchEvent(new CustomEvent('pm_auto_work_orders_updated', { detail: { updatedOrder } }));
          } catch {}

          setActiveThreeTabPmOrder(null);
          setBatchSuccessToast(
            isItemArchivedCheck(updatedOrder)
              ? `✓ دستور کار PM با شماره ${updatedOrder.woCode || updatedOrder.code} ثبت و در بخش نگهداری پیشگیرانه بایگانی شد.`
              : `✓ تغییرات دستور کار PM با شماره ${updatedOrder.woCode || updatedOrder.code} ثبت شد.`
          );
          setTimeout(() => setBatchSuccessToast(null), 5000);
        }}
      />

    </div>
  );
}
