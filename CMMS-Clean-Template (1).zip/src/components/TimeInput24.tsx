import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Clock } from 'lucide-react';
import { toEnDigits } from '../data/dateTimeUtils';

interface TimeInput24Props {
  value: string;
  onChange: (nextVal: string) => void;
  className?: string;
  placeholder?: string;
  disabled?: boolean;
}

const normalizeValidTime24 = (raw: string): string | null => {
  const clean = toEnDigits(raw || '').trim();
  if (!clean) return null;

  let hStr = '';
  let mStr = '';

  if (clean.includes(':')) {
    const [hPart, mPart = '00'] = clean.split(':');
    hStr = hPart.replace(/\D/g, '');
    mStr = mPart.replace(/\D/g, '');
  } else {
    const digits = clean.replace(/\D/g, '');
    if (digits.length <= 2) {
      hStr = digits;
      mStr = '00';
    } else if (digits.length === 3) {
      hStr = digits.slice(0, 1);
      mStr = digits.slice(1, 3);
    } else {
      hStr = digits.slice(0, 2);
      mStr = digits.slice(2, 4);
    }
  }

  if (!hStr) return null;
  let h = parseInt(hStr, 10);
  let m = parseInt(mStr || '0', 10);
  if (isNaN(h)) return null;
  if (isNaN(m)) m = 0;

  h = Math.max(0, Math.min(23, h));
  m = Math.max(0, Math.min(59, m));

  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};

const parseHourMin = (val: string): { hour: number; minute: number } => {
  const normalized = normalizeValidTime24(val);
  if (!normalized) return { hour: 8, minute: 0 };
  const [h, m] = normalized.split(':').map(n => parseInt(n, 10));
  return {
    hour: isNaN(h) ? 8 : Math.max(0, Math.min(23, h)),
    minute: isNaN(m) ? 0 : Math.max(0, Math.min(59, m))
  };
};

export const TimeInput24: React.FC<TimeInput24Props> = ({
  value,
  onChange,
  className = '',
  placeholder = '00:00',
  disabled = false
}) => {
  const [draft, setDraft] = useState<string>(normalizeValidTime24(value) || value || '');
  const [isOpen, setIsOpen] = useState(false);
  const [popoverPos, setPopoverPos] = useState<{ top: number; left: number }>({ top: 0, left: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setDraft(normalizeValidTime24(value) || value || '');
  }, [value]);

  const updatePopoverPosition = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const popWidth = 200;
    const popHeight = 250;
    let left = rect.left;
    if (left + popWidth > window.innerWidth - 8) {
      left = Math.max(8, window.innerWidth - popWidth - 8);
    }
    if (left < 8) left = 8;

    let top = rect.bottom + 6;
    if (top + popHeight > window.innerHeight - 8) {
      top = Math.max(8, rect.top - popHeight - 6);
    }
    setPopoverPos({ top, left });
  };

  useEffect(() => {
    if (!isOpen) return;
    updatePopoverPosition();

    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        containerRef.current?.contains(target) ||
        popoverRef.current?.contains(target)
      ) {
        return;
      }
      setIsOpen(false);
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    const handleScrollOrResize = () => updatePopoverPosition();

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleEsc);
    window.addEventListener('resize', handleScrollOrResize);
    window.addEventListener('scroll', handleScrollOrResize, true);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEsc);
      window.removeEventListener('resize', handleScrollOrResize);
      window.removeEventListener('scroll', handleScrollOrResize, true);
    };
  }, [isOpen]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    let raw = toEnDigits(e.target.value).replace(/[^0-9:]/g, '');

    // اگر کاربر ۴ رقم پشت سر هم تایپ کرد (مثلا 1430)، خودکار به 14:30 تبدیل شود
    if (!raw.includes(':') && raw.length >= 3) {
      const digits = raw.slice(0, 4);
      if (digits.length === 4) {
        raw = `${digits.slice(0, 2)}:${digits.slice(2, 4)}`;
      }
    }

    if (raw.length > 5) {
      raw = raw.slice(0, 5);
    }

    setDraft(raw);

    const exactMatch = raw.match(/^(\d{2}):(\d{2})$/);
    if (exactMatch) {
      const h = Math.max(0, Math.min(23, parseInt(exactMatch[1], 10)));
      const m = Math.max(0, Math.min(59, parseInt(exactMatch[2], 10)));
      const formatted = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      if (formatted !== raw) setDraft(formatted);
      onChange(formatted);
    }
  };

  const handleBlur = () => {
    if (disabled) return;
    const normalized = normalizeValidTime24(draft);
    if (normalized) {
      setDraft(normalized);
      if (normalized !== value) {
        onChange(normalized);
      }
    } else {
      const fallback = normalizeValidTime24(value) || '00:00';
      setDraft(fallback);
      if (fallback !== value) onChange(fallback);
    }
  };

  const { hour: currentHour, minute: currentMinute } = parseHourMin(draft || value);
  const hoursList = Array.from({ length: 24 }, (_, i) => i);
  const minutesList = Array.from({ length: 60 }, (_, i) => i);

  const selectHour = (h: number) => {
    if (disabled) return;
    const formatted = `${String(h).padStart(2, '0')}:${String(currentMinute).padStart(2, '0')}`;
    setDraft(formatted);
    onChange(formatted);
  };

  const selectMinute = (m: number) => {
    if (disabled) return;
    const formatted = `${String(currentHour).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    setDraft(formatted);
    onChange(formatted);
  };

  return (
    <div ref={containerRef} className="relative flex items-center w-full" dir="ltr">
      <input
        type="text"
        inputMode="numeric"
        maxLength={5}
        value={draft}
        disabled={disabled}
        onChange={handleInputChange}
        onBlur={handleBlur}
        placeholder={placeholder}
        dir="ltr"
        title={disabled ? 'فقط مشاهده' : 'فرمت ۲۴ ساعته (مثال: 14:30)'}
        className={`${className} ${disabled ? 'opacity-80 cursor-not-allowed pr-2' : 'pr-6'}`}
      />
      {!disabled && (
        <button
          type="button"
          onClick={() => setIsOpen(prev => !prev)}
          tabIndex={-1}
          title="انتخاب ساعت ۲۴ ساعته"
          className="absolute right-1.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
        >
          <Clock className="w-3 h-3" />
        </button>
      )}

      {!disabled && isOpen &&
        createPortal(
          <div
            ref={popoverRef}
            dir="rtl"
            style={{ top: popoverPos.top, left: popoverPos.left }}
            className="fixed z-[250] w-[200px] rounded-2xl bg-[#0b1530] border border-cyan-500/45 shadow-2xl p-2.5 text-xs text-slate-100 select-none"
          >
            <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-indigo-900/50">
              <span className="text-[10px] font-bold text-cyan-300">ساعت ۲۴ ساعته</span>
              <span className="font-mono font-bold text-xs text-white bg-[#070e22] px-2 py-0.5 rounded-md border border-cyan-500/30" dir="ltr">
                {String(currentHour).padStart(2, '0')}:{String(currentMinute).padStart(2, '0')}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2" dir="ltr">
              <div>
                <div className="text-[10px] text-slate-400 text-center mb-1 font-bold">ساعت (00-23)</div>
                <div className="max-h-44 overflow-y-auto space-y-0.5 pr-0.5">
                  {hoursList.map(h => {
                    const active = h === currentHour;
                    return (
                      <button
                        key={h}
                        type="button"
                        onClick={() => selectHour(h)}
                        className={`w-full py-1 rounded-lg font-mono text-xs font-bold transition-colors cursor-pointer ${
                          active
                            ? 'bg-cyan-600 text-white shadow-sm'
                            : 'bg-[#070e22]/70 text-slate-300 hover:bg-indigo-900/60 hover:text-white'
                        }`}
                      >
                        {String(h).padStart(2, '0')}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-400 text-center mb-1 font-bold">دقیقه (00-59)</div>
                <div className="max-h-44 overflow-y-auto space-y-0.5 pr-0.5">
                  {minutesList.map(m => {
                    const active = m === currentMinute;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => {
                          selectMinute(m);
                          setIsOpen(false);
                        }}
                        className={`w-full py-1 rounded-lg font-mono text-xs font-bold transition-colors cursor-pointer ${
                          active
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'bg-[#070e22]/70 text-slate-300 hover:bg-indigo-900/60 hover:text-white'
                        }`}
                      >
                        {String(m).padStart(2, '0')}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};

export default TimeInput24;
