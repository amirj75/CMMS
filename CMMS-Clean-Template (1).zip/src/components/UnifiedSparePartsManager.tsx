import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Package,
  Plus,
  Download,
  Search,
  Trash2,
  History,
  Calendar,
  User,
  Wrench,
  CheckCircle2,
  X,
  Tag,
  Clock,
  Layers,
  FileText,
  ArrowRight
} from 'lucide-react';
import {
  UnifiedSparePart,
  SparePartCategory,
  SparePartConsumptionRecord,
  getUnifiedSpareParts,
  addOrUpdateSparePart,
  deleteSparePart,
  subscribeToSpareParts,
  getSparePartConsumptions,
  recordSparePartConsumption,
  deleteSparePartConsumption
} from '../data/sparePartsData';

export interface UnifiedSparePartsManagerProps {
  technicians?: string[];
  theme?: 'dark' | 'light';
  accentColor?: 'purple' | 'amber';
  onBack?: () => void;
}

const toFaDigits = (val: number | string | undefined | null): string => {
  if (val === undefined || val === null) return '';
  return String(val).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)]);
};

export const UnifiedSparePartsManager: React.FC<UnifiedSparePartsManagerProps> = ({
  technicians = [],
  accentColor = 'purple',
  onBack
}) => {
  const [partsList, setPartsList] = useState<UnifiedSparePart[]>(() => getUnifiedSpareParts());
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [usageFilter, setUsageFilter] = useState<'all' | 'consumed' | 'pm' | 'technical'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // مودال افزودن قطعه جدید
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [partForm, setPartForm] = useState({
    code: '',
    name: '',
    category: 'مکانیکی' as SparePartCategory,
    unit: 'عدد',
    eqFamily: '',
    location: '',
    notes: '',
    price: ''
  });

  // مودال مشاهده سوابق مصرف قطعه
  const [viewingHistoryPart, setViewingHistoryPart] = useState<UnifiedSparePart | null>(null);

  // مودال ثبت مصرف مستقیم
  const [isRecordUsageModalOpen, setIsRecordUsageModalOpen] = useState(false);
  const [usageForm, setUsageForm] = useState<{
    partId: string;
    partCode: string;
    partName: string;
    workType: 'pm' | 'technical';
    workCode: string;
    workTitle: string;
    equipment: string;
    count: number;
    unit: string;
    date: string;
    technician: string;
    notes: string;
  }>({
    partId: '',
    partCode: '',
    partName: '',
    workType: 'pm',
    workCode: '',
    workTitle: '',
    equipment: '',
    count: 1,
    unit: 'عدد',
    date: '۱۴۰۵/۰۸/۱۰',
    technician: '',
    notes: ''
  });

  // اشتراک در تغییرات برای به‌روزرسانی آنی در کل سیستم
  useEffect(() => {
    const unsub = subscribeToSpareParts(parts => {
      setPartsList(parts);
    });
    return () => unsub();
  }, []);

  // بارگذاری سوابق مصرف
  const allConsumptions = useMemo(() => {
    return getSparePartConsumptions();
  }, [partsList, isRecordUsageModalOpen]);

  // استخراج تمام سوابق مربوط به یک قطعه
  const getConsumptionsForPart = useCallback((part: UnifiedSparePart): SparePartConsumptionRecord[] => {
    const pId = (part.id || '').toLowerCase();
    const pCode = (part.code || '').toLowerCase();
    const pName = (part.name || '').trim().toLowerCase();

    const matched = allConsumptions.filter(c => {
      const cId = (c.partId || '').toLowerCase();
      const cCode = (c.partCode || '').toLowerCase();
      const cName = (c.partName || '').trim().toLowerCase();
      return (
        (pId && cId === pId) ||
        (pCode && cCode === pCode) ||
        (pName && cName === pName)
      );
    });

    return matched.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  }, [allConsumptions]);

  // ثبت قطعه جدید
  const handleSavePart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partForm.name.trim()) return;

    addOrUpdateSparePart({
      code: partForm.code.trim() || undefined,
      name: partForm.name.trim(),
      category: partForm.category,
      unit: partForm.unit.trim() || 'عدد',
      eqFamily: partForm.eqFamily.trim() || '',
      location: partForm.location.trim() || '',
      notes: partForm.notes.trim() || '',
      price: partForm.price.trim() || ''
    });

    setIsAddModalOpen(false);
    setPartForm({
      code: '',
      name: '',
      category: 'مکانیکی',
      unit: 'عدد',
      eqFamily: '',
      location: '',
      notes: '',
      price: ''
    });
  };

  // حذف قطعه
  const handleDeletePart = (id: string) => {
    if (window.confirm('آیا از حذف این قطعه یدکی مصرفی از سیستم اطمینان دارید؟')) {
      const updated = deleteSparePart(id);
      setPartsList(updated);
      if (viewingHistoryPart?.id === id) {
        setViewingHistoryPart(null);
      }
    }
  };

  // ثبت سابقه مصرف جدید
  const handleSubmitUsage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!usageForm.partName.trim()) {
      alert('لطفاً قطعه مورد نظر را مشخص کنید.');
      return;
    }

    recordSparePartConsumption({
      partId: usageForm.partId || usageForm.partName,
      partCode: usageForm.partCode || '',
      partName: usageForm.partName.trim(),
      workType: usageForm.workType,
      workCode: usageForm.workCode.trim() || (usageForm.workType === 'pm' ? 'سرویس نگهداری PM' : 'دستورکار خدمات فنی'),
      workTitle: usageForm.workTitle.trim() || 'تعویض قطعه مصرفی',
      equipment: usageForm.equipment.trim() || '',
      count: Math.max(1, Number(usageForm.count) || 1),
      unit: usageForm.unit || 'عدد',
      date: usageForm.date.trim() || '۱۴۰۵/۰۸/۱۰',
      technician: usageForm.technician.trim() || 'تکنسین فنی',
      notes: usageForm.notes.trim() || ''
    });

    setIsRecordUsageModalOpen(false);
    setPartsList(getUnifiedSpareParts());
  };

  // خروجی اکسل CSV تمیز و مرتب
  const handleExportCsv = () => {
    try {
      const headers = [
        'ردیف',
        'کد قطعه',
        'نام قطعه یدکی مصرفی',
        'گروه تخصصی',
        'دستگاه / سالن',
        'مجموع تعداد مصرف',
        'آخرین کار استفاده‌شده',
        'نوع آخرین کار (PM یا خدمات فنی)',
        'تاریخ آخرین مصرف',
        'تکنسین آخرین مصرف',
        'محل قفسه / انبار',
        'مشخصات فنی'
      ];

      const rows = filteredParts.map((item, idx) => {
        const consumptions = getConsumptionsForPart(item);
        const totalUsed = consumptions.reduce((sum, c) => sum + (Number(c.count) || 1), 0);
        const latest = consumptions[0];
        const latestWorkType = latest ? (latest.workType === 'pm' ? 'نگهداری پیشگیرانه PM' : 'خدمات فنی') : '—';
        const latestJob = latest ? (latest.workCode || latest.workTitle || '') : 'هنوز مصرف نشده';

        return [
          idx + 1,
          `"${item.code || item.id}"`,
          `"${item.name}"`,
          `"${item.category || ''}"`,
          `"${item.eqFamily || ''}"`,
          `"${totalUsed} ${item.unit || 'عدد'}"`,
          `"${latestJob}"`,
          `"${latestWorkType}"`,
          `"${latest?.date || '—'}"`,
          `"${latest?.technician || '—'}"`,
          `"${item.location || ''}"`,
          `"${item.notes || ''}"`
        ];
      });

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `factory_spare_parts_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('CSV export error:', err);
    }
  };

  // فیلتر کردن اقلام
  const filteredParts = useMemo(() => {
    return partsList.filter(item => {
      if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;

      const consumptions = getConsumptionsForPart(item);
      if (usageFilter === 'consumed' && consumptions.length === 0) return false;
      if (usageFilter === 'pm' && !consumptions.some(c => c.workType === 'pm')) return false;
      if (usageFilter === 'technical' && !consumptions.some(c => c.workType === 'technical')) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesCode = (item.code || '').toLowerCase().includes(q);
        const matchesEq = (item.eqFamily || '').toLowerCase().includes(q);
        const matchesNotes = (item.notes || '').toLowerCase().includes(q);
        const matchesUsage = consumptions.some(c => 
          (c.workCode || '').toLowerCase().includes(q) ||
          (c.workTitle || '').toLowerCase().includes(q) ||
          (c.equipment || '').toLowerCase().includes(q) ||
          (c.technician || '').toLowerCase().includes(q)
        );
        return matchesName || matchesCode || matchesEq || matchesNotes || matchesUsage;
      }

      return true;
    });
  }, [partsList, categoryFilter, usageFilter, searchQuery, getConsumptionsForPart]);

  const isPurple = accentColor === 'purple';
  const brandGradient = isPurple 
    ? 'from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500' 
    : 'from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500';
  const brandBorder = isPurple ? 'border-purple-500/40' : 'border-amber-500/40';

  return (
    <div className="space-y-4 text-right">
      {/* هدر بخش لوازم یدکی و قطعات مصرفی */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-950/90 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm shrink-0"
              title="بازگشت به داشبورد"
            >
              <ArrowRight size={14} />
              <span>بازگشت به داشبورد</span>
            </button>
          )}
          <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-500/40 text-purple-300 flex items-center justify-center shadow-inner">
            <Package className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              <span>لوازم یدکی و قطعات مصرفی</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-900 text-purple-300 border border-purple-500/30 font-mono font-bold">
                {toFaDigits(partsList.length)} قلم قطعه
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              ثبت قطعات، کدگذاری و رهگیری سوابق استفاده‌شده در نگهداری پیشگیرانه (PM) و خدمات فنی
            </p>
          </div>
        </div>

        {/* دکمه‌های عملیات بالا */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r ${brandGradient} text-white text-xs font-bold shadow-lg transition-all cursor-pointer`}
          >
            <Plus className="w-4 h-4" />
            <span>ثبت قطعه یدکی جدید</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (partsList.length === 0) {
                alert('ابتدا باید حداقل یک قطعه در سامانه ثبت شود.');
                return;
              }
              const firstPart = partsList[0];
              setUsageForm({
                partId: firstPart.id,
                partCode: firstPart.code || firstPart.id,
                partName: firstPart.name,
                workType: 'pm',
                workCode: '',
                workTitle: '',
                equipment: firstPart.eqFamily || '',
                count: 1,
                unit: firstPart.unit || 'عدد',
                date: '۱۴۰۵/۰۸/۱۰',
                technician: '',
                notes: ''
              });
              setIsRecordUsageModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all cursor-pointer"
            title="ثبت سابقه مصرف برای یک کار"
          >
            <Wrench className="w-3.5 h-3.5 text-emerald-400" />
            <span>+ ثبت مصرف قطعه</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition-all cursor-pointer"
            title="دانلود خروجی اکسل CSV"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>اکسل قطعات</span>
          </button>
        </div>
      </div>

      {/* نوار فیلتر و جستجو (خلوت و بدون منبع یا نقطه سفارش) */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
        <div className="flex flex-wrap items-center gap-2">
          {/* فیلتر وضعیت مصرف */}
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setUsageFilter('all')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                usageFilter === 'all'
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              همه اقلام ({toFaDigits(partsList.length)})
            </button>
            <button
              type="button"
              onClick={() => setUsageFilter('consumed')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                usageFilter === 'consumed'
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              فقط مصرف‌شده‌ها
            </button>
            <button
              type="button"
              onClick={() => setUsageFilter('pm')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usageFilter === 'pm'
                  ? 'bg-purple-600 text-white'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
              <span>مصرف در PM</span>
            </button>
            <button
              type="button"
              onClick={() => setUsageFilter('technical')}
              className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usageFilter === 'technical'
                  ? 'bg-blue-600 text-white'
                  : 'text-blue-300 hover:text-white'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
              <span>مصرف در خدمات فنی</span>
            </button>
          </div>

          {/* فیلتر گروه تخصصی */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-purple-500 cursor-pointer"
          >
            <option value="all">همه گروه‌های تخصصی</option>
            <option value="مکانیکی">مکانیکی</option>
            <option value="برقی">برقی</option>
            <option value="هیدرولیک و پنوماتیک">هیدرولیک و پنوماتیک</option>
            <option value="ابزار دقیق">ابزار دقیق</option>
            <option value="عمومی و سایر">عمومی و سایر</option>
          </select>
        </div>

        {/* فیلد جستجوی زنده */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="جستجوی کد، نام، دستگاه یا کار..."
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl py-1.5 pr-9 pl-3 text-xs text-white placeholder-slate-500 outline-none focus:border-purple-500 shadow-inner"
          />
        </div>
      </div>

      {/* جدول قطعات یدکی خلوت‌شده و متمرکز بر مصرف */}
      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950/90 shadow-xl">
        <table className="w-full text-right whitespace-nowrap text-xs">
          <thead>
            <tr className="bg-slate-900/90 text-slate-400 border-b border-slate-800 font-bold">
              <th className="px-4 py-3.5 text-center w-12">#</th>
              <th className="px-4 py-3.5">کد قطعه</th>
              <th className="px-4 py-3.5">نام قطعه یدکی مصرفی</th>
              <th className="px-4 py-3.5">گروه تخصصی</th>
              <th className="px-4 py-3.5">دستگاه / سالن مرتبط</th>
              <th className="px-4 py-3.5 text-center">مجموع مصرف</th>
              <th className="px-4 py-3.5">آخرین کار استفاده‌شده (PM یا خدمات فنی)</th>
              <th className="px-4 py-3.5 text-center">سوابق استفاده</th>
              <th className="px-4 py-3.5 text-center w-24">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredParts.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-16 text-center">
                  <div className="max-w-md mx-auto space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-purple-400 flex items-center justify-center mx-auto shadow-lg">
                      <Package className="w-7 h-7" />
                    </div>
                    {partsList.length === 0 ? (
                      <>
                        <h3 className="text-base font-bold text-white">انبار قطعات یدکی در حال حاضر خالی است</h3>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          اقلام پیش‌فرض پاکسازی شدند تا بتوانید لوازم یدکی و قطعات مصرفی واقعی را خودتان ثبت نمایید.
                        </p>
                        <button
                          type="button"
                          onClick={() => setIsAddModalOpen(true)}
                          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-950/60 transition-all cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>ثبت اولین قطعه یدکی</span>
                        </button>
                      </>
                    ) : (
                      <>
                        <h3 className="text-sm font-bold text-white">هیچ قطعه‌ای با این مشخصات یافت نشد</h3>
                        <p className="text-xs text-slate-400">می‌توانید عبارت جستجو را پاک کنید یا فیلترها را تغییر دهید.</p>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              filteredParts.map((item, idx) => {
                const consumptions = getConsumptionsForPart(item);
                const totalUsed = consumptions.reduce((sum, c) => sum + (Number(c.count) || 1), 0);
                const latest = consumptions[0] || null;

                return (
                  <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                    {/* ردیف */}
                    <td className="px-4 py-3 text-center font-mono text-slate-500 font-bold">
                      {toFaDigits(idx + 1)}
                    </td>

                    {/* کد قطعه */}
                    <td className="px-4 py-3 font-mono font-bold">
                      <span className="px-2.5 py-1 rounded-xl bg-purple-950/80 text-purple-300 border border-purple-500/30 inline-block shadow-sm">
                        {item.code || item.id}
                      </span>
                    </td>

                    {/* نام قطعه */}
                    <td className="px-4 py-3">
                      <div className="font-bold text-white">{item.name}</div>
                      {item.location && (
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-normal">
                          محل: {item.location}
                        </span>
                      )}
                    </td>

                    {/* گروه تخصصی */}
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900 text-slate-300 border border-slate-700/80 text-[11px]">
                        {item.category}
                      </span>
                    </td>

                    {/* دستگاه / تجهیز */}
                    <td className="px-4 py-3 text-slate-300">
                      {item.eqFamily || '—'}
                    </td>

                    {/* مجموع مصرف */}
                    <td className="px-4 py-3 text-center">
                      {totalUsed > 0 ? (
                        <span className="font-mono font-black text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-2.5 py-1 rounded-xl inline-block shadow-sm">
                          {toFaDigits(totalUsed)} {item.unit || 'عدد'}
                        </span>
                      ) : (
                        <span className="text-slate-500 text-[11px] font-normal">
                          بدون مصرف
                        </span>
                      )}
                    </td>

                    {/* آخرین کار استفاده‌شده (PM یا خدمات فنی) */}
                    <td className="px-4 py-3">
                      {latest ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border inline-flex items-center gap-1 ${
                              latest.workType === 'pm'
                                ? 'bg-purple-950/90 text-purple-300 border-purple-500/50'
                                : 'bg-blue-950/90 text-blue-300 border-blue-500/50'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                latest.workType === 'pm' ? 'bg-purple-400' : 'bg-blue-400'
                              }`}></span>
                              <span>{latest.workType === 'pm' ? 'نگهداری پیشگیرانه PM' : 'خدمات فنی'}</span>
                            </span>
                            <span className="text-xs font-bold text-white font-mono">
                              {latest.workCode}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 flex items-center gap-2">
                            <span>{latest.date}</span>
                            {latest.equipment && (
                              <>
                                <span>•</span>
                                <span className="text-slate-300">{latest.equipment}</span>
                              </>
                            )}
                            {latest.technician && (
                              <>
                                <span>•</span>
                                <span className="text-purple-300">{latest.technician}</span>
                              </>
                            )}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-500 text-[11px]">هنوز در کاری مصرف نشده</span>
                      )}
                    </td>

                    {/* دکمه مشاهده سوابق استفاده (کدوم کار استفاده شده؟) */}
                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => setViewingHistoryPart(item)}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm ${
                          consumptions.length > 0
                            ? 'bg-purple-950/70 hover:bg-purple-900/90 text-purple-200 border-purple-500/50'
                            : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-700'
                        }`}
                        title="مشاهده جزئیات تمام دفعاتی که این قطعه در PM یا خدمات فنی مصرف شده است"
                      >
                        <History className="w-3.5 h-3.5 text-purple-400" />
                        <span>سوابق مصرف</span>
                        <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/50 text-white font-bold">
                          {toFaDigits(consumptions.length)}
                        </span>
                      </button>
                    </td>

                    {/* عملیات (+ مصرف / حذف) */}
                    <td className="px-4 py-3 text-center">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setUsageForm({
                              partId: item.id,
                              partCode: item.code || item.id,
                              partName: item.name,
                              workType: 'pm',
                              workCode: '',
                              workTitle: '',
                              equipment: item.eqFamily || '',
                              count: 1,
                              unit: item.unit || 'عدد',
                              date: '۱۴۰۵/۰۸/۱۰',
                              technician: '',
                              notes: ''
                            });
                            setIsRecordUsageModalOpen(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 hover:text-white border border-emerald-500/40 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          title="ثبت مصرف این قطعه برای یک کار جدید"
                        >
                          <Plus className="w-3 h-3" />
                          <span>مصرف</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeletePart(item.id)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title="حذف قطعه از سامانه"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* ======================================================== */}
      {/* MODAL 1: ثبت قطعه یدکی جدید (بدون موجودی و نقطه سفارش) */}
      {/* ======================================================== */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-purple-500/40 shadow-2xl p-6 space-y-4 text-right text-slate-200 animate-in zoom-in-95 my-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-400 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">ثبت قطعه یدکی مصرفی جدید</h3>
                  <p className="text-xs text-slate-400">مشخصات قطعه را جهت رهگیری مصارف در PM و خدمات فنی وارد نمایید</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePart} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="text-slate-300 font-bold block mb-1">کد قطعه (اختیاری):</label>
                  <input
                    type="text"
                    value={partForm.code}
                    onChange={e => setPartForm({ ...partForm, code: e.target.value.toUpperCase() })}
                    placeholder="مثال: PRT-01"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white font-mono uppercase outline-none"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">در صورت خالی بودن خودکار تولید می‌شود</span>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-300 font-bold block mb-1">نام قطعه یدکی: *</label>
                  <input
                    type="text"
                    required
                    value={partForm.name}
                    onChange={e => setPartForm({ ...partForm, name: e.target.value })}
                    placeholder="مثال: بلبرینگ دور بالا SKF 6204 یا رله ۲۴ ولت"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">گروه تخصصی: *</label>
                  <select
                    value={partForm.category}
                    onChange={e => setPartForm({ ...partForm, category: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none cursor-pointer"
                  >
                    <option value="مکانیکی">مکانیکی</option>
                    <option value="برقی">برقی</option>
                    <option value="هیدرولیک و پنوماتیک">هیدرولیک و پنوماتیک</option>
                    <option value="ابزار دقیق">ابزار دقیق</option>
                    <option value="عمومی و سایر">عمومی و سایر</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">واحد شمارش:</label>
                  <input
                    type="text"
                    value={partForm.unit}
                    onChange={e => setPartForm({ ...partForm, unit: e.target.value })}
                    placeholder="عدد / متر / لیتر / بسته"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none text-center"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">دستگاه یا سالن مرتبط (اختیاری):</label>
                  <input
                    type="text"
                    value={partForm.eqFamily}
                    onChange={e => setPartForm({ ...partForm, eqFamily: e.target.value })}
                    placeholder="مثال: پرس‌های هیدرولیک یا تراش CNC"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">محل قفسه یا نگهداری (اختیاری):</label>
                  <input
                    type="text"
                    value={partForm.location}
                    onChange={e => setPartForm({ ...partForm, location: e.target.value })}
                    placeholder="مثال: قفسه B • کشوی ۴"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">مشخصات فنی یا پارت‌نامبر (اختیاری):</label>
                <textarea
                  rows={2}
                  value={partForm.notes}
                  onChange={e => setPartForm({ ...partForm, notes: e.target.value })}
                  placeholder="مشخصات ولتاژ، ابعاد، برند، کاتالوگ یا توضیحات فنی..."
                  className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold shadow-lg shadow-purple-950/60 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>ثبت و ذخیره قطعه</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 2: مشاهده سوابق مصرف قطعه (کدوم کار استفاده شده؟ PM یا خدمات فنی؟) */}
      {/* ======================================================== */}
      {viewingHistoryPart && (() => {
        const consumptions = getConsumptionsForPart(viewingHistoryPart);
        const totalCount = consumptions.reduce((sum, c) => sum + (Number(c.count) || 1), 0);
        const pmConsumptions = consumptions.filter(c => c.workType === 'pm');
        const techConsumptions = consumptions.filter(c => c.workType === 'technical');

        return (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
            <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-purple-500/50 shadow-2xl p-6 space-y-4 text-right text-slate-200 animate-in zoom-in-95 my-6">
              
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-400 flex items-center justify-center">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">سوابق استفاده از قطعه:</h3>
                      <span className="font-mono font-bold text-purple-300 bg-purple-950 px-2 py-0.5 rounded-lg border border-purple-500/40">
                        {viewingHistoryPart.code || viewingHistoryPart.id}
                      </span>
                    </div>
                    <span className="text-xs text-slate-300 font-bold mt-0.5 block">{viewingHistoryPart.name}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setViewingHistoryPart(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* کارت‌های آماری خلاصه مصارف در PM و خدمات فنی */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
                  <span className="text-[11px] text-slate-400 block">مجموع مصرف قطعه</span>
                  <span className="text-xl font-mono font-black text-emerald-400">
                    {toFaDigits(totalCount)} {viewingHistoryPart.unit || 'عدد'}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-500/40 text-center">
                  <span className="text-[11px] text-purple-300 block">مصرف در نگهداری PM</span>
                  <span className="text-xl font-mono font-black text-purple-300">
                    {toFaDigits(pmConsumptions.length)} مورد
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-blue-950/40 border border-blue-500/40 text-center">
                  <span className="text-[11px] text-blue-300 block">مصرف در خدمات فنی</span>
                  <span className="text-xl font-mono font-black text-blue-300">
                    {toFaDigits(techConsumptions.length)} مورد
                  </span>
                </div>
              </div>

              {/* لیست سوابق استفاده‌شده */}
              <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                {consumptions.length === 0 ? (
                  <div className="py-12 text-center rounded-2xl bg-slate-950/70 border border-dashed border-slate-800 space-y-2">
                    <History className="w-8 h-8 text-slate-600 mx-auto" />
                    <h4 className="text-sm font-bold text-white">تاکنون هیچ مصرفی برای این قطعه ثبت نشده است</h4>
                    <p className="text-xs text-slate-400">
                      هر زمان این قطعه در دستورکار خدمات فنی یا در برنامه PM استفاده شود، سوابق آن به صورت خودکار در این بخش قابل مشاهده است.
                    </p>
                  </div>
                ) : (
                  consumptions.map((c, idx) => (
                    <div
                      key={c.id || idx}
                      className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-colors space-y-2"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border inline-flex items-center gap-1.5 ${
                            c.workType === 'pm'
                              ? 'bg-purple-950/90 text-purple-300 border-purple-500/50'
                              : 'bg-blue-950/90 text-blue-300 border-blue-500/50'
                          }`}>
                            <span className={`w-2 h-2 rounded-full ${
                              c.workType === 'pm' ? 'bg-purple-400' : 'bg-blue-400'
                            }`}></span>
                            <span>{c.workType === 'pm' ? 'نگهداری پیشگیرانه PM' : 'خدمات فنی (دستورکار)'}</span>
                          </span>

                          <span className="font-mono text-xs font-bold text-white bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800">
                            {c.workCode}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-black text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-lg border border-emerald-500/40">
                            تعداد: {toFaDigits(c.count)} {c.unit || viewingHistoryPart.unit || 'عدد'}
                          </span>

                          {c.id.startsWith('cons-') && (
                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm('آیا از حذف این رکورد سابقه مصرف اطمینان دارید؟')) {
                                  deleteSparePartConsumption(c.id);
                                  setPartsList(getUnifiedSpareParts());
                                }
                              }}
                              className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-rose-950/30 transition-colors"
                              title="حذف این سابقه"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {c.workTitle && (
                        <div className="text-xs text-white font-medium flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                          <span>شرح کار: {c.workTitle}</span>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-1 border-t border-slate-850">
                        {c.equipment && (
                          <span className="flex items-center gap-1 text-slate-300">
                            <Tag className="w-3 h-3 text-amber-400" />
                            <span>دستگاه / سالن: {c.equipment}</span>
                          </span>
                        )}
                        {c.technician && (
                          <span className="flex items-center gap-1 text-purple-300">
                            <User className="w-3 h-3 text-purple-400" />
                            <span>اقدام‌کننده: {c.technician}</span>
                          </span>
                        )}
                        {c.date && (
                          <span className="flex items-center gap-1 text-slate-400">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            <span>تاریخ: {c.date}</span>
                          </span>
                        )}
                      </div>

                      {c.notes && (
                        <p className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-800/80">
                          {c.notes}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* دکمه‌های پایین مودال */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setUsageForm({
                      partId: viewingHistoryPart.id,
                      partCode: viewingHistoryPart.code || viewingHistoryPart.id,
                      partName: viewingHistoryPart.name,
                      workType: 'pm',
                      workCode: '',
                      workTitle: '',
                      equipment: viewingHistoryPart.eqFamily || '',
                      count: 1,
                      unit: viewingHistoryPart.unit || 'عدد',
                      date: '۱۴۰۵/۰۸/۱۰',
                      technician: '',
                      notes: ''
                    });
                    setIsRecordUsageModalOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ ثبت مصرف جدید برای این قطعه</span>
                </button>

                <button
                  type="button"
                  onClick={() => setViewingHistoryPart(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  بستن
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* ======================================================== */}
      {/* MODAL 3: ثبت سابقه مصرف جدید برای کار مشخص (PM یا خدمات فنی) */}
      {/* ======================================================== */}
      {isRecordUsageModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-emerald-500/40 shadow-2xl p-6 space-y-4 text-right text-slate-200 animate-in zoom-in-95 my-6">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                  <Wrench className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">ثبت مصرف قطعه در کار</h3>
                  <p className="text-xs text-slate-400">مشخص کنید این قطعه برای کدوم کار (PM یا خدمات فنی) مصرف شده است</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRecordUsageModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitUsage} className="space-y-3.5 text-xs">
              {/* انتخاب قطعه */}
              <div>
                <label className="text-slate-300 font-bold block mb-1">قطعه یدکی مصرفی: *</label>
                <select
                  value={usageForm.partId}
                  onChange={e => {
                    const sel = partsList.find(p => p.id === e.target.value);
                    if (sel) {
                      setUsageForm({
                        ...usageForm,
                        partId: sel.id,
                        partCode: sel.code || sel.id,
                        partName: sel.name,
                        unit: sel.unit || 'عدد',
                        equipment: usageForm.equipment || sel.eqFamily || ''
                      });
                    }
                  }}
                  className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white outline-none cursor-pointer"
                >
                  {partsList.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.code ? `[${p.code}] ` : ''}{p.name} ({p.category})
                    </option>
                  ))}
                </select>
              </div>

              {/* نوع کار: نگهداری PM یا خدمات فنی (درخواست صریح کاربر) */}
              <div>
                <label className="text-slate-300 font-bold block mb-1.5">نوع کار و برنامه مصرف‌کننده: *</label>
                <div className="grid grid-cols-2 gap-3">
                  <label className={`p-3 rounded-2xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                    usageForm.workType === 'pm'
                      ? 'bg-purple-950/80 border-purple-500 text-white shadow-md shadow-purple-950/60'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}>
                    <input
                      type="radio"
                      name="workType"
                      checked={usageForm.workType === 'pm'}
                      onChange={() => setUsageForm({ ...usageForm, workType: 'pm' })}
                      className="accent-purple-500"
                    />
                    <div>
                      <strong className="block text-xs font-bold text-purple-300">🟣 نگهداری پیشگیرانه PM</strong>
                      <span className="text-[10px] text-slate-400">سرویس‌های دوره‌ای، روانکاری و تعمیرات PM</span>
                    </div>
                  </label>

                  <label className={`p-3 rounded-2xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                    usageForm.workType === 'technical'
                      ? 'bg-blue-950/80 border-blue-500 text-white shadow-md shadow-blue-950/60'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}>
                    <input
                      type="radio"
                      name="workType"
                      checked={usageForm.workType === 'technical'}
                      onChange={() => setUsageForm({ ...usageForm, workType: 'technical' })}
                      className="accent-blue-500"
                    />
                    <div>
                      <strong className="block text-xs font-bold text-blue-300">🔵 خدمات فنی</strong>
                      <span className="text-[10px] text-slate-400">دستورکارها، خرابی‌های اضطراری و تعمیرات</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* کد یا شماره دستورکار و شرح کار */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {usageForm.workType === 'pm' ? 'کد / برنامه PM:' : 'شماره دستورکار / درخواست کار:'}
                  </label>
                  <input
                    type="text"
                    value={usageForm.workCode}
                    onChange={e => setUsageForm({ ...usageForm, workCode: e.target.value })}
                    placeholder={usageForm.workType === 'pm' ? 'مثال: PM-102 یا سرویس هفتگی' : 'مثال: WO-204 یا REQ-108'}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">دستگاه / تجهیز و سالن:</label>
                  <input
                    type="text"
                    value={usageForm.equipment}
                    onChange={e => setUsageForm({ ...usageForm, equipment: e.target.value })}
                    placeholder="مثال: تراشکاری CNC • تورنوس TUTN01"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white outline-none"
                  />
                </div>
              </div>

              {/* شرح کار، تعداد و تاریخ */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="text-slate-300 font-bold block mb-1">تعداد مصرف: *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={usageForm.count}
                    onChange={e => setUsageForm({ ...usageForm, count: Math.max(1, parseInt(e.target.value, 10) || 1) })}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-mono text-center outline-none"
                  />
                </div>

                <div className="sm:col-span-1">
                  <label className="text-slate-300 font-bold block mb-1">تکنسین اقدام‌کننده:</label>
                  <select
                    value={usageForm.technician}
                    onChange={e => setUsageForm({ ...usageForm, technician: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-2.5 py-2 text-white outline-none cursor-pointer"
                  >
                    <option value="">--- انتخاب تکنسین ---</option>
                    {technicians.map((t, idx) => (
                      <option key={idx} value={t}>{t}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-1">
                  <label className="text-slate-300 font-bold block mb-1">تاریخ مصرف:</label>
                  <input
                    type="text"
                    value={usageForm.date}
                    onChange={e => setUsageForm({ ...usageForm, date: e.target.value })}
                    placeholder="۱۴۰۵/۰۸/۱۰"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white outline-none text-center font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">توضیحات اقدام / علت تعویض:</label>
                <input
                  type="text"
                  value={usageForm.notes}
                  onChange={e => setUsageForm({ ...usageForm, notes: e.target.value })}
                  placeholder="مثال: تعویض به علت لقی ساچمه و صدای غیرعادی اسپیندل"
                  className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRecordUsageModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold shadow-lg shadow-emerald-950/60 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>ثبت قطعی سابقه مصرف</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
