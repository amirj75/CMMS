import React, { useState, useMemo } from 'react';
import {
  BarChart2,
  TrendingUp,
  ShieldCheck,
  Users,
  Package,
  FileText,
  ClipboardList,
  Plus,
  Trash2,
  X,
  ArrowRight,
  Download,
  Search,
  Printer
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { ParetoReportModule } from './ParetoReportModule';
import { TechnicianWorkforceModule } from './TechnicianWorkforceModule';
import { EquipmentReliabilityModule } from './EquipmentReliabilityModule';
import { COMPANY_LOGO_WHITEBG } from '../data/auditImages';
import { usePrintSettings } from '../data/printSettings';

export type ReportTabKey =
  | 'pareto'
  | 'reliability'
  | 'workforce'
  | 'spareParts'
  | 'workRequests'
  | 'workOrders';

export type SourceCategoryKey = 'all' | 'workRequest' | 'techService' | 'pm';

interface WorkRequestReportsViewProps {
  onBack: () => void;
  systemTheme?: 'dark' | 'light';
  requestsList?: any[];
  onUpdateRequest?: (updatedReq: any) => void;
  onAddRequest?: (newReq: any) => void;
}

const CATEGORY_LABELS: Record<Exclude<SourceCategoryKey, 'all'>, string> = {
  workRequest: 'درخواست کار',
  techService: 'خدمات فنی',
  pm: 'پیشگیرانه (PM)'
};

const CATEGORY_BADGE_CLASSES: Record<Exclude<SourceCategoryKey, 'all'>, string> = {
  workRequest: 'bg-cyan-950/90 text-cyan-300 border border-cyan-500/40',
  techService: 'bg-blue-950/90 text-blue-300 border border-blue-500/40',
  pm: 'bg-purple-950/90 text-purple-300 border border-purple-500/40'
};

const WORK_REQUEST_PRIORITIES = new Set(['توقف تولید', 'توقف تجهیز', 'عدم توقف تجهیز']);
const WORK_REQUEST_TYPES = new Set(['اضطراری', 'اصلاحی', 'پیشگیرانه']);

function isWorkRequestShape(item: any): boolean {
  if (!item || typeof item !== 'object') return false;
  const src = String(item.source || item.originCategory || '').trim();
  if (src === 'workRequest' || item.fromWorkRequest === true) return true;
  if (String(item.id || '').startsWith('pwr-')) return true;
  const reqType = String(item.requestType || '').trim();
  if (WORK_REQUEST_TYPES.has(reqType)) return true;
  const prio = String(item.priority || '').trim();
  if (WORK_REQUEST_PRIORITIES.has(prio)) return true;
  if (item.equipmentCode || item.eqCode || item.equipmentFamilyName || item.failureTitle) return true;
  return false;
}

function resolveItemCategory(
  item: any,
  originHint?: Exclude<SourceCategoryKey, 'all'>,
  knownWrCodes?: Set<string>
): Exclude<SourceCategoryKey, 'all'> {
  if (!item) return originHint || 'techService';
  if (item._category && (item._category === 'workRequest' || item._category === 'techService' || item._category === 'pm')) {
    return item._category;
  }
  const code = String(item.code || item.id || '').trim().toUpperCase();
  const reqNum = String(item.reqNumber || item.code || '').trim().toUpperCase();
  const woCode = String(item.woCode || item.workOrderCode || item.woNumber || '').trim().toUpperCase();
  const reqType = String(item.requestType || '').trim();
  const opType = String(item.operationType || item.opType || '').trim();

  if (
    item.isPM === true ||
    item.pmGroupId ||
    item.pmPlanId ||
    item.isScheduledPM ||
    code.startsWith('PM-') ||
    code.startsWith('PMWR') ||
    woCode.startsWith('PM-') ||
    woCode.startsWith('PMWO') ||
    reqType === 'PM' ||
    opType.includes('(PM)') ||
    originHint === 'pm'
  ) {
    return 'pm';
  }
  if (
    originHint === 'workRequest' ||
    (knownWrCodes && ((code && knownWrCodes.has(code)) || (reqNum && knownWrCodes.has(reqNum)))) ||
    isWorkRequestShape(item)
  ) {
    return 'workRequest';
  }
  if (
    originHint === 'techService' ||
    reqType === 'خدمات فنی' ||
    String(item.department || '').includes('خدمات فنی')
  ) {
    return 'techService';
  }
  return 'techService';
}

export const WorkRequestReportsView: React.FC<WorkRequestReportsViewProps> = ({
  onBack,
  requestsList = [],
  onUpdateRequest,
  onAddRequest
}) => {
  const [activeTab, setActiveTab] = useState<ReportTabKey>('pareto');
  const printSettings = usePrintSettings();
  const [searchQuery, setSearchQuery] = useState('');
  const [wrCategoryFilter, setWrCategoryFilter] = useState<SourceCategoryKey>('all');
  const [woCategoryFilter, setWoCategoryFilter] = useState<SourceCategoryKey>('all');

  // استخراج یکپارچه کلیه درخواست کارها با تفکیک دقیق: درخواست کارها | خدمات فنی | پیشگیرانه (PM)
  const allRealWorkRequests = useMemo(() => {
    const map = new Map<string, any>();
    const knownWrCodes = new Set<string>();

    let savedWrList: any[] = [];
    try {
      const savedWr = localStorage.getItem('portal_pm_work_requests_v3');
      if (savedWr) {
        const parsed = JSON.parse(savedWr);
        if (Array.isArray(parsed)) savedWrList = parsed;
      }
    } catch {}

    const propList = Array.isArray(requestsList) ? requestsList : [];
    [...savedWrList, ...propList.filter(isWorkRequestShape)].forEach((item: any) => {
      const c = String(item?.code || item?.id || '').trim().toUpperCase();
      if (c) knownWrCodes.add(c);
    });

    const upsert = (item: any, originHint: Exclude<SourceCategoryKey, 'all'>) => {
      if (!item) return;
      const rawKey = String(item.code || item.id || `${originHint}-${map.size + 1}`).trim();
      const key = rawKey.toUpperCase();
      const _category = resolveItemCategory(item, originHint, knownWrCodes);
      if (!map.has(key)) {
        map.set(key, { ...item, _category });
      } else {
        const existing = map.get(key);
        const categoryPriority: Record<Exclude<SourceCategoryKey, 'all'>, number> = { pm: 3, workRequest: 2, techService: 1 };
        const mergedCategory =
          categoryPriority[_category] >= categoryPriority[existing._category as Exclude<SourceCategoryKey, 'all'>]
            ? _category
            : existing._category;
        map.set(key, {
          ...item,
          ...existing,
          _category: mergedCategory,
          workOrderCode: existing.workOrderCode || item.workOrderCode || existing.woCode || item.woCode,
          technician: existing.technician || item.technician,
          status: item.status === 'انجام شد' || item.status === 'completed' ? item.status : (existing.status || item.status),
          completedAt: existing.completedAt || item.completedAt,
          woStartTime: existing.woStartTime || item.woStartTime,
          woEndTime: existing.woEndTime || item.woEndTime,
          equipmentDowntimeMinutes: existing.equipmentDowntimeMinutes || item.equipmentDowntimeMinutes || existing.downtimeMinutes || item.downtimeMinutes,
          durationMinutes: existing.equipmentDowntimeMinutes || item.equipmentDowntimeMinutes || existing.durationMinutes || item.durationMinutes
        });
      }
    };

    // ۱. درخواست کارهای تجهیزات تولید (EM / CM / PM غیربرنامه‌ای)
    savedWrList.forEach((item: any) => upsert(item, 'workRequest'));
    propList.forEach((item: any) => upsert(item, isWorkRequestShape(item) ? 'workRequest' : 'techService'));

    // ۲. خدمات فنی (از localStorage؛ موارد همگام‌سازی‌شده از درخواست کار همچنان درخواست کار می‌مانند)
    try {
      const savedTs = localStorage.getItem('technicalServiceWorkRequests');
      if (savedTs) {
        const parsed = JSON.parse(savedTs);
        if (Array.isArray(parsed)) {
          parsed.forEach((item: any) => upsert(item, 'techService'));
        }
      }
    } catch {}

    // ۳. برنامه‌ریزی پیشگیرانه (PM)
    try {
      const savedPmWo = localStorage.getItem('pm_studio_work_orders_v15');
      if (savedPmWo) {
        const parsed = JSON.parse(savedPmWo);
        if (Array.isArray(parsed)) {
          parsed.forEach((item: any) => upsert(item, 'pm'));
        }
      }
      const savedAutoPm = localStorage.getItem('pm_studio_auto_work_orders_v1');
      if (savedAutoPm) {
        const parsed = JSON.parse(savedAutoPm);
        if (Array.isArray(parsed)) {
          parsed.forEach((item: any) => upsert(item, 'pm'));
        }
      }
    } catch {}

    return Array.from(map.values());
  }, [requestsList]);

  const wrCounts = useMemo(() => {
    const counts = { all: allRealWorkRequests.length, workRequest: 0, techService: 0, pm: 0 };
    allRealWorkRequests.forEach(r => {
      const cat = r._category as Exclude<SourceCategoryKey, 'all'>;
      if (counts[cat] !== undefined) counts[cat]++;
    });
    return counts;
  }, [allRealWorkRequests]);

  const filteredWorkRequestsList = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return allRealWorkRequests.filter(r => {
      if (wrCategoryFilter !== 'all' && r._category !== wrCategoryFilter) return false;
      if (!q) return true;
      const c = String(r.code || r.id || '').toLowerCase();
      const eq = String(r.equipmentName || r.eqName || r.place || r.equipment || '').toLowerCase();
      const eqC = String(r.equipmentCode || r.eqCode || '').toLowerCase();
      const f = String(r.failureTitle || r.title || '').toLowerCase();
      const d = String(r.description || r.actionDetails || '').toLowerCase();
      const t = String(r.technician || r.assignedTo || '').toLowerCase();
      return c.includes(q) || eq.includes(q) || eqC.includes(q) || f.includes(q) || d.includes(q) || t.includes(q);
    });
  }, [allRealWorkRequests, wrCategoryFilter, searchQuery]);

  // کلید ذخیره‌سازی داده‌های پارتو و لوازم یدکی در LocalStorage
  const storageKey = 'cmms_custom_reports_v2';

  const [reportsData, setReportsData] = useState<{
    pareto: Array<{ id: string; code: string; title: string; count: string; duration: string; percent: string }>;
    reliability: Array<{ id: string; eqCode: string; eqName: string; mtbf: string; mttr: string; availability: string; failureRate: string }>;
    workforce: Array<{ id: string; name: string; personnelCode: string; dept: string; tasksDone: string; totalHours: string; completionRate: string }>;
    spareParts: Array<{ id: string; partCode: string; partName: string; eqName: string; quantity: string; unit: string; date: string; woNumber: string }>;
    workOrders: Array<{ id: string; woNumber: string; reqNumber: string; technician: string; opType: string; date: string; durationMin: string; status: string }>;
  }>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      pareto: [],
      reliability: [],
      workforce: [],
      spareParts: [],
      workOrders: []
    };
  });

  // تجمیع خودکار کلیه دستور کارهای واقعی سیستم با تفکیک خدمات فنی - پیشگیرانه (PM) - درخواست کارها
  const allRealWorkOrders = useMemo(() => {
    const map = new Map<string, any>();
    const knownWrCodes = new Set<string>();

    let savedWrList: any[] = [];
    try {
      const savedWr = localStorage.getItem('portal_pm_work_requests_v3');
      if (savedWr) {
        const parsed = JSON.parse(savedWr);
        if (Array.isArray(parsed)) savedWrList = parsed;
      }
    } catch {}

    const propList = Array.isArray(requestsList) ? requestsList : [];
    [...savedWrList, ...propList.filter(isWorkRequestShape)].forEach((item: any) => {
      const c = String(item?.code || item?.id || '').trim().toUpperCase();
      if (c) knownWrCodes.add(c);
    });

    const normalizeWo = (item: any, originHint: Exclude<SourceCategoryKey, 'all'>) => {
      if (!item) return;
      const _category = resolveItemCategory(item, originHint, knownWrCodes);
      const reqNum = String(item.code || item.reqNumber || item.id || '—').trim();
      const explicitWo = String(item.woCode || item.workOrderCode || item.woNumber || '').trim();
      const woNum = String(
        explicitWo ||
        (String(item.id || '').startsWith('PM-') || String(item.id || '').startsWith('WO') ? item.id : '') ||
        (reqNum.startsWith('WR') ? reqNum.replace(/^WR/, 'WO') : `WO-${reqNum}`)
      ).trim();

      const normReq = reqNum && reqNum !== '—' ? reqNum.toUpperCase() : '';
      const normWo = woNum && woNum !== '—' ? woNum.toUpperCase() : '';
      const dedupKey = normReq ? `REQ:${normReq}` : `WO:${normWo}`;

      const isDone = item.status === 'انجام شد' || item.status === 'completed';
      const statusText = item.status === 'completed' ? 'انجام شد' : (item.status === 'pending' ? 'در حال اقدام' : (item.status || 'در حال اقدام'));
      const techList = [
        item.technician || item.assignedTo,
        ...(Array.isArray(item.coTechnicians) ? item.coTechnicians : []),
        ...(Array.isArray(item.assignedTechs) ? item.assignedTechs : []),
        ...(Array.isArray(item.woTechnicians) ? item.woTechnicians.map((t: any) => t?.name) : [])
      ]
        .map(v => String(v || '').trim())
        .filter(v => v && v !== 'در انتظار اعزام و ثبت مجریان');

      const nextRow = {
        id: dedupKey,
        woNumber: woNum,
        reqNumber: reqNum,
        _hasExplicitWo: Boolean(explicitWo),
        _category,
        equipment: item.equipmentName || item.eqName || item.equipment || item.place || item.category || '—',
        eqCode: item.equipmentCode || item.eqCode || '',
        title: item.failureTitle || item.title || '—',
        description: item.actionDetails || item.description || item.notes || '—',
        technician: Array.from(new Set(techList)).join('، ') || '—',
        opType: item.operationType || item.opType || item.requestType || CATEGORY_LABELS[_category],
        startTime: item.woStartTime || (item.woStartDate ? `${item.woStartDate} - ${item.woStartTimeOnly || ''}`.trim() : '') || item.requestTime || item.created || item.createdDate || item.date || '—',
        endTime: item.woEndTime || (item.woEndDate ? `${item.woEndDate} - ${item.woEndTimeOnly || ''}`.trim() : '') || item.completedAt || item.dueDate || (isDone ? 'تکمیل شده' : '—'),
        durationMin: item.equipmentDowntimeMinutes || item.downtimeMinutes || item.durationMinutes || item.durationMin || (item.estimatedHours ? Math.round(Number(item.estimatedHours) * 60) : '') || '—',
        status: statusText,
        isDone
      };

      if (!map.has(dedupKey)) {
        map.set(dedupKey, nextRow);
      } else {
        const existing = map.get(dedupKey);
        const categoryPriority: Record<Exclude<SourceCategoryKey, 'all'>, number> = { pm: 3, workRequest: 2, techService: 1 };
        const mergedCategory =
          categoryPriority[_category] >= categoryPriority[existing._category as Exclude<SourceCategoryKey, 'all'>]
            ? _category
            : existing._category;

        map.set(dedupKey, {
          ...existing,
          _category: mergedCategory,
          woNumber: !existing._hasExplicitWo && nextRow._hasExplicitWo ? nextRow.woNumber : existing.woNumber,
          _hasExplicitWo: existing._hasExplicitWo || nextRow._hasExplicitWo,
          equipment: existing.equipment !== '—' ? existing.equipment : nextRow.equipment,
          eqCode: existing.eqCode || nextRow.eqCode,
          title: existing.title !== '—' ? existing.title : nextRow.title,
          description: nextRow.description !== '—' && existing.description === '—' ? nextRow.description : existing.description,
          technician: existing.technician !== '—' ? existing.technician : nextRow.technician,
          opType: existing.opType || nextRow.opType,
          startTime: existing.startTime !== '—' ? existing.startTime : nextRow.startTime,
          endTime: (nextRow.isDone && !existing.isDone) || existing.endTime === '—' ? nextRow.endTime : existing.endTime,
          durationMin: existing.durationMin !== '—' ? existing.durationMin : nextRow.durationMin,
          status: nextRow.isDone ? nextRow.status : existing.status,
          isDone: existing.isDone || nextRow.isDone
        });
      }
    };

    savedWrList.forEach(item => normalizeWo(item, 'workRequest'));
    propList.forEach(item => normalizeWo(item, isWorkRequestShape(item) ? 'workRequest' : 'techService'));

    try {
      const savedTs = localStorage.getItem('technicalServiceWorkRequests');
      if (savedTs) {
        const parsed = JSON.parse(savedTs);
        if (Array.isArray(parsed)) parsed.forEach(item => normalizeWo(item, 'techService'));
      }
    } catch {}

    try {
      const savedPmWo = localStorage.getItem('pm_studio_work_orders_v15');
      if (savedPmWo) {
        const parsed = JSON.parse(savedPmWo);
        if (Array.isArray(parsed)) parsed.forEach(item => normalizeWo(item, 'pm'));
      }
      const savedAutoPm = localStorage.getItem('pm_studio_auto_work_orders_v1');
      if (savedAutoPm) {
        const parsed = JSON.parse(savedAutoPm);
        if (Array.isArray(parsed)) parsed.forEach(item => normalizeWo(item, 'pm'));
      }
    } catch {}

    (reportsData.workOrders || []).forEach(item => {
      normalizeWo(item, 'techService');
    });

    return Array.from(map.values());
  }, [requestsList, reportsData.workOrders]);

  const woCounts = useMemo(() => {
    const counts = { all: allRealWorkOrders.length, workRequest: 0, techService: 0, pm: 0 };
    allRealWorkOrders.forEach(r => {
      const cat = r._category as Exclude<SourceCategoryKey, 'all'>;
      if (counts[cat] !== undefined) counts[cat]++;
    });
    return counts;
  }, [allRealWorkOrders]);

  const filteredWorkOrdersList = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return allRealWorkOrders.filter(r => {
      if (woCategoryFilter !== 'all' && r._category !== woCategoryFilter) return false;
      if (!q) return true;
      return (
        String(r.woNumber || '').toLowerCase().includes(q) ||
        String(r.reqNumber || '').toLowerCase().includes(q) ||
        String(r.equipment || '').toLowerCase().includes(q) ||
        String(r.eqCode || '').toLowerCase().includes(q) ||
        String(r.title || '').toLowerCase().includes(q) ||
        String(r.description || '').toLowerCase().includes(q) ||
        String(r.technician || '').toLowerCase().includes(q) ||
        String(r.opType || '').toLowerCase().includes(q)
      );
    });
  }, [allRealWorkOrders, woCategoryFilter, searchQuery]);

  const saveReportsData = (newData: typeof reportsData) => {
    setReportsData(newData);
    try {
      localStorage.setItem(storageKey, JSON.stringify(newData));
    } catch {}
  };

  // مودال افزودن سطر جدید (فقط برای پارتو و لوازم یدکی)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [modalFormData, setModalFormData] = useState<Record<string, string>>({});

  const handleOpenAddModal = () => {
    setModalFormData({});
    setIsAddModalOpen(true);
  };

  const handleSaveModalForm = () => {
    const id = Date.now().toString();
    const copy = { ...reportsData };

    if (activeTab === 'pareto') {
      copy.pareto = [
        ...copy.pareto,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          count: modalFormData.count || '1',
          duration: modalFormData.duration || '60',
          percent: modalFormData.percent || '10'
        }
      ];
    } else if (activeTab === 'spareParts') {
      copy.spareParts = [
        ...copy.spareParts,
        {
          id,
          partCode: modalFormData.partCode || '',
          partName: modalFormData.partName || '',
          eqName: modalFormData.eqName || '',
          quantity: modalFormData.quantity || '1',
          unit: modalFormData.unit || 'عدد',
          date: modalFormData.date || '',
          woNumber: modalFormData.woNumber || ''
        }
      ];
    }

    saveReportsData(copy);
    setIsAddModalOpen(false);
  };

  const handleDeleteItem = (tab: 'pareto' | 'spareParts', itemId: string) => {
    const copy = { ...reportsData };
    if (tab === 'pareto') copy.pareto = copy.pareto.filter(i => i.id !== itemId);
    if (tab === 'spareParts') copy.spareParts = copy.spareParts.filter(i => i.id !== itemId);
    saveReportsData(copy);
  };

  // اجرای مطمئن پرینت با window.open و iframe پشتیبان
  const executeDirectHtmlPrint = (htmlContent: string, iframeId: string) => {
    let winOpened = false;
    try {
      const printWin = window.open('', '_blank', 'width=1050,height=800,top=40,left=40');
      if (printWin) {
        winOpened = true;
        printWin.document.open();
        printWin.document.write(htmlContent);
        printWin.document.close();
        printWin.focus();
      }
    } catch {}

    if (!winOpened) {
      try {
        let iframe = document.getElementById(iframeId) as HTMLIFrameElement | null;
        if (iframe) iframe.remove();
        iframe = document.createElement('iframe');
        iframe.id = iframeId;
        iframe.style.position = 'fixed';
        iframe.style.top = '-9999px';
        iframe.style.left = '-9999px';
        document.body.appendChild(iframe);
        const fDoc = iframe.contentWindow?.document;
        if (fDoc) {
          fDoc.open();
          fDoc.write(htmlContent);
          fDoc.close();
          setTimeout(() => {
            iframe?.contentWindow?.focus();
            iframe?.contentWindow?.print();
          }, 400);
        }
      } catch {
        window.print();
      }
    }
  };

  // چاپ مستقیم لیست درخواست کارها با تفکیک دسته و لوگوی رسمی
  const handlePrintWorkRequests = () => {
    const filterTitle = wrCategoryFilter === 'all' ? 'همه بخش‌ها' : CATEGORY_LABELS[wrCategoryFilter];
    const wrListCfg = printSettings.workRequestsListReport;
    const printContent = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head>
        <meta charset="utf-8" />
        <title>${wrListCfg.docTitle} - ${filterTitle} (${wrListCfg.docCode})</title>
        <style>
          @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-FD.woff2') format('woff2'); font-weight: 100 400; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
          @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-Bold-FD.woff2') format('woff2'); font-weight: 500 900; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
          @page { size: A4 landscape; margin: 8mm; }
          body { font-family: 'PersianDigits', Tahoma, 'Vazirmatn', system-ui, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 12px; }
          * { box-sizing: border-box; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 10.5px; }
          th, td { border: 1px solid #475569; padding: 6px 8px; text-align: right; }
          th { background: #f1f5f9; font-weight: bold; }
          .no-print { display: none !important; }
          @media print { .no-print { display: none !important; } body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 12px; text-align: left;">
          <button id="directPrintBtn" style="background:#2563eb; color:#ffffff; border:none; padding:8px 20px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px;">ارسال مستقیم به چاپگر (Print)</button>
          <button onclick="window.close()" style="background:#64748b; color:#ffffff; border:none; padding:8px 14px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px; margin-right:6px;">بستن</button>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 14px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <img src="${COMPANY_LOGO_WHITEBG}" alt="لوگو" style="height: 50px; width: auto; object-fit: contain;" />
            <div>
              <h2 style="margin: 0 0 3px 0; font-size: 15px; font-weight: bold; color: #0f172a;">${wrListCfg.docTitle} (${filterTitle})</h2>
              <div style="font-size: 11px; color: #475569;">سامانه نگهداری، تعمیرات و خدمات فنی</div>
            </div>
          </div>
          <div style="text-align: left; font-family: monospace; font-size: 11px; color: #334155;">
            <div>کد سند: <strong>${wrListCfg.docCode}</strong></div>
            <div>تعداد کل: <strong>${filteredWorkRequestsList.length}</strong> مورد</div>
            <div>تاریخ چاپ: ${new Date().toLocaleDateString('fa-IR')}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 36px; text-align: center;">ردیف</th>
              <th style="width: 90px;">شماره درخواست</th>
              <th style="width: 85px; text-align: center;">دسته</th>
              <th style="width: 80px;">کد تجهیز</th>
              <th style="width: 120px;">نام تجهیز / محل</th>
              <th>عنوان عیب / شرح</th>
              <th style="width: 105px;">شروع</th>
              <th style="width: 105px;">پایان</th>
              <th style="width: 75px; text-align: center;">اولویت</th>
              <th>توضیحات</th>
              <th style="width: 80px; text-align: center;">وضعیت</th>
            </tr>
          </thead>
          <tbody>
            ${filteredWorkRequestsList.map((r, i) => `
              <tr>
                <td style="text-align: center; font-family: monospace;">${i + 1}</td>
                <td style="font-family: monospace; font-weight: bold; color: #1e40af;">${r.code || r.id || '—'}</td>
                <td style="text-align: center; font-weight: bold;">${CATEGORY_LABELS[r._category as Exclude<SourceCategoryKey, 'all'>] || '—'}</td>
                <td style="font-family: monospace;">${r.equipmentCode || r.eqCode || '—'}</td>
                <td style="font-weight: bold;">${r.equipmentName || r.eqName || r.place || r.equipment || '—'}</td>
                <td>${r.failureTitle || r.title || '—'}</td>
                <td style="font-family: monospace; font-size: 10px;">${r.requestTime || r.created || r.woStartTime || '—'}</td>
                <td style="font-family: monospace; font-size: 10px;">${r.completedAt || r.woEndTime || (r.status === 'انجام شد' ? 'تکمیل' : '—')}</td>
                <td style="text-align: center; font-weight: bold;">${r.priority || 'عادی'}</td>
                <td style="color: #334155;">${r.description || r.actionDetails || '—'}</td>
                <td style="text-align: center; font-weight: bold;">${r.status || 'در حال اقدام'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <script>
          const btn = document.getElementById('directPrintBtn');
          if (btn) btn.addEventListener('click', function() { window.print(); });
          window.focus();
          setTimeout(function() { window.print(); }, 350);
        </script>
      </body>
      </html>
    `;
    executeDirectHtmlPrint(printContent, 'workrequests-print-iframe');
  };

  // چاپ مستقیم لیست دستور کارها با تفکیک دسته و لوگوی رسمی
  const handlePrintWorkOrders = () => {
    const filterTitle = woCategoryFilter === 'all' ? 'همه بخش‌ها' : CATEGORY_LABELS[woCategoryFilter];
    const woListCfg = printSettings.workOrdersListReport;
    const printContent = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head>
        <meta charset="utf-8" />
        <title>${woListCfg.docTitle} - ${filterTitle} (${woListCfg.docCode})</title>
        <style>
          @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-FD.woff2') format('woff2'); font-weight: 100 400; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
          @font-face { font-family: 'PersianDigits'; src: url('/fonts/Shabnam-Bold-FD.woff2') format('woff2'); font-weight: 500 900; font-display: swap; unicode-range: U+06F0-06F9, U+0660-066C; }
          @page { size: A4 landscape; margin: 8mm; }
          body { font-family: 'PersianDigits', Tahoma, 'Vazirmatn', system-ui, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 12px; }
          * { box-sizing: border-box; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 10.5px; }
          th, td { border: 1px solid #475569; padding: 6px 8px; text-align: right; }
          th { background: #f1f5f9; font-weight: bold; }
          .no-print { display: none !important; }
          @media print { .no-print { display: none !important; } body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 12px; text-align: left;">
          <button id="directPrintBtn" style="background:#2563eb; color:#ffffff; border:none; padding:8px 20px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px;">ارسال مستقیم به چاپگر (Print)</button>
          <button onclick="window.close()" style="background:#64748b; color:#ffffff; border:none; padding:8px 14px; border-radius:8px; font-weight:bold; cursor:pointer; font-family:tahoma,sans-serif; font-size:12px; margin-right:6px;">بستن</button>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 14px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <img src="${COMPANY_LOGO_WHITEBG}" alt="لوگو" style="height: 50px; width: auto; object-fit: contain;" />
            <div>
              <h2 style="margin: 0 0 3px 0; font-size: 15px; font-weight: bold; color: #0f172a;">${woListCfg.docTitle} (${filterTitle})</h2>
              <div style="font-size: 11px; color: #475569;">سامانه نگهداری، تعمیرات و خدمات فنی</div>
            </div>
          </div>
          <div style="text-align: left; font-family: monospace; font-size: 11px; color: #334155;">
            <div>کد سند: <strong>${woListCfg.docCode}</strong></div>
            <div>تعداد کل: <strong>${filteredWorkOrdersList.length}</strong> دستور کار</div>
            <div>تاریخ چاپ: ${new Date().toLocaleDateString('fa-IR')}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 36px; text-align: center;">ردیف</th>
              <th style="width: 90px;">شماره دستور کار</th>
              <th style="width: 90px;">شماره درخواست</th>
              <th style="width: 85px; text-align: center;">دسته</th>
              <th style="width: 120px;">تجهیز / محل</th>
              <th>عنوان و شرح عملیات</th>
              <th style="width: 110px;">تکنسین مجری</th>
              <th style="width: 100px;">تاریخ و ساعت شروع</th>
              <th style="width: 100px;">تاریخ و ساعت پایان</th>
              <th style="width: 65px; text-align: center;">مدت (دقیقه)</th>
              <th style="width: 80px; text-align: center;">وضعیت</th>
            </tr>
          </thead>
          <tbody>
            ${filteredWorkOrdersList.map((r, i) => `
              <tr>
                <td style="text-align: center; font-family: monospace;">${i + 1}</td>
                <td style="font-family: monospace; font-weight: bold; color: #1e40af;">${r.woNumber || '—'}</td>
                <td style="font-family: monospace;">${r.reqNumber || '—'}</td>
                <td style="text-align: center; font-weight: bold;">${CATEGORY_LABELS[r._category as Exclude<SourceCategoryKey, 'all'>] || '—'}</td>
                <td style="font-weight: bold;">${r.eqCode ? `${r.eqCode} - ` : ''}${r.equipment || '—'}</td>
                <td>${r.title !== '—' ? r.title : r.description}${r.description && r.description !== '—' && r.title !== '—' ? ` — ${r.description}` : ''}</td>
                <td>${r.technician || '—'}</td>
                <td style="font-family: monospace; font-size: 10px;">${r.startTime || '—'}</td>
                <td style="font-family: monospace; font-size: 10px;">${r.endTime || '—'}</td>
                <td style="text-align: center; font-family: monospace;">${r.durationMin || '—'}</td>
                <td style="text-align: center; font-weight: bold;">${r.status || 'در حال اقدام'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <script>
          const btn = document.getElementById('directPrintBtn');
          if (btn) btn.addEventListener('click', function() { window.print(); });
          window.focus();
          setTimeout(function() { window.print(); }, 350);
        </script>
      </body>
      </html>
    `;
    executeDirectHtmlPrint(printContent, 'workorders-print-iframe');
  };

  // خروجی اکسل برای تمامی تب‌ها
  const handleExportExcel = () => {
    let rows: any[] = [];
    let fileName = 'report.xlsx';

    if (activeTab === 'pareto') {
      fileName = 'گزارش_پارتو.xlsx';
      rows = reportsData.pareto.map(r => ({
        'کد تجهیز / توقف': r.code,
        'شرح علت خرابی': r.title,
        'فراوانی (تعداد)': r.count,
        'مدت زمان توقف': r.duration,
        'درصد تجمعی': r.percent
      }));
    } else if (activeTab === 'spareParts') {
      fileName = 'لوازم_یدکی_مصرفی.xlsx';
      rows = reportsData.spareParts.map(r => ({
        'کد قطعه': r.partCode,
        'نام قطعه یدکی': r.partName,
        'تجهیز مرتبط': r.eqName,
        'تعداد مصرفی': r.quantity,
        'واحد': r.unit,
        'تاریخ مصرف': r.date,
        'شماره دستور کار': r.woNumber
      }));
    } else if (activeTab === 'workRequests') {
      fileName = 'لیست_درخواست_کارها.xlsx';
      rows = filteredWorkRequestsList.map((r, idx) => ({
        'ردیف': idx + 1,
        'شماره درخواست': r.code || r.id || '—',
        'دسته': CATEGORY_LABELS[r._category as Exclude<SourceCategoryKey, 'all'>] || '—',
        'کد دستگاه': r.equipmentCode || r.eqCode || '—',
        'نام دستگاه / محل': r.equipmentName || r.eqName || r.place || r.equipment || '—',
        'عنوان عیب / خرابی': r.failureTitle || r.title || '—',
        'تاریخ و ساعت شروع': r.requestTime || r.created || r.woStartTime || '—',
        'تاریخ و ساعت پایان': r.completedAt || r.woEndTime || (r.status === 'انجام شد' ? 'تکمیل شده' : '—'),
        'اولویت': r.priority || 'عادی',
        'توضیحات و شرح درخواست': r.description || r.actionDetails || '—',
        'وضعیت': r.status || 'در حال اقدام',
        'تکنسین مسئول': r.technician || '—'
      }));
    } else if (activeTab === 'workOrders') {
      fileName = 'لیست_دستور_کارها.xlsx';
      rows = filteredWorkOrdersList.map((r, idx) => ({
        'ردیف': idx + 1,
        'شماره دستور کار': r.woNumber,
        'شماره درخواست': r.reqNumber,
        'دسته': CATEGORY_LABELS[r._category as Exclude<SourceCategoryKey, 'all'>] || '—',
        'تجهیز / محل': r.eqCode ? `${r.eqCode} - ${r.equipment}` : r.equipment,
        'شرح عملیات': r.title !== '—' ? r.title : r.description,
        'توضیحات اقدام': r.description,
        'تکنسین مجری': r.technician,
        'نوع عملیات': r.opType,
        'تاریخ و ساعت شروع': r.startTime,
        'تاریخ و ساعت پایان': r.endTime,
        'مدت زمان (دقیقه)': r.durationMin,
        'وضعیت': r.status
      }));
    }

    if (rows.length === 0) {
      return;
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'گزارش');
    XLSX.writeFile(wb, fileName);
  };

  const tabsList: Array<{ id: ReportTabKey; label: string; icon: any }> = [
    { id: 'pareto', label: 'گزارش پارتو', icon: TrendingUp },
    { id: 'reliability', label: 'قابلیت اطمینان تجهیز', icon: ShieldCheck },
    { id: 'workforce', label: 'عملکرد نیروی انسانی', icon: Users },
    { id: 'workRequests', label: 'لیست درخواست کارها', icon: FileText },
    { id: 'spareParts', label: 'لوازم یدکی', icon: Package },
    { id: 'workOrders', label: 'لیست دستور کارها', icon: ClipboardList }
  ];

  const renderCategorySegmentedControl = (
    active: SourceCategoryKey,
    onChange: (next: SourceCategoryKey) => void,
    counts: { all: number; workRequest: number; techService: number; pm: number }
  ) => (
    <div className="flex flex-wrap items-center gap-1.5 bg-[#070e22] p-1 rounded-xl border border-indigo-500/30 text-[11px]">
      <button
        type="button"
        onClick={() => onChange('all')}
        className={`px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
          active === 'all' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
        }`}
      >
        همه ({counts.all})
      </button>
      <button
        type="button"
        onClick={() => onChange('workRequest')}
        className={`px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
          active === 'workRequest' ? 'bg-cyan-600 text-white shadow-sm' : 'text-cyan-300/80 hover:text-white hover:bg-cyan-950/50'
        }`}
      >
        درخواست کارها ({counts.workRequest})
      </button>
      <button
        type="button"
        onClick={() => onChange('techService')}
        className={`px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
          active === 'techService' ? 'bg-blue-600 text-white shadow-sm' : 'text-blue-300/80 hover:text-white hover:bg-blue-950/50'
        }`}
      >
        خدمات فنی ({counts.techService})
      </button>
      <button
        type="button"
        onClick={() => onChange('pm')}
        className={`px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
          active === 'pm' ? 'bg-purple-600 text-white shadow-sm' : 'text-purple-300/80 hover:text-white hover:bg-purple-950/50'
        }`}
      >
        پیشگیرانه ({counts.pm})
      </button>
    </div>
  );

  return (
    <div className="w-full bg-[#0c162e]/90 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl overflow-hidden select-text text-right font-sans space-y-0">

      {/* سربرگ گزارش‌ها */}
      <div className="p-4 sm:p-5 border-b border-indigo-900/40 flex flex-col sm:flex-row justify-between sm:items-center gap-4 bg-[#070e22]/60">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <BarChart2 size={22} />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white">
              گزارش‌ها و تحلیل‌های فنی مهندسی
            </h2>
            <p className="text-xs text-slate-400">
              شاخص‌های آماری، عملکرد ماشین‌آلات و ثبت وقایع نت
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {activeTab !== 'pareto' && activeTab !== 'reliability' && activeTab !== 'workforce' && (
            <button
              type="button"
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-600/30 text-xs font-bold transition-all cursor-pointer"
            >
              <Download size={14} />
              <span>خروجی اکسل (Excel)</span>
            </button>
          )}

          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#0c162e] border border-indigo-500/30 text-slate-300 hover:text-white hover:border-cyan-400 text-xs font-bold transition-all cursor-pointer"
          >
            <ArrowRight size={14} />
            <span>بازگشت به کارتابل</span>
          </button>
        </div>
      </div>

      {/* نوار تب‌های ۶ گانه گزارش بدون شلوغ شدن منو */}
      <div className="flex items-center gap-1.5 p-2 bg-[#070e22]/90 border-b border-indigo-900/30 overflow-x-auto">
        {tabsList.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveTab(tab.id);
                setSearchQuery('');
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Icon size={14} />
              <span>{tab.label}</span>
              {tab.id === 'workRequests' && (
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-slate-900/80 text-cyan-300 border border-cyan-500/30">
                  {allRealWorkRequests.length}
                </span>
              )}
              {tab.id === 'workOrders' && (
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-slate-900/80 text-cyan-300 border border-cyan-500/30">
                  {allRealWorkOrders.length}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* محتوای رندر هر تب */}
      {activeTab === 'pareto' ? (
        <div className="p-4 sm:p-5">
          <ParetoReportModule requestsList={allRealWorkRequests} />
        </div>
      ) : activeTab === 'reliability' ? (
        <div className="p-4 sm:p-5">
          <EquipmentReliabilityModule requestsList={requestsList} />
        </div>
      ) : activeTab === 'workforce' ? (
        <div className="p-4 sm:p-5">
          <TechnicianWorkforceModule
            requestsList={requestsList}
            onUpdateRequest={onUpdateRequest}
            onAddRequest={onAddRequest}
          />
        </div>
      ) : activeTab === 'workRequests' ? (
        <div className="p-4 sm:p-5 space-y-4">
          <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 flex-1">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="جستجو در کد، تجهیز، شرح یا تکنسین..."
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                />
              </div>
              {renderCategorySegmentedControl(wrCategoryFilter, setWrCategoryFilter, wrCounts)}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handlePrintWorkRequests}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                <Printer size={14} />
                <span>چاپ و پرینت لیست</span>
              </button>

              <button
                type="button"
                onClick={handleExportExcel}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                <Download size={14} />
                <span>ذخیره اکسل (XLSX)</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">شماره درخواست</th>
                  <th className="p-3 text-center">دسته</th>
                  <th className="p-3">کد دستگاه</th>
                  <th className="p-3">نام دستگاه / محل</th>
                  <th className="p-3">عنوان عیب / خرابی</th>
                  <th className="p-3">تاریخ و ساعت شروع</th>
                  <th className="p-3">تاریخ و ساعت پایان</th>
                  <th className="p-3 text-center">اولویت</th>
                  <th className="p-3">توضیحات و شرح درخواست</th>
                  <th className="p-3 text-center">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {filteredWorkRequestsList.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-8 text-center text-slate-500">
                      هیچ درخواست کاری در این بخش یافت نشد.
                    </td>
                  </tr>
                ) : (
                  filteredWorkRequestsList.map((req: any, idx: number) => {
                    const isDone = req.status === 'انجام شد' || req.status === 'completed';
                    const cat = (req._category || 'techService') as Exclude<SourceCategoryKey, 'all'>;
                    const prio = req.priority || 'عادی';
                    let prioColor = 'bg-slate-800 text-slate-300';
                    if (prio.includes('توقف') || prio.includes('فوری') || prio.includes('بحرانی')) {
                      prioColor = 'bg-red-950/80 text-red-300 border border-red-800/40';
                    } else if (prio.includes('اضطراری') || prio.includes('بالا')) {
                      prioColor = 'bg-amber-950/80 text-amber-300 border border-amber-800/40';
                    } else if (prio.includes('پیشگیرانه')) {
                      prioColor = 'bg-teal-950/80 text-teal-300 border border-teal-800/40';
                    }

                    return (
                      <tr key={req.code || req.id || idx} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3 font-mono font-bold text-cyan-300">{req.code || req.id || `WR-${idx + 1}`}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold whitespace-nowrap ${CATEGORY_BADGE_CLASSES[cat]}`}>
                            {CATEGORY_LABELS[cat]}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-purple-300">{req.equipmentCode || req.eqCode || '—'}</td>
                        <td className="p-3 font-bold text-white max-w-[150px] truncate">{req.equipmentName || req.eqName || req.place || req.equipment || '—'}</td>
                        <td className="p-3 text-slate-200 font-medium max-w-[180px] truncate">{req.failureTitle || req.title || '—'}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">{req.woStartTime || req.requestTime || req.created || '—'}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">{req.woEndTime || req.completedAt || (isDone ? 'تکمیل شده' : '—')}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${prioColor}`}>
                            {prio}
                          </span>
                        </td>
                        <td className="p-3 text-slate-300 max-w-xs text-[11px] leading-relaxed">
                          {req.description || req.actionDetails || '—'}
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isDone
                              ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/40'
                              : req.status === 'لغو' || req.status === 'لغو شده'
                              ? 'bg-rose-950/90 text-rose-300 border border-rose-500/40'
                              : 'bg-cyan-950/90 text-cyan-300 border border-cyan-500/40'
                          }`}>
                            {req.status === 'completed' ? 'انجام شد' : (req.status || 'در انتظار دستور برنامه ریزی')}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === 'workOrders' ? (
        <div className="p-4 sm:p-5 space-y-4">
          <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 flex-1">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="جستجو در دستور کار، تجهیز، عملیات یا تکنسین..."
                  className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                />
              </div>
              {renderCategorySegmentedControl(woCategoryFilter, setWoCategoryFilter, woCounts)}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handlePrintWorkOrders}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                <Printer size={14} />
                <span>چاپ و پرینت لیست</span>
              </button>

              <button
                type="button"
                onClick={handleExportExcel}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                <Download size={14} />
                <span>ذخیره اکسل (XLSX)</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                  <th className="p-3">شماره دستور کار</th>
                  <th className="p-3">شماره درخواست</th>
                  <th className="p-3 text-center">دسته</th>
                  <th className="p-3">تجهیز / محل</th>
                  <th className="p-3">عنوان و شرح عملیات</th>
                  <th className="p-3">تکنسین مجری</th>
                  <th className="p-3">تاریخ و ساعت شروع</th>
                  <th className="p-3">تاریخ و ساعت پایان</th>
                  <th className="p-3 text-center">مدت (دقیقه)</th>
                  <th className="p-3 text-center">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333538]/50">
                {filteredWorkOrdersList.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-8 text-center text-slate-500">
                      هیچ دستور کاری در این بخش یافت نشد.
                    </td>
                  </tr>
                ) : (
                  filteredWorkOrdersList.map((item: any) => {
                    const cat = (item._category || 'techService') as Exclude<SourceCategoryKey, 'all'>;
                    return (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3 font-mono font-bold text-cyan-300">{item.woNumber || '—'}</td>
                        <td className="p-3 font-mono text-slate-400">{item.reqNumber || '—'}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold whitespace-nowrap ${CATEGORY_BADGE_CLASSES[cat]}`}>
                            {CATEGORY_LABELS[cat]}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-white max-w-[150px] truncate">
                          {item.eqCode ? <span className="font-mono text-purple-300 ml-1">{item.eqCode}</span> : null}
                          {item.equipment}
                        </td>
                        <td className="p-3 text-slate-200 max-w-xs text-[11px] leading-relaxed">
                          <div className="font-semibold text-white truncate">{item.title}</div>
                          {item.description && item.description !== '—' && (
                            <div className="text-slate-400 truncate">{item.description}</div>
                          )}
                        </td>
                        <td className="p-3 text-slate-200 font-medium">{item.technician || '—'}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">{item.startTime || '—'}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">{item.endTime || '—'}</td>
                        <td className="p-3 text-center font-mono text-amber-300">{item.durationMin || '—'}</td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.isDone
                              ? 'bg-emerald-950/90 border border-emerald-500/40 text-emerald-300'
                              : item.status === 'لغو' || item.status === 'لغو شده'
                              ? 'bg-rose-950/90 border border-rose-500/40 text-rose-300'
                              : 'bg-cyan-950/90 border border-cyan-500/40 text-cyan-300'
                          }`}>
                            {item.status || 'در انتظار دستور برنامه ریزی'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <>
          {/* نوار فیلتر و افزودن برای تب لوازم یدکی */}
          <div className="p-4 sm:p-5 border-b border-indigo-900/30 flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 bg-[#070e22]/30">
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="جستجو در این جدول..."
                className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl pr-8 pl-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
              />
            </div>

            <button
              type="button"
              onClick={handleOpenAddModal}
              className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer shrink-0"
            >
              <Plus size={15} />
              <span>ثبت مصرف لوازم یدکی</span>
            </button>
          </div>

          <div className="p-4 sm:p-5">
            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد قطعه</th>
                    <th className="p-3.5">نام قطعه یدکی</th>
                    <th className="p-3.5">تجهیز مرتبط</th>
                    <th className="p-3.5 text-center">تعداد مصرفی</th>
                    <th className="p-3.5 text-center">واحد</th>
                    <th className="p-3.5 text-center">تاریخ مصرف</th>
                    <th className="p-3.5 text-center">شماره دستورکار</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {reportsData.spareParts
                    .filter(r => !searchQuery || (r.partCode + r.partName).toLowerCase().includes(searchQuery.toLowerCase()))
                    .length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    reportsData.spareParts
                      .filter(r => !searchQuery || (r.partCode + r.partName).toLowerCase().includes(searchQuery.toLowerCase()))
                      .map(item => (
                        <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                          <td className="p-3.5 font-mono font-bold text-cyan-300">{item.partCode || '—'}</td>
                          <td className="p-3.5 font-bold text-white">{item.partName || '—'}</td>
                          <td className="p-3.5 text-slate-300">{item.eqName || '—'}</td>
                          <td className="p-3.5 text-center font-mono text-purple-300">{item.quantity || '—'}</td>
                          <td className="p-3.5 text-center text-slate-400">{item.unit || 'عدد'}</td>
                          <td className="p-3.5 text-center font-mono text-slate-400">{item.date || '—'}</td>
                          <td className="p-3.5 text-center font-mono text-amber-300">{item.woNumber || '—'}</td>
                          <td className="p-3.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleDeleteItem('spareParts', item.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                            >
                              <Trash2 size={14} />
                            </button>
                          </td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* مودال فرم ثبت مصرف لوازم یدکی */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#0c162e] border border-indigo-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center pb-3 border-b border-indigo-900/40">
              <h3 className="text-sm font-bold text-white">
                ثبت رکورد جدید در {tabsList.find(t => t.id === activeTab)?.label}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {activeTab === 'spareParts' && (
                <>
                  <div>
                    <label className="block text-slate-400 mb-1">کد قطعه</label>
                    <input
                      type="text"
                      placeholder="مثال: SP-102"
                      value={modalFormData.partCode || ''}
                      onChange={e => setModalFormData({ ...modalFormData, partCode: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">نام قطعه یدکی</label>
                    <input
                      type="text"
                      placeholder="مثال: بلبرینگ ۶۲۰۴ دور بالا"
                      value={modalFormData.partName || ''}
                      onChange={e => setModalFormData({ ...modalFormData, partName: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">تجهیز مرتبط</label>
                    <input
                      type="text"
                      placeholder="مثال: فرز هارتفورد"
                      value={modalFormData.eqName || ''}
                      onChange={e => setModalFormData({ ...modalFormData, eqName: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-400 mb-1">تعداد</label>
                      <input
                        type="number"
                        placeholder="1"
                        value={modalFormData.quantity || ''}
                        onChange={e => setModalFormData({ ...modalFormData, quantity: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">واحد</label>
                      <input
                        type="text"
                        placeholder="عدد / لیتر"
                        value={modalFormData.unit || ''}
                        onChange={e => setModalFormData({ ...modalFormData, unit: e.target.value })}
                        className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2 text-white"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveModalForm}
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-md"
              >
                ذخیره سطر
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
