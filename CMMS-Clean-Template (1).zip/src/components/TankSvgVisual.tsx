import React from 'react';
import { OilTank } from '../data/portalData';

export function TankSvgVisual({ tank, index }: { tank: OilTank; index: number }) {
  const p = Math.max(0, Math.min(100, (tank.currentLiters / tank.capacityLiters) * 100));
  const y = 302 - p * 2.05;
  const u = `gtank_${tank.id || index}`;
  const color = tank.colorClass && tank.colorClass.startsWith('#') ? tank.colorClass : '#d88b12';
  const pctRounded = Math.round(p);
  const formattedLit = Number(tank.currentLiters).toLocaleString('en-US').replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  const formattedPct = String(pctRounded).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);

  return (
    <svg className="w-full h-full max-w-[320px] drop-shadow-xl" viewBox="0 0 250 340">
      <defs>
        <linearGradient id={`${u}m`}>
          <stop stopColor="#4b5964" />
          <stop offset="0.2" stopColor="#e4ebef" />
          <stop offset="0.38" stopColor="#65727d" />
          <stop offset="0.58" stopColor="#f5f8fa" />
          <stop offset="0.78" stopColor="#65727d" />
          <stop offset="1" stopColor="#26323b" />
        </linearGradient>
        <linearGradient id={`${u}l`} x2="0" y2="1">
          <stop stopColor={color} />
          <stop offset="1" stopColor={color} stopOpacity="0.85" />
        </linearGradient>
        <clipPath id={`${u}c`}>
          <rect x="47" y="85" width="156" height="218" rx="29" />
        </clipPath>
      </defs>
      <ellipse cx="125" cy="313" rx="91" ry="12" fill="#000" opacity="0.45" />
      <path d="M63 92Q63 62 91 51h68q28 11 28 41l14 10v190q0 21-20 21H69q-20 0-20-21V102Z" fill={`url(#${u}m)`} stroke="#b9c5cc" strokeWidth="2" />
      <rect x="47" y="85" width="156" height="218" rx="29" fill="#07131d" stroke="#d0d9df" strokeWidth="3" />
      <g clipPath={`url(#${u}c)`}>
        <rect x="47" y={y} width="156" height={Math.max(0, 303 - y)} fill={`url(#${u}l)`} />
        <path d={`M35 ${y}Q65 ${y-9} 95 ${y}T155 ${y}T215 ${y}`} fill="none" stroke={color} strokeWidth="5">
          <animate attributeName="d" dur="3s" repeatCount="indefinite" values={`M35 ${y}Q65 ${y-9} 95 ${y}T155 ${y}T215 ${y};M35 ${y}Q65 ${y+8} 95 ${y}T155 ${y+8}T215 ${y};M35 ${y}Q65 ${y-9} 95 ${y}T155 ${y}T215 ${y}`} />
        </path>
      </g>
      {/* نشانگر کپسولی مقدار و درصد داخل مخزن مطابق عکس مرجع */}
      <rect x="66" y="286" width="118" height="22" rx="11" fill="#0c1219" stroke="#333f4d" strokeWidth="1.5" />
      <text x="125" y="301" textAnchor="middle" fill="#ffffff" fontSize="10.5" fontWeight="bold" fontFamily="PersianDigits, Vazirmatn, Tahoma, sans-serif">
        {formattedLit} لیتر — ٪{formattedPct}
      </text>

      <ellipse cx="125" cy="51" rx="34" ry="10" fill="#9aa6ae" stroke="#e4eaee" strokeWidth="2" />
      <rect x="99" y="34" width="52" height="17" rx="7" fill={`url(#${u}m)`} stroke="#d9e0e5" strokeWidth="2" />
      <path d="M78 85V66L62 55" fill="none" stroke="#bcc7cd" strokeWidth="6" />
      <circle cx="61" cy="54" r="5" fill="#7c8992" />
      <path d="M202 105h17v180h-17M219 110h12M219 145h8M219 180h12M219 215h8M219 250h12M219 285h12" fill="none" stroke="#d2d9de" strokeWidth="2" />
      <path d="M48 246H34v18h14" fill="none" stroke="#aebac2" strokeWidth="4" />
      <circle cx="29" cy="264" r="7" fill={color} />
    </svg>
  );
}
