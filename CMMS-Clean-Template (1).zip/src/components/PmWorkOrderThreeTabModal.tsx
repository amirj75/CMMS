import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle,
  Box,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Clock,
  Package,
  Plus,
  Printer,
  Search,
  Timer,
  Trash2,
  Users,
  Wrench,
  X,
  Zap
} from 'lucide-react';
import TimeInput24 from './TimeInput24';
import { OSVEH_LOGO_WHITEBG_URL } from '../data/auditImages';
import {
  computeMinutesBetweenShamsiDateTimes,
  extractShamsiDateAndTime,
  formatMinutesDurationFa
} from '../data/dateTimeUtils';
import {
  DEFAULT_PRESET_CONSUMABLES,
  getUnifiedSpareParts,
  WorkOrderConsumableItem
} from '../data/sparePartsData';
import { usePrintSettings } from '../data/printSettings';
import {
  addShamsiDaysPm,
  getGroupFamilyMaintenanceActivities,
  getTodayShamsiDateStringPm,
  isItemArchivedCheck,
  PM_AUTO_GROUP_META,
  resolveGroupEquipmentsList
} from '../data/pmAutoWorkOrders';
import type { PmWorkRequestItem, WoActivityEntry, WoDelayEntry, WoTechnicianEntry, WoWorkDayEntry } from './WorkRequestModule';

interface PmWorkOrderThreeTabModalProps {
  isOpen: boolean;
  targetOrder: PmWorkRequestItem | null;
  familyList: any[];
  equipmentList: any[];
  technicians: string[];
  onClose: () => void;
  onSaveOrder: (updatedOrder: PmWorkRequestItem) => void;
  onQuickUpdateOrder?: (updatedOrder: PmWorkRequestItem) => void;
}

const normalizeFaText = (val: string) =>
  String(val || '')
    .replace(/ي/g, 'ی')
    .replace(/ى/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\u200c/g, '')
    .trim()
    .toLowerCase();

const compactFaText = (val: string) =>
  normalizeFaText(val).replace(/[\s_\-–—()（）/\\]+/g, '');

const tokenKeyFaText = (val: string) =>
  normalizeFaText(val)
    .split(/[\s_\-–—()（）/\\]+/)
    .filter(Boolean)
    .sort()
    .join('|');

const calcTechRowHours = (sDate: string, sTime: string, eDate: string, eTime: string, fallbackHours = 1): number => {
  const mins = computeMinutesBetweenShamsiDateTimes(sDate, sTime, eDate, eTime);
  if (mins > 0) return Math.round((mins / 60) * 100) / 100;
  return fallbackHours;
};

const escHtml = (val: unknown): string =>
  String(val ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

export const PmWorkOrderThreeTabModal: React.FC<PmWorkOrderThreeTabModalProps> = ({
  isOpen,
  targetOrder,
  familyList,
  equipmentList,
  technicians,
  onClose,
  onSaveOrder,
  onQuickUpdateOrder
}) => {
  const printSettings = usePrintSettings();
  const [woModalPage, setWoModalPage] = useState<1 | 2 | 3>(1);
  const [woValidationError, setWoValidationError] = useState<string | null>(null);
  const [woActivityRangeEdited, setWoActivityRangeEdited] = useState(false);
  const [woActivitySearch, setWoActivitySearch] = useState('');
  const [isWoActivityDropdownOpen, setIsWoActivityDropdownOpen] = useState(false);
  const [familyDataVersion, setFamilyDataVersion] = useState(0);
  const woActivityDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onAssetUpdated = () => setFamilyDataVersion(v => v + 1);
    window.addEventListener('asset_class_data_updated', onAssetUpdated as EventListener);
    return () => window.removeEventListener('asset_class_data_updated', onAssetUpdated as EventListener);
  }, []);

  const [isEquipSectionOpen, setIsEquipSectionOpen] = useState(false);
  const [selectedEquipmentIds, setSelectedEquipmentIds] = useState<string[]>([]);
  const [equipSavedHint, setEquipSavedHint] = useState(false);

  const [woConsumableTab, setWoConsumableTab] = useState<'برقی' | 'مکانیکی' | 'سایر'>('مکانیکی');
  const [woShowPresetsBar, setWoShowPresetsBar] = useState(false);
  const [isWoSparePartsOpen, setIsWoSparePartsOpen] = useState(false);
  const [isWoDelaysOpen, setIsWoDelaysOpen] = useState(false);
  const [woNewPartName, setWoNewPartName] = useState('');
  const [woNewPartCount, setWoNewPartCount] = useState(1);
  const [woNewPartUnit, setWoNewPartUnit] = useState('عدد');

  const [woForm, setWoForm] = useState<{
    woCode: string;
    status: string;
    woStartDate: string;
    woStartTime: string;
    woEndDate: string;
    woEndTime: string;
    workDays: WoWorkDayEntry[];
    activities: WoActivityEntry[];
    technicians: WoTechnicianEntry[];
    consumables: WorkOrderConsumableItem[];
    delays: WoDelayEntry[];
    notes: string;
  }>({
    woCode: '',
    status: 'در انتظار دستور برنامه ریزی',
    woStartDate: '',
    woStartTime: '08:00',
    woEndDate: '',
    woEndTime: '16:00',
    workDays: [],
    activities: [],
    technicians: [],
    consumables: [],
    delays: [],
    notes: ''
  });

  useEffect(() => {
    if (!isOpen || !targetOrder) return;
    const todayStr = getTodayShamsiDateStringPm();
    const now = new Date();
    const nowTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const resolveDefaultWoCode = () => {
      if (targetOrder.woCode) return targetOrder.woCode;
      if (targetOrder.workOrderCode) return targetOrder.workOrderCode;
      const c = String(targetOrder.code || '').trim();
      if (/^PMWR/i.test(c)) return c.replace(/^PMWR/i, 'PMWO');
      if (/^(PMWO|WO)/i.test(c)) return c;
      if (/^WR/i.test(c)) return c.replace(/^WR/i, 'WO');
      return c || 'PMWO0001';
    };

    const parsedStart = extractShamsiDateAndTime(
      targetOrder.woStartDate ? `${targetOrder.woStartDate} ${targetOrder.woStartTimeOnly || ''}` : (targetOrder.woStartTime || targetOrder.requestTime),
      todayStr,
      '08:00'
    );
    const parsedEnd = extractShamsiDateAndTime(
      targetOrder.woEndDate ? `${targetOrder.woEndDate} ${targetOrder.woEndTimeOnly || ''}` : (targetOrder.woEndTime || targetOrder.completedAt),
      todayStr,
      nowTimeStr
    );

    const initialTechs: WoTechnicianEntry[] =
      Array.isArray(targetOrder.woTechnicians) && targetOrder.woTechnicians.length > 0
        ? targetOrder.woTechnicians.map((t: any, idx: number) => {
            const sDate = t.startDate || t.date || parsedStart.date || todayStr;
            const eDate = t.endDate || t.startDate || t.date || parsedEnd.date || todayStr;
            const sTime = t.startTime || '08:00';
            const eTime = t.endTime || '09:00';
            const computedHrs = calcTechRowHours(sDate, sTime, eDate, eTime, Number(t.hours) || 1);
            return {
              id: t.id || `wt-${Date.now()}-${idx}`,
              name: t.name || '',
              startDate: sDate,
              startTime: sTime,
              endDate: eDate,
              endTime: eTime,
              hours: t.customHours && Number(t.hours) > 0 ? Number(t.hours) : (t.startTime && t.endTime ? computedHrs : (Number(t.hours) || computedHrs)),
              customStartDate: Boolean(t.customStartDate),
              customStartTime: Boolean(t.customStartTime),
              customEndDate: Boolean(t.customEndDate),
              customEndTime: Boolean(t.customEndTime),
              customHours: Boolean(t.customHours)
            };
          })
        : targetOrder.technician
        ? [
            {
              id: `wt-${Date.now()}-0`,
              name: targetOrder.technician,
              startDate: parsedStart.date,
              startTime: parsedStart.time,
              endDate: parsedEnd.date,
              endTime: parsedEnd.time,
              hours: targetOrder.durationMinutes
                ? Math.round((targetOrder.durationMinutes / 60) * 100) / 100
                : calcTechRowHours(parsedStart.date, parsedStart.time, parsedEnd.date, parsedEnd.time, 1)
            },
            ...(Array.isArray(targetOrder.coTechnicians)
              ? targetOrder.coTechnicians.map((co, idx) => ({
                  id: `wt-${Date.now()}-${idx + 1}`,
                  name: co,
                  startDate: parsedStart.date,
                  startTime: parsedStart.time,
                  endDate: parsedEnd.date,
                  endTime: parsedEnd.time,
                  hours: calcTechRowHours(parsedStart.date, parsedStart.time, parsedEnd.date, parsedEnd.time, 1)
                }))
              : [])
          ]
        : [];

    setWoModalPage(1);
    setIsEquipSectionOpen(false);
    setEquipSavedHint(false);
    setWoActivitySearch('');
    setIsWoActivityDropdownOpen(false);
    setWoConsumableTab('مکانیکی');
    setWoShowPresetsBar(false);
    setIsWoSparePartsOpen(false);
    setIsWoDelaysOpen(false);
    setWoNewPartName('');
    setWoNewPartCount(1);
    setWoNewPartUnit('عدد');
    setWoValidationError(null);
    setWoActivityRangeEdited(Boolean(targetOrder.woStartDate || targetOrder.woEndDate));
    const initStartDate = targetOrder.woStartDate || parsedStart.date;
    const initStartTime = targetOrder.woStartTimeOnly || parsedStart.time;
    const initEndDate = targetOrder.woEndDate || parsedEnd.date;
    const initEndTime = targetOrder.woEndTimeOnly || parsedEnd.time;
    const initialWorkDays: WoWorkDayEntry[] =
      Array.isArray(targetOrder.woWorkDays) && targetOrder.woWorkDays.length > 0
        ? targetOrder.woWorkDays.map((wd, idx) => ({
            id: wd.id || `wd-${Date.now()}-${idx + 1}`,
            startDate: wd.startDate || initStartDate,
            startTime: wd.startTime || initStartTime,
            endDate: wd.endDate || initEndDate,
            endTime: wd.endTime || initEndTime
          }))
        : [
            {
              id: `wd-${Date.now()}-1`,
              startDate: initStartDate,
              startTime: initStartTime,
              endDate: initEndDate,
              endTime: initEndTime
            }
          ];

    setWoForm({
      woCode: resolveDefaultWoCode(),
      status: targetOrder.status === 'لغو شده' ? 'لغو' : (targetOrder.status === 'در حال اقدام' ? 'در انتظار دستور برنامه ریزی' : (targetOrder.status || 'در انتظار دستور برنامه ریزی')),
      woStartDate: initialWorkDays[0].startDate,
      woStartTime: initialWorkDays[0].startTime,
      woEndDate: initialWorkDays[initialWorkDays.length - 1].endDate,
      woEndTime: initialWorkDays[initialWorkDays.length - 1].endTime,
      workDays: initialWorkDays,
      activities: Array.isArray(targetOrder.woActivities) ? targetOrder.woActivities : [],
      technicians: initialTechs,
      consumables: Array.isArray(targetOrder.consumables) ? targetOrder.consumables : [],
      delays: Array.isArray(targetOrder.woDelays) ? targetOrder.woDelays : [],
      notes: targetOrder.woNotes || ''
    });
  }, [isOpen, targetOrder?.id]);

  const candidateEquipments = useMemo(() => {
    if (!targetOrder) return [] as Array<{ id: string; name: string; location?: string; family?: string }>;
    const map = new Map<string, { id: string; name: string; location?: string; family?: string }>();

    const addEq = (e: any) => {
      const id = String(e?.id || '').trim();
      if (!id) return;
      if (!map.has(id)) {
        map.set(id, {
          id,
          name: String(e?.name || id),
          location: String(e?.location || ''),
          family: String(e?.family || '')
        });
      }
    };

    if (Array.isArray(targetOrder.pmCandidateEquipments) && targetOrder.pmCandidateEquipments.length > 0) {
      targetOrder.pmCandidateEquipments.forEach(addEq);
    }

    if (targetOrder.pmGroupId) {
      let assignedMap: Record<string, string[]> = {};
      try {
        const raw = localStorage.getItem('pm_studio_group_assigned_eq_v3');
        if (raw) assignedMap = JSON.parse(raw) || {};
      } catch {}
      const groupEqs = resolveGroupEquipmentsList(targetOrder.pmGroupId, equipmentList || [], assignedMap);
      groupEqs.forEach(addEq);
    }

    if (map.size === 0 && targetOrder.equipmentCode) {
      const matched = (equipmentList || []).find(e => String(e?.id || '').toUpperCase() === String(targetOrder.equipmentCode).toUpperCase());
      if (matched) addEq(matched);
      else addEq({ id: targetOrder.equipmentCode, name: targetOrder.equipmentName || targetOrder.equipmentCode, location: targetOrder.locationName || '' });
    }

    return Array.from(map.values());
  }, [targetOrder, equipmentList, isOpen]);

  useEffect(() => {
    if (!isOpen || !targetOrder) return;
    if (Array.isArray(targetOrder.pmSelectedEquipmentIds)) {
      setSelectedEquipmentIds(targetOrder.pmSelectedEquipmentIds);
    } else {
      setSelectedEquipmentIds(candidateEquipments.map(e => e.id));
    }
  }, [isOpen, targetOrder?.id, candidateEquipments]);

  useEffect(() => {
    const handleOutside = (ev: MouseEvent) => {
      if (woActivityDropdownRef.current && !woActivityDropdownRef.current.contains(ev.target as Node)) {
        setIsWoActivityDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const combinedTechnicians = useMemo(() => {
    const set = new Set<string>();
    const addName = (raw: any) => {
      const clean = String(raw || '').trim();
      if (clean) set.add(clean);
    };
    if (Array.isArray(technicians)) technicians.forEach(addName);
    try {
      const tsSaved = localStorage.getItem('technicalServiceTechnicians');
      if (tsSaved) {
        const parsed = JSON.parse(tsSaved);
        if (Array.isArray(parsed)) parsed.forEach(addName);
      }
    } catch {}
    try {
      let deletedNames: string[] = [];
      const delRaw = localStorage.getItem('pm_studio_deleted_techs_v2');
      if (delRaw) {
        const parsedDel = JSON.parse(delRaw);
        if (Array.isArray(parsedDel)) deletedNames = parsedDel;
      }
      const pmSaved = localStorage.getItem('pm_studio_techs_v5');
      if (pmSaved) {
        const parsedPm = JSON.parse(pmSaved);
        if (Array.isArray(parsedPm)) {
          parsedPm.forEach((t: any) => {
            const name = typeof t === 'string' ? t : t?.name;
            if (name && !deletedNames.includes(name)) addName(name);
          });
        }
      }
    } catch {}
    return Array.from(set);
  }, [technicians, isOpen]);

  const woFamilyMaintenanceActivities = useMemo(() => {
    void familyDataVersion;
    if (!targetOrder) return [] as Array<{ id: string; code: string; title: string; familyName?: string; familyId?: string }>;
    const seen = new Set<string>();
    const results: Array<{ id: string; code: string; title: string; familyName?: string; familyId?: string }> = [];

    if (targetOrder.pmGroupId) {
      let assignedMap: Record<string, string[]> = {};
      try {
        const raw = localStorage.getItem('pm_studio_group_assigned_eq_v3');
        if (raw) assignedMap = JSON.parse(raw) || {};
      } catch {}
      const grpActs = getGroupFamilyMaintenanceActivities(
        targetOrder.pmGroupId,
        familyList,
        equipmentList,
        assignedMap
      );
      grpActs.forEach(ga => {
        const key = `${normalizeFaText(ga.code)}||${normalizeFaText(ga.title)}`;
        if (seen.has(key)) return;
        seen.add(key);
        results.push({
          id: ga.id,
          code: ga.code,
          title: ga.title,
          familyName: ga.familyName,
          familyId: ga.familyId
        });
      });
    }

    const famCode = (targetOrder.equipmentFamilyCode || '').trim();
    const famName = (targetOrder.equipmentFamilyName || '').trim();
    const eqCode = (targetOrder.equipmentCode || '').trim();
    const famNameCompact = compactFaText(famName);
    const famNameTokens = tokenKeyFaText(famName);
    const matchedIds: string[] = [];
    const addId = (id: string) => {
      if (id && !matchedIds.includes(id)) matchedIds.push(id);
    };

    if (famCode) {
      const byCode = familyList.find(f => (f.id || '').toLowerCase() === famCode.toLowerCase());
      addId(byCode ? byCode.id : famCode);
    }
    if (famNameCompact) {
      familyList.forEach(f => {
        if (compactFaText(f.name || '') === famNameCompact || (famNameTokens && tokenKeyFaText(f.name || '') === famNameTokens)) {
          addId(f.id);
        }
      });
    }
    if (matchedIds.length === 0 && eqCode) {
      const matchedEq = equipmentList.find(eq => (eq.id || '').toLowerCase() === eqCode.toLowerCase());
      if (matchedEq?.family) {
        const eqFamC = compactFaText(matchedEq.family);
        const eqFamT = tokenKeyFaText(matchedEq.family);
        familyList.forEach(f => {
          if (compactFaText(f.name || '') === eqFamC || (eqFamT && tokenKeyFaText(f.name || '') === eqFamT)) {
            addId(f.id);
          }
        });
      }
    }

    matchedIds.forEach(fId => {
      try {
        const raw = localStorage.getItem(`pmworks_asset_class_data_${fId}`);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        const famObj = familyList.find(f => f.id === fId);
        if (Array.isArray(parsed?.maintenance)) {
          parsed.maintenance.forEach((m: any, idx: number) => {
            const title = String(m?.title || '').trim();
            const code = String(m?.code || '').trim();
            if (!title) return;
            const key = `${normalizeFaText(code)}||${normalizeFaText(title)}`;
            if (seen.has(key)) return;
            seen.add(key);
            results.push({
              id: m?.id || `${fId}-act-${idx}`,
              code,
              title,
              familyName: famObj?.name || fId,
              familyId: fId
            });
          });
        }
      } catch {}
    });

    return results;
  }, [targetOrder, familyList, equipmentList, isOpen, familyDataVersion]);

  const filteredWoFamilyActivities = useMemo(() => {
    const q = normalizeFaText(woActivitySearch);
    if (!q) return woFamilyMaintenanceActivities;
    return woFamilyMaintenanceActivities.filter(a =>
      normalizeFaText(a.title).includes(q) ||
      normalizeFaText(a.code).includes(q) ||
      normalizeFaText(a.familyName || '').includes(q)
    );
  }, [woFamilyMaintenanceActivities, woActivitySearch]);

  const unifiedInventoryParts = useMemo(() => {
    try {
      return getUnifiedSpareParts();
    } catch {
      return [];
    }
  }, [isOpen]);

  if (!isOpen || !targetOrder) return null;

  const isWoReadOnly = isItemArchivedCheck(targetOrder);

  const handleAddWoWorkDay = () => {
    if (isWoReadOnly) return;
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      const currentDays: WoWorkDayEntry[] =
        prev.workDays.length > 0
          ? prev.workDays
          : [
              {
                id: `wd-${Date.now()}-1`,
                startDate: prev.woStartDate || getTodayShamsiDateStringPm(),
                startTime: prev.woStartTime || '08:00',
                endDate: prev.woEndDate || getTodayShamsiDateStringPm(),
                endTime: prev.woEndTime || '16:00'
              }
            ];
      const last = currentDays[currentDays.length - 1];
      const nextDate = addShamsiDaysPm(last.endDate || last.startDate || getTodayShamsiDateStringPm(), 1);
      const nextDays: WoWorkDayEntry[] = [
        ...currentDays,
        {
          id: `wd-${Date.now()}-${currentDays.length + 1}`,
          startDate: nextDate,
          startTime: last.startTime || '08:00',
          endDate: nextDate,
          endTime: last.endTime || '16:00'
        }
      ];
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleUpdateWoWorkDay = (
    wdId: string,
    field: 'startDate' | 'startTime' | 'endDate' | 'endTime',
    value: string
  ) => {
    if (isWoReadOnly) return;
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      const baseDays: WoWorkDayEntry[] =
        prev.workDays.length > 0
          ? prev.workDays
          : [
              {
                id: wdId,
                startDate: prev.woStartDate || getTodayShamsiDateStringPm(),
                startTime: prev.woStartTime || '08:00',
                endDate: prev.woEndDate || getTodayShamsiDateStringPm(),
                endTime: prev.woEndTime || '16:00'
              }
            ];
      const nextDays = baseDays.map(d => (d.id === wdId ? { ...d, [field]: value } : d));
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleRemoveWoWorkDay = (wdId: string) => {
    if (isWoReadOnly) return;
    setWoActivityRangeEdited(true);
    setWoForm(prev => {
      if (prev.workDays.length <= 1) return prev;
      const nextDays = prev.workDays.filter(d => d.id !== wdId);
      return {
        ...prev,
        workDays: nextDays,
        woStartDate: nextDays[0].startDate,
        woStartTime: nextDays[0].startTime,
        woEndDate: nextDays[nextDays.length - 1].endDate,
        woEndTime: nextDays[nextDays.length - 1].endTime
      };
    });
  };

  const handleAddWoActivity = (act: { id: string; code: string; title: string }) => {
    setWoForm(prev => ({
      ...prev,
      activities: [
        ...prev.activities,
        {
          id: `woa-${Date.now()}-${prev.activities.length + 1}`,
          code: act.code,
          title: act.title,
          startDate: prev.woStartDate || getTodayShamsiDateStringPm(),
          startTime: prev.woStartTime || '08:00',
          endDate: prev.woEndDate || getTodayShamsiDateStringPm(),
          endTime: prev.woEndTime || '16:00'
        }
      ]
    }));
    setIsWoActivityDropdownOpen(false);
    setWoActivitySearch('');
    setWoValidationError(null);
  };

  const handleAddWoTechnician = (presetName = '') => {
    const todayStr = getTodayShamsiDateStringPm();
    const firstTech = woForm.technicians[0];
    const baseStartDate = firstTech?.startDate || woForm.woStartDate || todayStr;
    const baseStartTime = firstTech?.startTime || woForm.woStartTime || '08:00';
    const baseEndDate = firstTech?.endDate || woForm.woEndDate || todayStr;
    const baseEndTime = firstTech?.endTime || woForm.woEndTime || '16:00';
    const baseHours = calcTechRowHours(baseStartDate, baseStartTime, baseEndDate, baseEndTime, firstTech?.hours || 1);

    setWoForm(prev => ({
      ...prev,
      technicians: [
        ...prev.technicians,
        {
          id: `wt-${Date.now()}-${prev.technicians.length + 1}`,
          name: presetName,
          startDate: baseStartDate,
          startTime: baseStartTime,
          endDate: baseEndDate,
          endTime: baseEndTime,
          hours: baseHours
        }
      ]
    }));
  };

  const handleAddWoConsumablePreset = (name: string, category: 'برقی' | 'مکانیکی' | 'سایر') => {
    setWoForm(prev => {
      const existing = prev.consumables.find(c => c.name === name && c.category === category);
      if (existing) {
        return {
          ...prev,
          consumables: prev.consumables.map(c => c.id === existing.id ? { ...c, count: c.count + 1 } : c)
        };
      }
      return {
        ...prev,
        consumables: [...prev.consumables, { id: `wc-${Date.now()}-${Math.random()}`, name, count: 1, unit: 'عدد', category }]
      };
    });
  };

  const handleAddWoCustomConsumable = () => {
    const trimmed = woNewPartName.trim();
    if (!trimmed) return;
    setWoForm(prev => ({
      ...prev,
      consumables: [
        ...prev.consumables,
        {
          id: `wc-${Date.now()}-${Math.random()}`,
          name: trimmed,
          count: Math.max(1, woNewPartCount || 1),
          unit: woNewPartUnit || 'عدد',
          category: woConsumableTab
        }
      ]
    }));
    setWoNewPartName('');
    setWoNewPartCount(1);
  };

  const handleAddWoDelay = () => {
    setWoForm(prev => ({
      ...prev,
      delays: [...prev.delays, { id: `wod-${Date.now()}-${prev.delays.length + 1}`, code: '', title: '', days: 0, hours: 0 }]
    }));
  };

  const handleSave = (overrideStatus?: string) => {
    if (isWoReadOnly) return;
    const rawStatus = overrideStatus || woForm.status || 'در انتظار دستور برنامه ریزی';
    const finalStatus = rawStatus === 'انجام شده' ? 'انجام شد' : (rawStatus === 'لغو شده' ? 'لغو' : rawStatus);

    if (finalStatus === 'انجام شد' && woForm.activities.length === 0) {
      setWoValidationError('برای تغییر وضعیت دستور کار به «انجام شده»، ثبت حداقل یک فعالیت نگه‌داشت در تب «فعالیت» الزامی است.');
      setWoModalPage(3);
      return;
    }
    setWoValidationError(null);

    const validTechs = woForm.technicians
      .filter(t => t.name && t.name.trim())
      .map(t => {
        const calcMins = computeMinutesBetweenShamsiDateTimes(t.startDate, t.startTime, t.endDate, t.endTime);
        const effHours = !t.customHours && calcMins > 0 ? Math.round((calcMins / 60) * 100) / 100 : (Number(t.hours) || 0);
        return { ...t, hours: effHours };
      });

    const uniqueTechNames = Array.from(new Set(validTechs.map(t => t.name.trim())));
    const primaryTech = uniqueTechNames[0] || undefined;
    const coTechs = uniqueTechNames.slice(1);
    const totalTechHours = validTechs.reduce((sum, t) => sum + Math.max(0, Number(t.hours) || 0), 0);
    const techDurationMinutes = totalTechHours > 0 ? Math.round(totalTechHours * 60) : 0;

    const equipmentDowntimeMinutes = computeMinutesBetweenShamsiDateTimes(
      woForm.woStartDate,
      woForm.woStartTime,
      woForm.woEndDate,
      woForm.woEndTime
    );
    const durationMinutes = equipmentDowntimeMinutes > 0
      ? equipmentDowntimeMinutes
      : (techDurationMinutes > 0 ? techDurationMinutes : targetOrder.durationMinutes);

    const woStartTime = `${woForm.woStartDate || ''} - ${woForm.woStartTime || ''}`.trim();
    const woEndTime = `${woForm.woEndDate || ''} - ${woForm.woEndTime || ''}`.trim();

    const partsUsedText = woForm.consumables
      .map(c => `${c.name} (${c.count} ${c.unit || 'عدد'})`)
      .join('، ');

    const normalizedActivities: WoActivityEntry[] = woForm.activities.map(a => ({
      ...a,
      startDate: woForm.woStartDate || a.startDate,
      startTime: woForm.woStartTime || a.startTime,
      endDate: woForm.woEndDate || a.endDate,
      endTime: woForm.woEndTime || a.endTime
    }));

    const resolvedWoCode = woForm.woCode.trim() || targetOrder.woCode || targetOrder.workOrderCode || String(targetOrder.code || '').replace(/^PMWR/i, 'PMWO');

    const buildUpdatedEquipmentSummary = (nextSelectedIds: string[]) => {
      const grpMeta = PM_AUTO_GROUP_META.find(g => g.id === targetOrder.pmGroupId);
      const grpName = targetOrder.pmGroupName || grpMeta?.name || targetOrder.equipmentFamilyName || 'تجهیزات';
      const selectedEqObjs = candidateEquipments.filter(e => nextSelectedIds.includes(e.id));
      const primaryEq = selectedEqObjs[0];
      const nextEqCode = primaryEq?.id || targetOrder.equipmentCode;
      const nextEqName =
        selectedEqObjs.length === 0
          ? `${grpName} (بدون تجهیز انتخاب‌شده)`
          : selectedEqObjs.length === 1
          ? primaryEq.name
          : `${grpName} (${selectedEqObjs.length} تجهیز: ${selectedEqObjs.slice(0, 3).map(e => e.id).join('، ')}${selectedEqObjs.length > 3 ? ' ...' : ''})`;
      return { nextEqCode, nextEqName, selectedEqObjs };
    };

    const { nextEqCode, nextEqName } = buildUpdatedEquipmentSummary(selectedEquipmentIds);

    const updatedItem: PmWorkRequestItem = {
      ...targetOrder,
      woCode: resolvedWoCode,
      workOrderCode: resolvedWoCode,
      equipmentCode: nextEqCode,
      equipmentName: nextEqName,
      pmCandidateEquipments: candidateEquipments,
      pmSelectedEquipmentIds: selectedEquipmentIds,
      status: finalStatus,
      technician: primaryTech,
      coTechnicians: coTechs.length > 0 ? coTechs : undefined,
      durationMinutes,
      equipmentDowntimeMinutes,
      downtimeMinutes: equipmentDowntimeMinutes,
      woStartDate: woForm.woStartDate,
      woStartTimeOnly: woForm.woStartTime,
      woEndDate: woForm.woEndDate,
      woEndTimeOnly: woForm.woEndTime,
      woStartTime,
      woEndTime,
      completedAt: finalStatus === 'انجام شد' ? (woEndTime || getTodayShamsiDateStringPm()) : targetOrder.completedAt,
      woWorkDays: woForm.workDays,
      woActivities: normalizedActivities,
      woTechnicians: validTechs,
      consumables: woForm.consumables,
      partsUsed: partsUsedText || undefined,
      woDelays: woForm.delays,
      woNotes: woForm.notes.trim() || undefined,
      isArchivedWorkOrder: finalStatus === 'انجام شد' || finalStatus === 'لغو'
    };

    onSaveOrder(updatedItem);
  };

  const handleToggleEquipmentSelection = (eqId: string) => {
    if (isWoReadOnly) return;
    const nextSelectedIds = selectedEquipmentIds.includes(eqId)
      ? selectedEquipmentIds.filter(id => id !== eqId)
      : [...selectedEquipmentIds, eqId];
    applyEquipmentSelectionUpdate(nextSelectedIds);
  };

  const applyEquipmentSelectionUpdate = (nextSelectedIds: string[]) => {
    if (isWoReadOnly || !targetOrder) return;
    setSelectedEquipmentIds(nextSelectedIds);
    const grpMeta = PM_AUTO_GROUP_META.find(g => g.id === targetOrder.pmGroupId);
    const grpName = targetOrder.pmGroupName || grpMeta?.name || targetOrder.equipmentFamilyName || 'تجهیزات';
    const selectedEqObjs = candidateEquipments.filter(e => nextSelectedIds.includes(e.id));
    const primaryEq = selectedEqObjs[0];
    const nextEqCode = primaryEq?.id || targetOrder.equipmentCode;
    const nextEqName =
      selectedEqObjs.length === 0
        ? `${grpName} (بدون تجهیز انتخاب‌شده)`
        : selectedEqObjs.length === 1
        ? primaryEq.name
        : `${grpName} (${selectedEqObjs.length} تجهیز: ${selectedEqObjs.slice(0, 3).map(e => e.id).join('، ')}${selectedEqObjs.length > 3 ? ' ...' : ''})`;

    if (onQuickUpdateOrder) {
      onQuickUpdateOrder({
        ...targetOrder,
        equipmentCode: nextEqCode,
        equipmentName: nextEqName,
        pmCandidateEquipments: candidateEquipments,
        pmSelectedEquipmentIds: nextSelectedIds
      });
      setEquipSavedHint(true);
      setTimeout(() => setEquipSavedHint(false), 2000);
    }
  };

  const triggerPrintOrder = () => {
    const woNum = targetOrder.woCode || targetOrder.workOrderCode || woForm.woCode;
    const printCfg = printSettings.workOrderClosedA4;
    const activities = Array.isArray(woForm.activities) ? woForm.activities : [];
    const techRows = woForm.technicians;
    const parts = woForm.consumables;
    const delays = woForm.delays;
    const isDone = woForm.status === 'انجام شد' || woForm.status === 'انجام شده';
    const selectedEqListForPrint = candidateEquipments.filter(e => selectedEquipmentIds.includes(e.id));
    const html = `<!DOCTYPE html>
<html dir="rtl" lang="fa"><head><meta charset="utf-8" /><title>${escHtml(printCfg.docTitle)} - ${escHtml(woNum)}</title>
<style>
  @page { size: A4 portrait; margin: 10mm; }
  body { font-family: Tahoma, Arial, sans-serif; color: #0f172a; margin: 0; padding: 12px; font-size: 11px; }
  .box { border: 1.5px solid #0f172a; border-radius: 6px; padding: 12px; }
  .hdr { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; }
  th, td { border: 1px solid #334155; padding: 5px 6px; text-align: right; }
  th { background: #f1f5f9; }
</style></head>
<body><div class="box">
  <div class="hdr">
    <img src="${escHtml(OSVEH_LOGO_WHITEBG_URL)}" style="height:44px" />
    <div style="text-align:center"><h2 style="margin:0;font-size:15px">${escHtml(printCfg.docTitle)}</h2><div>کد سند: ${escHtml(printCfg.docCode)}</div></div>
    <div style="text-align:left;font-family:monospace"><div>دستور کار: <b>${escHtml(woNum)}</b></div><div>درخواست PM: <b>${escHtml(targetOrder.code)}</b></div></div>
  </div>
  <table>
    <tr><th>تجهیز</th><td>${escHtml(targetOrder.equipmentName)} (${escHtml(targetOrder.equipmentCode)})</td><th>مکان</th><td>${escHtml(targetOrder.locationName)}</td></tr>
    <tr><th>خانواده تجهیز</th><td>${escHtml(targetOrder.equipmentFamilyName)}</td><th>وضعیت</th><td>${escHtml(isDone ? 'انجام شده' : woForm.status)}</td></tr>
    <tr><th>شروع</th><td dir="ltr">${escHtml(`${woForm.woStartDate} ${woForm.woStartTime}`)}</td><th>پایان</th><td dir="ltr">${escHtml(`${woForm.woEndDate} ${woForm.woEndTime}`)}</td></tr>
  </table>
  ${selectedEqListForPrint.length > 0 ? `<p><b>تجهیزات انتخاب‌شده (${selectedEqListForPrint.length}):</b> ${escHtml(selectedEqListForPrint.map(e => `${e.name} (${e.id})`).join('، '))}</p>` : ''}
  <h4>فعالیت‌های انجام‌شده (${activities.length})</h4>
  <table><thead><tr><th>ردیف</th><th>کد</th><th>شرح فعالیت</th></tr></thead><tbody>
    ${activities.map((a, i) => `<tr><td>${i + 1}</td><td dir="ltr">${escHtml(a.code || '—')}</td><td>${escHtml(a.title)}</td></tr>`).join('')}
  </tbody></table>
  ${techRows.length > 0 ? `<h4>تکنسین‌ها</h4><table><thead><tr><th>نام</th><th>تاریخ</th><th>ساعت</th><th>مدت</th></tr></thead><tbody>${techRows.map(t => `<tr><td>${escHtml(t.name)}</td><td dir="ltr">${escHtml(`${t.startDate} تا ${t.endDate}`)}</td><td dir="ltr">${escHtml(`${t.startTime} تا ${t.endTime}`)}</td><td>${escHtml(t.hours)} ساعت</td></tr>`).join('')}</tbody></table>` : ''}
  ${parts.length > 0 ? `<p><b>قطعات مصرفی:</b> ${escHtml(parts.map(p => `${p.name} (${p.count} ${p.unit || 'عدد'})`).join('، '))}</p>` : ''}
  ${delays.length > 0 ? `<p><b>تاخیرات:</b> ${escHtml(delays.map(d => `${d.title || d.code}: ${d.days} روز ${d.hours} ساعت`).join('، '))}</p>` : ''}
  ${woForm.notes ? `<p><b>توضیحات:</b> ${escHtml(woForm.notes)}</p>` : ''}
</div></body></html>`;

    try {
      const existing = document.getElementById('pm-wo-print-iframe');
      if (existing) existing.remove();
      const iframe = document.createElement('iframe');
      iframe.id = 'pm-wo-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.top = '-9999px';
      iframe.style.left = '-9999px';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(html);
        doc.close();
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      }
    } catch {}
  };

  return createPortal(
    <div
      dir="rtl"
      className="fixed inset-0 z-[130] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl rounded-3xl bg-[#0e1424] border border-indigo-500/40 shadow-2xl flex flex-col max-h-[93vh] overflow-hidden text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* سربرگ مودال دستور کار */}
        <div className="px-5 py-4 bg-[#070e22] border-b border-indigo-900/50 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-md">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex flex-wrap items-center gap-2">
                <span>فرم دستور کار نگهداری پیشگیرانه (PM)</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded-lg bg-cyan-950/80 text-cyan-300 border border-cyan-500/40">
                  {woForm.woCode}
                </span>
                {isWoReadOnly && (
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                    بایگانی‌شده (فقط مشاهده)
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400 font-mono">
                کد درخواست PM: {targetOrder.code} • {targetOrder.equipmentName} ({targetOrder.equipmentCode})
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-rose-600/80 text-slate-400 hover:text-white transition-all cursor-pointer"
            title="بستن فرم"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* نوار جابجایی بین تب مشخصات، فعالیت و وضعیت */}
        <div className="px-5 py-2.5 bg-[#091124] border-b border-indigo-900/40 grid grid-cols-3 gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setWoModalPage(1)}
            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
              woModalPage === 1
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-400/50 shadow-md'
                : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
            }`}
          >
            <span>مشخصات</span>
          </button>
          <button
            type="button"
            onClick={() => setWoModalPage(2)}
            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
              woModalPage === 2
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-400/50 shadow-md'
                : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
            }`}
          >
            <span>فعالیت</span>
          </button>
          <button
            type="button"
            onClick={() => setWoModalPage(3)}
            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
              woModalPage === 3
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-400/50 shadow-md'
                : 'bg-[#0c162e] text-slate-400 hover:text-white border-indigo-500/20'
            }`}
          >
            <span>تغییر وضعیت</span>
          </button>
        </div>

        {/* بدنه اسکرول‌شونده صفحات */}
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          {woModalPage === 1 ? (
            /* ================= صفحه اول: مشخصات کامل ================= */
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                  <span className="text-[11px] text-slate-400 block mb-1">کد درخواست PM</span>
                  <span className="font-mono font-bold text-sm text-purple-300">{targetOrder.code}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                  <label className="text-[11px] text-slate-400 block mb-1">شماره دستور کار PM</label>
                  <input
                    type="text"
                    value={woForm.woCode}
                    disabled={isWoReadOnly}
                    onChange={e => !isWoReadOnly && setWoForm(prev => ({ ...prev, woCode: e.target.value }))}
                    className={`w-full bg-[#0c162e] border border-cyan-500/40 rounded-lg px-2.5 py-1 text-xs font-mono font-bold text-white outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                    dir="ltr"
                  />
                </div>
                <div className="p-3 rounded-xl bg-[#070e22] border border-indigo-500/25">
                  <span className="text-[11px] text-slate-400 block mb-1">وضعیت فعلی دستور کار</span>
                  <span className={`inline-flex px-2.5 py-0.5 rounded-lg text-xs font-bold border ${
                    woForm.status === 'انجام شد'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                      : woForm.status === 'لغو' || woForm.status === 'لغو شده'
                      ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                      : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                  }`}>
                    {woForm.status === 'انجام شد' ? 'انجام شده' : woForm.status}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/25 space-y-3">
                <h3 className="text-xs font-black text-cyan-300 pb-2 border-b border-indigo-900/40">
                  مشخصات کامل تجهیز و مکان
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">کد تجهیز</span>
                    <span className="font-mono font-bold text-white">{targetOrder.equipmentCode || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">عنوان و نوع تجهیز</span>
                    <span className="font-bold text-white">{targetOrder.equipmentName || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">مسیر کد خانواده تجهیز</span>
                    <span className="font-mono font-bold text-indigo-300">{targetOrder.equipmentFamilyCode || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-2">
                    <span className="text-[10px] text-slate-400 block mb-0.5">مسیر عنوان خانواده تجهیز</span>
                    <span className="font-bold text-slate-100">{targetOrder.equipmentFamilyName || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">کد مکان</span>
                    <span className="font-mono font-bold text-slate-200">{targetOrder.locationCode || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-3">
                    <span className="text-[10px] text-slate-400 block mb-0.5">مسیر عنوان مکان</span>
                    <span className="font-bold text-slate-100">{targetOrder.locationName || '—'}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/25 space-y-3">
                <h3 className="text-xs font-black text-amber-300 pb-2 border-b border-indigo-900/40">
                  مشخصات سرویس پیشگیرانه، اولویت و ثبت‌کننده
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">کد برنامه / حالت</span>
                    <span className="font-mono font-bold text-amber-300">{targetOrder.failureCode || 'PM-SCH'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-2">
                    <span className="text-[10px] text-slate-400 block mb-0.5">عنوان برنامه نگهداری پیشگیرانه</span>
                    <span className="font-bold text-amber-200">{targetOrder.failureTitle || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">نوع دستور کار</span>
                    <span className="font-bold text-purple-300">{targetOrder.requestType || 'پیشگیرانه'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">اولویت</span>
                    <span className="font-bold text-rose-300">{targetOrder.priority || 'عدم توقف تجهیز'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">زمان سررسید</span>
                    <span className="font-mono text-slate-200" dir="ltr">{targetOrder.requestTime || '—'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">متقاضی و صادرکننده</span>
                    <span className="font-bold text-white">{targetOrder.operatorName || 'سیستم زمان‌بندی خودکار PM'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">کد سیستمی</span>
                    <span className="font-mono text-slate-200">{targetOrder.operatorPersonnelCode || 'SYS-PM'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#0c162e]/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">وضعیت پرونده</span>
                    <span className="font-bold text-cyan-300">{targetOrder.status || '—'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#0c162e]/80 border border-slate-800 sm:col-span-3">
                    <span className="text-[10px] text-slate-400 block mb-1">توضیحات برنامه و تجهیزات مشمول</span>
                    <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                      {targetOrder.description || '—'}
                    </p>
                  </div>

                  {/* بخش کشویی انتخاب تجهیزات مشمول فعالیت (به صورت پیش‌فرض بسته) */}
                  <div className="sm:col-span-3 rounded-xl bg-[#0c162e]/90 border border-cyan-500/30 overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setIsEquipSectionOpen(prev => !prev)}
                      className="w-full px-3.5 py-2.5 flex items-center justify-between gap-2 text-right hover:bg-[#112042]/70 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-xs font-bold text-cyan-200">
                          تجهیزات انتخاب‌شده برای انجام این فعالیت
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/35">
                          {selectedEquipmentIds.length} از {candidateEquipments.length} دستگاه
                        </span>
                        {equipSavedHint && (
                          <span className="text-[10px] font-bold text-emerald-300 animate-in fade-in">
                            ✓ ثبت شد
                          </span>
                        )}
                      </div>
                      <span className={`w-7 h-7 rounded-lg bg-[#070e22] border border-cyan-500/30 flex items-center justify-center text-cyan-300 transition-transform duration-200 shrink-0 ${isEquipSectionOpen ? 'rotate-180' : ''}`}>
                        <ChevronDown className="w-4 h-4" />
                      </span>
                    </button>

                    {isEquipSectionOpen && (
                      <div className="p-3 border-t border-cyan-500/20 bg-[#070e22]/70 space-y-2.5 animate-in fade-in duration-150">
                        {!isWoReadOnly && candidateEquipments.length > 1 && (
                          <div className="flex items-center justify-between gap-2 text-[11px]">
                            <span className="text-slate-400">
                              در صورت عدم نیاز به انجام فعالیت روی هر تجهیز، تیک آن را بردارید:
                            </span>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => applyEquipmentSelectionUpdate(candidateEquipments.map(e => e.id))}
                                className="px-2 py-1 rounded-lg bg-cyan-950/70 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-500/30 font-bold cursor-pointer"
                              >
                                انتخاب همه
                              </button>
                              <button
                                type="button"
                                onClick={() => applyEquipmentSelectionUpdate([])}
                                className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold cursor-pointer"
                              >
                                لغو همه
                              </button>
                            </div>
                          </div>
                        )}

                        {candidateEquipments.length === 0 ? (
                          <div className="py-3 text-center text-xs text-slate-500">
                            تجهیزی برای این برنامه یافت نشد.
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-0.5">
                            {candidateEquipments.map(eq => {
                              const isChecked = selectedEquipmentIds.includes(eq.id);
                              return (
                                <label
                                  key={eq.id}
                                  className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition-all select-none ${
                                    isWoReadOnly ? 'cursor-not-allowed opacity-80' : 'cursor-pointer'
                                  } ${
                                    isChecked
                                      ? 'bg-[#0e1b38] border-cyan-500/45 text-white shadow-sm'
                                      : 'bg-[#070e22]/80 border-slate-800 text-slate-500'
                                  }`}
                                >
                                  <input
                                    type="checkbox"
                                    checked={isChecked}
                                    disabled={isWoReadOnly}
                                    onChange={() => handleToggleEquipmentSelection(eq.id)}
                                    className="w-4 h-4 rounded accent-cyan-500 bg-slate-900 border-slate-700 cursor-pointer shrink-0"
                                  />
                                  <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-mono font-bold text-[11px] px-1.5 py-0.5 rounded bg-slate-900 text-cyan-300 border border-cyan-500/25 shrink-0">
                                        {eq.id}
                                      </span>
                                      <span className={`text-xs font-bold truncate ${isChecked ? 'text-slate-100' : 'text-slate-500 line-through'}`}>
                                        {eq.name}
                                      </span>
                                    </div>
                                    {eq.location && (
                                      <span className="text-[10px] text-slate-400 block mt-0.5 truncate">
                                        {eq.location}
                                      </span>
                                    )}
                                  </div>
                                </label>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : woModalPage === 2 ? (
            /* ================= صفحه دوم: فعالیت، تکنسین، قطعات و تاخیر ================= */
            <div className="space-y-5">
              {/* ۱. فعالیت‌های نگه‌داشت */}
              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-cyan-500/30 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-cyan-400" />
                    <div>
                      <h3 className="text-xs font-black text-white">فعالیت‌های نگه‌داشت انجام‌شده</h3>
                      <span className="text-[10px] text-slate-400 block">
                        فعالیت‌های زمان‌بندی‌شده PM و فعالیت‌های خانواده تجهیز ({targetOrder.equipmentFamilyName || targetOrder.equipmentFamilyCode || '—'})
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                    {woForm.activities.length} فعالیت
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-[#0c162e] border border-cyan-500/25 space-y-2.5">
                  {(woForm.workDays.length > 0
                    ? woForm.workDays
                    : [
                        {
                          id: 'wd-fallback-1',
                          startDate: woForm.woStartDate,
                          startTime: woForm.woStartTime,
                          endDate: woForm.woEndDate,
                          endTime: woForm.woEndTime
                        }
                      ]
                  ).map((wd, wdIdx, wdArr) => (
                    <div key={wd.id} className="flex flex-col sm:flex-row sm:items-end gap-2">
                      {wdArr.length > 1 && (
                        <span className="text-[10px] font-bold px-2 py-1.5 rounded-lg bg-cyan-950/70 text-cyan-300 border border-cyan-500/30 shrink-0 self-start sm:self-end text-center">
                          روز {wdIdx + 1}
                        </span>
                      )}
                      <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                        <div>
                          <label className="text-slate-400 block mb-1">تاریخ شروع</label>
                          <input
                            type="text"
                            value={wd.startDate}
                            disabled={isWoReadOnly}
                            onChange={e => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'startDate', e.target.value)}
                            dir="ltr"
                            placeholder="1405/08/23"
                            className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 block mb-1">ساعت شروع</label>
                          <TimeInput24
                            value={wd.startTime}
                            disabled={isWoReadOnly}
                            onChange={nextVal => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'startTime', nextVal)}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400"
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 block mb-1">تاریخ پایان</label>
                          <input
                            type="text"
                            value={wd.endDate}
                            disabled={isWoReadOnly}
                            onChange={e => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'endDate', e.target.value)}
                            dir="ltr"
                            placeholder="1405/08/23"
                            className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 block mb-1">ساعت پایان</label>
                          <TimeInput24
                            value={wd.endTime}
                            disabled={isWoReadOnly}
                            onChange={nextVal => !isWoReadOnly && handleUpdateWoWorkDay(wd.id, 'endTime', nextVal)}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none focus:border-cyan-400"
                          />
                        </div>
                      </div>
                      {!isWoReadOnly && (
                        wdIdx === 0 ? (
                          <button
                            type="button"
                            onClick={handleAddWoWorkDay}
                            title="افزودن یک روز کاری"
                            className="h-[30px] px-2.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-300 border border-cyan-500/40 flex items-center justify-center transition-all cursor-pointer shrink-0 self-end"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleRemoveWoWorkDay(wd.id)}
                            title="حذف این روز کاری"
                            className="h-[30px] px-2.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 border border-rose-500/30 flex items-center justify-center transition-all cursor-pointer shrink-0 self-end"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )
                      )}
                    </div>
                  ))}
                </div>

                {!isWoReadOnly && (
                  <div ref={woActivityDropdownRef} className="relative">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={woActivitySearch}
                        onFocus={() => setIsWoActivityDropdownOpen(true)}
                        onChange={e => {
                          setWoActivitySearch(e.target.value);
                          setIsWoActivityDropdownOpen(true);
                        }}
                        placeholder={`سرچ سریع فعالیت از خانواده ${targetOrder.pmGroupName || targetOrder.equipmentFamilyName || 'تجهیز'} (با کد یا عنوان)...`}
                        className="w-full bg-[#0c162e] border border-cyan-500/40 rounded-xl pr-9 pl-20 py-2 text-xs text-white outline-none focus:border-cyan-400"
                      />
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30 pointer-events-none">
                        {woFamilyMaintenanceActivities.length} مورد
                      </span>
                    </div>

                    {isWoActivityDropdownOpen && (
                      <div className="absolute left-0 right-0 mt-1.5 max-h-48 overflow-y-auto rounded-xl bg-[#0b1530] border border-cyan-500/40 shadow-2xl z-30 divide-y divide-slate-800">
                        {woFamilyMaintenanceActivities.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-400">
                            فعلاً فعالیتی برای خانواده «{targetOrder.pmGroupName || targetOrder.equipmentFamilyName || 'این تجهیز'}» در بخش خانواده تجهیز ثبت نشده است.
                          </div>
                        ) : filteredWoFamilyActivities.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-400">موردی یافت نشد.</div>
                        ) : (
                          filteredWoFamilyActivities.map(act => (
                            <button
                              key={`${act.familyId || 'f'}-${act.id}`}
                              type="button"
                              onClick={() => handleAddWoActivity(act)}
                              className="w-full px-3 py-2 text-right hover:bg-cyan-900/40 flex items-center justify-between gap-2 text-xs transition-colors cursor-pointer"
                            >
                              <div className="min-w-0 flex-1">
                                <span className="text-white font-semibold truncate block">{act.title}</span>
                                {act.familyName && (
                                  <span className="text-[10px] text-slate-400 truncate block">
                                    خانواده: {act.familyName}
                                  </span>
                                )}
                              </div>
                              <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 shrink-0">
                                {act.code || 'بدون کد'}
                              </span>
                            </button>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                )}

                {woForm.activities.length > 0 && (
                  <div className="space-y-2 pt-1">
                    {woForm.activities.map((act, actIdx) => (
                      <div key={act.id} className="px-3 py-2 rounded-xl bg-[#0c162e] border border-indigo-500/30 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-[10px] font-mono text-slate-400 shrink-0">{actIdx + 1}.</span>
                          <span className="font-mono text-[11px] px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-500/40 shrink-0">
                            {act.code || '—'}
                          </span>
                          <span className="text-xs font-bold text-white truncate">{act.title}</span>
                        </div>
                        {!isWoReadOnly && (
                          <button
                            type="button"
                            onClick={() =>
                              setWoForm(prev => ({
                                ...prev,
                                activities: prev.activities.filter(a => a.id !== act.id)
                              }))
                            }
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer shrink-0"
                            title="حذف فعالیت"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ۲. تکنسین‌های مجری */}
              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/30 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-indigo-400" />
                    <div>
                      <h3 className="text-xs font-black text-white">تکنسین‌های انجام‌دهنده</h3>
                      <span className="text-[10px] text-slate-400 block">
                        تامین‌شده از تکنسین‌های ثبت‌شده در بخش پیشگیرانه و خدمات فنی
                      </span>
                    </div>
                  </div>
                  {!isWoReadOnly && (
                    <button
                      type="button"
                      onClick={() => handleAddWoTechnician()}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>افزودن تکنسین</span>
                    </button>
                  )}
                </div>

                {!isWoReadOnly && combinedTechnicians.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {combinedTechnicians.map(tName => (
                      <button
                        key={tName}
                        type="button"
                        onClick={() => handleAddWoTechnician(tName)}
                        className="px-2.5 py-1 rounded-lg bg-[#0c162e] hover:bg-indigo-900/60 border border-indigo-500/30 text-[11px] text-slate-200 hover:text-white flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <Plus className="w-3 h-3 text-indigo-400" />
                        <span>{tName}</span>
                      </button>
                    ))}
                  </div>
                )}

                {woForm.technicians.length === 0 ? (
                  <div className="text-center py-3 text-[11px] text-slate-500 border border-dashed border-slate-700 rounded-xl">
                    {isWoReadOnly ? 'تکنسینی برای این دستور کار ثبت نشده است.' : 'برای ثبت کارکرد، روی نام تکنسین یا دکمه «افزودن تکنسین» کلیک کنید.'}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {woForm.technicians.map((techRow, techIdx) => {
                      const updateFirstAndFollowers = (
                        field: 'startDate' | 'startTime' | 'endDate' | 'endTime',
                        customFlag: 'customStartDate' | 'customStartTime' | 'customEndDate' | 'customEndTime',
                        nextVal: string
                      ) => {
                        if (isWoReadOnly) return;
                        const statusFieldMap = {
                          startDate: 'woStartDate',
                          startTime: 'woStartTime',
                          endDate: 'woEndDate',
                          endTime: 'woEndTime'
                        } as const;
                        setWoForm(prev => ({
                          ...prev,
                          ...(techIdx === 0 && !woActivityRangeEdited
                            ? {
                                [statusFieldMap[field]]: nextVal,
                                ...(prev.workDays.length <= 1
                                  ? {
                                      workDays: (prev.workDays.length > 0
                                        ? prev.workDays
                                        : [{
                                            id: `wd-${Date.now()}-1`,
                                            startDate: prev.woStartDate,
                                            startTime: prev.woStartTime,
                                            endDate: prev.woEndDate,
                                            endTime: prev.woEndTime
                                          }]
                                      ).map((d, i) => (i === 0 ? { ...d, [field]: nextVal } : d))
                                    }
                                  : {})
                              }
                            : {}),
                          technicians: prev.technicians.map((t, idx) => {
                            const shouldUpdate = techIdx === 0 ? (idx === 0 || !t[customFlag]) : t.id === techRow.id;
                            if (!shouldUpdate) return t;
                            const updated = {
                              ...t,
                              [field]: nextVal,
                              ...(techIdx !== 0 ? { [customFlag]: true } : {}),
                              customHours: false
                            };
                            updated.hours = calcTechRowHours(updated.startDate, updated.startTime, updated.endDate, updated.endTime, updated.hours);
                            return updated;
                          })
                        }));
                      };

                      return (
                        <div key={techRow.id} className="grid grid-cols-12 gap-2 items-center p-2.5 rounded-xl bg-[#0c162e] border border-indigo-500/25 text-xs">
                          <div className="col-span-12 sm:col-span-3">
                            <label className="text-[10px] text-slate-400 block mb-0.5">نام تکنسین</label>
                            <select
                              value={techRow.name}
                              disabled={isWoReadOnly}
                              onChange={e =>
                                !isWoReadOnly &&
                                setWoForm(prev => ({
                                  ...prev,
                                  technicians: prev.technicians.map(t => t.id === techRow.id ? { ...t, name: e.target.value } : t)
                                }))
                              }
                              className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                            >
                              <option value="">انتخاب تکنسین...</option>
                              {combinedTechnicians.map(name => (
                                <option key={name} value={name}>{name}</option>
                              ))}
                              {techRow.name && !combinedTechnicians.includes(techRow.name) && (
                                <option value={techRow.name}>{techRow.name}</option>
                              )}
                            </select>
                          </div>
                          <div className="col-span-6 sm:col-span-2">
                            <label className="text-[10px] text-slate-400 block mb-0.5">تاریخ شروع</label>
                            <input
                              type="text"
                              value={techRow.startDate}
                              disabled={isWoReadOnly}
                              onChange={e => updateFirstAndFollowers('startDate', 'customStartDate', e.target.value)}
                              dir="ltr"
                              className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                            />
                          </div>
                          <div className="col-span-6 sm:col-span-2">
                            <label className="text-[10px] text-slate-400 block mb-0.5">ساعت شروع</label>
                            <TimeInput24
                              value={techRow.startTime}
                              disabled={isWoReadOnly}
                              onChange={nextVal => updateFirstAndFollowers('startTime', 'customStartTime', nextVal)}
                              className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-1.5 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400"
                            />
                          </div>
                          <div className="col-span-6 sm:col-span-2">
                            <label className="text-[10px] text-slate-400 block mb-0.5">تاریخ پایان</label>
                            <input
                              type="text"
                              value={techRow.endDate}
                              disabled={isWoReadOnly}
                              onChange={e => updateFirstAndFollowers('endDate', 'customEndDate', e.target.value)}
                              dir="ltr"
                              className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                            />
                          </div>
                          <div className="col-span-6 sm:col-span-2">
                            <label className="text-[10px] text-slate-400 block mb-0.5">ساعت پایان</label>
                            <TimeInput24
                              value={techRow.endTime}
                              disabled={isWoReadOnly}
                              onChange={nextVal => updateFirstAndFollowers('endTime', 'customEndTime', nextVal)}
                              className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-1.5 py-1.5 text-white font-mono text-center outline-none focus:border-indigo-400"
                            />
                          </div>
                          <div className="col-span-9 sm:col-span-1">
                            <label className="text-[10px] text-slate-400 block mb-0.5">ساعت</label>
                            <input
                              type="number"
                              min={0}
                              step="0.25"
                              value={techRow.hours}
                              disabled={isWoReadOnly}
                              onChange={e =>
                                !isWoReadOnly &&
                                setWoForm(prev => ({
                                  ...prev,
                                  technicians: prev.technicians.map(t =>
                                    t.id === techRow.id ? { ...t, hours: Math.max(0, parseFloat(e.target.value) || 0), customHours: true } : t
                                  )
                                }))
                              }
                              dir="ltr"
                              className={`w-full bg-[#070e22] border border-slate-700 rounded-lg px-1 py-1.5 text-emerald-300 font-mono font-bold text-center outline-none focus:border-indigo-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                            />
                          </div>
                          <div className="col-span-12 flex items-center justify-between pt-1 border-t border-slate-800/60">
                            <span className="text-[10px] text-slate-400 font-mono">
                              بازه ثبت‌شده: {techRow.startDate} ({techRow.startTime}) تا {techRow.endDate} ({techRow.endTime}) • {formatMinutesDurationFa(Math.round((Number(techRow.hours) || 0) * 60))}
                            </span>
                            {!isWoReadOnly && (
                              <button
                                type="button"
                                onClick={() =>
                                  setWoForm(prev => ({
                                    ...prev,
                                    technicians: prev.technicians.filter(t => t.id !== techRow.id)
                                  }))
                                }
                                className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer flex items-center gap-1 text-[10px]"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>حذف</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    <div className="text-left text-[11px] text-emerald-300 font-mono font-bold pt-1">
                      جمع ساعت کارکرد ثبت‌شده: {Math.round(woForm.technicians.reduce((s, t) => s + (Number(t.hours) || 0), 0) * 100) / 100} ساعت
                    </div>
                  </div>
                )}
              </div>

              {/* ۳. لوازم و قطعات مصرفی */}
              <div className="rounded-2xl bg-gradient-to-b from-slate-900/90 to-blue-950/90 border border-amber-500/40 shadow-lg overflow-hidden">
                <button
                  type="button"
                  onClick={() => setIsWoSparePartsOpen(prev => !prev)}
                  className="w-full p-4 flex flex-wrap items-center justify-between gap-2 text-right hover:bg-slate-900/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                      <Package className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-amber-300 block">لوازم و قطعات مصرفی دستور کار</span>
                      <span className="text-[10px] text-blue-200/70 block">ثبت اقلام مصرفی از انبار در ۳ گروه برقی، مکانیکی و سایر</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40">
                      {woForm.consumables.reduce((acc, c) => acc + c.count, 0)} قلم انتخاب‌شده
                    </span>
                    {isWoSparePartsOpen ? <ChevronUp className="w-4 h-4 text-amber-300" /> : <ChevronDown className="w-4 h-4 text-amber-300" />}
                  </div>
                </button>

                {isWoSparePartsOpen && (
                  <div className="px-4 pb-4 pt-2 border-t border-blue-900/40 space-y-3">
                    {!isWoReadOnly && (
                      <>
                        <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-950/80 border border-blue-900/60">
                          {(['برقی', 'مکانیکی', 'سایر'] as const).map(cat => {
                            const isActive = woConsumableTab === cat;
                            const catCount = woForm.consumables.filter(c => c.category === cat).reduce((s, c) => s + c.count, 0);
                            return (
                              <button
                                key={cat}
                                type="button"
                                onClick={() => setWoConsumableTab(cat)}
                                className={`py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                  isActive
                                    ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-md border border-amber-400/50'
                                    : 'text-blue-300 hover:text-white hover:bg-blue-900/30'
                                }`}
                              >
                                {cat === 'برقی' && <Zap className="w-3.5 h-3.5" />}
                                {cat === 'مکانیکی' && <Wrench className="w-3.5 h-3.5" />}
                                {cat === 'سایر' && <Box className="w-3.5 h-3.5" />}
                                <span>{cat === 'سایر' ? 'سایر اقلام' : `لوازم ${cat}`}</span>
                                {catCount > 0 && (
                                  <span className="text-[10px] px-1.5 rounded-full bg-slate-950/90 text-amber-200 font-mono font-bold">
                                    {catCount}
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>

                        <div className="space-y-1.5 pt-1">
                          <div className="flex items-center justify-between">
                            <button
                              type="button"
                              onClick={() => setWoShowPresetsBar(!woShowPresetsBar)}
                              className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300 hover:text-amber-200 transition-colors cursor-pointer"
                            >
                              <span>پیشنهادات سریع {woConsumableTab === 'سایر' ? 'سایر اقلام' : `لوازم ${woConsumableTab}`}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setWoShowPresetsBar(!woShowPresetsBar)}
                              className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-900/90 border border-amber-500/30 text-amber-300 hover:text-white cursor-pointer"
                            >
                              {woShowPresetsBar ? '▲ بستن نوار' : '▼ نمایش نوار اقلام'}
                            </button>
                          </div>

                          {woShowPresetsBar && (
                            <div className="flex items-center gap-2 overflow-x-auto py-2 px-2.5 rounded-xl bg-slate-950/90 border border-amber-500/40">
                              {Array.from(new Set([
                                ...unifiedInventoryParts
                                  .filter(p =>
                                    woConsumableTab === 'برقی'
                                      ? p.category === 'برقی' || p.category === 'ابزار دقیق'
                                      : woConsumableTab === 'مکانیکی'
                                      ? p.category === 'مکانیکی' || p.category === 'هیدرولیک و پنوماتیک'
                                      : p.category === 'عمومی و سایر'
                                  )
                                  .map(p => p.name),
                                ...DEFAULT_PRESET_CONSUMABLES[woConsumableTab]
                              ])).map((pName, idx) => {
                                const inList = woForm.consumables.find(c => c.name === pName && c.category === woConsumableTab);
                                return (
                                  <button
                                    key={idx}
                                    type="button"
                                    onClick={() => handleAddWoConsumablePreset(pName, woConsumableTab)}
                                    className={`shrink-0 whitespace-nowrap px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-all border cursor-pointer ${
                                      inList
                                        ? 'bg-amber-950/90 border-amber-500/80 text-amber-200 font-bold'
                                        : 'bg-slate-900/90 hover:bg-amber-950/40 border-blue-800/60 text-blue-200 hover:text-white'
                                    }`}
                                  >
                                    <span className="text-amber-400 font-bold">+</span>
                                    <span>{pName}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>

                        <div className="pt-2 border-t border-blue-900/40">
                          <datalist id="pm-wo-unified-parts-datalist">
                            {unifiedInventoryParts.map(p => (
                              <option key={p.id} value={p.name} />
                            ))}
                          </datalist>
                          <div className="grid grid-cols-12 gap-2">
                            <div className="col-span-12 sm:col-span-6">
                              <input
                                type="text"
                                list="pm-wo-unified-parts-datalist"
                                value={woNewPartName}
                                onChange={e => setWoNewPartName(e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleAddWoCustomConsumable();
                                  }
                                }}
                                placeholder={`نام قطعه ${woConsumableTab}...`}
                                className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                              />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <input
                                type="number"
                                min={1}
                                value={woNewPartCount}
                                onChange={e => setWoNewPartCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                                className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white font-mono text-center focus:outline-none focus:border-amber-400"
                              />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <select
                                value={woNewPartUnit}
                                onChange={e => setWoNewPartUnit(e.target.value)}
                                className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                              >
                                <option value="عدد">عدد</option>
                                <option value="متر">متر</option>
                                <option value="لیتر">لیتر</option>
                                <option value="کیلوگرم">کیلوگرم</option>
                                <option value="بسته">بسته</option>
                                <option value="شاخه">شاخه</option>
                              </select>
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <button
                                type="button"
                                onClick={handleAddWoCustomConsumable}
                                className="w-full py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1 cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" />
                                <span>افزودن</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {woForm.consumables.length > 0 && (
                      <div className={`space-y-1.5 ${!isWoReadOnly ? 'pt-2 border-t border-blue-900/40' : ''}`}>
                        {woForm.consumables.map(part => (
                          <div key={part.id} className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/90 border border-amber-500/30 text-xs">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 text-[10px] font-bold shrink-0">{part.category}</span>
                              <span className="font-bold text-white truncate">{part.name}</span>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="font-mono font-bold text-amber-300">{part.count} {part.unit || 'عدد'}</span>
                              {!isWoReadOnly && (
                                <button
                                  type="button"
                                  onClick={() => setWoForm(prev => ({ ...prev, consumables: prev.consumables.filter(c => c.id !== part.id) }))}
                                  className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* ۴. تاخیر */}
              <div className="rounded-2xl bg-[#070e22]/90 border border-rose-500/30 overflow-hidden">
                <button
                  type="button"
                  onClick={() => setIsWoDelaysOpen(prev => !prev)}
                  className="w-full p-4 flex flex-wrap items-center justify-between gap-2 text-right hover:bg-[#0c162e]/60 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Timer className="w-4 h-4 text-rose-400" />
                    <div>
                      <h3 className="text-xs font-black text-white">تاخیر</h3>
                      <span className="text-[10px] text-slate-400 block">ثبت کد تاخیر، عنوان، تعداد روز و ساعت تاخیر</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-rose-950/80 text-rose-300 border border-rose-500/40">
                      {woForm.delays.length} مورد
                    </span>
                    {isWoDelaysOpen ? <ChevronUp className="w-4 h-4 text-rose-300" /> : <ChevronDown className="w-4 h-4 text-rose-300" />}
                  </div>
                </button>

                {isWoDelaysOpen && (
                  <div className="px-4 pb-4 pt-2 border-t border-rose-900/40 space-y-3">
                    {!isWoReadOnly && (
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={handleAddWoDelay}
                          className="px-3 py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>افزودن تاخیر</span>
                        </button>
                      </div>
                    )}
                    {woForm.delays.map(delay => (
                      <div key={delay.id} className="grid grid-cols-12 gap-2 items-center p-2.5 rounded-xl bg-[#0c162e] border border-rose-500/25 text-xs">
                        <div className="col-span-4 sm:col-span-3">
                          <label className="text-[10px] text-slate-400 block mb-0.5">کد تاخیر</label>
                          <input
                            type="text"
                            value={delay.code}
                            disabled={isWoReadOnly}
                            onChange={e => setWoForm(prev => ({ ...prev, delays: prev.delays.map(d => d.id === delay.id ? { ...d, code: e.target.value } : d) }))}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono outline-none"
                          />
                        </div>
                        <div className="col-span-8 sm:col-span-5">
                          <label className="text-[10px] text-slate-400 block mb-0.5">عنوان تاخیر</label>
                          <input
                            type="text"
                            value={delay.title}
                            disabled={isWoReadOnly}
                            onChange={e => setWoForm(prev => ({ ...prev, delays: prev.delays.map(d => d.id === delay.id ? { ...d, title: e.target.value } : d) }))}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white outline-none"
                          />
                        </div>
                        <div className="col-span-5 sm:col-span-2">
                          <label className="text-[10px] text-slate-400 block mb-0.5">روز</label>
                          <input
                            type="number"
                            min={0}
                            value={delay.days}
                            disabled={isWoReadOnly}
                            onChange={e => setWoForm(prev => ({ ...prev, delays: prev.delays.map(d => d.id === delay.id ? { ...d, days: parseInt(e.target.value, 10) || 0 } : d) }))}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none"
                          />
                        </div>
                        <div className="col-span-5 sm:col-span-1">
                          <label className="text-[10px] text-slate-400 block mb-0.5">ساعت</label>
                          <input
                            type="number"
                            min={0}
                            value={delay.hours}
                            disabled={isWoReadOnly}
                            onChange={e => setWoForm(prev => ({ ...prev, delays: prev.delays.map(d => d.id === delay.id ? { ...d, hours: parseFloat(e.target.value) || 0 } : d) }))}
                            className="w-full bg-[#070e22] border border-slate-700 rounded-lg px-2 py-1 text-white font-mono text-center outline-none"
                          />
                        </div>
                        {!isWoReadOnly && (
                          <div className="col-span-2 sm:col-span-1 flex justify-end pt-3">
                            <button
                              type="button"
                              onClick={() => setWoForm(prev => ({ ...prev, delays: prev.delays.filter(d => d.id !== delay.id) }))}
                              className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ۵. توضیحات تکمیلی */}
              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-indigo-500/25 space-y-2">
                <label className="text-xs font-bold text-slate-300 block">توضیحات تکمیلی دستور کار</label>
                <textarea
                  rows={2}
                  value={woForm.notes}
                  disabled={isWoReadOnly}
                  onChange={e => !isWoReadOnly && setWoForm(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="گزارش فنی یا یادداشت سرپرست نگهداری پیشگیرانه..."
                  className="w-full bg-[#0c162e] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          ) : (
            /* ================= صفحه سوم: تغییر وضعیت دستور کار و خواب تجهیز ================= */
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-emerald-500/35 space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-emerald-900/40">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <div>
                    <h3 className="text-xs font-black text-white">تغییر وضعیت دستور کار</h3>
                    <span className="text-[10px] text-slate-400 block">
                      وضعیت نهایی پرونده (مثلاً انجام شده) را انتخاب نمایید
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { value: 'در انتظار دستور برنامه ریزی', label: 'در انتظار دستور' },
                    { value: 'در حال انجام', label: 'در حال انجام' },
                    { value: 'انجام شد', label: 'انجام شده' },
                    { value: 'لغو', label: 'لغو' }
                  ].map(opt => {
                    const isSelected =
                      woForm.status === opt.value ||
                      (opt.value === 'انجام شد' && woForm.status === 'انجام شده') ||
                      (opt.value === 'لغو' && woForm.status === 'لغو شده');
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        disabled={isWoReadOnly}
                        onClick={() => {
                          if (isWoReadOnly) return;
                          setWoValidationError(null);
                          setWoForm(prev => ({ ...prev, status: opt.value }));
                        }}
                        className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                          isWoReadOnly ? 'cursor-not-allowed opacity-85' : 'cursor-pointer'
                        } ${
                          isSelected
                            ? opt.value === 'انجام شد'
                              ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                              : opt.value === 'لغو'
                              ? 'bg-rose-600 text-white border-rose-400 shadow-md'
                              : 'bg-cyan-600 text-white border-cyan-400 shadow-md'
                            : 'bg-[#0c162e] text-slate-300 hover:text-white border-slate-700/80'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                        <span>{opt.label}</span>
                      </button>
                    );
                  })}
                </div>

                {!isWoReadOnly && ((woForm.status === 'انجام شد' || woForm.status === 'انجام شده') && woForm.activities.length === 0) && (
                  <div className={`p-3 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
                    woValidationError
                      ? 'bg-rose-950/70 border-rose-500/60 text-rose-200'
                      : 'bg-amber-950/50 border-amber-500/40 text-amber-200'
                  }`}>
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>
                        {woValidationError || 'برای ثبت وضعیت «انجام شده»، ابتدا حداقل یک فعالیت نگه‌داشت در تب «فعالیت» ثبت نمایید.'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setWoModalPage(2)}
                      className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold transition-all cursor-pointer shrink-0"
                    >
                      ثبت فعالیت در تب فعالیت
                    </button>
                  </div>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-[#070e22]/90 border border-cyan-500/35 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-900/40">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <div>
                      <h3 className="text-xs font-black text-white">زمان‌بندی خواب تجهیز (شروع و پایان توقف)</h3>
                      <span className="text-[10px] text-slate-400 block">
                        بازه اجرایی جهت محاسبه شاخص‌های قابلیت اطمینان و بایگانی PM
                      </span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-amber-950/80 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold">
                    مدت زمان:{' '}
                    {formatMinutesDurationFa(
                      computeMinutesBetweenShamsiDateTimes(woForm.woStartDate, woForm.woStartTime, woForm.woEndDate, woForm.woEndTime)
                    )}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                    <label className="text-[11px] text-slate-400 block mb-1.5">تاریخ شروع</label>
                    <input
                      type="text"
                      value={woForm.woStartDate}
                      disabled={isWoReadOnly}
                      onChange={e => !isWoReadOnly && setWoForm(prev => ({
                        ...prev,
                        woStartDate: e.target.value,
                        workDays: prev.workDays.map((d, i) => (i === 0 ? { ...d, startDate: e.target.value } : d))
                      }))}
                      dir="ltr"
                      className={`w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                    <label className="text-[11px] text-slate-400 block mb-1.5">ساعت شروع</label>
                    <TimeInput24
                      value={woForm.woStartTime}
                      disabled={isWoReadOnly}
                      onChange={nextVal => !isWoReadOnly && setWoForm(prev => ({
                        ...prev,
                        woStartTime: nextVal,
                        workDays: prev.workDays.map((d, i) => (i === 0 ? { ...d, startTime: nextVal } : d))
                      }))}
                      className="w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                    <label className="text-[11px] text-slate-400 block mb-1.5">تاریخ پایان</label>
                    <input
                      type="text"
                      value={woForm.woEndDate}
                      disabled={isWoReadOnly}
                      onChange={e => !isWoReadOnly && setWoForm(prev => ({
                        ...prev,
                        woEndDate: e.target.value,
                        workDays: prev.workDays.map((d, i, arr) => (i === arr.length - 1 ? { ...d, endDate: e.target.value } : d))
                      }))}
                      dir="ltr"
                      className={`w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400 ${isWoReadOnly ? 'opacity-80 cursor-not-allowed' : ''}`}
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-[#0c162e] border border-indigo-500/25">
                    <label className="text-[11px] text-slate-400 block mb-1.5">ساعت پایان</label>
                    <TimeInput24
                      value={woForm.woEndTime}
                      disabled={isWoReadOnly}
                      onChange={nextVal => !isWoReadOnly && setWoForm(prev => ({
                        ...prev,
                        woEndTime: nextVal,
                        workDays: prev.workDays.map((d, i, arr) => (i === arr.length - 1 ? { ...d, endTime: nextVal } : d))
                      }))}
                      className="w-full bg-[#070e22] border border-cyan-500/40 rounded-lg px-2.5 py-1.5 text-white font-mono text-center outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* پاورقی مودال */}
        <div className="px-5 py-3.5 bg-[#070e22] border-t border-indigo-900/50 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
          >
            {isWoReadOnly ? 'بستن' : 'انصراف'}
          </button>

          {woModalPage === 3 && !isWoReadOnly && (
            <button
              type="button"
              onClick={() => handleSave()}
              className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>ثبت</span>
            </button>
          )}

          {isWoReadOnly && (
            <button
              type="button"
              onClick={triggerPrintOrder}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>چاپ دستور کار ({printSettings.workOrderClosedA4.docCode})</span>
            </button>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};

export default PmWorkOrderThreeTabModal;
