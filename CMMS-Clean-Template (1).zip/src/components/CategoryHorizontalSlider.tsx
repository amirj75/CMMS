import React, { useRef, useState, useEffect } from 'react';
import { ChecklistCategory, EquipmentItem } from '../data/portalData';
import { DEFAULT_CATEGORY_IMAGES } from '../data/defaultCategoryImages';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface CategoryHorizontalSliderProps {
  categories: ChecklistCategory[];
  equipments: EquipmentItem[];
  onSelectCategory: (cat: ChecklistCategory) => void;
  onEditCategory?: (cat: ChecklistCategory) => void;
  onOpenManageModal?: () => void;
  toFaDigits: (val: number | string) => string;
}

export const CategoryHorizontalSlider: React.FC<CategoryHorizontalSliderProps> = ({
  categories,
  equipments,
  onSelectCategory,
  onEditCategory,
  onOpenManageModal,
  toFaDigits,
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [isDown, setIsDown] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftState, setScrollLeftState] = useState(0);
  const isDraggingRef = useRef(false);
  const dragDistanceRef = useRef(0);

  // ناوبری با دکمه‌های اسکرول نرم چپ و راست
  const handleScrollStep = (direction: 'left' | 'right') => {
    if (!sliderRef.current) return;
    const scrollAmount = 360;
    sliderRef.current.scrollBy({
      left: direction === 'right' ? scrollAmount : -scrollAmount,
      behavior: 'smooth',
    });
  };

  // رویدادهای درگ ماوس مطابق کد ارسالی کاربر
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!sliderRef.current) return;
    setIsDown(true);
    isDraggingRef.current = false;
    dragDistanceRef.current = 0;
    const pageX = e.pageX;
    setStartX(pageX - sliderRef.current.offsetLeft);
    setScrollLeftState(sliderRef.current.scrollLeft);
  };

  const handleMouseLeave = () => {
    setIsDown(false);
  };

  const handleMouseUp = () => {
    setIsDown(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDown || !sliderRef.current) return;
    e.preventDefault();
    const pageX = e.pageX;
    const x = pageX - sliderRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    sliderRef.current.scrollLeft = scrollLeftState - walk;
    dragDistanceRef.current += Math.abs(walk);
    if (dragDistanceRef.current > 8) {
      isDraggingRef.current = true;
    }
  };

  return (
    <div className="max-w-6xl mx-auto w-full select-none no-select">
      {/* هدر دسته‌بندی تجهیزات مطابق کد نمونه کاربر */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h2 className="text-xl sm:text-2xl font-bold text-slate-100 flex items-center gap-3">
          <span className="bg-emerald-900/40 text-emerald-400 p-2 rounded-lg text-lg">⚙️</span>
          <span>دسته‌بندی تجهیزات</span>
          <span className="text-xs sm:text-sm font-normal text-slate-500 mr-2">
            (برای جابه‌جایی به چپ و راست بکشید)
          </span>
        </h2>

        {/* دکمه‌های کمکی و مدیریت دسته‌ها */}
        <div className="flex items-center gap-2">
          {onOpenManageModal && (
            <button
              type="button"
              onClick={onOpenManageModal}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-700/80 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>مدیریت دسته‌ها</span>
              <span>←</span>
            </button>
          )}

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => handleScrollStep('right')}
              className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-700/80 transition-colors shadow-sm cursor-pointer"
              title="اسکرول به راست"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => handleScrollStep('left')}
              className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-700/80 transition-colors shadow-sm cursor-pointer"
              title="اسکرول به چپ"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* اسلایدر افقی با قابلیت Drag کشیدن با ماوس و تاچ در موبایل */}
      <div
        ref={sliderRef}
        id="slider"
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
        className={`flex gap-4 sm:gap-6 overflow-x-auto no-scrollbar pb-8 pt-4 transition-colors touch-pan-x ${
          isDown ? 'cursor-grabbing' : 'cursor-grab'
        }`}
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
        }}
      >
        {categories.map((cat) => {
          // محاسبه تعداد واقعی دستگاه‌های تخصیص‌یافته به این دسته
          const realCount = equipments.filter((e) => e.category === cat.name).length;

          return (
            <div
              key={cat.id || cat.name}
              onClick={() => {
                // اگر کاربر در حال درگ کردن بوده، کلیک ثبت نشود
                if (isDraggingRef.current) return;
                onSelectCategory(cat);
              }}
              className="group relative min-w-[280px] sm:min-w-[340px] h-[190px] sm:h-[200px] rounded-2xl overflow-hidden flex-shrink-0 shadow-lg shadow-slate-950 transition-all duration-300 hover:-translate-y-2 border border-slate-700 hover:border-emerald-500/60 hover:shadow-[0_0_20px_rgba(16,185,129,0.25)] bg-slate-900 cursor-pointer"
            >
              {/* لایه تصویر پس‌زمینه با دید مناسب در حالت عادی و شفافیت و درخشش ۱۰۰٪ در حالت هاور */}
              {(() => {
                const bgImage = cat.image || DEFAULT_CATEGORY_IMAGES[cat.name] || DEFAULT_CATEGORY_IMAGES[cat.id];
                if (!bgImage) return null;
                return (
                  <div
                    className="absolute inset-0 bg-cover bg-center filter blur-[1px] opacity-80 scale-100 group-hover:blur-none group-hover:opacity-100 group-hover:scale-105 transition-all duration-500 ease-out pointer-events-none"
                    style={{ backgroundImage: `url(${bgImage})` }}
                  />
                );
              })()}

              {/* دکمه ویرایش (مداد) در گوشه بالا سمت چپ */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (onEditCategory) {
                    onEditCategory(cat);
                  }
                }}
                className="absolute top-3 left-3 z-30 bg-slate-950/70 hover:bg-slate-800 text-slate-300 hover:text-emerald-400 p-2 rounded-full backdrop-blur-md border border-slate-700 transition-colors shadow-lg cursor-pointer"
                title="ویرایش دسته‌بندی و عکس"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                  />
                </svg>
              </button>

              {/* لایه گرادیانت ملایم: حفظ وضوح تصویر ماشین در حالت عادی و شفافیت کامل در هاور */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/40 to-slate-950/20 group-hover:from-slate-950/50 group-hover:via-slate-950/15 group-hover:to-transparent transition-all duration-500 z-10 pointer-events-none" />

              {/* محتوای متنی روی کارت با سایه شارپ برای خوانایی عالی روی عکس روشن */}
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center transition-transform duration-500 group-hover:-translate-y-4 pointer-events-none">
                <h3 className="text-3xl font-extrabold text-white tracking-wider mb-2 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                  {cat.name}
                </h3>
                {/* متن تعداد دستگاه با رنگ سبز نئونی و کادر شیشه‌ای */}
                <p className="text-sm text-emerald-300 font-bold bg-slate-950/75 backdrop-blur-sm border border-emerald-500/50 px-3.5 py-1 rounded-xl shadow-lg">
                  {toFaDigits(realCount)} دستگاه
                </p>
              </div>

              {/* دکمه ورود (ظاهر شدن هنگام هاور با افکت نئونی سبز) */}
              <div className="absolute bottom-0 left-0 w-full p-5 z-20 opacity-0 translate-y-4 transition-all duration-500 group-hover:opacity-100 group-hover:translate-y-0 flex justify-center">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectCategory(cat);
                  }}
                  className="bg-slate-900/80 backdrop-blur-md border border-emerald-500/60 text-emerald-400 hover:bg-emerald-600 hover:text-white px-6 py-2.5 rounded-xl text-sm font-medium transition-colors shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center gap-2 cursor-pointer"
                >
                  <span>ورود به زیرمجموعه‌ها</span>
                  <span>←</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
