import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Wrench, 
  Droplet, 
  Calendar, 
  ClipboardCheck, 
  ChevronLeft, 
  ChevronRight, 
  Activity, 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle2, 
  Clock
} from 'lucide-react';

interface RotaryCarousel3DProps {
  activeRequestsCount: number;
  archivedRequestsCount: number;
  totalRequestsCount: number;
  pmSchedulesCount: number;
  pmDoneCount: number;
  pmDueCount: number;
  oilTanks: Array<{ id: string | number; name: string; currentLiters: number; capacityLiters: number; oilType?: string }>;
  totalOilLiters: number;
  totalOilCapacity: number;
  lowOilTanksCount: number;
  conformingPercentage: number;
  completedChecklistsCount: number;
  onSelectView: (view: 'technical' | 'pm' | 'oil' | 'checklist') => void;
  toFaDigits: (num: any) => string;
  fa: (num: any) => string;
}

export const RotaryCarousel3D: React.FC<RotaryCarousel3DProps> = ({
  activeRequestsCount,
  archivedRequestsCount,
  totalRequestsCount,
  pmSchedulesCount,
  pmDoneCount,
  pmDueCount,
  oilTanks,
  totalOilLiters,
  totalOilCapacity,
  lowOilTanksCount,
  conformingPercentage,
  completedChecklistsCount,
  onSelectView,
  toFaDigits,
  fa
}) => {
  const TOTAL_CARDS = 4;
  const THETA = 360 / TOTAL_CARDS; // 90 deg
  const CYLINDER_RADIUS = 315; // px cylinder radius

  const [currentAngle, setCurrentAngle] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const sceneRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const startPointerXRef = useRef(0);
  const startAngleRef = useRef(0);
  const dragDistanceRef = useRef(0);

  // Compute active front index from angle
  const computeFrontIndex = (angle: number) => {
    const raw = Math.round(-angle / THETA);
    return ((raw % TOTAL_CARDS) + TOTAL_CARDS) % TOTAL_CARDS;
  };

  const updateAngle = useCallback((angle: number) => {
    setCurrentAngle(angle);
    const frontIdx = computeFrontIndex(angle);
    setActiveIndex(frontIdx);
  }, []);

  const snapToNearest = useCallback(() => {
    const nearest = Math.round(currentAngle / THETA) * THETA;
    updateAngle(nearest);
  }, [currentAngle, updateAngle]);

  const rotateStep = useCallback((delta: number) => {
    const target = currentAngle + delta * THETA;
    updateAngle(target);
  }, [currentAngle, updateAngle]);

  const rotateToIndex = useCallback((targetIdx: number) => {
    const curIdx = computeFrontIndex(currentAngle);
    let diff = targetIdx - curIdx;
    if (diff > TOTAL_CARDS / 2) diff -= TOTAL_CARDS;
    if (diff < -TOTAL_CARDS / 2) diff += TOTAL_CARDS;
    const targetAngle = currentAngle - diff * THETA;
    updateAngle(targetAngle);
  }, [currentAngle, updateAngle]);

  // Pointer Drag Handlers (Live Mouse & Touch Swipe)
  const handlePointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button.card-action-btn')) {
      return;
    }
    setIsDragging(true);
    startPointerXRef.current = e.clientX;
    startAngleRef.current = currentAngle;
    dragDistanceRef.current = 0;

    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch (_) {}
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - startPointerXRef.current;
    dragDistanceRef.current += Math.abs(deltaX);
    const newAngle = startAngleRef.current + deltaX * 0.38;
    updateAngle(newAngle);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (_) {}
    snapToNearest();
  };

  // Keyboard Navigation (Arrow Keys)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        rotateStep(1);
      } else if (e.key === 'ArrowLeft') {
        rotateStep(-1);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [rotateStep]);

  // Initial layout
  useEffect(() => {
    updateAngle(0);
  }, [updateAngle]);

  // Dynamic floor stage glow
  const themeGlows = [
    'radial-gradient(ellipse at center, rgba(16, 185, 129, 0.45) 0%, rgba(6, 182, 212, 0.15) 45%, transparent 70%)',
    'radial-gradient(ellipse at center, rgba(245, 158, 11, 0.45) 0%, rgba(234, 88, 12, 0.16) 45%, transparent 70%)',
    'radial-gradient(ellipse at center, rgba(168, 85, 247, 0.45) 0%, rgba(99, 102, 241, 0.16) 45%, transparent 70%)',
    'radial-gradient(ellipse at center, rgba(59, 130, 246, 0.45) 0%, rgba(6, 182, 212, 0.16) 45%, transparent 70%)',
  ];

  return (
    <div className="relative w-full flex flex-col items-center justify-center py-1 select-none">
      {/* Virtual 3D Stage Floor Glow */}
      <div 
        className="absolute bottom-5 w-[540px] h-[115px] rounded-full pointer-events-none transition-all duration-700"
        style={{
          background: themeGlows[activeIndex],
          transform: 'rotateX(75deg)'
        }}
      />

      {/* 3D Scene Viewport */}
      <div
        ref={sceneRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className={`w-full h-[525px] flex items-center justify-center cursor-grab active:cursor-grabbing touch-none relative ${
          isDragging ? 'cursor-grabbing' : ''
        }`}
        style={{ 
          perspective: '1200px',
          WebkitPerspective: '1200px'
        }}
      >
        {/* 
          3D Carousel Cylinder:
          By translating the cylinder back by -CYLINDER_RADIUS, the front card (+CYLINDER_RADIUS)
          sits EXACTLY at Z = 0 (the screen plane). This eliminates GPU texture upscaling blur
          and renders all Persian text and numbers at crisp 100% native pixel density!
        */}
        <div
          ref={carouselRef}
          className="relative w-[305px] sm:w-[315px] h-[495px]"
          style={{
            transformStyle: 'preserve-3d',
            WebkitTransformStyle: 'preserve-3d',
            transform: `translateZ(-${CYLINDER_RADIUS}px) rotateY(${currentAngle}deg)`,
            transition: isDragging ? 'none' : 'transform 0.65s cubic-bezier(0.2, 0.9, 0.3, 1)',
            willChange: 'transform'
          }}
        >
          {/* ================= CARD 0: چک‌لیست و بازرسی (Theme Green, 0 deg) ================= */}
          <div
            onClick={() => {
              if (dragDistanceRef.current < 10) {
                if (activeIndex !== 0) rotateToIndex(0);
                else onSelectView('checklist');
              }
            }}
            className={`absolute top-0 left-0 w-full h-full rounded-[1.75rem] p-5 cursor-pointer flex flex-col justify-between transition-all duration-500 ${
              activeIndex === 0
                ? 'z-50 border-2 border-emerald-400 shadow-[0_0_60px_-10px_rgba(16,185,129,0.55),0_20px_40px_rgba(0,0,0,0.7)] opacity-100 scale-100 ring-1 ring-emerald-400/40'
                : 'border border-slate-700/80 shadow-xl opacity-45 hover:opacity-75'
            }`}
            style={{
              background: 'linear-gradient(155deg, #0e2920 0%, #061712 100%)',
              transform: `rotateY(0deg) translateZ(${CYLINDER_RADIUS}px)`,
              backfaceVisibility: 'visible',
              WebkitBackfaceVisibility: 'visible',
              WebkitFontSmoothing: 'antialiased',
              MozOsxFontSmoothing: 'grayscale',
              textRendering: 'geometricPrecision',
              filter: activeIndex === 0 ? 'none' : 'blur(2.5px) brightness(0.55)',
            }}
          >
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-500 text-white flex items-center justify-center font-black shadow-lg shadow-emerald-500/40 ring-2 ring-emerald-400/60">
                  <ClipboardCheck className="w-7 h-7" />
                </div>
                <span className="text-xs font-black px-3.5 py-1 rounded-full border border-emerald-400/60 bg-emerald-950 text-emerald-200 flex items-center gap-1.5 shadow-md">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>بازرسی تجهیزات</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl font-black text-white flex items-center justify-between tracking-tight drop-shadow-sm">
                  <span>چک‌لیست و بازرسی تجهیزات</span>
                  <ChevronLeft className="w-5 h-5 text-emerald-400" />
                </h3>
                <p className="text-xs sm:text-[13px] font-semibold text-slate-100 mt-1.5 leading-relaxed">
                  ثبت چک‌لیست‌های روزانه، گزارش مغایرت و کنترل سلامت ماشین‌آلات خط تولید
                </p>
              </div>

              {/* Stats Widget */}
              <div className="rounded-2xl border-2 border-emerald-500/30 bg-[#07130e] p-3.5 space-y-3 shadow-inner">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-slate-100 font-bold">شاخص انطباق سلامت</span>
                  <span className="text-emerald-300 font-mono font-black text-base">{toFaDigits(conformingPercentage)}٪</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
                  <div className="bg-gradient-to-r from-teal-500 to-emerald-400 h-full rounded-full" style={{ width: `${conformingPercentage}%` }} />
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-slate-200 font-bold block">تکمیل شده</span>
                    <span className="text-sm sm:text-base font-black text-emerald-300 font-mono">{fa(completedChecklistsCount || 24)} مورد</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-slate-200 font-bold block">نرخ بازرسی</span>
                    <span className="text-sm sm:text-base font-black text-cyan-300 font-mono">روزانه</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative z-10 pt-3.5 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs sm:text-sm text-slate-100 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> آماده ثبت فرم جدید
              </span>
              <button 
                onClick={(e) => { e.stopPropagation(); onSelectView('checklist'); }}
                className="card-action-btn px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs sm:text-sm shadow-lg shadow-emerald-600/40 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <span>ورود به بازرسی</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ================= CARD 1: انبار روغن و روانکارها (Theme Orange, 90 deg) ================= */}
          <div
            onClick={() => {
              if (dragDistanceRef.current < 10) {
                if (activeIndex !== 1) rotateToIndex(1);
                else onSelectView('oil');
              }
            }}
            className={`absolute top-0 left-0 w-full h-full rounded-[1.75rem] p-5 cursor-pointer flex flex-col justify-between transition-all duration-500 ${
              activeIndex === 1
                ? 'z-50 border-2 border-amber-400 shadow-[0_0_60px_-10px_rgba(245,158,11,0.55),0_20px_40px_rgba(0,0,0,0.7)] opacity-100 scale-100 ring-1 ring-amber-400/40'
                : 'border border-slate-700/80 shadow-xl opacity-45 hover:opacity-75'
            }`}
            style={{
              background: 'linear-gradient(155deg, #2b1808 0%, #160a02 100%)',
              transform: `rotateY(90deg) translateZ(${CYLINDER_RADIUS}px)`,
              backfaceVisibility: 'visible',
              WebkitBackfaceVisibility: 'visible',
              WebkitFontSmoothing: 'antialiased',
              MozOsxFontSmoothing: 'grayscale',
              textRendering: 'geometricPrecision',
              filter: activeIndex === 1 ? 'none' : 'blur(2.5px) brightness(0.55)',
            }}
          >
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-600 via-orange-600 to-yellow-500 text-white flex items-center justify-center font-black shadow-lg shadow-amber-500/40 ring-2 ring-amber-400/60">
                  <Droplet className="w-7 h-7" />
                </div>
                <span className={`text-xs font-black px-3.5 py-1 rounded-full border flex items-center gap-1.5 shadow-md ${
                  lowOilTanksCount > 0 ? 'text-rose-200 bg-rose-950 border-rose-400/60' : 'text-amber-200 bg-amber-950 border-amber-400/60'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${lowOilTanksCount > 0 ? 'bg-rose-400 animate-ping' : 'bg-amber-400 animate-pulse'}`} />
                  <span>{lowOilTanksCount > 0 ? `${toFaDigits(lowOilTanksCount)} مخزن کسری` : 'انبار روانکارها'}</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl font-black text-white flex items-center justify-between tracking-tight drop-shadow-sm">
                  <span>انبار روغن و روانکارها</span>
                  <ChevronLeft className="w-5 h-5 text-amber-400" />
                </h3>
                <p className="text-xs sm:text-[13px] font-semibold text-slate-100 mt-1.5 leading-relaxed">
                  پایش سطح لحظه‌ای مخازن، کاردکس مصرف و صدور حواله شارژ
                </p>
              </div>

              {/* 4 Tanks Graphical Preview */}
              <div className="rounded-2xl border-2 border-amber-500/30 bg-[#160c04] p-3.5 space-y-3 shadow-inner">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-amber-200 font-bold flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-amber-400" /> موجودی کل مخازن
                  </span>
                  <span className="text-amber-300 font-mono font-black text-sm sm:text-base">{fa(totalOilLiters)} / {fa(totalOilCapacity)} L</span>
                </div>

                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {oilTanks.slice(0, 4).map((tank) => {
                    const pct = Math.max(0, Math.min(100, Math.round((tank.currentLiters / tank.capacityLiters) * 100)));
                    const isCrit = pct < 25;
                    return (
                      <div key={tank.id} className="p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-center flex flex-col items-center">
                        <div className="w-6 h-10 rounded-md bg-slate-950 border border-slate-700 overflow-hidden flex flex-col justify-end p-0.5">
                          <div
                            className={`w-full rounded-[2px] transition-all duration-500 ${
                              isCrit ? 'bg-gradient-to-t from-rose-600 to-rose-400' : 'bg-gradient-to-t from-amber-600 to-yellow-400'
                            }`}
                            style={{ height: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs text-white mt-1 font-bold truncate max-w-full">{tank.name.replace('مخزن شماره ', 'م ')}</span>
                        <span className={`text-xs font-mono font-black ${isCrit ? 'text-rose-400' : 'text-amber-300'}`}>{toFaDigits(pct)}٪</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="relative z-10 pt-3.5 border-t border-slate-800 flex items-center justify-between">
              <span className={`text-xs sm:text-sm flex items-center gap-1.5 font-bold ${lowOilTanksCount > 0 ? 'text-rose-300' : 'text-slate-100'}`}>
                {lowOilTanksCount > 0 ? (
                  <><AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" /> هشدار سفارش روغن</>
                ) : (
                  <><CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> وضعیت موجودی پایدار</>
                )}
              </span>
              <button 
                onClick={(e) => { e.stopPropagation(); onSelectView('oil'); }}
                className="card-action-btn px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/40 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <span>مدیریت مخازن</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ================= CARD 2: نگهداری پیشگیرانه PM (Theme Purple, 180 deg) ================= */}
          <div
            onClick={() => {
              if (dragDistanceRef.current < 10) {
                if (activeIndex !== 2) rotateToIndex(2);
                else onSelectView('pm');
              }
            }}
            className={`absolute top-0 left-0 w-full h-full rounded-[1.75rem] p-5 cursor-pointer flex flex-col justify-between transition-all duration-500 ${
              activeIndex === 2
                ? 'z-50 border-2 border-purple-400 shadow-[0_0_60px_-10px_rgba(168,85,247,0.55),0_20px_40px_rgba(0,0,0,0.7)] opacity-100 scale-100 ring-1 ring-purple-400/40'
                : 'border border-slate-700/80 shadow-xl opacity-45 hover:opacity-75'
            }`}
            style={{
              background: 'linear-gradient(155deg, #220f33 0%, #11061c 100%)',
              transform: `rotateY(180deg) translateZ(${CYLINDER_RADIUS}px)`,
              backfaceVisibility: 'visible',
              WebkitBackfaceVisibility: 'visible',
              WebkitFontSmoothing: 'antialiased',
              MozOsxFontSmoothing: 'grayscale',
              textRendering: 'geometricPrecision',
              filter: activeIndex === 2 ? 'none' : 'blur(2.5px) brightness(0.55)',
            }}
          >
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 text-white flex items-center justify-center font-black shadow-lg shadow-purple-500/40 ring-2 ring-purple-400/60">
                  <Calendar className="w-7 h-7" />
                </div>
                <span className="text-xs font-black px-3.5 py-1 rounded-full border border-purple-400/60 bg-purple-950 text-purple-200 flex items-center gap-1.5 shadow-md">
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                  <span>برنامه PM</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl font-black text-white flex items-center justify-between tracking-tight drop-shadow-sm">
                  <span>نگهداری پیشگیرانه PM</span>
                  <ChevronLeft className="w-5 h-5 text-purple-400" />
                </h3>
                <p className="text-xs sm:text-[13px] font-semibold text-slate-100 mt-1.5 leading-relaxed">
                  زمان‌بندی سرویس دوره‌ای، کالیبراسیون و پیشگیری از توقفات ناخواسته
                </p>
              </div>

              {/* Stats Box */}
              <div className="rounded-2xl border-2 border-purple-500/30 bg-[#12071a] p-3.5 space-y-3 shadow-inner">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-slate-100 font-bold">اجرای برنامه‌های PM</span>
                  <span className="text-purple-300 font-mono font-black text-base">
                    {pmSchedulesCount > 0 ? toFaDigits(Math.round((pmDoneCount / pmSchedulesCount) * 100)) : '۱۰۰'}٪
                  </span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800">
                  <div 
                    className="bg-gradient-to-r from-indigo-500 to-purple-400 h-full rounded-full" 
                    style={{ width: `${pmSchedulesCount > 0 ? (pmDoneCount / pmSchedulesCount) * 100 : 80}%` }} 
                  />
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-rose-300 font-bold block">سررسید</span>
                    <span className="text-sm sm:text-base font-black text-rose-400 font-mono">{fa(pmDueCount)}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-emerald-300 font-bold block">انجام‌شده</span>
                    <span className="text-sm sm:text-base font-black text-emerald-300 font-mono">{fa(pmDoneCount)}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-purple-200 font-bold block">کل برنامه</span>
                    <span className="text-sm sm:text-base font-black text-white font-mono">{fa(pmSchedulesCount)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative z-10 pt-3.5 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs sm:text-sm text-slate-100 font-bold flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-purple-400 shrink-0" /> تقویم زمان‌بندی آنلاین
              </span>
              <button 
                onClick={(e) => { e.stopPropagation(); onSelectView('pm'); }}
                className="card-action-btn px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs sm:text-sm shadow-lg shadow-purple-600/40 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <span>ورود به PM</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ================= CARD 3: خدمات فنی و دستور کارها (Theme Blue, 270 deg) ================= */}
          <div
            onClick={() => {
              if (dragDistanceRef.current < 10) {
                if (activeIndex !== 3) rotateToIndex(3);
                else onSelectView('technical');
              }
            }}
            className={`absolute top-0 left-0 w-full h-full rounded-[1.75rem] p-5 cursor-pointer flex flex-col justify-between transition-all duration-500 ${
              activeIndex === 3
                ? 'z-50 border-2 border-cyan-400 shadow-[0_0_60px_-10px_rgba(6,182,212,0.55),0_20px_40px_rgba(0,0,0,0.7)] opacity-100 scale-100 ring-1 ring-cyan-400/40'
                : 'border border-slate-700/80 shadow-xl opacity-45 hover:opacity-75'
            }`}
            style={{
              background: 'linear-gradient(155deg, #091e3d 0%, #040e21 100%)',
              transform: `rotateY(270deg) translateZ(${CYLINDER_RADIUS}px)`,
              backfaceVisibility: 'visible',
              WebkitBackfaceVisibility: 'visible',
              WebkitFontSmoothing: 'antialiased',
              MozOsxFontSmoothing: 'grayscale',
              textRendering: 'geometricPrecision',
              filter: activeIndex === 3 ? 'none' : 'blur(2.5px) brightness(0.55)',
            }}
          >
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 text-white flex items-center justify-center font-black shadow-lg shadow-cyan-500/40 ring-2 ring-cyan-400/60">
                  <Wrench className="w-7 h-7" />
                </div>
                <span className="text-xs font-black px-3.5 py-1 rounded-full border border-cyan-400/60 bg-cyan-950 text-cyan-200 flex items-center gap-1.5 shadow-md">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>کارتابل فعال</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl font-black text-white flex items-center justify-between tracking-tight drop-shadow-sm">
                  <span>خدمات فنی و دستورکارها</span>
                  <ChevronLeft className="w-5 h-5 text-cyan-400" />
                </h3>
                <p className="text-xs sm:text-[13px] font-semibold text-slate-100 mt-1.5 leading-relaxed">
                  ثبت درخواست خرابی، ارجاع تکنسین، ثبت زمان کارکرد و آرشیو فنی
                </p>
              </div>

              {/* Stats Box */}
              <div className="rounded-2xl border-2 border-cyan-500/30 bg-[#040e1c] p-3.5 space-y-3 shadow-inner">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="text-slate-100 font-bold">توزیع پرونده‌های فنی</span>
                  <span className="text-cyan-300 font-mono font-black text-sm sm:text-base">
                    {fa(activeRequestsCount)} جاری • {fa(archivedRequestsCount)} بایگانی
                  </span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden flex border border-slate-800">
                  <div 
                    className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full" 
                    style={{ width: `${totalRequestsCount > 0 ? (activeRequestsCount / totalRequestsCount) * 100 : 50}%` }} 
                  />
                  <div 
                    className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full ml-1" 
                    style={{ width: `${totalRequestsCount > 0 ? (archivedRequestsCount / totalRequestsCount) * 100 : 50}%` }} 
                  />
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-cyan-200 font-bold block">دستورکارهای فعال</span>
                    <span className="text-sm sm:text-base font-black text-cyan-300 font-mono">{fa(activeRequestsCount)} مورد</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-xs text-emerald-200 font-bold block">آرشیو تکمیل شده</span>
                    <span className="text-sm sm:text-base font-black text-emerald-300 font-mono">{fa(archivedRequestsCount)} مورد</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative z-10 pt-3.5 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs sm:text-sm text-slate-100 font-bold flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-cyan-400 shrink-0" /> کارتابل آماده پذیرش
              </span>
              <button 
                onClick={(e) => { e.stopPropagation(); onSelectView('technical'); }}
                className="card-action-btn px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-cyan-600/40 transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <span>ورود به کارتابل</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Navigation Controls & Pagination Indicators */}
      <div className="flex items-center gap-4 mt-2 z-20">
        <button
          onClick={() => rotateStep(1)}
          className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 border-2 border-slate-700 hover:border-cyan-400 text-slate-100 hover:text-white flex items-center justify-center transition-all shadow-md active:scale-95 cursor-pointer"
          title="کارت قبلی"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 shadow-inner">
          {[
            { idx: 0, title: 'چک‌لیست و بازرسی', color: 'bg-emerald-400 ring-emerald-400/50' },
            { idx: 1, title: 'انبار روغن', color: 'bg-amber-400 ring-amber-400/50' },
            { idx: 2, title: 'برنامه PM', color: 'bg-purple-400 ring-purple-400/50' },
            { idx: 3, title: 'خدمات فنی', color: 'bg-cyan-400 ring-cyan-400/50' },
          ].map((dot) => (
            <button
              key={dot.idx}
              onClick={() => rotateToIndex(dot.idx)}
              title={dot.title}
              className={`w-3 h-3 rounded-full transition-all duration-300 cursor-pointer ${
                activeIndex === dot.idx
                  ? `${dot.color} ring-4 scale-125`
                  : 'bg-slate-600 hover:bg-slate-500'
              }`}
            />
          ))}
        </div>

        <button
          onClick={() => rotateStep(-1)}
          className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 border-2 border-slate-700 hover:border-cyan-400 text-slate-100 hover:text-white flex items-center justify-center transition-all shadow-md active:scale-95 cursor-pointer"
          title="کارت بعدی"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>

    </div>
  );
};
