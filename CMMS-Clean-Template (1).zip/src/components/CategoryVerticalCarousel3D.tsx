import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, Layers, Sliders, ArrowLeft } from 'lucide-react';
import { ChecklistCategory, EquipmentItem } from '../data/portalData';

interface CategoryVerticalCarousel3DProps {
  categories: ChecklistCategory[];
  equipments: EquipmentItem[];
  onSelectCategory: (category: ChecklistCategory) => void;
  onActiveCategoryChange?: (category: ChecklistCategory) => void;
  toFaDigits: (str: string | number) => string;
}

// متادیتای اختصاصی ۹ دسته اصلی
const CATEGORY_META: Record<string, { icon: string; subtitle: string; gradient: string; borderColor: string }> = {
  'تورنوس': {
    icon: '⚙️',
    subtitle: 'ماشین‌آلات تراشکاری دقیق سوئیسی (Swiss Lathe)',
    gradient: 'from-cyan-950/90 via-[#0a1828]/95 to-slate-950',
    borderColor: 'border-cyan-400'
  },
  'فرز': {
    icon: '🔩',
    subtitle: 'فرزهای سنتر، عمودی و چندمحوره CNC',
    gradient: 'from-blue-950/90 via-[#0a1525]/95 to-slate-950',
    borderColor: 'border-blue-400'
  },
  'تراش': {
    icon: '📐',
    subtitle: 'دستگاه‌های تراش دستی، NC و تراشکاری صنعتی',
    gradient: 'from-indigo-950/90 via-[#0c1328]/95 to-slate-950',
    borderColor: 'border-indigo-400'
  },
  'سینتک': {
    icon: '🏭',
    subtitle: 'ماشین‌آلات تراش و کنترلرهای CNC سینتک (Syntec)',
    gradient: 'from-teal-950/90 via-[#081820]/95 to-slate-950',
    borderColor: 'border-teal-400'
  },
  'مایر': {
    icon: '⚡',
    subtitle: 'ماشین‌های براده‌برداری و قطعه‌سازی دقیق مایر (Mayer)',
    gradient: 'from-amber-950/80 via-[#18140c]/95 to-slate-950',
    borderColor: 'border-amber-400'
  },
  'استار': {
    icon: '⭐',
    subtitle: 'ماشین‌آلات تراش سوئیس تایپ استار ژاپن (Star)',
    gradient: 'from-purple-950/80 via-[#140d22]/95 to-slate-950',
    borderColor: 'border-purple-400'
  },
  'پرس': {
    icon: '🔨',
    subtitle: 'پرس‌های ضربه‌ای، هیدرولیک و شکل‌دهی قالب',
    gradient: 'from-rose-950/80 via-[#1c0c12]/95 to-slate-950',
    borderColor: 'border-rose-400'
  },
  'تجهیزات دستی': {
    icon: '🔧',
    subtitle: 'دریل‌های ستونی، سنگ رومیزی و ابزارهای دستی',
    gradient: 'from-emerald-950/80 via-[#0a1a14]/95 to-slate-950',
    borderColor: 'border-emerald-400'
  },
  'متفرقه': {
    icon: '📦',
    subtitle: 'سایر ماشین‌آلات، اره‌های نواری و تجهیزات متفرقه',
    gradient: 'from-slate-900/90 via-[#0e141c]/95 to-slate-950',
    borderColor: 'border-slate-400'
  }
};

export function CategoryVerticalCarousel3D({
  categories,
  equipments,
  onSelectCategory,
  onActiveCategoryChange,
  toFaDigits
}: CategoryVerticalCarousel3DProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isLiveAutoRoll, setIsLiveAutoRoll] = useState(true);
  const rollDirectionRef = useRef<'down' | 'up'>('down');
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const startYRef = useRef(0);
  const accumulatedDiffRef = useRef(0);
  const lastWheelTimeRef = useRef(0);

  const len = categories.length;

  const handleNext = useCallback(() => {
    if (len === 0) return;
    setActiveIndex(prev => (prev + 1) % len);
  }, [len]);

  const handlePrev = useCallback(() => {
    if (len === 0) return;
    setActiveIndex(prev => (prev - 1 + len) % len);
  }, [len]);

  // اطلاع‌رسانی به والد در مورد تغییر دسته فعال
  useEffect(() => {
    if (categories[activeIndex] && onActiveCategoryChange) {
      onActiveCategoryChange(categories[activeIndex]);
    }
  }, [activeIndex, categories, onActiveCategoryChange]);

  // چرخش زنده خودکار رولی از بالا به پایین و برعکس (Bi-directional Live Auto-Roll)
  useEffect(() => {
    if (!isLiveAutoRoll || len <= 1) return;

    const interval = setInterval(() => {
      setActiveIndex(prev => {
        if (rollDirectionRef.current === 'down') {
          if (prev < len - 1) {
            return prev + 1;
          } else {
            rollDirectionRef.current = 'up';
            return Math.max(0, prev - 1);
          }
        } else {
          if (prev > 0) {
            return prev - 1;
          } else {
            rollDirectionRef.current = 'down';
            return Math.min(len - 1, prev + 1);
          }
        }
      });
    }, 3200);

    return () => clearInterval(interval);
  }, [isLiveAutoRoll, len]);

  // ۱. اسکرول با غلتک ماوس (Wheel) با تفکیک کامل از صفحه اصلی
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const now = Date.now();
      if (now - lastWheelTimeRef.current < 150) return;

      if (Math.abs(e.deltaY) > 8) {
        lastWheelTimeRef.current = now;
        if (e.deltaY > 0) {
          handleNext();
        } else {
          handlePrev();
        }
      }
    };

    container.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', onWheel);
    };
  }, [handleNext, handlePrev]);

  // ۲. کنترل لمسی حرفه‌ای با انگشت در گوشی و تبلت (Native Touch Gestures with passive: false)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      isDraggingRef.current = true;
      startYRef.current = e.touches[0].clientY;
      accumulatedDiffRef.current = 0;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || e.touches.length !== 1) return;
      const currentY = e.touches[0].clientY;
      const diff = currentY - startYRef.current;
      accumulatedDiffRef.current += diff;
      startYRef.current = currentY;

      // جلوگیری از اسکرول صفحه هنگام کشیدن انگشت روی استوانه ۳ بعدی
      if (Math.abs(accumulatedDiffRef.current) > 6) {
        e.preventDefault();
      }

      // چرخش رول با هر ۳۰ پیکسل حرکت انگشت
      const threshold = 30;
      if (accumulatedDiffRef.current > threshold) {
        handlePrev();
        accumulatedDiffRef.current = 0;
      } else if (accumulatedDiffRef.current < -threshold) {
        handleNext();
        accumulatedDiffRef.current = 0;
      }
    };

    const onTouchEnd = () => {
      isDraggingRef.current = false;
      accumulatedDiffRef.current = 0;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: false });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd);
    container.addEventListener('touchcancel', onTouchEnd);

    return () => {
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [handleNext, handlePrev]);

  // ۳. درگ ماوس روی دسکتاپ (Mouse Drag)
  const handleMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('button')) return;
    isDraggingRef.current = true;
    startYRef.current = e.clientY;
    accumulatedDiffRef.current = 0;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const diff = e.clientY - startYRef.current;
    accumulatedDiffRef.current += diff;
    startYRef.current = e.clientY;

    const threshold = 35;
    if (accumulatedDiffRef.current > threshold) {
      handlePrev();
      accumulatedDiffRef.current = 0;
    } else if (accumulatedDiffRef.current < -threshold) {
      handleNext();
      accumulatedDiffRef.current = 0;
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
    accumulatedDiffRef.current = 0;
  };

  // ۴. کنترل با کلیدهای کیبورد (ArrowUp / ArrowDown)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      handleNext();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      handlePrev();
    }
  };

  if (len === 0) return null;

  // ۵ موقعیت در صحنه: -2, -1, 0 (وسط), 1, 2
  const visibleSlots = [-2, -1, 0, 1, 2];

  return (
    <section
      ref={containerRef}
      id="carousel-container"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="max-w-4xl mx-auto w-full flex-1 flex flex-col justify-center perspective relative h-[500px] select-none no-select outline-none rounded-3xl bg-slate-950/80 backdrop-blur-md border border-slate-800 shadow-2xl overflow-hidden py-4 cursor-grab active:cursor-grabbing"
    >
      {/* هاله نور پس‌زمینه زمردی متمرکز */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-80 h-36 bg-emerald-500/20 rounded-full blur-3xl" />
      </div>

      {/* پیام راهنما مطابق کد کاربر */}
      <div className="absolute top-4 inset-x-0 text-center text-xs text-slate-500 z-10 pointer-events-none">
        چرخش استوانه‌ای با غلتک ماوس، کشیدن لمسی یا کلیدهای کیبورد (⬆️/⬇️)
      </div>

      {/* کنترل‌های ناوبری در گوشه */}
      <div className="absolute top-3 left-4 z-40 flex items-center gap-2 bg-slate-900/90 px-3 py-1 rounded-full border border-slate-800 text-xs font-mono text-slate-300 shadow-md">
        <span>دسته {toFaDigits(activeIndex + 1)}</span>
        <span className="text-slate-600">/</span>
        <span className="text-slate-400">{toFaDigits(len)}</span>

        {/* دکمه وضعیت چرخش زنده خودکار */}
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setIsLiveAutoRoll(prev => !prev); }}
          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-sans font-bold transition-all cursor-pointer ${
            isLiveAutoRoll 
              ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/50 shadow-sm animate-pulse' 
              : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
          }`}
          title="پخش خودکار زنده از بالا به پایین و برعکس"
        >
          <span className={`w-1.5 h-1.5 rounded-full ${isLiveAutoRoll ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
          <span>{isLiveAutoRoll ? 'رول زنده ↕' : 'متوقف'}</span>
        </button>

        <div className="flex items-center gap-1 mr-1 pr-1 border-r border-slate-700">
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            className="p-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="دسته قبلی (چرخش به بالا)"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            className="p-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="دسته بعدی (چرخش به پایین)"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ماسک گرادیانت فید ملایم در بالا و پایین برای القای عمق استوانه‌ای */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-slate-950 via-slate-950/80 to-transparent z-20" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent z-20" />

      {/* صحنه ۵ کارتی سه‌بعدی استوانه‌ای با انیمیشن روان عقب و جلو رفتن کارت‌ها */}
      <div id="cards-wrapper" className="w-full relative h-[400px] flex justify-center items-center mt-8 preserve-3d px-3 sm:px-6">
        {categories.map((cat, idx) => {
          // محاسبه فاصله دایره‌ای کارت نسبت به کارت فعال در مرکز
          let diff = idx - activeIndex;
          while (diff > len / 2) diff -= len;
          while (diff < -len / 2) diff += len;

          const isCenter = diff === 0;
          const isVisible = Math.abs(diff) <= 2;
          const meta = CATEGORY_META[cat.name] || {
            icon: '📦',
            subtitle: 'تجهیزات و ماشین‌آلات خط تولید',
            gradient: 'from-blue-950/90 via-slate-900 to-slate-950',
            borderColor: 'border-cyan-400'
          };

          // تعداد دقیق دستگاه‌های تخصیص‌یافته به این دسته در سامانه
          const realCount = equipments.filter(e => e.category === cat.name).length;

          // محاسبات هندسی عمودی، پرسپکتیو سه‌بعدی
          let translateY = 0;
          let scale = 1;
          let opacity = 1;
          let zIndex = 30;
          let rotateX = 0;
          let translateZ = 0;

          if (diff === 0) {
            translateY = 0;
            scale = 1;
            opacity = 1;
            zIndex = 30;
            rotateX = 0;
            translateZ = 0;
          } else if (diff === -1) {
            translateY = -92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = 10;
            translateZ = -45;
          } else if (diff === 1) {
            translateY = 92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = -10;
            translateZ = -45;
          } else if (diff === -2) {
            translateY = -170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = 18;
            translateZ = -95;
          } else if (diff === 2) {
            translateY = 170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = -18;
            translateZ = -95;
          } else {
            // کارت‌های دورتر به نرمی به پشت استوانه می‌روند
            translateY = diff < 0 ? -240 : 240;
            scale = 0.60;
            opacity = 0;
            zIndex = 5;
            rotateX = diff < 0 ? 25 : -25;
            translateZ = -140;
          }

          return (
            <div
              key={cat.id || cat.name}
              onClick={() => {
                setActiveIndex(idx);
                if (isCenter) {
                  onSelectCategory({ ...cat, equipmentCount: realCount });
                }
              }}
              style={{
                transform: `translateY(${translateY}px) translateZ(${translateZ}px) rotateX(${rotateX}deg) scale(${scale})`,
                opacity,
                zIndex,
                pointerEvents: isVisible ? 'auto' : 'none',
                transition: 'transform 600ms cubic-bezier(0.22, 1, 0.36, 1), opacity 600ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 600ms ease, border-color 600ms ease, background-color 600ms ease'
              }}
              className={`carousel-card absolute w-full max-w-2xl h-[104px] sm:h-[98px] preserve-3d rounded-2xl p-4 sm:px-6 flex items-center justify-between border cursor-pointer will-change-transform ${
                isCenter
                  ? 'bg-slate-900/95 backdrop-blur-md border-2 border-emerald-500 shadow-[0_0_35px_rgba(16,185,129,0.30)] ring-2 ring-emerald-500/50 z-30'
                  : 'bg-slate-900/80 backdrop-blur-sm border border-slate-800 text-slate-400 shadow-none hover:border-slate-700'
              }`}
            >
              {/* بخش سمت راست: آیکون، نام دسته و زیرعنوان */}
              <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                <div className={`w-13 h-13 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl shrink-0 shadow-inner ${
                  isCenter ? 'bg-slate-800/80 border border-emerald-500/50 scale-105' : 'bg-slate-800/60 border border-slate-700/60 grayscale opacity-60'
                }`}>
                  <span>{meta.icon}</span>
                </div>

                <div className="min-w-0 space-y-0.5 text-right">
                  <div className="flex items-center gap-2">
                    <h3 className={`text-base sm:text-lg font-black truncate ${
                      isCenter ? 'text-white' : 'text-slate-400'
                    }`}>
                      {cat.name}
                    </h3>

                    {/* بج موجودی دستگاه */}
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold border ${
                      isCenter
                        ? (realCount > 0
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                            : 'bg-emerald-950/50 text-emerald-400/70 border-emerald-600/30')
                        : 'bg-slate-800/80 text-slate-400 border-slate-700/60'
                    }`}>
                      {toFaDigits(realCount)} دستگاه
                    </span>
                  </div>

                  <p className={`text-[11px] sm:text-xs truncate max-w-md ${isCenter ? 'text-slate-300' : 'text-slate-500'}`}>
                    {meta.subtitle}
                  </p>
                </div>
              </div>

              {/* بخش سمت چپ: دکمه اقدام ورود به دسته (دکمه اقدام فیروزه‌ای برای کارت فعال) */}
              <div className="flex items-center gap-2 shrink-0">
                {isCenter ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectCategory({ ...cat, equipmentCount: realCount });
                    }}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white font-bold text-xs transition-all shadow-lg shadow-cyan-950/60 flex items-center gap-1.5 cursor-pointer hover:scale-105 border border-cyan-400/50"
                  >
                    <span>مدیریت و ثبت تجهیزات</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-500 font-bold hidden sm:inline">
                    کلیک برای چرخش ↺
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
