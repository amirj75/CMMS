import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Check, X, Move, Crop } from 'lucide-react';

interface ImageFramingModalProps {
  isOpen: boolean;
  imageSrc: string;
  categoryName?: string;
  onConfirm: (croppedDataUrl: string) => void;
  onCancel: () => void;
  aspectRatio?: number; // عرض به ارتفاع، پیش‌فرض 1.7 (مطابق کارت‌های 340x200)
}

export const ImageFramingModal: React.FC<ImageFramingModalProps> = ({
  isOpen,
  imageSrc,
  categoryName,
  onConfirm,
  onCancel,
  aspectRatio = 1.7,
}) => {
  const [zoom, setZoom] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const frameRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  // ریست کردن زوم و آفست در هنگام باز شدن تصویر جدید
  useEffect(() => {
    if (isOpen) {
      setZoom(1);
      setOffset({ x: 0, y: 0 });
    }
  }, [isOpen, imageSrc]);

  // رویدادهای درگ با ماوس و لمس برای جابه‌جایی تصویر درون کادر
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX - offset.x,
      y: e.clientY - offset.y,
    };
  };

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;
    setOffset({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y,
    });
  }, [isDragging]);

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      dragStartRef.current = {
        x: e.touches[0].clientX - offset.x,
        y: e.touches[0].clientY - offset.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    setOffset({
      x: e.touches[0].clientX - dragStartRef.current.x,
      y: e.touches[0].clientY - dragStartRef.current.y,
    });
  };

  const handleReset = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
  };

  // رندر کادر نهایی روی Canvas و تولید Data URL باکیفیت
  const handleCropConfirm = () => {
    if (!imgRef.current || !frameRef.current) {
      onConfirm(imageSrc);
      return;
    }

    const frameRect = frameRef.current.getBoundingClientRect();
    const imgElement = imgRef.current;

    // عرض بهینه ۴۸۰ پیکسل و کیفیت فشرده جهت اشغال تنها ۲۵ الی ۳۵ کیلوبایت در حافظه محلی و پایگاه داده
    const outputWidth = 480;
    const outputHeight = Math.round(480 / (aspectRatio || 1.7));

    const canvas = document.createElement('canvas');
    canvas.width = outputWidth;
    canvas.height = outputHeight;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      onConfirm(imageSrc);
      return;
    }

    // مقیاس تبدیل ابعاد DOM به Canvas
    const scaleRatio = outputWidth / frameRect.width;

    // پاکسازی بوم با رنگ پیش‌فرض تاریک
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, outputWidth, outputHeight);

    // محاسبه مختصات در سیستم مختصات بوم
    ctx.save();
    ctx.translate(outputWidth / 2, outputHeight / 2);
    ctx.translate(offset.x * scaleRatio, offset.y * scaleRatio);
    ctx.scale(zoom, zoom);

    // اندازه نمایش تصویر
    const renderedWidth = imgElement.width * scaleRatio;
    const renderedHeight = imgElement.height * scaleRatio;

    ctx.drawImage(
      imgElement,
      -renderedWidth / 2,
      -renderedHeight / 2,
      renderedWidth,
      renderedHeight
    );
    ctx.restore();

    try {
      let croppedUrl = canvas.toDataURL('image/webp', 0.78);
      if (!croppedUrl.startsWith('data:image/webp')) {
        croppedUrl = canvas.toDataURL('image/jpeg', 0.75);
      }
      onConfirm(croppedUrl);
    } catch {
      try {
        const croppedUrl = canvas.toDataURL('image/jpeg', 0.75);
        onConfirm(croppedUrl);
      } catch {
        onConfirm(imageSrc);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-6 space-y-4 text-right text-slate-200">
        
        {/* نوار بالایی مودال */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
              <Crop className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">تنظیم کادر و مقیاس عکس پس‌زمینه</h3>
              <p className="text-[11px] text-slate-400">عکس را بکشید یا بزرگ و کوچک کنید</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* کادر فریم تصویر با تناسب دقیق ابعاد کارت دسته‌بندی */}
        <div className="relative flex flex-col items-center">
          <div
            ref={frameRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleMouseUp}
            className="relative w-full aspect-[1.7/1] rounded-2xl overflow-hidden border-2 border-emerald-500/80 shadow-[0_0_25px_rgba(16,185,129,0.25)] bg-slate-950 cursor-move select-none flex items-center justify-center"
          >
            {/* تصویر قابل حرکت و زوم */}
            <img
              ref={imgRef}
              src={imageSrc}
              alt="تنظیم کادر"
              draggable={false}
              style={{
                transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`,
                transformOrigin: 'center center',
                transition: isDragging ? 'none' : 'transform 0.1s ease-out',
                maxWidth: '100%',
                maxHeight: '100%',
                objectFit: 'contain',
              }}
              className="pointer-events-none select-none"
            />

            {/* خطوط راهنمای کادربندی (Rule of Thirds) */}
            <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 border border-emerald-500/30">
              <div className="border-b border-r border-emerald-500/20" />
              <div className="border-b border-r border-emerald-500/20" />
              <div className="border-b border-emerald-500/20" />
              <div className="border-b border-r border-emerald-500/20" />
              <div className="border-b border-r border-emerald-500/20" />
              <div className="border-b border-emerald-500/20" />
              <div className="border-r border-emerald-500/20" />
              <div className="border-r border-emerald-500/20" />
              <div />
            </div>

            {/* پیش‌نمایش برچسب تستی روی کادر */}
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-4 bg-slate-950/20">
              <span className="text-xl sm:text-2xl font-bold text-white drop-shadow-lg tracking-wide">
                {categoryName || 'پیش‌نمایش کارت'}
              </span>
            </div>

            {/* نشانگر قابلیت حرکت دادن */}
            <div className="absolute bottom-2 left-2 z-20 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded-lg border border-slate-700 text-[10px] text-slate-300 flex items-center gap-1 pointer-events-none">
              <Move className="w-3 h-3 text-emerald-400" />
              <span>برای جابه‌جایی بکشید</span>
            </div>
          </div>
        </div>

        {/* کنترل‌های بزرگ‌نمایی و کوچک‌نمایی (Zoom Controls) */}
        <div className="space-y-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span className="flex items-center gap-1.5">
              <span>اندازه / زوم عکس:</span>
              <span className="text-emerald-400 font-mono">{Math.round(zoom * 100)}٪</span>
            </span>
            <button
              type="button"
              onClick={handleReset}
              className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>بازنشانی</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setZoom(z => Math.max(0.5, +(z - 0.1).toFixed(2)))}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              title="کوچک‌تر"
            >
              <ZoomOut className="w-4 h-4" />
            </button>

            <input
              type="range"
              min="0.5"
              max="3"
              step="0.05"
              value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="flex-1 accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
            />

            <button
              type="button"
              onClick={() => setZoom(z => Math.min(3, +(z + 0.1).toFixed(2)))}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              title="بزرگ‌تر"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* دکمه‌های تأیید و انصراف */}
        <div className="flex items-center gap-2.5 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={handleCropConfirm}
            className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-950/60 cursor-pointer flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>تأیید و انتخاب کادر</span>
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
          >
            انصراف
          </button>
        </div>

      </div>
    </div>
  );
};
