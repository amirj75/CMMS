import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Calendar, 
  MapPin, 
  ArrowLeft, 
  ArrowRight, 
  ChevronUp, 
  ChevronDown, 
  Check, 
  RotateCcw, 
  FileText 
} from 'lucide-react';
import { WorkRequest, ConsumableItem } from '../App';

interface VerticalCarousel3DProps {
  items: WorkRequest[];
  isArchive?: boolean;
  flippedCards: Record<string, boolean>;
  toggleCardFlip: (code: string) => void;
  onCompleteWorkOrder?: (req: WorkRequest) => void;
  onViewRequestDetails?: (req: WorkRequest) => void;
  onRestoreFromArchive?: (code: string) => void;
  formatPersianDateBadge: (date?: string) => { day: string; month: string };
  fa: (n: number | string) => string;
  toFaDigits: (str: string | number) => string;
}

export function VerticalCarousel3D({
  items,
  isArchive = false,
  flippedCards,
  toggleCardFlip,
  onCompleteWorkOrder,
  onViewRequestDetails,
  onRestoreFromArchive,
  formatPersianDateBadge,
  fa,
  toFaDigits
}: VerticalCarousel3DProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const startYRef = useRef(0);
  const lastWheelTimeRef = useRef(0);

  // اطمینان از قرار داشتن شاخص در محدوده مجاز هنگام فیلتر شدن آیتم‌ها
  useEffect(() => {
    if (activeIndex >= items.length && items.length > 0) {
      setActiveIndex(items.length - 1);
    }
  }, [items.length, activeIndex]);

  const handleNext = useCallback(() => {
    setActiveIndex(prev => (prev < items.length - 1 ? prev + 1 : prev));
  }, [items.length]);

  const handlePrev = useCallback(() => {
    setActiveIndex(prev => (prev > 0 ? prev - 1 : 0));
  }, []);

  // ۱. کنترل با اسکرول چرخ ماوس با وقفه ملایم و تفکیک کامل از اسکرول صفحه اصلی (درخواست کاربر: فقط با ماوس رول بالا پایین بشه)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onWheelHandler = (e: WheelEvent) => {
      // تفکیک کامل غلتک ماوس: جلوگیری از بالا و پایین شدن صفحه اصلی هنگام چرخیدن روی کاروسل
      e.preventDefault();
      e.stopPropagation();

      const now = Date.now();
      if (now - lastWheelTimeRef.current < 160) return;
      if (Math.abs(e.deltaY) > 10) {
        lastWheelTimeRef.current = now;
        if (e.deltaY > 0) {
          handleNext();
        } else {
          handlePrev();
        }
      }
    };

    container.addEventListener('wheel', onWheelHandler, { passive: false });
    return () => {
      container.removeEventListener('wheel', onWheelHandler);
    };
  }, [handleNext, handlePrev]);

  // ۲. مدیریت هوشمند لمس گوشی و تبلت با تفکیک کامل از اسکرول صفحه (حل مشکل بالا پایین شدن کل صفحه در گوشی)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let touchStartY = 0;
    let isSwiping = false;

    const onTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0].clientY;
      isSwiping = true;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isSwiping) return;
      const currentY = e.touches[0].clientY;
      const diff = currentY - touchStartY;

      // جلوگیری از اسکرول کل صفحه گوشی در حین بالا و پایین کشیدن رول کارت‌ها
      if (Math.abs(diff) > 8) {
        if (e.cancelable) {
          e.preventDefault();
        }
      }

      if (diff > 35) {
        handlePrev();
        touchStartY = currentY;
        isSwiping = false;
      } else if (diff < -35) {
        handleNext();
        touchStartY = currentY;
        isSwiping = false;
      }
    };

    const onTouchEnd = () => {
      isSwiping = false;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    container.addEventListener('touchcancel', onTouchEnd, { passive: true });

    return () => {
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [handleNext, handlePrev]);

  // ۳. کنترل با درگ ماوس روی دسکتاپ
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    startYRef.current = e.clientY;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const diff = e.clientY - startYRef.current;
    if (diff > 40) {
      handlePrev();
      startYRef.current = e.clientY;
      isDraggingRef.current = false;
    } else if (diff < -40) {
      handleNext();
      startYRef.current = e.clientY;
      isDraggingRef.current = false;
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // ۴. کنترل با کلیدهای جهت‌نمای کیبورد (ArrowUp / ArrowDown)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
      e.preventDefault();
      handleNext();
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
      e.preventDefault();
      handlePrev();
    }
  };

  if (items.length === 0) return null;

  return (
    <div 
      ref={containerRef}
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full h-[410px] sm:h-[430px] flex items-center justify-center perspective outline-none select-none overflow-hidden py-4 cursor-grab active:cursor-grabbing touch-none overscroll-contain"
    >
      {/* نشانگر موقعیت کارت (شمارنده و دکمه‌های ناوبری سریع در گوشه سمت راست) */}
      <div className="absolute top-1 right-2 sm:right-4 z-40 flex items-center gap-1.5 bg-[#091124]/90 px-3 py-1 rounded-full border border-[#1b2b52] text-xs font-mono text-cyan-300 shadow-md">
        <span>{toFaDigits(activeIndex + 1)}</span>
        <span className="text-blue-500/50">/</span>
        <span className="text-slate-400">{toFaDigits(items.length)}</span>

        <div className="flex items-center gap-0.5 mr-1 pr-1 border-r border-[#1b2b52]">
          <button
            type="button"
            disabled={activeIndex === 0}
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            className={`p-1 rounded-md transition-all ${
              activeIndex === 0 ? 'text-slate-600 cursor-not-allowed' : 'text-blue-300 hover:text-white hover:bg-blue-900/40 cursor-pointer'
            }`}
            title="کارت قبلی (بالا)"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={activeIndex >= items.length - 1}
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            className={`p-1 rounded-md transition-all ${
              activeIndex >= items.length - 1 ? 'text-slate-600 cursor-not-allowed' : 'text-blue-300 hover:text-white hover:bg-blue-900/40 cursor-pointer'
            }`}
            title="کارت بعدی (پایین)"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ماسک گرادیانت بالا و پایین برای القای عمق بینهایت سه‌بعدی */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-14 bg-gradient-to-b from-[#030816] via-[#030816]/70 to-transparent z-20" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#030816] via-[#030816]/70 to-transparent z-20" />

      {/* لیست ۵ کارت سه‌بعدی در چرخه عمودی */}
      <div className="w-full max-w-5xl h-full relative flex items-center justify-center preserve-3d px-2 sm:px-4">
        {items.map((req, idx) => {
          const diff = idx - activeIndex;
          // فقط تا ۲ موقعیت بالا و پایین (مجموع ۵ کارت) در صحنه رندر می‌شوند
          if (Math.abs(diff) > 2) return null;

          const isCenter = diff === 0;
          const cardKey = req.code || req.workOrderCode || `${isArchive ? 'arch' : 'active'}-${idx}-${req.title}`;
          const isFlipped = !!flippedCards[cardKey];
          const dateBadge = formatPersianDateBadge(isArchive ? (req.completedAt || req.created) : (req.created || req.woDate));

          // محاسبات دقیق فاصله عمودی، مقیاس و زاویه سه‌بعدی
          let translateY = 0;
          let scale = 1;
          let opacity = 1;
          let zIndex = 30;
          let rotateX = 0;
          let translateZ = 0;

          if (diff === 0) {
            translateY = 0;
            scale = 1;
            opacity = 1;
            zIndex = 30;
            rotateX = 0;
            translateZ = 0;
          } else if (diff === -1) {
            translateY = -92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = 10;
            translateZ = -45;
          } else if (diff === 1) {
            translateY = 92;
            scale = 0.88;
            opacity = 0.65;
            zIndex = 20;
            rotateX = -10;
            translateZ = -45;
          } else if (diff === -2) {
            translateY = -170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = 18;
            translateZ = -95;
          } else if (diff === 2) {
            translateY = 170;
            scale = 0.76;
            opacity = 0.28;
            zIndex = 10;
            rotateX = -18;
            translateZ = -95;
          }

          return (
            <div
              key={cardKey}
              onClick={() => {
                if (!isCenter) {
                  setActiveIndex(idx);
                }
              }}
              style={{
                transform: `translateY(${translateY}px) translateZ(${translateZ}px) rotateX(${rotateX}deg) scale(${scale})`,
                opacity,
                zIndex,
                pointerEvents: isCenter ? 'auto' : 'auto'
              }}
              className={`carousel-card absolute w-full max-w-4xl h-[126px] sm:h-[114px] transition-all duration-500 ease-out preserve-3d ${
                !isCenter ? 'cursor-pointer hover:opacity-80' : ''
              }`}
            >
              {/* بدنه چرخشی سه‌بعدی (3D Flip Inner Card) */}
              <div 
                className={`card-inner w-full h-full relative preserve-3d transition-transform duration-1500 ease-in-out ${
                  isFlipped ? 'rotate-y-180' : ''
                }`}
              >
                {/* نمای روی کارت (Front Face) */}
                <div 
                  className={`absolute inset-0 w-full h-full backface-hidden bg-[#0c162d] border ${
                    isCenter ? 'border-cyan-500/60 shadow-2xl shadow-blue-950/60' : 'border-[#1b2b52] shadow-lg shadow-black/40'
                  } rounded-2xl p-3.5 sm:px-5 flex items-center justify-between transition-colors ${
                    isFlipped ? 'pointer-events-none' : 'pointer-events-auto'
                  }`}
                >
                  <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                    {/* جعبه تاریخ سرمه‌ای کارخانه با فونت درشت */}
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-[#111e3c] border border-blue-600/30 flex flex-col items-center justify-center shrink-0 text-blue-200 shadow-inner">
                      <Calendar className={`w-4 h-4 mb-0.5 ${isArchive ? 'text-emerald-400' : 'text-cyan-400'}`} />
                      <span className="text-[11px] sm:text-xs font-bold text-white font-mono leading-none">
                        {dateBadge.day} {dateBadge.month}
                      </span>
                    </div>

                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm sm:text-base font-bold text-white leading-snug truncate">
                          {req.title}
                        </h3>
                        <span className="text-[10px] font-mono font-bold text-cyan-400 bg-[#112344] px-2 py-0.5 rounded border border-blue-600/30">
                          {req.code}
                        </span>
                        {isArchive ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-600/40">
                            مختومه ✓
                          </span>
                        ) : req.priority?.includes('ایمنی') ? (
                          <span className="text-[9px] font-bold px-2 py-0.2 rounded bg-rose-950/80 text-rose-300 border border-rose-600/40">
                            {req.priority}
                          </span>
                        ) : null}
                        {req.durationMinutes && (
                          <span className="text-[10px] text-slate-400 font-mono">
                            ({fa(req.durationMinutes)} دقیقه)
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-xs text-blue-300/80">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-blue-400" />
                          <span>{req.place}</span>
                        </span>
                        <span className="text-blue-500/40">•</span>
                        <span className="truncate max-w-[150px]">
                          تکنسین: <strong className="text-slate-200 font-medium">{req.technician || (isArchive ? '—' : 'بدون تکنسین')}</strong>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* دکمه جزئیات با انیمیشن چرخش ۱.۵ ثانیه‌ای سه‌بعدی */}
                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleCardFlip(cardKey);
                      }}
                      className="bg-[#13203c] hover:bg-blue-900/50 border border-blue-600/40 text-blue-200 hover:text-white text-xs px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-sm active:scale-95"
                    >
                      <span>{isArchive ? 'جزئیات سابقه' : 'جزئیات'}</span>
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* نمای پشت کارت (Back Face - Rotated 180 deg) */}
                <div 
                  className={`absolute inset-0 w-full h-full backface-hidden rotate-y-180 bg-[#0c162d] border border-blue-600/60 rounded-2xl p-3.5 sm:px-5 flex items-center justify-between shadow-2xl shadow-blue-950/60 ${
                    isFlipped ? 'pointer-events-auto' : 'pointer-events-none'
                  }`}
                >
                  <div className="space-y-1 text-xs min-w-0 pr-1">
                    <div className="flex items-center gap-3 text-slate-300 flex-wrap">
                      <span>شناسه: <b className="font-mono text-cyan-300">{req.code}</b></span>
                      <span>تکنسین: <b className="text-white">{req.technician || 'تعیین نشده'}</b></span>
                      <span>وضعیت: <b className={isArchive ? 'text-emerald-300' : 'text-amber-300'}>{req.status}</b></span>
                      {req.operationType && (
                        <span>تخصص: <b className="text-blue-200">{req.operationType}</b></span>
                      )}
                    </div>
                    {isArchive ? (
                      <>
                        {req.actionDetails && (
                          <p className="text-[11px] text-slate-300 truncate max-w-sm">
                            اقدام: {req.actionDetails}
                          </p>
                        )}
                        {req.consumables && req.consumables.length > 0 && (
                          <p className="text-[11px] text-amber-300 truncate">
                            لوازم: {req.consumables.map((c: ConsumableItem) => `${c.name} (${c.count})`).join('، ')}
                          </p>
                        )}
                      </>
                    ) : (
                      <p className="text-[11px] text-slate-400 truncate max-w-xl">
                        شرح عیب: {req.description || 'ثبت نشده'}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleCardFlip(cardKey);
                      }}
                      className="text-slate-400 hover:text-slate-200 text-xs px-3 py-2 rounded-xl border border-slate-700 hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>بازگشت</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    
                    {isArchive ? (
                      <>
                        {onViewRequestDetails && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              onViewRequestDetails(req);
                            }}
                            className="bg-cyan-700 hover:bg-cyan-600 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-1 cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>شناسنامه</span>
                          </button>
                        )}

                        {onRestoreFromArchive && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              onRestoreFromArchive(req.code);
                            }}
                            className="bg-[#13203c] hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-2 rounded-xl transition-colors flex items-center gap-1 cursor-pointer border border-slate-700"
                            title="بازگردانی به کارهای جاری"
                          >
                            <RotateCcw className="w-3 h-3 text-amber-400" />
                            <span className="hidden sm:inline">بازگردانی</span>
                          </button>
                        )}
                      </>
                    ) : (
                      onCompleteWorkOrder && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onCompleteWorkOrder(req);
                          }}
                          className="bg-cyan-700 hover:bg-cyan-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>ثبت فعالیت و بستن</span>
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      )
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
