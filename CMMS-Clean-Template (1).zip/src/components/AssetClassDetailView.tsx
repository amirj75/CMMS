import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import {
  FolderTree,
  Plus,
  Trash2,
  Check,
  X,
  Save,
  ArrowRight,
  Layers,
  Wrench,
  Activity,
  AlertTriangle,
  FileText,
  Clock,
  ShieldCheck,
  Upload,
  Download
} from 'lucide-react';

export interface AssetFamilyItem {
  id: string;
  name: string;
  group?: string;
  description?: string;
}

interface AssetClassDetailViewProps {
  family: AssetFamilyItem;
  onBack: () => void;
  onUpdateFamily?: (updated: AssetFamilyItem) => void;
  equipments?: any[];
}

// تب‌های صفحه (بدون تب پروفایل طبق دستور صریح کاربر)
type TabKey =
  | 'specs'
  | 'tree'
  | 'opParams'
  | 'cmParams'
  | 'failures'
  | 'archive'
  | 'maintenance'
  | 'equipments';

export const AssetClassDetailView: React.FC<AssetClassDetailViewProps> = ({
  family,
  onBack,
  onUpdateFamily,
  equipments = []
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('specs');

  // فرم مشخصات اصلی (مشخصات)
  const [code, setCode] = useState(family.id || '');
  const [name, setName] = useState(family.name || '');
  const [group, setGroup] = useState(family.group || '');
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  useEffect(() => {
    setCode(family.id || '');
    setName(family.name || '');
    setGroup(family.group || '');
  }, [family]);

  // کلید ذخیره‌سازی داده‌های این خانواده در LocalStorage
  const storageKey = `pmworks_asset_class_data_${family.id}`;

  // وضعیت داده‌های هر بخش (کاملاً خالی طبق دستور صریح کاربر، آماده ثبت توسط کاربر)
  const [customData, setCustomData] = useState<{
    tree: Array<{ id: string; code: string; title: string; level: string; desc: string }>;
    opParams: Array<{ id: string; code: string; title: string; unit: string; normalVal: string; period: string }>;
    cmParams: Array<{ id: string; code: string; method: string; point: string; range: string; unit: string }>;
    failures: Array<{ id: string; code: string; title: string; cause: string; solution: string }>;
    archive: Array<{ id: string; code: string; title: string; docType: string; version: string; date: string }>;
    maintenance: Array<{ id: string; code: string; title: string; type: string; frequency: string; role: string }>;
    equipments: Array<{ id: string; code: string; name: string; location: string; status: string }>;
  }>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return {
      tree: [],
      opParams: [],
      cmParams: [],
      failures: [],
      archive: [],
      maintenance: [],
      equipments: []
    };
  });

  useEffect(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setCustomData(JSON.parse(saved));
        return;
      }
    } catch {}
    setCustomData({
      tree: [],
      opParams: [],
      cmParams: [],
      failures: [],
      archive: [],
      maintenance: [],
      equipments: []
    });
  }, [storageKey]);

  const saveCustomData = (newData: typeof customData) => {
    setCustomData(newData);
    try {
      localStorage.setItem(storageKey, JSON.stringify(newData));
    } catch {}
    window.dispatchEvent(new CustomEvent('asset_class_data_updated', { detail: { familyId: family.id } }));
  };

  const handleSaveSpecs = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const updated: AssetFamilyItem = {
      ...family,
      id: code.trim(),
      name: name.trim(),
      group: group.trim()
    };
    if (onUpdateFamily) {
      onUpdateFamily(updated);
    }
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 2500);
  };

  // مودال ثبت سطر جدید برای هر تب
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [modalFormData, setModalFormData] = useState<Record<string, string>>({});

  // مودال ورود با اکسل برای حالت‌های خرابی و فعالیت‌های نگه‌داشت
  const [excelImportTarget, setExcelImportTarget] = useState<'failures' | 'maintenance' | null>(null);
  const [excelPasteText, setExcelPasteText] = useState('');
  const [excelParsedRows, setExcelParsedRows] = useState<Array<{ code: string; title: string }>>([]);
  const [excelErrorMsg, setExcelErrorMsg] = useState<string | null>(null);
  const [excelRawGrid, setExcelRawGrid] = useState<any[][]>([]);
  const [excelDataStartRow, setExcelDataStartRow] = useState<number>(0);
  const [excelColOptions, setExcelColOptions] = useState<Array<{ idx: number; label: string }>>([]);
  const [excelSelectedCodeCol, setExcelSelectedCodeCol] = useState<number>(-1);
  const [excelSelectedTitleCol, setExcelSelectedTitleCol] = useState<number>(-1);

  const resetExcelColumnState = () => {
    setExcelRawGrid([]);
    setExcelDataStartRow(0);
    setExcelColOptions([]);
    setExcelSelectedCodeCol(-1);
    setExcelSelectedTitleCol(-1);
  };

  const handleOpenExcelImport = (target: 'failures' | 'maintenance') => {
    setExcelImportTarget(target);
    setExcelPasteText('');
    setExcelParsedRows([]);
    setExcelErrorMsg(null);
    resetExcelColumnState();
  };

  const handleDownloadClassExcelTemplate = () => {
    if (!excelImportTarget) return;
    const isFailure = excelImportTarget === 'failures';
    const sampleRows = isFailure
      ? [
          { 'کد خرابی': 'FL-01', 'عنوان حالت خرابی': 'لرزش غیرعادی اسپیندل' },
          { 'کد خرابی': 'FL-02', 'عنوان حالت خرابی': 'افت فشار روغن هیدرولیک' }
        ]
      : [
          { 'کد تجهیز': 'TUTN01', 'عنوان فعالیت نگه‌داشت': 'بررسی و تنظیم فشار روغن هیدرولیک' },
          { 'کد تجهیز': 'TUTN01', 'عنوان فعالیت نگه‌داشت': 'آچارکشی و روانکاری محورهای حرکتی' }
        ];
    const ws = XLSX.utils.json_to_sheet(sampleRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, isFailure ? 'حالت‌های خرابی' : 'فعالیت‌های نگه‌داشت');
    XLSX.writeFile(wb, isFailure ? 'قالب_حالت_خرابی.xlsx' : 'قالب_فعالیت_نگهداشت.xlsx');
  };

  const normalizeExcelCellHeader = (val: any) =>
    String(val ?? '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/ي/g, 'ی')
      .replace(/ى/g, 'ی')
      .replace(/ك/g, 'ک')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();

  const toEnDigitsExcel = (val: string) =>
    String(val ?? '')
      .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
      .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

  const looksLikeShortCode = (val: string) => {
    const s = toEnDigitsExcel(val).trim();
    if (!s || s.length > 48) return false;
    return /^[a-zA-Z0-9\-_/. ]+$/.test(s) || /^\d+$/.test(s);
  };

  const isNumericRowIndexCell = (val: string) => {
    const s = toEnDigitsExcel(val).trim();
    return /^\d+$/.test(s) && s.length <= 5;
  };

  const isRowIndexHeader = (h: string) => {
    const c = h.replace(/[\s_\-:]/g, '');
    return (
      c === 'ردیف' ||
      c === 'شماره' ||
      c === 'شمارهردیف' ||
      c === 'row' ||
      c === 'radif' ||
      c === 'no' ||
      c === '#' ||
      c === 'index'
    );
  };

  const hasDescriptiveText = (val: string) => {
    const s = String(val ?? '').trim();
    if (!s) return false;
    if (/[\u0600-\u06FF]/.test(s)) return true;
    return !looksLikeShortCode(s) && !isNumericRowIndexCell(s);
  };

  const getExcelColLetter = (idx: number) => {
    let n = idx + 1;
    let letter = '';
    while (n > 0) {
      const rem = (n - 1) % 26;
      letter = String.fromCharCode(65 + rem) + letter;
      n = Math.floor((n - 1) / 26);
    }
    return letter;
  };

  const getCodeHeaderScore = (h: string): number => {
    if (!h || isRowIndexHeader(h)) return 0;
    if (
      h.includes('کد تجهیز') ||
      h.includes('کد دستگاه') ||
      h.includes('کد ماشین') ||
      h.includes('شناسه تجهیز') ||
      h.includes('شماره تجهیز') ||
      h.includes('equipment code') ||
      h.includes('asset code') ||
      h === 'tag'
    ) {
      return 4;
    }
    if (
      h.includes('کد فعالیت') ||
      h.includes('کد خرابی') ||
      h.includes('کد آیتم') ||
      h.includes('کد سرویس') ||
      h.includes('کد pm') ||
      h.includes('activity code') ||
      h.includes('task code') ||
      h.includes('failure code')
    ) {
      return 3;
    }
    if (
      h === 'کد' ||
      h === 'code' ||
      h === 'id' ||
      h.includes('کد') ||
      h.includes('code') ||
      h.includes('شناسه')
    ) {
      return 2;
    }
    return 0;
  };

  const getTitleHeaderScore = (h: string): number => {
    if (!h || isRowIndexHeader(h)) return 0;
    // هر ستونی که عنوان کد یا شناسه دارد به هیچ وجه ستون عنوان فعالیت نیست
    if (
      getCodeHeaderScore(h) > 0 ||
      h.includes('کد') ||
      h.includes('code') ||
      h.includes('شناسه') ||
      h === 'id' ||
      h === 'tag'
    ) {
      return 0;
    }
    if (
      (h.includes('تجهیز') ||
        h.includes('دستگاه') ||
        h.includes('ماشین') ||
        h.includes('موقعیت') ||
        h.includes('سالن') ||
        h.includes('گروه') ||
        h.includes('دوره') ||
        h.includes('تناوب') ||
        h.includes('واحد') ||
        h.includes('مسئول') ||
        h.includes('اپراتور') ||
        h.includes('تاریخ')) &&
      !h.includes('فعالیت') &&
      !h.includes('خرابی') &&
      !h.includes('شرح') &&
      !h.includes('عنوان') &&
      !h.includes('کار') &&
      !h.includes('چک') &&
      !h.includes('موضوع') &&
      !h.includes('توضیح')
    ) {
      return 0;
    }
    if (
      h.includes('عنوان فعالیت') ||
      h.includes('شرح فعالیت') ||
      h.includes('نام فعالیت') ||
      h.includes('شرح کار') ||
      h.includes('عنوان کار') ||
      h.includes('عنوان حالت خرابی') ||
      h.includes('شرح خرابی') ||
      h.includes('حالت خرابی') ||
      h.includes('activity title') ||
      h.includes('activity name') ||
      h.includes('task title') ||
      h.includes('task name')
    ) {
      return 5;
    }
    if (
      h.includes('عنوان') ||
      h.includes('شرح') ||
      h.includes('چک لیست') ||
      h.includes('چک‌لیست') ||
      h.includes('دستورالعمل') ||
      h.includes('موضوع') ||
      h.includes('توضیح') ||
      h.includes('title') ||
      h.includes('description') ||
      h.includes('checklist') ||
      h.includes('subject')
    ) {
      return 4;
    }
    if (
      h.includes('فعالیت') ||
      h.includes('خرابی') ||
      h.includes('اقدام') ||
      h.includes('سرویس') ||
      h.includes('کار') ||
      h.includes('activity') ||
      h.includes('task') ||
      h.includes('work')
    ) {
      return 3;
    }
    if (h === 'name' || h === 'نام') {
      return 1;
    }
    return 0;
  };

  const extractRowsUsingMapping = (
    nonEmptyRows: any[][],
    startIdx: number,
    codeColIdx: number,
    titleColIdx: number,
    rankedCodeFallbackCols: number[],
    isFailure: boolean
  ): Array<{ code: string; title: string }> => {
    const baseCount = isFailure ? customData.failures.length : customData.maintenance.length;
    const rows: Array<{ code: string; title: string }> = [];

    for (let rIdx = startIdx; rIdx < nonEmptyRows.length; rIdx++) {
      const row = nonEmptyRows[rIdx];
      let rawCode = '';
      let rawTitle = '';

      if (codeColIdx >= 0) {
        rawCode = String(row[codeColIdx] ?? '').trim();
      }
      if (!rawCode && rankedCodeFallbackCols.length > 0) {
        for (const cCol of rankedCodeFallbackCols) {
          if (cCol === titleColIdx) continue;
          const val = String(row[cCol] ?? '').trim();
          if (val) {
            rawCode = val;
            break;
          }
        }
      }

      if (titleColIdx >= 0) {
        rawTitle = String(row[titleColIdx] ?? '').trim();
      }

      // اگر ستون عنوان خالی بود یا اشتباهاً دقیقاً همان کد بود، دنبال ستون متنی توصیفی بگرد
      if (!rawTitle || (rawCode && rawTitle === rawCode && !hasDescriptiveText(rawTitle))) {
        const descriptiveIdx = row.findIndex((cell, idx) => {
          if (idx === codeColIdx || rankedCodeFallbackCols.includes(idx)) return false;
          const v = String(cell ?? '').trim();
          return v !== '' && v !== rawCode && hasDescriptiveText(v);
        });
        if (descriptiveIdx !== -1) {
          rawTitle = String(row[descriptiveIdx] ?? '').trim();
        } else if (!rawTitle) {
          const anyExtra = row.findIndex((cell, idx) => {
            if (idx === codeColIdx || rankedCodeFallbackCols.includes(idx)) return false;
            const v = String(cell ?? '').trim();
            return v !== '' && v !== rawCode && !isNumericRowIndexCell(v);
          });
          if (anyExtra !== -1) rawTitle = String(row[anyExtra] ?? '').trim();
        }
      }

      if (!rawTitle && !rawCode) continue;
      if (!rawTitle && rawCode) {
        rawTitle = rawCode;
        rawCode = '';
      }

      const resolvedCode = isFailure
        ? (rawCode || `FL-${String(baseCount + rows.length + 1).padStart(2, '0')}`)
        : rawCode;

      rows.push({
        code: resolvedCode,
        title: rawTitle
      });
    }

    return rows;
  };

  const analyzeAndParseExcelGrid = (
    rawGrid: any[][],
    isFailure: boolean
  ): {
    rows: Array<{ code: string; title: string }>;
    nonEmptyRows: any[][];
    dataStartRow: number;
    colOptions: Array<{ idx: number; label: string }>;
    codeColIdx: number;
    titleColIdx: number;
  } => {
    const nonEmptyRows = rawGrid.filter(
      r => Array.isArray(r) && r.some(cell => String(cell ?? '').trim() !== '')
    );
    if (nonEmptyRows.length === 0) {
      return {
        rows: [],
        nonEmptyRows: [],
        dataStartRow: 0,
        colOptions: [],
        codeColIdx: -1,
        titleColIdx: -1
      };
    }

    const maxCols = nonEmptyRows.reduce((m, r) => Math.max(m, r.length), 0);
    let headerRowIdx = -1;
    let rankedCodeColIndices: number[] = [];
    let titleColIdx = -1;

    for (let r = 0; r < Math.min(nonEmptyRows.length, 25); r++) {
      const rowNorm = nonEmptyRows[r].map(normalizeExcelCellHeader);
      const codeCols = rowNorm
        .map((h, idx) => ({ idx, score: getCodeHeaderScore(h) }))
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .map(x => x.idx);

      // ستون‌های کد به طور کامل از کاندیدهای عنوان حذف می‌شوند
      const titleCols = rowNorm
        .map((h, idx) => ({ idx, score: getTitleHeaderScore(h) }))
        .filter(x => x.score > 0 && !codeCols.includes(x.idx))
        .sort((a, b) => b.score - a.score)
        .map(x => x.idx);

      if (codeCols.length > 0 && titleCols.length > 0) {
        headerRowIdx = r;
        rankedCodeColIndices = codeCols;
        titleColIdx = titleCols[0];
        break;
      }
      if (codeCols.length > 0 && headerRowIdx === -1) {
        const fallbackTitleIdx = rowNorm.findIndex(
          (h, idx) => !codeCols.includes(idx) && h !== '' && !isRowIndexHeader(h)
        );
        if (fallbackTitleIdx !== -1) {
          headerRowIdx = r;
          rankedCodeColIndices = codeCols;
          titleColIdx = fallbackTitleIdx;
        }
      }
    }

    const isHeaderRow = headerRowIdx !== -1;
    const dataStartRow = isHeaderRow ? headerRowIdx + 1 : 0;
    const sampleRows = nonEmptyRows.slice(dataStartRow, dataStartRow + 30);

    // تحلیل آماری محتوای ستون‌ها برای تشخیص دقیق ستون متنی عنوان و ستون کد (حتی اگر سرتیتر غیرمعمول یا چند کد وجود داشته باشد)
    const colStats = Array.from({ length: maxCols }, (_, colIdx) => {
      let nonEmptyCount = 0;
      let descriptiveCount = 0;
      let codeLikeCount = 0;
      let rowNumCount = 0;
      for (const r of sampleRows) {
        const val = String(r[colIdx] ?? '').trim();
        if (!val) continue;
        nonEmptyCount++;
        if (isNumericRowIndexCell(val)) {
          rowNumCount++;
        } else if (hasDescriptiveText(val)) {
          descriptiveCount++;
        } else if (looksLikeShortCode(val)) {
          codeLikeCount++;
        }
      }
      return { colIdx, nonEmptyCount, descriptiveCount, codeLikeCount, rowNumCount };
    });

    // اگر ستون عنوان انتخاب‌شده عملاً حاوی متن فارسی/توصیفی نیست، اما ستون غیرکد دیگری پر از متن توصیفی است، جایگزین کن
    if (titleColIdx !== -1 && sampleRows.length > 0) {
      const chosenStat = colStats[titleColIdx];
      const betterTextCol = [...colStats]
        .filter(
          c =>
            c.colIdx !== rankedCodeColIndices[0] &&
            !rankedCodeColIndices.includes(c.colIdx) &&
            c.descriptiveCount > 0
        )
        .sort((a, b) => b.descriptiveCount - a.descriptiveCount)[0];
      if (chosenStat && chosenStat.descriptiveCount === 0 && betterTextCol) {
        titleColIdx = betterTextCol.colIdx;
      }
    }

    // اگر سرتیتر پیدا نشد، بر اساس الگوی محتوای ستون‌ها انتخاب کن
    let primaryCodeColIdx = rankedCodeColIndices[0] ?? -1;
    if (!isHeaderRow || primaryCodeColIdx === -1 || titleColIdx === -1) {
      if (titleColIdx === -1) {
        const bestTextCol = [...colStats]
          .filter(c => c.colIdx !== primaryCodeColIdx && c.descriptiveCount > 0)
          .sort((a, b) => b.descriptiveCount - a.descriptiveCount)[0];
        if (bestTextCol) {
          titleColIdx = bestTextCol.colIdx;
        } else {
          const nonRowCol = [...colStats]
            .filter(c => c.colIdx !== primaryCodeColIdx && c.nonEmptyCount > 0 && c.rowNumCount < c.nonEmptyCount)
            .sort((a, b) => b.nonEmptyCount - a.nonEmptyCount);
          titleColIdx = nonRowCol[nonRowCol.length - 1]?.colIdx ?? (maxCols > 1 ? 1 : 0);
        }
      }

      if (primaryCodeColIdx === -1) {
        const bestCodeCol = [...colStats]
          .filter(
            c =>
              c.colIdx !== titleColIdx &&
              c.codeLikeCount > 0 &&
              c.rowNumCount < c.nonEmptyCount
          )
          .sort((a, b) => b.codeLikeCount - a.codeLikeCount)[0];
        if (bestCodeCol) {
          primaryCodeColIdx = bestCodeCol.colIdx;
        }
      }
    }

    // اگر ستون کد اصلی در ردیف‌های نمونه خالی است ولی کد دومی (مثلاً کد فعالیت) پر است، آن را به عنوان ستون اصلی کد بگیر
    if (primaryCodeColIdx !== -1 && rankedCodeColIndices.length > 1 && sampleRows.length > 0) {
      const primaryStat = colStats[primaryCodeColIdx];
      if (!primaryStat || primaryStat.nonEmptyCount === 0) {
        const filledFallback = rankedCodeColIndices.find(
          idx => idx !== titleColIdx && (colStats[idx]?.nonEmptyCount ?? 0) > 0
        );
        if (filledFallback !== undefined) {
          primaryCodeColIdx = filledFallback;
        }
      }
    }

    // ساخت لیست ستون‌ها برای نمایش در کشویی انتخاب ستون
    const colOptions: Array<{ idx: number; label: string }> = [];
    for (let c = 0; c < maxCols; c++) {
      const headerLabel = isHeaderRow ? String(nonEmptyRows[headerRowIdx]?.[c] ?? '').trim() : '';
      const firstSample = String(
        nonEmptyRows.slice(dataStartRow).find(r => String(r[c] ?? '').trim() !== '')?.[c] ?? ''
      ).trim();
      const hasAnyData = Boolean(headerLabel || firstSample);
      if (!hasAnyData) continue;
      const sampleSnippet = firstSample ? ` (${firstSample.slice(0, 22)}${firstSample.length > 22 ? '...' : ''})` : '';
      const baseName = headerLabel || `ستون ${getExcelColLetter(c)}`;
      colOptions.push({
        idx: c,
        label: headerLabel ? `${getExcelColLetter(c)}: ${baseName}` : `${baseName}${sampleSnippet}`
      });
    }

    const rows = extractRowsUsingMapping(
      nonEmptyRows,
      dataStartRow,
      primaryCodeColIdx,
      titleColIdx,
      rankedCodeColIndices,
      isFailure
    );

    return {
      rows,
      nonEmptyRows,
      dataStartRow,
      colOptions,
      codeColIdx: primaryCodeColIdx,
      titleColIdx
    };
  };

  const expandSheetMergesToGrid = (ws: XLSX.WorkSheet): any[][] => {
    const grid: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }) as any[][];
    const merges = (ws['!merges'] || []) as Array<{ s: { r: number; c: number }; e: { r: number; c: number } }>;
    merges.forEach(m => {
      const topVal = grid[m.s.r]?.[m.s.c];
      if (topVal === undefined || topVal === null || String(topVal).trim() === '') return;
      // ادغام‌های افقی عریض (مانند تیتر بالای جدول) در ستون‌های دیگر کپی نشوند تا ستون‌بندی جدول به‌هم نخورد
      const isWideHorizontalBanner = m.s.r === m.e.r && m.e.c - m.s.c >= 2;
      if (isWideHorizontalBanner) return;
      for (let r = m.s.r; r <= m.e.r; r++) {
        if (!grid[r]) continue;
        for (let c = m.s.c; c <= m.e.c; c++) {
          if (grid[r][c] === undefined || grid[r][c] === null || String(grid[r][c]).trim() === '') {
            grid[r][c] = topVal;
          }
        }
      }
    });
    return grid;
  };

  const handleClassExcelColumnOverride = (nextCodeCol: number, nextTitleCol: number) => {
    if (!excelImportTarget || excelRawGrid.length === 0) return;
    setExcelSelectedCodeCol(nextCodeCol);
    setExcelSelectedTitleCol(nextTitleCol);
    const isFailure = excelImportTarget === 'failures';
    const rows = extractRowsUsingMapping(
      excelRawGrid,
      excelDataStartRow,
      nextCodeCol,
      nextTitleCol,
      [],
      isFailure
    );
    setExcelParsedRows(rows);
  };

  const handleClassExcelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !excelImportTarget) return;
    const isFailure = excelImportTarget === 'failures';
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) {
          setExcelErrorMsg('فایل اکسل خالی یا غیرقابل خواندن است.');
          return;
        }
        const wb = XLSX.read(buffer, { type: 'array' });
        let matchedResult: ReturnType<typeof analyzeAndParseExcelGrid> | null = null;
        for (const sheetName of wb.SheetNames) {
          const ws = wb.Sheets[sheetName];
          const grid = expandSheetMergesToGrid(ws);
          const analyzed = analyzeAndParseExcelGrid(grid, isFailure);
          if (analyzed.rows.length > 0) {
            matchedResult = analyzed;
            break;
          }
        }
        if (!matchedResult) {
          setExcelErrorMsg('هیچ ردیفی در فایل اکسل یافت نشد.');
          resetExcelColumnState();
          return;
        }
        setExcelRawGrid(matchedResult.nonEmptyRows);
        setExcelDataStartRow(matchedResult.dataStartRow);
        setExcelColOptions(matchedResult.colOptions);
        setExcelSelectedCodeCol(matchedResult.codeColIdx);
        setExcelSelectedTitleCol(matchedResult.titleColIdx);
        setExcelParsedRows(matchedResult.rows);
        setExcelErrorMsg(null);
      } catch (err: any) {
        setExcelErrorMsg('خطا در خواندن فایل اکسل: ' + (err?.message || 'فرمت نامعتبر'));
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const handleParseClassExcelPaste = (text: string) => {
    setExcelPasteText(text);
    if (!text.trim() || !excelImportTarget) {
      setExcelParsedRows([]);
      resetExcelColumnState();
      return;
    }
    const isFailure = excelImportTarget === 'failures';
    const grid = text
      .trim()
      .split(/\r?\n/)
      .map(line => (line.includes('\t') ? line.split('\t') : line.split(',')));
    const analyzed = analyzeAndParseExcelGrid(grid, isFailure);
    setExcelRawGrid(analyzed.nonEmptyRows);
    setExcelDataStartRow(analyzed.dataStartRow);
    setExcelColOptions(analyzed.colOptions);
    setExcelSelectedCodeCol(analyzed.codeColIdx);
    setExcelSelectedTitleCol(analyzed.titleColIdx);
    setExcelParsedRows(analyzed.rows);
    setExcelErrorMsg(null);
  };

  const handleConfirmClassExcelImport = () => {
    if (!excelImportTarget || excelParsedRows.length === 0) return;
    const copy = { ...customData };
    const now = Date.now();
    if (excelImportTarget === 'failures') {
      const added = excelParsedRows.map((r, idx) => ({
        id: `${now}-fl-${idx}`,
        code: r.code,
        title: r.title,
        cause: '',
        solution: ''
      }));
      copy.failures = [...copy.failures, ...added];
    } else {
      const added = excelParsedRows.map((r, idx) => ({
        id: `${now}-mn-${idx}`,
        code: r.code,
        title: r.title,
        type: 'PM',
        frequency: '',
        role: ''
      }));
      copy.maintenance = [...copy.maintenance, ...added];
    }
    saveCustomData(copy);
    setExcelImportTarget(null);
    setExcelParsedRows([]);
    setExcelPasteText('');
    resetExcelColumnState();
  };

  const handleOpenAddModal = () => {
    setModalFormData({});
    setIsAddModalOpen(true);
  };

  const handleSaveModalForm = () => {
    const id = Date.now().toString();
    const copy = { ...customData };

    if (activeTab === 'tree') {
      copy.tree = [
        ...copy.tree,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          level: modalFormData.level || 'سطح ۱',
          desc: modalFormData.desc || ''
        }
      ];
    } else if (activeTab === 'opParams') {
      copy.opParams = [
        ...copy.opParams,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          unit: modalFormData.unit || '',
          normalVal: modalFormData.normalVal || '',
          period: modalFormData.period || ''
        }
      ];
    } else if (activeTab === 'cmParams') {
      copy.cmParams = [
        ...copy.cmParams,
        {
          id,
          code: modalFormData.code || '',
          method: modalFormData.method || '',
          point: modalFormData.point || '',
          range: modalFormData.range || '',
          unit: modalFormData.unit || ''
        }
      ];
    } else if (activeTab === 'failures') {
      copy.failures = [
        ...copy.failures,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          cause: modalFormData.cause || '',
          solution: modalFormData.solution || ''
        }
      ];
    } else if (activeTab === 'archive') {
      copy.archive = [
        ...copy.archive,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          docType: modalFormData.docType || '',
          version: modalFormData.version || '1.0',
          date: modalFormData.date || ''
        }
      ];
    } else if (activeTab === 'maintenance') {
      copy.maintenance = [
        ...copy.maintenance,
        {
          id,
          code: modalFormData.code || '',
          title: modalFormData.title || '',
          type: modalFormData.type || 'PM',
          frequency: modalFormData.frequency || '',
          role: modalFormData.role || ''
        }
      ];
    } else if (activeTab === 'equipments') {
      copy.equipments = [
        ...copy.equipments,
        {
          id,
          code: modalFormData.code || '',
          name: modalFormData.name || '',
          location: modalFormData.location || '',
          status: modalFormData.status || 'فعال'
        }
      ];
    }

    saveCustomData(copy);
    setIsAddModalOpen(false);
  };

  const handleDeleteItem = (tab: TabKey, itemId: string) => {
    const copy = { ...customData };
    if (tab === 'tree') copy.tree = copy.tree.filter(i => i.id !== itemId);
    if (tab === 'opParams') copy.opParams = copy.opParams.filter(i => i.id !== itemId);
    if (tab === 'cmParams') copy.cmParams = copy.cmParams.filter(i => i.id !== itemId);
    if (tab === 'failures') copy.failures = copy.failures.filter(i => i.id !== itemId);
    if (tab === 'archive') copy.archive = copy.archive.filter(i => i.id !== itemId);
    if (tab === 'maintenance') copy.maintenance = copy.maintenance.filter(i => i.id !== itemId);
    if (tab === 'equipments') copy.equipments = copy.equipments.filter(i => i.id !== itemId);
    saveCustomData(copy);
  };

  const tabsList: Array<{ id: TabKey; label: string }> = [
    { id: 'specs', label: 'مشخصات' },
    { id: 'tree', label: 'درخت خانواده تجهیز' },
    { id: 'opParams', label: 'پارامتر های کارکردی' },
    { id: 'cmParams', label: 'پارامتر های CM' },
    { id: 'failures', label: 'حالت‌های خرابی' },
    { id: 'archive', label: 'آرشیو فنی' },
    { id: 'maintenance', label: 'فعالیت‌های نگه‌داشت' },
    { id: 'equipments', label: 'لیست تجهیزات' }
  ];

  return (
    <div className="w-full bg-[#0c162e]/90 backdrop-blur-xl rounded-2xl border border-indigo-500/20 shadow-2xl overflow-hidden select-text text-right font-sans space-y-0">
      
      {/* سربرگ بومی و هماهنگ با طراحی کل سامانه */}
      <div className="p-4 sm:p-5 border-b border-indigo-900/40 bg-[#070e22]/90 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        
        {/* عنوان و مشخصات خانواده تجهیز */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 shadow-sm shrink-0">
            <FolderTree size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-black text-white">
                شناسنامه خانواده تجهیز: {name || family.name}
              </h2>
              <span className="font-mono text-xs px-2.5 py-0.5 rounded-md bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold">
                {code || family.id}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              گروه تجهیزات: <span className="text-slate-300 font-bold">{group || family.group || 'ماشین‌آلات تولید'}</span>
            </p>
          </div>
        </div>

        {/* دکمه بازگشت به لیست خانواده‌ها */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#070e22] hover:bg-[#112042] border border-indigo-500/30 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
          >
            <ArrowRight size={14} />
            <span>بازگشت به لیست خانواده‌ها</span>
          </button>
        </div>
      </div>

      {/* نوار تب‌ها با تم تیره و مدرن سامانه */}
      <div className="border-b border-indigo-900/40 bg-[#070e22]/60 px-4 py-2.5 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 min-w-max">
          {tabsList.map(tab => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#132448] text-cyan-300 border border-cyan-500/40 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#112042] border border-transparent'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* محتوای تب فعال */}
      <div className="p-5 sm:p-6">
        
        {/* ۱. تب مشخصات */}
        {activeTab === 'specs' && (
          <form onSubmit={handleSaveSpecs} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* کد خانواده تجهیز */}
              <div className="bg-[#070e22]/90 border border-indigo-500/30 rounded-xl p-3.5 focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400/30 transition-all">
                <label className="text-xs font-bold text-slate-400 block mb-1.5">
                  کد خانواده تجهیز
                </label>
                <input
                  type="text"
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  placeholder="کد خانواده..."
                  className="w-full text-sm font-bold text-cyan-300 bg-transparent outline-none font-mono text-right"
                />
              </div>

              {/* نام خانواده تجهیز */}
              <div className="bg-[#070e22]/90 border border-indigo-500/30 rounded-xl p-3.5 focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400/30 transition-all">
                <label className="text-xs font-bold text-slate-400 block mb-1.5">
                  نام خانواده تجهیز
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="نام خانواده تجهیز..."
                  className="w-full text-sm font-bold text-white bg-transparent outline-none text-right"
                />
              </div>

              {/* نام گروه خانواده تجهیز */}
              <div className="bg-[#070e22]/90 border border-indigo-500/30 rounded-xl p-3.5 focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400/30 transition-all">
                <label className="text-xs font-bold text-slate-400 block mb-1.5">
                  نام گروه خانواده تجهیز
                </label>
                <input
                  type="text"
                  value={group}
                  onChange={e => setGroup(e.target.value)}
                  placeholder="گروه خانواده تجهیز..."
                  className="w-full text-sm font-bold text-slate-200 bg-transparent outline-none text-right"
                />
              </div>
            </div>

            {/* ذخیره مشخصات */}
            <div className="flex items-center justify-between pt-4 border-t border-indigo-900/40">
              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-black shadow-lg shadow-cyan-950/50 cursor-pointer transition-all active:scale-95"
                >
                  <Save size={15} />
                  <span>ذخیره مشخصات</span>
                </button>
                {isSavedAlert && (
                  <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 animate-in fade-in">
                    <Check size={15} />
                    <span>مشخصات با موفقیت ذخیره شد</span>
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={onBack}
                className="px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                بازگشت به جدول
              </button>
            </div>
          </form>
        )}

        {/* ۲. درخت خانواده تجهیز */}
        {activeTab === 'tree' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Plus size={15} />
                <span>افزودن زیرمجموعه جدید</span>
              </button>
              <span className="text-xs text-slate-400 font-bold">
                تعداد ردیف‌ها: {customData.tree.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد بخش / مجموعه</th>
                    <th className="p-3.5">نام بخش / زیرمجموعه</th>
                    <th className="p-3.5">سطح ساختار</th>
                    <th className="p-3.5">توضیحات</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.tree.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.tree.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.title || '—'}</td>
                        <td className="p-3.5 text-slate-300">{item.level || '—'}</td>
                        <td className="p-3.5 text-slate-400">{item.desc || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('tree', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۳. پارامتر های کارکردی */}
        {activeTab === 'opParams' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Plus size={15} />
                <span>افزودن پارامتر کارکردی</span>
              </button>
              <span className="text-xs text-slate-400 font-bold">
                تعداد پارامترها: {customData.opParams.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد پارامتر</th>
                    <th className="p-3.5">عنوان پارامتر</th>
                    <th className="p-3.5">واحد اندازه‌گیری</th>
                    <th className="p-3.5">مقدار اسمی / نرمال</th>
                    <th className="p-3.5">دوره ثبت</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.opParams.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.opParams.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.title || '—'}</td>
                        <td className="p-3.5 text-slate-300">{item.unit || '—'}</td>
                        <td className="p-3.5 font-mono text-purple-300">{item.normalVal || '—'}</td>
                        <td className="p-3.5 text-slate-400">{item.period || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('opParams', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۴. پارامتر های CM */}
        {activeTab === 'cmParams' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Plus size={15} />
                <span>افزودن پارامتر CM</span>
              </button>
              <span className="text-xs text-slate-400 font-bold">
                تعداد موارد: {customData.cmParams.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد CM</th>
                    <th className="p-3.5">روش پایش وضعیت</th>
                    <th className="p-3.5">محل / نقطه اندازه‌گیری</th>
                    <th className="p-3.5">محدوده مجاز</th>
                    <th className="p-3.5">واحد</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.cmParams.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.cmParams.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.method || '—'}</td>
                        <td className="p-3.5 text-slate-300">{item.point || '—'}</td>
                        <td className="p-3.5 font-mono text-purple-300">{item.range || '—'}</td>
                        <td className="p-3.5 text-slate-400">{item.unit || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('cmParams', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۵. حالت‌های خرابی */}
        {activeTab === 'failures' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenAddModal}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  <Plus size={15} />
                  <span>افزودن حالت خرابی</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleOpenExcelImport('failures')}
                  title="ورود از اکسل"
                  className="flex items-center justify-center p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-slate-700 transition-all shadow-md cursor-pointer"
                >
                  <Upload size={16} />
                </button>
              </div>
              <span className="text-xs text-slate-400 font-bold">
                تعداد حالات خرابی: {customData.failures.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد خرابی</th>
                    <th className="p-3.5">عنوان حالت خرابی</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.failures.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.failures.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-rose-400">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.title || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('failures', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۶. آرشیو فنی */}
        {activeTab === 'archive' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Plus size={15} />
                <span>افزودن مدرک فنی</span>
              </button>
              <span className="text-xs text-slate-400 font-bold">
                تعداد مدارک: {customData.archive.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد مدرک</th>
                    <th className="p-3.5">عنوان مدرک</th>
                    <th className="p-3.5">نوع سند</th>
                    <th className="p-3.5">نسخه</th>
                    <th className="p-3.5">تاریخ ثبت</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.archive.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.archive.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.title || '—'}</td>
                        <td className="p-3.5 text-slate-300">{item.docType || '—'}</td>
                        <td className="p-3.5 font-mono text-purple-300">{item.version || '1.0'}</td>
                        <td className="p-3.5 font-mono text-slate-400">{item.date || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('archive', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۷. فعالیت‌های نگه‌داشت */}
        {activeTab === 'maintenance' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenAddModal}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  <Plus size={15} />
                  <span>افزودن فعالیت نگه‌داشت</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleOpenExcelImport('maintenance')}
                  title="ورود از اکسل"
                  className="flex items-center justify-center p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-slate-700 transition-all shadow-md cursor-pointer"
                >
                  <Upload size={16} />
                </button>
              </div>
              <span className="text-xs text-slate-400 font-bold">
                تعداد فعالیت‌ها: {customData.maintenance.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد فعالیت</th>
                    <th className="p-3.5">عنوان فعالیت نگه‌داشت</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.maintenance.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.maintenance.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.title || '—'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('maintenance', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ۸. لیست تجهیزات مرتبط */}
        {activeTab === 'equipments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                <Plus size={15} />
                <span>افزودن تجهیز به این خانواده</span>
              </button>
              <span className="text-xs text-slate-400 font-bold">
                تعداد تجهیزات: {customData.equipments.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-indigo-500/20 bg-[#070e22]/90">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-[#070e22] text-slate-400 border-b border-indigo-900/40 font-bold">
                    <th className="p-3.5">کد دستگاه</th>
                    <th className="p-3.5">عنوان و نام دستگاه</th>
                    <th className="p-3.5">موقعیت استقرار</th>
                    <th className="p-3.5">وضعیت</th>
                    <th className="p-3.5 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#333538]/50">
                  {customData.equipments.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-500">
                        داده‌ای ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    customData.equipments.map(item => (
                      <tr key={item.id} className="hover:bg-[#112042]/50 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-cyan-300">{item.code || '—'}</td>
                        <td className="p-3.5 font-bold text-white">{item.name || '—'}</td>
                        <td className="p-3.5 text-slate-300">{item.location || '—'}</td>
                        <td className="p-3.5 text-slate-400">{item.status || 'فعال'}</td>
                        <td className="p-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem('equipments', item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* مودال عمومی ثبت آیتم با انتقال به ریشه صفحه (Portal) تا هرگز برش نخورد */}
      {isAddModalOpen && createPortal(
        <div dir="rtl" className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-[#0c162e] rounded-2xl shadow-2xl border border-indigo-500/30 p-5 space-y-4 text-right animate-in fade-in zoom-in-95">
            
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <span className="font-bold text-sm text-white">
                {activeTab === 'tree' && 'افزودن بخش به درخت خانواده'}
                {activeTab === 'opParams' && 'ثبت پارامتر کارکردی جدید'}
                {activeTab === 'cmParams' && 'ثبت پارامتر پایش وضعیت (CM)'}
                {activeTab === 'failures' && 'ثبت حالت خرابی جدید'}
                {activeTab === 'archive' && 'ثبت سند در آرشیو فنی'}
                {activeTab === 'maintenance' && 'ثبت فعالیت نگه‌داشت جدید'}
                {activeTab === 'equipments' && 'افزودن تجهیز به خانواده'}
              </span>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              
              {activeTab === 'tree' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد بخش / مجموعه</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">نام بخش / زیرمجموعه</label>
                    <input
                      type="text"
                      value={modalFormData.title || ''}
                      onChange={e => setModalFormData({ ...modalFormData, title: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">سطح ساختار</label>
                    <input
                      type="text"
                      value={modalFormData.level || ''}
                      placeholder="سطح ۱"
                      onChange={e => setModalFormData({ ...modalFormData, level: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">توضیحات</label>
                    <textarea
                      rows={2}
                      value={modalFormData.desc || ''}
                      onChange={e => setModalFormData({ ...modalFormData, desc: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'opParams' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد پارامتر</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">عنوان پارامتر</label>
                    <input
                      type="text"
                      value={modalFormData.title || ''}
                      onChange={e => setModalFormData({ ...modalFormData, title: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">واحد اندازه‌گیری</label>
                    <input
                      type="text"
                      value={modalFormData.unit || ''}
                      onChange={e => setModalFormData({ ...modalFormData, unit: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">مقدار اسمی / نرمال</label>
                    <input
                      type="text"
                      value={modalFormData.normalVal || ''}
                      onChange={e => setModalFormData({ ...modalFormData, normalVal: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">دوره ثبت</label>
                    <input
                      type="text"
                      value={modalFormData.period || ''}
                      placeholder="روزانه / هفتگی / ماهانه"
                      onChange={e => setModalFormData({ ...modalFormData, period: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'cmParams' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد CM</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">روش پایش وضعیت</label>
                    <input
                      type="text"
                      value={modalFormData.method || ''}
                      placeholder="ارتعاش‌سنجی / آنالیز روغن / ترموگرافی"
                      onChange={e => setModalFormData({ ...modalFormData, method: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">محل / نقطه اندازه‌گیری</label>
                    <input
                      type="text"
                      value={modalFormData.point || ''}
                      onChange={e => setModalFormData({ ...modalFormData, point: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">محدوده مجاز</label>
                    <input
                      type="text"
                      value={modalFormData.range || ''}
                      onChange={e => setModalFormData({ ...modalFormData, range: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">واحد</label>
                    <input
                      type="text"
                      value={modalFormData.unit || ''}
                      onChange={e => setModalFormData({ ...modalFormData, unit: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'failures' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد خرابی</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      placeholder="FL-01"
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">عنوان حالت خرابی</label>
                    <input
                      type="text"
                      value={modalFormData.title || ''}
                      onChange={e => setModalFormData({ ...modalFormData, title: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'archive' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد مدرک</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">عنوان مدرک</label>
                    <input
                      type="text"
                      value={modalFormData.title || ''}
                      onChange={e => setModalFormData({ ...modalFormData, title: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">نوع سند</label>
                    <input
                      type="text"
                      value={modalFormData.docType || ''}
                      placeholder="نقشه / کاتالوگ / راهنما"
                      onChange={e => setModalFormData({ ...modalFormData, docType: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">نسخه</label>
                    <input
                      type="text"
                      value={modalFormData.version || '1.0'}
                      onChange={e => setModalFormData({ ...modalFormData, version: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">تاریخ ثبت</label>
                    <input
                      type="text"
                      value={modalFormData.date || ''}
                      placeholder="۱۴۰۵/۰۸/۲۱"
                      onChange={e => setModalFormData({ ...modalFormData, date: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'maintenance' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد فعالیت</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      placeholder="PM-01"
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">عنوان فعالیت نگه‌داشت</label>
                    <input
                      type="text"
                      value={modalFormData.title || ''}
                      onChange={e => setModalFormData({ ...modalFormData, title: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

              {activeTab === 'equipments' && (
                <>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">کد دستگاه</label>
                    <input
                      type="text"
                      value={modalFormData.code || ''}
                      onChange={e => setModalFormData({ ...modalFormData, code: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">عنوان و نام دستگاه</label>
                    <input
                      type="text"
                      value={modalFormData.name || ''}
                      onChange={e => setModalFormData({ ...modalFormData, name: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">موقعیت استقرار</label>
                    <input
                      type="text"
                      value={modalFormData.location || ''}
                      onChange={e => setModalFormData({ ...modalFormData, location: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">وضعیت</label>
                    <input
                      type="text"
                      value={modalFormData.status || 'فعال'}
                      onChange={e => setModalFormData({ ...modalFormData, status: e.target.value })}
                      className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                </>
              )}

            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveModalForm}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                ذخیره سطر
              </button>
            </div>

          </div>
        </div>,
        document.body
      )}

      {/* مودال ورود از اکسل برای حالت‌های خرابی و فعالیت‌های نگه‌داشت */}
      {excelImportTarget && createPortal(
        <div dir="rtl" className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#0c162e] rounded-2xl shadow-2xl border border-emerald-500/35 p-5 space-y-4 text-right animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
              <span className="font-bold text-sm text-white">
                {excelImportTarget === 'failures'
                  ? 'ورود گروهی حالت‌های خرابی از اکسل'
                  : 'ورود گروهی فعالیت‌های نگه‌داشت از اکسل'}
              </span>
              <button
                type="button"
                onClick={() => setExcelImportTarget(null)}
                className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {excelErrorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {excelErrorMsg}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <button
                type="button"
                onClick={handleDownloadClassExcelTemplate}
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/35 text-indigo-300 border border-indigo-500/30 font-bold cursor-pointer transition-all"
              >
                <Download size={14} />
                <span>دانلود قالب اکسل</span>
              </button>
              <label className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/35 text-emerald-300 border border-emerald-500/30 font-bold cursor-pointer transition-all">
                <Upload size={14} />
                <span>انتخاب فایل اکسل</span>
                <input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleClassExcelFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            <div className="text-xs space-y-1.5">
              <label className="block text-slate-300 font-bold">
                {excelImportTarget === 'failures'
                  ? 'یا الصاق مستقیم از اکسل (ستون اول کد و ستون دوم عنوان):'
                  : 'یا الصاق مستقیم از اکسل (خواندن کد تجهیز/کد و عنوان فعالیت از اکسل):'}
              </label>
              <textarea
                rows={4}
                value={excelPasteText}
                onChange={e => handleParseClassExcelPaste(e.target.value)}
                placeholder={excelImportTarget === 'failures' ? 'FL-01\tلرزش غیرعادی اسپیندل' : 'TUTN01\tبررسی و تنظیم فشار روغن'}
                className="w-full bg-[#070e22] border border-indigo-500/30 rounded-xl p-2.5 text-white font-mono text-xs outline-none focus:border-emerald-400 resize-none"
              />
            </div>

            {excelColOptions.length >= 2 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-2.5 rounded-xl bg-[#070e22]/90 border border-cyan-500/25 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-cyan-300 mb-1">
                    {excelImportTarget === 'failures' ? 'ستون کد خرابی:' : 'ستون کد تجهیز / کد:'}
                  </label>
                  <select
                    value={excelSelectedCodeCol}
                    onChange={e => handleClassExcelColumnOverride(Number(e.target.value), excelSelectedTitleCol)}
                    className="w-full bg-[#0c162e] border border-indigo-500/35 rounded-lg px-2 py-1.5 text-white text-[11px] outline-none focus:border-cyan-400"
                  >
                    <option value={-1}>بدون ستون کد</option>
                    {excelColOptions.map(opt => (
                      <option key={opt.idx} value={opt.idx}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 mb-1">
                    {excelImportTarget === 'failures' ? 'ستون عنوان خرابی:' : 'ستون عنوان فعالیت:'}
                  </label>
                  <select
                    value={excelSelectedTitleCol}
                    onChange={e => handleClassExcelColumnOverride(excelSelectedCodeCol, Number(e.target.value))}
                    className="w-full bg-[#0c162e] border border-indigo-500/35 rounded-lg px-2 py-1.5 text-white text-[11px] outline-none focus:border-emerald-400"
                  >
                    {excelColOptions.map(opt => (
                      <option key={opt.idx} value={opt.idx}>{opt.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {excelParsedRows.length > 0 && (
              <div className="max-h-40 overflow-y-auto space-y-1 rounded-xl border border-indigo-900/40 bg-[#070e22]/70 p-2 text-xs">
                {excelParsedRows.map((row, idx) => (
                  <div key={idx} className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-[#0c162e] border border-indigo-500/20">
                    <span className="font-bold text-white truncate">{row.title}</span>
                    <span className="font-mono text-cyan-300 text-[11px] shrink-0">{row.code || 'بدون کد'}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-indigo-900/40">
              <button
                type="button"
                onClick={() => setExcelImportTarget(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                انصراف
              </button>
              <button
                type="button"
                disabled={excelParsedRows.length === 0}
                onClick={handleConfirmClassExcelImport}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer shadow-md"
              >
                تایید و ثبت ({excelParsedRows.length})
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

    </div>
  );
};
