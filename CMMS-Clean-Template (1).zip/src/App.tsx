import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { 
  Wrench, 
  User, 
  Users,
  Search, 
  Plus, 
  Clock, 
  FileText, 
  ArrowRight, 
  ArrowLeft,
  Sparkles, 
  Bot,
  X, 
  Edit3, 
  Trash2, 
  ShieldAlert, 
  Code, 
  Check, 
  Copy, 
  Play,
  LayoutDashboard, 
  Menu, 
  MoreHorizontal,
  Droplet, 
  ClipboardCheck, 
  BarChart3, 
  Printer, 
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  CheckCircle,
  Activity,
  Layers,
  ArrowDownCircle,
  Timer,
  Archive,
  RotateCcw,
  History,
  Database,
  Key,
  RefreshCw,
  ExternalLink,
  Server,
  Home,
  Sliders,
  Volume2,
  VolumeX,
  AlertTriangle,
  ArrowUpRight,
  Download,
  Gauge,
  Box,
  Package,
  Filter,
  Calendar,
  MapPin,
  Camera,
  Upload,
  TrendingUp,
  BarChart2,
  Zap,
  Star,
  Wifi,
  WifiOff,
  Cloud,
  CloudOff,
  ShieldCheck,
  CheckSquare,
  CalendarCheck,
  Monitor,
  Laptop,
  HardDrive,
  FileSpreadsheet,
  Crop,
  Sun,
  Moon,
  Image as ImageIcon
} from 'lucide-react';
import * as XLSX from 'xlsx';

import { usePWAInstall } from './hooks/usePWAInstall';
import PMStudio from './components/PMStudio';
import WorkRequestModule from './components/WorkRequestModule';
import { usePrintSettings } from './data/printSettings';
import {
  syncDuePmWorkOrders,
  loadAutoPmWorkOrders,
  saveAutoPmWorkOrders,
  isItemArchivedCheck,
  normalizeShamsiDatePm,
  getTodayShamsiDateStringPm
} from './data/pmAutoWorkOrders';
import { 
  getStoredSupabaseConfig, 
  saveSupabaseConfig, 
  getSupabase, 
  fetchWorkRequestsFromSupabase, 
  upsertWorkRequestInSupabase, 
  updateStatusInSupabase, 
  fetchTanksFromSupabase,
  updateTankInSupabase,
  fetchCentralStorageFromSupabase,
  saveCentralStorageToSupabase,
  SQL_SCHEMA_SCRIPT, 
  DEFAULT_SUPABASE_URL 
} from './supabase';
import { 
  INITIAL_OIL_TANKS, 
  OilTank, 
  REPRESENTATIVE_EQUIPMENTS, 
  EquipmentItem,
  ChecklistCategory,
  INITIAL_CHECKLIST_CATEGORIES,
  INSPECTION_DEFECT_OPTIONS,
  DefectOption,
  InspectionRecord,
  OperatorLeaderboardItem,
  INITIAL_OPERATOR_LEADERBOARD,
  INITIAL_INSPECTIONS
} from './data/portalData';
import {
  PRODUCTION_OPERATORS_LIST,
  ProductionOperator
} from './data/operatorsData';
import {
  HISTORICAL_OIL_TRANSACTIONS,
  normalizeShamsiDateStr
} from './data/oilTransactionsData';
import { JalaliDatePicker } from './components/JalaliDatePicker';
import { OilOfficialPrintModal } from './components/OilOfficialPrintModal';
import { VerticalCarousel3D } from './components/VerticalCarousel3D';
import { CategoryVerticalCarousel3D } from './components/CategoryVerticalCarousel3D';
import { CategoryHorizontalSlider } from './components/CategoryHorizontalSlider';
import { EquipmentVerticalCarousel3D } from './components/EquipmentVerticalCarousel3D';
import { ImageFramingModal } from './components/ImageFramingModal';
import { TankSvgVisual } from './components/TankSvgVisual';
import { compressImageDataUrl } from './utils/imageCompressor';
import defaultPlantEquipment from './data/plantEquipment.json';
import { DEFAULT_CATEGORY_IMAGES } from './data/defaultCategoryImages';
import { BRAND_CONFIG } from './data/brandConfig';

// ۹ دسته اصلی طبق درخواست مؤکد کاربر (بدون زیرمجموعه و با حفظ پایدار تصاویر دستگاه‌ها)
export const EXACT_9_MAIN_CATEGORIES: ChecklistCategory[] = [];
import { 
  COMPANY_LOGO,
  COMPANY_LOGO_WHITEBG,
  COMPANY_LOGO_DARK,
  OSVEH_LOGO_URL,
  OSVEH_LOGO_WHITEBG_URL
} from './data/auditImages';
import { 
  getTechnicianAllTasks 
} from './data/technicianHistory';
import {
  PmSchedule,
  INITIAL_PM_SCHEDULES,
  PmCategory,
  PmPeriodicity,
  PmPriority,
  PmStatus
} from './data/pmData';
import {
  UnifiedSparePart,
  SparePartCategory,
  SparePartSource,
  SparePartFilterSource,
  getUnifiedSpareParts,
  saveUnifiedSpareParts,
  getSparePartConsumptions,
  addOrUpdateSparePart,
  adjustSparePartStock,
  deleteSparePart,
  subscribeToSpareParts,
  clearAllSparePartsReports
} from './data/sparePartsData';
import { UnifiedSparePartsManager } from './components/UnifiedSparePartsManager';
import defaultFactoryLocations from './data/factoryLocations.json';

export const FACTORY_LOCATIONS: string[] = [];

export interface ConsumableItem {
  id: string;
  name: string;
  count: number;
  category: 'برقی' | 'مکانیکی' | 'سایر';
  unit?: string;
}

export const DEFAULT_PRESET_CONSUMABLES: Record<'برقی' | 'مکانیکی' | 'سایر', string[]> = {
  'برقی': [
    'فیوز مینیاتوری ۱۶ آمپر',
    'فیوز مینیاتوری ۲۵ آمپر',
    'کنتاکتور اشنایدر ۹ آمپر',
    'کنتاکتور اشنایدر ۱۸ آمپر',
    'کلید حرارتی ۲.۵ تا ۴ آمپر',
    'سنسور القایی نوری',
    'میکروسوئیچ غلطکی',
    'کابلشو و سرسیم سایز ۲.۵',
    'چسب برق نسوز',
    'ترمینال ریلی فونیکس'
  ],
  'مکانیکی': [
    'بلبرینگ شیار عمیق ۶۲۰۴',
    'بلبرینگ ۶۲۰۵ 2RS',
    'اورینگ NBR سایزهای مختلف',
    'کاسه نمد ضد روغن',
    'تسمه پروانه مقطع A',
    'تسمه دینام مقطع B',
    'پیچ آلن فولادی نمره ۸',
    'مهره کاسه نمدی و واشر فنری',
    'شیلنگ هیدرولیک فشار قوی',
    'کوپلینگ انعطاف‌پذیر لاستیکی'
  ],
  'سایر': [
    'اسپری زنگ‌بر و روانکار WD-40',
    'گریس نسوز بر پایه لیتیوم',
    'چسب قطره‌ای صنعتی لاکتایت',
    'نوار تفلون صنعتی گاز و مایع',
    'دستکش کار صنعتی مقاوم',
    'پارچه تنظیف صنعتی',
    'سیلیکون RTV و درزگیر حرارتی'
  ]
};

export interface WorkRequest {
  code: string;               // کد درخواست (مثلاً WR001883)
  workOrderCode?: string;     // کد دستور کار مرتبط (مثلاً WO001883)
  place: string;              // نام سالن یا بخش
  created: string;            // تاریخ و زمان درخواست
  title: string;              // عنوان خرابی یا درخواست
  priority: 'ایمنی (اولویت بالا)' | 'عادی' | string;
  description: string;        // شرح عیب اولیه (توسط درخواست‌دهنده)
  status: 'در حال اقدام' | 'در حال انجام' | 'انجام شد' | 'لغو' | 'در انتظار دستور برنامه ریزی' | string;
  
  // فیلدهای ادغام‌شده دستور کار (عملیات تکنسین)
  technician?: string;        // تکنسین مسئول اصلی
  coTechnicians?: string[];   // تکنسین‌های همکار / کمکی
  complexityLevel?: 'آسان' | 'معمولی' | 'دشوار'; // سطح پیچیدگی کار
  operationType?: string;     // نوع عملیات (برق، مکانیک، تاسیسات، عمومی)
  actionDetails?: string;     // شرح کامل عملیات و اقدامات انجام‌شده
  woDate?: string;            // تاریخ اجرای دستور کار
  woStartTime?: string;       // ساعت شروع دستور کار
  woEndTime?: string;         // ساعت پایان دستور کار
  durationMinutes?: number;   // مدت زمان صرف‌شده محاسبه‌شده از اختلاف شروع و پایان (دقیقه)
  completedAt?: string;       // تاریخ و زمان پایان کار
  completedTimestamp?: number;// زمان دقیق اختتام (میلی‌ثانیه) جهت محاسبه مدت سپری‌شده
  consumables?: ConsumableItem[]; // لوازم و قطعات مصرفی ثبت‌شده در دستور کار
  partsUsed?: string;         // متن خلاصه قطعات و لوازم مصرفی جهت نمایش در کارت و جستجو
  source?: 'workRequest' | 'techService' | 'pm' | string; // مبدا ثبت درخواست
  originCategory?: 'workRequest' | 'techService' | 'pm';
  requestType?: string;       // نوع درخواست (اضطراری، اصلاحی، پیشگیرانه، PM)
  equipmentCode?: string;
  equipmentName?: string;
  equipmentFamilyName?: string;
  failureTitle?: string;
  woTechnicians?: Array<{ id?: string; name: string; startDate?: string; startTime?: string; endDate?: string; endTime?: string; date?: string; hours: number }>;
  woActivities?: any[];
  woDelays?: any[];
  woStartDate?: string;
  woStartTimeOnly?: string;
  woEndDate?: string;
  woEndTimeOnly?: string;
  equipmentDowntimeMinutes?: number;
  downtimeMinutes?: number;
  isArchivedWorkOrder?: boolean;
}

const DEFAULT_TECHNICIANS: string[] = [];

// تمامی بایگانی‌ها و سوابق تستی صفر شدند تا کاربران از صفر شروع به ثبت نمایند
const DEFAULT_TECH_HISTORICAL_ACTIONS: Record<string, { 
  title: string; 
  code: string; 
  hoursAgo: number; 
  details: string; 
  place: string;
  completedCount: number;
  totalMinutes: number;
}> = {};

export interface OilOperation {
  id: string;
  tank_id: number;
  tank_name: string;
  type: 'in' | 'out';
  amount_l: number;
  operator: string;
  equipment?: string;
  created_at: string;
}



const CLOUD_CENTRAL_URL = '';

export const getApiUrl = (endpoint: string): string => {
  const ep = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  if (typeof window !== 'undefined' && window.location && window.location.protocol.startsWith('http')) {
    return ep;
  }
  return `${CLOUD_CENTRAL_URL}${ep}`;
};

// جدول درخواست‌ها و کارهای جاری کاملاً خالی است تا کاربر اطلاعات واقعی خود را ثبت کند
const INITIAL_WORK_REQUESTS: WorkRequest[] = [];

export const jalaliToGregorian = (jy: number, jm: number, jd: number): [number, number, number] => {
  try {
    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + (Math.floor(((jy % 33) + 3) / 4)) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor(--days / 36524);
      days %= 36524;
      if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const sal_b = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    for (gm = 0; gm < 13 && gd > sal_b[gm]; gm++) gd -= sal_b[gm];
    return [gy, gm, gd];
  } catch {
    return [2026, 1, 1];
  }
};

export const parseShamsiDateTimeToMs = (str?: string): number => {
  if (!str) return 0;
  try {
    const clean = String(str)
      .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
      .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584));
    
    const dateMatch = clean.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
    if (!dateMatch) return 0;
    const jy = parseInt(dateMatch[1], 10);
    const jm = parseInt(dateMatch[2], 10);
    const jd = parseInt(dateMatch[3], 10);
    
    let hour = 12;
    let minute = 0;
    let second = 0;
    const timeMatch = clean.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (timeMatch) {
      hour = parseInt(timeMatch[1], 10);
      minute = parseInt(timeMatch[2], 10);
      if (timeMatch[3]) second = parseInt(timeMatch[3], 10);
    }
    
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
    const d = new Date(gy, gm - 1, gd, hour, minute, second);
    return isNaN(d.getTime()) ? 0 : d.getTime();
  } catch {
    return 0;
  }
};

export const getOilTxSortScore = (tx: any): number => {
  if (!tx) return 0;
  try {
    if (tx.timestamp && typeof tx.timestamp === 'number' && tx.timestamp > 1000000000000) return tx.timestamp;
    if (tx.id && typeof tx.id === 'string' && tx.id.startsWith('tx-')) {
      const num = parseInt(tx.id.replace('tx-', ''), 10);
      if (!isNaN(num) && num > 1000000000000) return num;
    }
    const parsed = parseShamsiDateTimeToMs(tx.created_at);
    if (parsed > 0) return parsed;
  } catch {
    // fallback
  }
  return 0;
};

export default function App() {
  const printSettings = usePrintSettings();
  // حالت روشنایی سامانه (خورشید: روشن / ماه: تیره) با حفظ کامل تصویر زمینه و رنگ کارت‌ها
  const [systemTheme, setSystemTheme] = useState<'dark' | 'light'>(() => {
    try {
      return (localStorage.getItem('cmms_system_theme') as 'dark' | 'light') || 'dark';
    } catch {
      return 'dark';
    }
  });

  const handleToggleSystemTheme = (theme: 'dark' | 'light') => {
    setSystemTheme(theme);
    try {
      localStorage.setItem('cmms_system_theme', theme);
    } catch {}
  };

  useEffect(() => {
    try {
      if (systemTheme === 'light') {
        document.documentElement.classList.add('theme-light');
        document.documentElement.classList.remove('theme-dark');
        document.body.classList.add('theme-light');
        document.body.classList.remove('theme-dark');
      } else {
        document.documentElement.classList.add('theme-dark');
        document.documentElement.classList.remove('theme-light');
        document.body.classList.add('theme-dark');
        document.body.classList.remove('theme-light');
      }
    } catch {}
  }, [systemTheme]);

  const [technicians, setTechnicians] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('technicalServiceTechnicians');
      return saved ? JSON.parse(saved) : DEFAULT_TECHNICIANS;
    } catch {
      return DEFAULT_TECHNICIANS;
    }
  });

  const [workRequests, setWorkRequests] = useState<WorkRequest[]>(() => {
    try {
      const isCleared = localStorage.getItem('technicalServiceCleanSlate_v10');
      if (!isCleared) {
        localStorage.setItem('technicalServiceCleanSlate_v10', 'true');
        localStorage.removeItem('technicalServiceWorkRequests');
        return [];
      }
      const isReportsReset = localStorage.getItem('factory_spare_parts_reports_reset_v10');
      const saved = localStorage.getItem('technicalServiceWorkRequests');
      if (saved) {
        const parsed: WorkRequest[] = JSON.parse(saved);
        if (!isReportsReset && Array.isArray(parsed)) {
          clearAllSparePartsReports();
          const cleaned = parsed.map(r => ({ ...r, consumables: [], partsUsed: '' }));
          try { localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(cleaned)); } catch {}
          return cleaned;
        }
        return parsed;
      }
      return [];
    } catch {
      return [];
    }
  });

  // پرچم برای جلوگیری از لوپ بین دریافت و ارسال به سرور مرکزی
  const isSyncingFromServerRef = useRef(false);
  const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pendingPushKeysRef = useRef<Record<string, any>>({});
  const hasCompletedInitialServerFetchRef = useRef(false);

  // ارسال فوری و بدون تاخیر داده‌ها به سرور ابری Supabase و سرور مرکزی با قفل محافظ
  const pushStateToServerImmediate = useCallback(async (partialState: any) => {
    isSyncingFromServerRef.current = true;
    try {
      const nowTs = Date.now();
      const updatedTanksToSave = partialState.oilTanks || JSON.parse(localStorage.getItem('portal_oil_tanks') || '[]');
      const updatedTxToSave = partialState.oilTransactions || JSON.parse(localStorage.getItem('portal_oil_transactions_v8') || '[]');

      const fullStorage = {
        oilTanks: updatedTanksToSave,
        oilTransactions: updatedTxToSave,
        workRequests: JSON.parse(localStorage.getItem('technicalServiceWorkRequests') || '[]'),
        equipments: JSON.parse(localStorage.getItem('portal_equipments_v9') || '[]'),
        checklistCategories: JSON.parse(localStorage.getItem('portal_exact9_categories_v9_data') || '[]'),
        technicians: JSON.parse(localStorage.getItem('technicalServiceTechnicians') || '[]'),
        technicianPhotos: JSON.parse(localStorage.getItem('technicalServiceTechnicianPhotos') || '{}'),
        inspectionLogs: JSON.parse(localStorage.getItem('portal_inspections_v5') || '[]'),
        pmSchedules: JSON.parse(localStorage.getItem('app_pm_schedules_v1') || '[]'),
        operatorLeaderboard: JSON.parse(localStorage.getItem('portal_operator_leaderboard_v5') || '[]'),
        productionOperators: JSON.parse(localStorage.getItem('portal_production_operators_v2') || '[]'),
        unifiedSpareParts: JSON.parse(localStorage.getItem('factory_unified_spare_parts_v2') || '[]'),
        sparePartsConsumptions: JSON.parse(localStorage.getItem('factory_spare_parts_consumptions_v1') || '[]'),
        ...partialState,
        _updatedAt: nowTs
      };
      
      try {
        localStorage.setItem('portal_central_last_write_ts', String(nowTs));
        if (fullStorage.oilTanks) localStorage.setItem('portal_oil_tanks', JSON.stringify(fullStorage.oilTanks));
        if (fullStorage.oilTransactions) localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(fullStorage.oilTransactions));
        if (fullStorage.checklistCategories) localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(fullStorage.checklistCategories));
        if (fullStorage.equipments) localStorage.setItem('portal_equipments_v9', JSON.stringify(fullStorage.equipments));
        if (fullStorage.unifiedSpareParts) localStorage.setItem('factory_unified_spare_parts_v2', JSON.stringify(fullStorage.unifiedSpareParts));
        if (fullStorage.sparePartsConsumptions) localStorage.setItem('factory_spare_parts_consumptions_v1', JSON.stringify(fullStorage.sparePartsConsumptions));
      } catch {}

      // ۱. ذخیره مستقیم و بلادرنگ در پایگاه داده ابری Supabase با await
      const res = await saveCentralStorageToSupabase(fullStorage);
      if (!res.success) {
        console.warn('Supabase immediate save error:', res.error);
      }

      // ۲. ارسال همزمان به سرور محلی
      try {
        fetch(getApiUrl('/api/portal/sync-state'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullStorage)
        }).catch(err => {
          console.warn('Central server immediate push error:', err);
        });
      } catch (e) {
        console.warn('Immediate sync error:', e);
      }
    } catch (err) {
      console.warn('Error in pushStateToServerImmediate:', err);
    } finally {
      // رهاسازی قفل همگام‌سازی پس از ۲ ثانیه جهت تضمین اعمال تغییرات در کلاود
      setTimeout(() => {
        isSyncingFromServerRef.current = false;
      }, 2000);
    }
  }, []);

  // ارسال خودکار تغییرات به سرور مرکزی و دیتابیس ابری Supabase با debounce
  const pushStateToServer = useCallback((partialState: any) => {
    if (isSyncingFromServerRef.current) return;
    if (!hasCompletedInitialServerFetchRef.current) return;

    pendingPushKeysRef.current = {
      ...pendingPushKeysRef.current,
      ...partialState
    };

    if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    syncTimeoutRef.current = setTimeout(async () => {
      const payload = { ...pendingPushKeysRef.current };
      pendingPushKeysRef.current = {};

      try {
        const fullStorage = {
          oilTanks: JSON.parse(localStorage.getItem('portal_oil_tanks') || '[]'),
          oilTransactions: JSON.parse(localStorage.getItem('portal_oil_transactions_v8') || '[]'),
          workRequests: JSON.parse(localStorage.getItem('technicalServiceWorkRequests') || '[]'),
          equipments: JSON.parse(localStorage.getItem('portal_equipments_v9') || '[]'),
          checklistCategories: JSON.parse(localStorage.getItem('portal_exact9_categories_v9_data') || '[]'),
          technicians: JSON.parse(localStorage.getItem('technicalServiceTechnicians') || '[]'),
          technicianPhotos: JSON.parse(localStorage.getItem('technicalServiceTechnicianPhotos') || '{}'),
          inspectionLogs: JSON.parse(localStorage.getItem('portal_inspections_v5') || '[]'),
          pmSchedules: JSON.parse(localStorage.getItem('app_pm_schedules_v1') || '[]'),
          operatorLeaderboard: JSON.parse(localStorage.getItem('portal_operator_leaderboard_v5') || '[]'),
          productionOperators: JSON.parse(localStorage.getItem('portal_production_operators_v2') || '[]'),
          unifiedSpareParts: JSON.parse(localStorage.getItem('factory_unified_spare_parts_v2') || '[]'),
          sparePartsConsumptions: JSON.parse(localStorage.getItem('factory_spare_parts_consumptions_v1') || '[]'),
          ...payload,
          _updatedAt: Date.now()
        };
        try {
          localStorage.setItem('portal_central_last_write_ts', String(fullStorage._updatedAt));
          if (payload.unifiedSpareParts) localStorage.setItem('factory_unified_spare_parts_v2', JSON.stringify(payload.unifiedSpareParts));
          if (payload.sparePartsConsumptions) localStorage.setItem('factory_spare_parts_consumptions_v1', JSON.stringify(payload.sparePartsConsumptions));
        } catch {}
        saveCentralStorageToSupabase(fullStorage).catch(() => {});
      } catch {}

      fetch(getApiUrl('/api/portal/sync-state'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(err => {
        console.warn('Central server sync error:', err);
      });
    }, 400);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(workRequests));
      pushStateToServer({ workRequests });
    } catch (e) {
      console.error(e);
    }
  }, [workRequests, pushStateToServer]);

  // ذخیره و همگام‌سازی فهرست تکنسین‌ها با سرور
  useEffect(() => {
    try {
      localStorage.setItem('technicalServiceTechnicians', JSON.stringify(technicians));
      pushStateToServer({ technicians });
    } catch (e) {
      console.error(e);
    }
  }, [technicians, pushStateToServer]);

  // عکس‌های تکنسین‌ها (با پس‌زمینه سفید یکدست و قابلیت بارگذاری مستقیم)
  const [technicianPhotos, setTechnicianPhotos] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('technicalServiceTechnicianPhotos');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleUploadTechnicianPhoto = (techName: string, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setTechnicianPhotos(prev => {
          const next = { ...prev, [techName]: result };
          try {
            localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(next));
            pushStateToServer({ technicianPhotos: next });
          } catch (err) {
            console.error('Failed to save photo to localStorage', err);
          }
          return next;
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveTechnicianPhoto = (techName: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setTechnicianPhotos(prev => {
      const next = { ...prev };
      delete next[techName];
      try {
        localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(next));
        pushStateToServer({ technicianPhotos: next });
      } catch (err) {
        console.error('Failed to remove photo from localStorage', err);
      }
      return next;
    });
  };

  // وضعیت‌های مربوط به نمودار مقایسه هفتگی شنبه تا پنجشنبه
  const [weeklyChartTechFilter, setWeeklyChartTechFilter] = useState<string>('همه');
  const [weeklyChartMetric, setWeeklyChartMetric] = useState<'both' | 'hours' | 'count'>('both');
  const [selectedChartDay, setSelectedChartDay] = useState<string | null>(null);

  // تفکیک نام و نام خانوادگی تکنسین جهت نمایش بدون بریدگی نام خانوادگی در صفحه اصلی و نام کامل در پروفایل
  const getTechNames = (fullName: string) => {
    const trimmed = (fullName || '').trim();
    const parts = trimmed.split(/\s+/);
    if (parts.length <= 1) {
      return { full: trimmed, last: trimmed, first: '' };
    }
    const first = parts[0];
    const last = parts.slice(1).join(' ');
    return { full: trimmed, last, first };
  };

  // روزهای کاری استاندارد هفته در ایران (شنبه تا پنجشنبه)
  const PERSIAN_WORK_DAYS = [
    { key: 'sat', name: 'شنبه', dayNum: 6, short: 'ش' },
    { key: 'sun', name: 'یکشنبه', dayNum: 0, short: 'ی' },
    { key: 'mon', name: 'دوشنبه', dayNum: 1, short: 'د' },
    { key: 'tue', name: 'سه‌شنبه', dayNum: 2, short: 'س' },
    { key: 'wed', name: 'چهارشنبه', dayNum: 3, short: 'چ' },
    { key: 'thu', name: 'پنجشنبه', dayNum: 4, short: 'پ' },
  ];

  const getWorkRequestDayKey = (r: WorkRequest): string => {
    const text = `${r.woDate || ''} ${r.created || ''} ${r.completedAt || ''} ${r.title || ''} ${r.description || ''}`;
    if (text.includes('یکشنبه')) return 'sun';
    if (text.includes('دوشنبه')) return 'mon';
    if (text.includes('سه‌شنبه')) return 'tue';
    if (text.includes('چهارشنبه')) return 'wed';
    if (text.includes('پنجشنبه')) return 'thu';
    if (text.includes('شنبه')) return 'sat';

    const ts = r.completedTimestamp || parseShamsiDateTime(r.completedAt || (r.woDate ? `${r.woDate} — ${r.woEndTime || '12:00'}` : r.created));
    if (ts && ts > 0) {
      const d = new Date(ts);
      const day = d.getDay();
      if (day === 6) return 'sat';
      if (day === 0) return 'sun';
      if (day === 1) return 'mon';
      if (day === 2) return 'tue';
      if (day === 3) return 'wed';
      if (day === 4) return 'thu';
      return 'sat';
    }

    const numMatch = r.code?.match(/\d+/);
    if (numMatch) {
      const num = parseInt(numMatch[0], 10);
      const keys = ['sat', 'sun', 'mon', 'tue', 'wed', 'thu'];
      return keys[num % 6];
    }
    return 'sat';
  };

  const getWorkRequestDurationMinutes = (r: WorkRequest): number => {
    if (r.durationMinutes && r.durationMinutes > 0) return r.durationMinutes;
    if (r.woStartTime && r.woEndTime) {
      const diff = computeMinutesDiff(r.woStartTime, r.woEndTime);
      if (diff > 0) return diff;
    }
    return r.status === 'انجام شد' ? 60 : 30;
  };

  const [mainTableTab, setMainTableTab] = useState<'active' | 'archive'>('active');
  const [archiveNotice, setArchiveNotice] = useState<string | null>(null);
  const [techSearch, setTechSearch] = useState('');
  const [techStatusFilter, setTechStatusFilter] = useState('');
  const [techDisplayView, setTechDisplayView] = useState<'3dCards' | 'table'>('3dCards');
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});
  const [expandedTech, setExpandedTech] = useState<string | null>(null);
  const [isWorkOrdersMenuOpen, setIsWorkOrdersMenuOpen] = useState(false);
  const [showKpiMetrics, setShowKpiMetrics] = useState(false);
  const toggleCardFlip = (code: string) => setFlippedCards(prev => ({ ...prev, [code]: !prev[code] }));
  const [isSideToolbarOpen, setIsSideToolbarOpen] = useState(false);
  const [isPmSideToolbarOpen, setIsPmSideToolbarOpen] = useState(false);
  const { isInstallable, isInstalled, install: pwaInstall, updateServiceWorker } = usePWAInstall();
  const [isBottomToolsOpen, setIsBottomToolsOpen] = useState(false);

  // Navigation State: Portal is the primary entry page
  const [currentView, setCurrentView] = useState<'portal' | 'oil' | 'checklist' | 'technical' | 'pm' | 'workRequest'>('portal');

  // رفرنس پخش خودکار و روان ویدیوی لوگوی صفحه اول
  const bgVideoRef = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (currentView === 'portal' && bgVideoRef.current) {
      bgVideoRef.current.muted = true;
      bgVideoRef.current.defaultMuted = true;
      const playPromise = bgVideoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {});
      }
    }
  }, [currentView, systemTheme]);
  const [filterPlace, setFilterPlace] = useState('همه');
  const [filterPriority, setFilterPriority] = useState('همه');
  const [filterTechnician, setFilterTechnician] = useState('همه');
  const [filterOpType, setFilterOpType] = useState('همه');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'duration'>('newest');
  const [newTechName, setNewTechName] = useState('');
  const [selectedTechnicianProfile, setSelectedTechnicianProfile] = useState<string | null>(null);
  const [techProfileSearch, setTechProfileSearch] = useState('');
  const [techProfileStatusFilter, setTechProfileStatusFilter] = useState<'همه' | 'انجام شد' | 'در حال اقدام'>('همه');
  const [expandedTechTaskIds, setExpandedTechTaskIds] = useState<Record<string, boolean>>({});
  // وضعیت‌های مربوط به تحلیل هوش مصنوعی تکنسین
  const [aiAnalysisResults, setAiAnalysisResults] = useState<Record<string, any>>({});
  const [aiAnalysisLoading, setAiAnalysisLoading] = useState<boolean>(false);
  const [isAiAnalysisOpen, setIsAiAnalysisOpen] = useState<boolean>(false);
  const [aiAnalysisCopied, setAiAnalysisCopied] = useState<boolean>(false);

  // Oil Warehouse Tanks State
  const [oilTanks, setOilTanks] = useState<OilTank[]>(() => {
    try {
      const s = localStorage.getItem('portal_oil_tanks');
      if (s) {
        const parsed: OilTank[] = JSON.parse(s);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      localStorage.setItem('portal_oil_tanks', JSON.stringify(INITIAL_OIL_TANKS));
      return INITIAL_OIL_TANKS;
    } catch {
      return INITIAL_OIL_TANKS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_oil_tanks', JSON.stringify(oilTanks));
      pushStateToServer({ oilTanks });
    } catch (e) {
      console.error(e);
    }
  }, [oilTanks, pushStateToServer]);

  // Equipments Checklist State (از صفر شروع می‌شود تا موجودی کلیه دسته‌ها دقیقاً صفر باشد و کاربر با اکسل یا دستی اضافه کند)
  const [equipments, setEquipments] = useState<EquipmentItem[]>(() => {
    try {
      const vKey = 'portal_equipments_clean_slate_v9';
      if (localStorage.getItem(vKey) !== '9') {
        localStorage.setItem(vKey, '9');
        localStorage.setItem('portal_equipments_v9', JSON.stringify([]));
        return [];
      }
      const s = localStorage.getItem('portal_equipments_v9');
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(equipments));
      pushStateToServer({ equipments });
    } catch (e) {
      console.error(e);
    }
  }, [equipments, pushStateToServer]);

  // تصحیح خودکار و قطعی تجهیزات چک‌لیست:
  // ۱) کدهای TUMN، MIDR، MIMN، SBMU، WBMN، دریل فرز و تجهیزات دستی منوآل قطعا متعلق به «تجهیزات دستی» هستند
  // ۲) کدهای TUMA و تراش مایر منحصراً و قطعاً متعلق به دسته «مایر» هستند
  // ۳) کدهای TUTN و TUCT و تورنوس سوئیسی منحصراً متعلق به دسته «تورنوس» هستند
  // ۴) ۳۷ دستگاه با کد TULT و TUTL قطعا متعلق به دسته «تراش» هستند
  // ۵) کدهای MICN و فرزهای CNC (به جز دریل فرز MIDR) در دسته «فرز» قرار می‌گیرند
  useEffect(() => {
    setEquipments(prev => {
      let hasChange = false;
      const fixed = prev.map(eq => {
        const codeUpper = (eq.code || '').trim().toUpperCase();
        const nameClean = (eq.name || '').trim();

        // ۱. تجهیزات دستی: دریل فرز (MIDR)، دریل دستی/عمودی (MIMN)، تراش دستی (TUMN)، سندبلاست (SBMU, WBMN)
        if (
          codeUpper.startsWith('TUMN') || 
          codeUpper.startsWith('MIDR') || 
          codeUpper.startsWith('MIMN') || 
          codeUpper.startsWith('SBMU') || 
          codeUpper.startsWith('WBMN') || 
          nameClean.includes('دریل فرز') || 
          nameClean.includes('دریل') || 
          nameClean.includes('تراش دستی') || 
          nameClean.includes('دستی') || 
          nameClean.toLowerCase().includes('manual')
        ) {
          if (eq.category !== 'تجهیزات دستی') {
            hasChange = true;
            return { ...eq, category: 'تجهیزات دستی' as any };
          }
          return eq;
        }

        // ۲. تراش مایر (TUMA): قطعاً و منحصراً در دسته مایر (نه تورنوس و نه تراش)
        if (
          codeUpper.startsWith('TUMA') || 
          nameClean.includes('مایر') || 
          nameClean.toLowerCase().includes('mayer')
        ) {
          if (eq.category !== 'مایر') {
            hasChange = true;
            return { ...eq, category: 'مایر' as any };
          }
          return eq;
        }

        // ۳. تورنوس (TUTN, TUCT): قطعاً در دسته تورنوس
        if (
          codeUpper.startsWith('TUTN') || 
          codeUpper.startsWith('TUCT') || 
          (nameClean.includes('تورنوس') && !nameClean.includes('مایر') && !codeUpper.startsWith('TUMA'))
        ) {
          if (eq.category !== 'تورنوس') {
            hasChange = true;
            return { ...eq, category: 'تورنوس' as any };
          }
          return eq;
        }

        // ۴. کدهای TULT و TUTL (تراشکاری دقیق CNC) که دستی یا مایر نیستند، در دسته تراش قرار گیرند
        if (codeUpper.startsWith('TULT') || codeUpper.startsWith('TUTL')) {
          if (eq.category !== 'تراش') {
            hasChange = true;
            return { ...eq, category: 'تراش' as any };
          }
          return eq;
        }

        // ۵. استار (TUST, ST)
        if (codeUpper.startsWith('TUST') || codeUpper.startsWith('ST') || nameClean.includes('استار')) {
          if (eq.category !== 'استار') {
            hasChange = true;
            return { ...eq, category: 'استار' as any };
          }
          return eq;
        }

        // ۶. سینتک (TUSY, SY)
        if (codeUpper.startsWith('TUSY') || codeUpper.startsWith('SY') || nameClean.includes('سینتک')) {
          if (eq.category !== 'سینتک') {
            hasChange = true;
            return { ...eq, category: 'سینتک' as any };
          }
          return eq;
        }

        // ۷. پرس‌ها (PR)
        if (codeUpper.startsWith('PR') || nameClean.includes('پرس')) {
          if (eq.category !== 'پرس') {
            hasChange = true;
            return { ...eq, category: 'پرس' as any };
          }
          return eq;
        }

        return eq;
      });
      if (hasChange) {
        try {
          localStorage.setItem('portal_equipments_v9', JSON.stringify(fixed));
        } catch {}
        pushStateToServer({ equipments: fixed });
      }
      return hasChange ? fixed : prev;
    });
  }, []);

  // همگام‌سازی پیوسته و هوشمند تعداد تجهیزات در هر دسته اصلی بر اساس واقعیت آرایه تجهیزات
  useEffect(() => {
    if (!equipments) return;
    setChecklistCategories(prev => {
      let changed = false;
      const updated = prev.map(c => {
        const realCount = equipments.filter(e => e.category === c.name).length;
        if (c.equipmentCount !== realCount) {
          changed = true;
          return { ...c, equipmentCount: realCount };
        }
        return c;
      });
      return changed ? updated : prev;
    });
  }, [equipments]);

  // Oil refill / consume transaction modal state
  const [selectedTankForTx, setSelectedTankForTx] = useState<OilTank | null>(null);
  const [tankTxAmount, setTankTxAmount] = useState<string>('200');
  const [tankTxType, setTankTxType] = useState<'refill' | 'consume'>('refill');
  const [tankTxHall, setTankTxHall] = useState<string>(FACTORY_LOCATIONS[0] || 'سالن ۱');
  const [isSirenActive, setIsSirenActive] = useState<boolean>(false);
  const sirenAudioCtxRef = useRef<AudioContext | null>(null);

  // Oil Transactions and Live Clock State
  const [oilTransactions, setOilTransactions] = useState<OilOperation[]>(() => {
    try {
      const vKey = 'portal_oil_tx_version_v12';
      if (localStorage.getItem(vKey) !== '12') {
        localStorage.setItem(vKey, '12');
        localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(HISTORICAL_OIL_TRANSACTIONS));
        localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(HISTORICAL_OIL_TRANSACTIONS));
        return HISTORICAL_OIL_TRANSACTIONS;
      }
      const s = localStorage.getItem('portal_oil_transactions_v12') || localStorage.getItem('portal_oil_transactions_v8');
      return s ? JSON.parse(s) : HISTORICAL_OIL_TRANSACTIONS;
    } catch {
      return HISTORICAL_OIL_TRANSACTIONS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(oilTransactions));
      pushStateToServer({ oilTransactions });
    } catch (e) {
      console.error(e);
    }
  }, [oilTransactions, pushStateToServer]);

  // همیشه تازه‌ترین تراکنش‌ها در رتبه اول برای نمایش در جدول ۵ عملیات اخیر
  const sortedRecentOilTransactions = useMemo(() => {
    return [...oilTransactions].sort((a, b) => getOilTxSortScore(b) - getOilTxSortScore(a));
  }, [oilTransactions]);

  // فیلترهای پیشرفته گزارش‌گیری انبار روغن (تاریخ دقیق و جستجو)
  const [oilReportStartDate, setOilReportStartDate] = useState<string>('');
  const [oilReportEndDate, setOilReportEndDate] = useState<string>('');
  const [oilReportSearch, setOilReportSearch] = useState<string>('');

  // Persian Live Clock
  const [persianClock, setPersianClock] = useState<string>('۱۴۰۵ آبان ۲، شنبه ساعت ۱۳:۵۴:۴۲');
  useEffect(() => {
    const updateTime = () => {
      try {
        const d = new Date();
        const dateStr = d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });
        const timeStr = d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setPersianClock(`${dateStr} ساعت ${timeStr}`);
      } catch {}
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Top consumption period and grouping filter
  const [topConsumptionPeriod, setTopConsumptionPeriod] = useState<'all' | 'monthly' | '3months' | '6months' | 'yearly'>('all');
  const [topConsumptionMode, setTopConsumptionMode] = useState<'equipment' | 'operator'>('equipment');
  const [topConsumptionPage, setTopConsumptionPage] = useState<number>(1);
  const [isOilReportModalOpen, setIsOilReportModalOpen] = useState(false);
  const [isOilOfficialPrintModalOpen, setIsOilOfficialPrintModalOpen] = useState(false);
  const [oilReportFilterTank, setOilReportFilterTank] = useState('all');
  const [oilReportTab, setOilReportTab] = useState<'out' | 'in'>('out');

  // Withdraw and Entry Modals state
  const [oilModalMode, setOilModalMode] = useState<'none' | 'withdraw' | 'entry'>('none');
  const [oilTargetTankId, setOilTargetTankId] = useState<number>(1);
  const [oilOpAmount, setOilOpAmount] = useState<string>('5');
  const [oilOpOperator, setOilOpOperator] = useState<string>('');
  const [oilOpEquipment, setOilOpEquipment] = useState<string>('');
  const [oilOpError, setOilOpError] = useState<string | null>(null);
  const [isSubmittingOilOp, setIsSubmittingOilOp] = useState<boolean>(false);

  // Checklist filters
  const [checklistCategoryFilter, setChecklistCategoryFilter] = useState('همه');
  const [checklistHallFilter, setChecklistHallFilter] = useState('همه');
  const [checklistSearch, setChecklistSearch] = useState('');

  // ۹ دسته اصلی چک‌لیست (موجودی اولیه همگی صفر و حفظ همیشگی تصاویر)
  const [checklistCategories, setChecklistCategories] = useState<ChecklistCategory[]>(() => {
    try {
      const persistentPhotos = (() => {
        try { return JSON.parse(localStorage.getItem('portal_category_persistent_photos_v1') || '{}'); } catch { return {}; }
      })();

      const restoreImages = (cats: ChecklistCategory[]) => cats.map(c => ({
        ...c,
        image: c.image || persistentPhotos[c.id] || persistentPhotos[c.name] || DEFAULT_CATEGORY_IMAGES[c.name] || DEFAULT_CATEGORY_IMAGES[c.id] || undefined
      }));

      const s = localStorage.getItem('portal_exact9_categories_v9_data');
      if (s) {
        const parsed = JSON.parse(s);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return restoreImages(parsed);
        }
      }
      return restoreImages(EXACT_9_MAIN_CATEGORIES);
    } catch {
      return EXACT_9_MAIN_CATEGORIES;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(checklistCategories));
      pushStateToServer({ checklistCategories });
    } catch (e) {
      console.error(e);
    }
  }, [checklistCategories, pushStateToServer]);

  // Inspection Logs State (داده‌های پیشین ثبت بازرسی صفر شدند تا کاربر بتواند از نو ثبت کند)
  const [inspectionLogs, setInspectionLogs] = useState<InspectionRecord[]>(() => {
    try {
      const vKey = 'portal_inspections_clean_v5';
      if (localStorage.getItem(vKey) !== '5') {
        localStorage.setItem(vKey, '5');
        localStorage.removeItem('portal_inspections_v2');
        localStorage.setItem('portal_inspections_v5', JSON.stringify([]));
        return [];
      }
      const s = localStorage.getItem('portal_inspections_v5');
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_inspections_v5', JSON.stringify(inspectionLogs));
      pushStateToServer({ inspectionLogs });
    } catch (e) {
      console.error(e);
    }
  }, [inspectionLogs, pushStateToServer]);

  // Operator Leaderboard State (تعداد بازرسی‌های تمام اپراتورها صفر شد)
  // Operator Leaderboard State (فقط اپراتورهای دارای بازرسی واقعی تا الان)
  const [operatorLeaderboard, setOperatorLeaderboard] = useState<OperatorLeaderboardItem[]>(() => {
    try {
      const vKey = 'portal_operator_leaderboard_clean_v6';
      if (localStorage.getItem(vKey) !== '6') {
        localStorage.setItem(vKey, '6');
        localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify([]));
        return [];
      }
      const s = localStorage.getItem('portal_operator_leaderboard_v5');
      if (s) {
        const parsed = JSON.parse(s);
        if (Array.isArray(parsed)) return parsed.filter((op: any) => (op.inspectionsCount || 0) > 0);
      }
      return [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(operatorLeaderboard));
      pushStateToServer({ operatorLeaderboard });
    } catch (e) {
      console.error(e);
    }
  }, [operatorLeaderboard, pushStateToServer]);

  // Production Operators State (128 operators from PersonnelList CSV with personnel codes)
  const [productionOperators, setProductionOperators] = useState<ProductionOperator[]>(() => {
    try {
      const s = localStorage.getItem('portal_production_operators_v2');
      if (s) {
        const parsed = JSON.parse(s);
        if (Array.isArray(parsed) && parsed.length >= 50) return parsed;
      }
      return PRODUCTION_OPERATORS_LIST;
    } catch {
      return PRODUCTION_OPERATORS_LIST;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('portal_production_operators_v2', JSON.stringify(productionOperators));
      pushStateToServer({ productionOperators });
    } catch (e) {
      console.error(e);
    }
  }, [productionOperators, pushStateToServer]);

  // ========================================================
  // CENTRAL MULTI-DEVICE SERVER SYNC (همگام‌سازی بلادرنگ کامپیوتر و گوشی)
  // ========================================================
  const [centralSyncState, setCentralSyncState] = useState<'synced' | 'syncing' | 'offline'>('synced');

  const hasPushedInitialRef = useRef(false);

  // دریافت و اعمال زنده داده‌های سرور مرکزی با اولویت دیتابیس ابری Supabase
  const fetchAndApplyCentralState = useCallback(async () => {
    if (isSyncingFromServerRef.current) return;
    try {
      let s: any = null;

      // اولویت نخست: واکشی مستقیم و زنده از سرور ابری Supabase
      try {
        const supaRes = await fetchCentralStorageFromSupabase();
        if (supaRes && supaRes.data && typeof supaRes.data === 'object') {
          s = supaRes.data;
        }
      } catch (err) {
        console.warn('Supabase direct fetch failed, trying local server:', err);
      }

      // اولویت دوم: در صورت عدم پاسخ Supabase، واکشی از سرور محلی
      if (!s) {
        const res = await fetch(getApiUrl('/api/portal/sync-state'));
        if (res.ok) {
          const payload = await res.json();
          if (payload && payload.success) {
            s = payload.data || {};
          }
        }
      }

      if (!s) return;
      if (isSyncingFromServerRef.current) return;

      let needsPushBackToServer = false;
      const pushBackPayload: Record<string, any> = {};

      isSyncingFromServerRef.current = true;

      // ۱. تراکنش‌های انبار روغن (Oil Transactions) - ادغام کامل و مرتب‌سازی دقیق نزولی
      const localTx: OilOperation[] = (() => {
        try {
          return JSON.parse(localStorage.getItem('portal_oil_transactions_v8') || localStorage.getItem('portal_oil_transactions_v7') || '[]');
        } catch { return []; }
      })();
      const serverTx: OilOperation[] = Array.isArray(s.oilTransactions) ? s.oilTransactions : [];

      const txMap = new Map<string, OilOperation>();
      serverTx.forEach(t => { if (t && t.id) txMap.set(t.id, t); });
      localTx.forEach(t => {
        if (t && t.id) {
          if (!txMap.has(t.id)) {
            txMap.set(t.id, t);
            needsPushBackToServer = true;
          }
        }
      });
      const mergedTx = Array.from(txMap.values()).sort((a, b) => getOilTxSortScore(b) - getOilTxSortScore(a));
      if (mergedTx.length > 0) {
        setOilTransactions(mergedTx);
        try { 
          localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(mergedTx));
          localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(mergedTx));
          localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(mergedTx));
        } catch {}
        if (needsPushBackToServer) {
          pushBackPayload.oilTransactions = mergedTx;
        }
      }

      // ۲. مخازن روغن (Oil Tanks) - الگوریتم قطعی تطبیق و حفاظت در برابر بازگشت موجودی
      const serverTanks: OilTank[] = Array.isArray(s.oilTanks) && s.oilTanks.length > 0 ? s.oilTanks : [];
      const curLocalTanks: OilTank[] = (() => {
        try { return JSON.parse(localStorage.getItem('portal_oil_tanks') || '[]'); } catch { return []; }
      })();

      if (serverTanks.length > 0) {
        if (curLocalTanks.length === 0) {
          setOilTanks(serverTanks);
          try { localStorage.setItem('portal_oil_tanks', JSON.stringify(serverTanks)); } catch {}
        } else {
          let hasLocalUpdate = false;
          let hasServerUpdate = false;
          const mergedTanks = curLocalTanks.map(lt => {
            const st = serverTanks.find(t => String(t.id) === String(lt.id));
            if (!st) return lt;

            // اگر سرور مقدار کمتری دارد (برداشت در دستگاه دیگر ثبت شده)، مقدار کمتر سرور اعمال شود
            if (st.currentLiters < lt.currentLiters) {
              hasServerUpdate = true;
              return { ...lt, currentLiters: st.currentLiters, lastRefill: st.lastRefill || lt.lastRefill };
            }
            // اگر در لوکال برداشتی انجام شده و مقدار لوکال کمتر از سرور است، مقدار لوکال قاطعانه حفظ و سرور به‌روزرسانی می‌شود
            if (lt.currentLiters < st.currentLiters) {
              hasLocalUpdate = true;
              return lt;
            }
            return lt;
          });

          if (hasServerUpdate) {
            setOilTanks(mergedTanks);
            try { localStorage.setItem('portal_oil_tanks', JSON.stringify(mergedTanks)); } catch {}
          }
          if (hasLocalUpdate) {
            needsPushBackToServer = true;
            pushBackPayload.oilTanks = mergedTanks;
          }
        }
      }

      // ۳. درخواست‌ها و دستورکارهای فنی (Work Requests)
      const localWR: WorkRequest[] = (() => {
        try {
          return JSON.parse(localStorage.getItem('technicalServiceWorkRequests') || '[]');
        } catch { return []; }
      })();
      const serverWR: WorkRequest[] = Array.isArray(s.workRequests) ? s.workRequests : [];

      const isAutoPmWr = (w: any) =>
        Boolean(w?.isScheduledPM) ||
        Boolean(w?.pmSourceKey) ||
        /^PM(?:WR|WO)?\d+$/i.test(String(w?.code || '').trim());

      const wrMap = new Map<string, WorkRequest>();
      serverWR.forEach(w => { if (w && w.code && !w.code.startsWith('SYSTEM_') && !isAutoPmWr(w)) wrMap.set(w.code, w); });
      localWR.forEach(w => {
        if (w && w.code && !w.code.startsWith('SYSTEM_') && !isAutoPmWr(w)) {
          if (!wrMap.has(w.code)) {
            wrMap.set(w.code, w);
            needsPushBackToServer = true;
          } else {
            const existing = wrMap.get(w.code)!;
            if (w.status === 'انجام شد' && existing.status !== 'انجام شد') {
              wrMap.set(w.code, w);
              needsPushBackToServer = true;
            }
          }
        }
      });
      const mergedWR = Array.from(wrMap.values());
      if (mergedWR.length > 0 || serverWR.some(isAutoPmWr) || localWR.some(isAutoPmWr)) {
        setWorkRequests(mergedWR);
        try { localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(mergedWR)); } catch {}
        if (needsPushBackToServer || serverWR.some(isAutoPmWr)) {
          pushBackPayload.workRequests = mergedWR;
        }
      }

      // ۴. تجهیزات (Equipments) - ادغام هوشمند محلی و سرور با حفظ آخرین وضعیت بازرسی و دسته‌بندی
      const localEq = (() => {
        try { return JSON.parse(localStorage.getItem('portal_equipments_v9') || '[]'); } catch { return []; }
      })();
      const serverEq = Array.isArray(s.equipments) ? s.equipments : [];
      const eqMap = new Map<string, any>();
      serverEq.forEach((e: any) => { if (e && e.id) eqMap.set(e.id, e); });
      localEq.forEach((e: any) => {
        if (e && e.id) {
          if (!eqMap.has(e.id)) {
            eqMap.set(e.id, e);
            needsPushBackToServer = true;
          } else {
            const existing = eqMap.get(e.id)!;
            const localTs = Number(e.updatedAt) || 0;
            const serverTs = Number(existing.updatedAt) || 0;
            const isLocalNewer = localTs > serverTs || (localTs === serverTs && Boolean(e.category) && !existing.category);
            const isInspectionNewer = Boolean(e.lastInspectionDate && (!existing.lastInspectionDate || e.lastInspectionDate >= existing.lastInspectionDate));

            if (isLocalNewer || (localTs >= serverTs && isInspectionNewer)) {
              eqMap.set(e.id, { ...existing, ...e });
              if (existing.category !== e.category || existing.inspector !== e.inspector || existing.status !== e.status) {
                needsPushBackToServer = true;
              }
            } else {
              eqMap.set(e.id, { ...e, ...existing });
            }
          }
        }
      });
      const mergedEq = Array.from(eqMap.values());
      if (mergedEq.length > 0) {
        setEquipments(mergedEq);
        try { localStorage.setItem('portal_equipments_v9', JSON.stringify(mergedEq)); } catch {}
        if (needsPushBackToServer) {
          pushBackPayload.equipments = mergedEq;
        }
      }

      // ۵. دسته‌بندی چک‌لیست‌ها - ادغام هوشمند به طوری که تصاویر و تغییرات دسته‌ها هرگز پاک نشوند
      const persistentPhotos = (() => {
        try { return JSON.parse(localStorage.getItem('portal_category_persistent_photos_v1') || '{}'); } catch { return {}; }
      })();
      const localCats: ChecklistCategory[] = (() => {
        try { return JSON.parse(localStorage.getItem('portal_exact9_categories_v9_data') || '[]'); } catch { return []; }
      })();
      const serverCats: ChecklistCategory[] = Array.isArray(s.checklistCategories) ? s.checklistCategories : [];
      const catMap = new Map<string, ChecklistCategory>();

      serverCats.forEach((c: any) => {
        if (c && (c.id || c.name)) {
          const key = c.id || c.name;
          const img = c.image || persistentPhotos[key] || persistentPhotos[c.name] || DEFAULT_CATEGORY_IMAGES[c.name] || DEFAULT_CATEGORY_IMAGES[key];
          catMap.set(key, { ...c, image: img });
        }
      });

      localCats.forEach((lc: any) => {
        if (!lc || (!lc.id && !lc.name)) return;
        const key = lc.id || lc.name;
        if (!catMap.has(key)) {
          const img = lc.image || persistentPhotos[key] || persistentPhotos[lc.name] || DEFAULT_CATEGORY_IMAGES[lc.name] || DEFAULT_CATEGORY_IMAGES[key];
          catMap.set(key, { ...lc, image: img });
          needsPushBackToServer = true;
        } else {
          const sc = catMap.get(key)!;
          const localTs = Number(lc.updatedAt) || 0;
          const serverTs = Number(sc.updatedAt) || 0;
          // تصویر دسته: در صورتی که محلی، سرور یا استور پایدار تصویر دارد حفظ شود
          const bestImage = lc.image || sc.image || persistentPhotos[key] || persistentPhotos[sc.name] || persistentPhotos[lc.name] || DEFAULT_CATEGORY_IMAGES[sc.name] || DEFAULT_CATEGORY_IMAGES[lc.name];

          if (localTs >= serverTs) {
            catMap.set(key, { ...sc, ...lc, image: bestImage });
            if (!sc.image && bestImage) {
              needsPushBackToServer = true;
            }
          } else {
            catMap.set(key, { ...lc, ...sc, image: bestImage });
            if (!sc.image && bestImage) {
              needsPushBackToServer = true;
            }
          }
        }
      });

      const mergedCats = Array.from(catMap.values());
      if (mergedCats.length > 0) {
        setChecklistCategories(mergedCats);
        try { localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(mergedCats)); } catch {}
        if (needsPushBackToServer) {
          pushBackPayload.checklistCategories = mergedCats;
        }
      }

      // ۶. گزارش‌های بازرسی - ادغام کامل و بدون حذف رکوردهای محلی تازه ثبت‌شده (رفع قطعی مشکل «یکی ثبت میشه یکی نمیشه»)
      const localLogs: InspectionRecord[] = (() => {
        try { return JSON.parse(localStorage.getItem('portal_inspections_v5') || '[]'); } catch { return []; }
      })();
      const serverLogs: InspectionRecord[] = Array.isArray(s.inspectionLogs) ? s.inspectionLogs : [];
      const logMap = new Map<string, InspectionRecord>();
      serverLogs.forEach((l: any) => { if (l && l.id) logMap.set(l.id, l); });
      localLogs.forEach((l: any) => {
        if (l && l.id && !logMap.has(l.id)) {
          logMap.set(l.id, l);
          needsPushBackToServer = true;
        }
      });
      const mergedLogs = Array.from(logMap.values());
      if (mergedLogs.length > 0) {
        setInspectionLogs(mergedLogs);
        try { localStorage.setItem('portal_inspections_v5', JSON.stringify(mergedLogs)); } catch {}
        if (needsPushBackToServer) {
          pushBackPayload.inspectionLogs = mergedLogs;
        }
      }

      // ۷. رتبه‌بندی اپراتورها (Operator Leaderboard)
      if (Array.isArray(s.operatorLeaderboard) && s.operatorLeaderboard.length > 0) {
        setOperatorLeaderboard(s.operatorLeaderboard);
        try { localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(s.operatorLeaderboard)); } catch {}
      }

      // ۸. تکنسین‌ها
      if (Array.isArray(s.technicians) && s.technicians.length > 0) {
        setTechnicians(s.technicians);
        try { localStorage.setItem('technicalServiceTechnicians', JSON.stringify(s.technicians)); } catch {}
      }

      // ۹. عکس‌های پرسنلی
      if (s.technicianPhotos && typeof s.technicianPhotos === 'object' && Object.keys(s.technicianPhotos).length > 0) {
        setTechnicianPhotos(prev => {
          const merged = { ...prev, ...s.technicianPhotos };
          try { localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(merged)); } catch {}
          return merged;
        });
      }

      // ۱۰. زمان‌بندی PM
      if (Array.isArray(s.pmSchedules)) {
        setPmSchedules(s.pmSchedules);
        try { localStorage.setItem('app_pm_schedules_v1', JSON.stringify(s.pmSchedules)); } catch {}
      }

      // ۱۱. قطعات یدکی و اقلام مصرفی انبار
      if (Array.isArray(s.unifiedSpareParts) && s.unifiedSpareParts.length > 0) {
        const curParts = getUnifiedSpareParts();
        if (curParts.length === 0) {
          saveUnifiedSpareParts(s.unifiedSpareParts);
          setUnifiedSpareParts(s.unifiedSpareParts);
        } else {
          const partMap = new Map<string, any>();
          curParts.forEach(p => { if (p && p.id) partMap.set(p.id, p); });
          let partsChanged = false;
          s.unifiedSpareParts.forEach((sp: any) => {
            if (sp && sp.id && !partMap.has(sp.id)) {
              partMap.set(sp.id, sp);
              partsChanged = true;
            }
          });
          if (partsChanged) {
            const mergedList = Array.from(partMap.values());
            saveUnifiedSpareParts(mergedList);
            setUnifiedSpareParts(mergedList);
          }
        }
      }

      if (s.pmGroupActivities && typeof s.pmGroupActivities === 'object') {
        try {
          if (!localStorage.getItem('pm_studio_group_acts_v6')) {
            localStorage.setItem('pm_studio_group_acts_v6', JSON.stringify(s.pmGroupActivities));
          }
        } catch {}
      }

      if (Array.isArray(s.pmAutoWorkOrders)) {
        try {
          const localAuto = loadAutoPmWorkOrders();
          const autoMap = new Map<string, any>();
          s.pmAutoWorkOrders.forEach((o: any) => {
            const key = o?.pmSourceKey || o?.code || o?.id;
            if (key) autoMap.set(String(key), o);
          });
          localAuto.forEach((o: any) => {
            const key = o?.pmSourceKey || o?.code || o?.id;
            if (!key) return;
            const existing = autoMap.get(String(key));
            if (!existing || (isItemArchivedCheck(o) && !isItemArchivedCheck(existing))) {
              autoMap.set(String(key), o);
            }
          });
          const mergedAuto = Array.from(autoMap.values());
          saveAutoPmWorkOrders(mergedAuto);
        } catch {}
      }

      try {
        syncDuePmWorkOrders();
      } catch {}

      // ارسال خودکار بک به سرور مرکزی و Supabase در صورت وجود دیتای جدیدتر در این کلاینت
      if (needsPushBackToServer && Object.keys(pushBackPayload).length > 0) {
        saveCentralStorageToSupabase(pushBackPayload).catch(() => {});
        fetch(getApiUrl('/api/portal/sync-state'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(pushBackPayload)
        }).catch(e => console.warn('Pushback merge sync failed:', e));
      }

      hasCompletedInitialServerFetchRef.current = true;
      setTimeout(() => {
        isSyncingFromServerRef.current = false;
      }, 300);
      setCentralSyncState('synced');
    } catch (err) {
      console.warn('Central server sync error:', err);
      hasCompletedInitialServerFetchRef.current = true;
    }
  }, []);

  // دکمه ارسال کلیه اطلاعات این دستگاه به سرور مرکزی جهت باز شدن فوری در گوشی
  const handleForceUploadAllToServer = async () => {
    try {
      setCentralSyncState('syncing');
      const payload = {
        oilTanks,
        oilTransactions,
        workRequests,
        equipments,
        checklistCategories,
        technicians,
        technicianPhotos,
        inspectionLogs,
        pmSchedules,
        operatorLeaderboard,
        _updatedAt: Date.now()
      };

      // ۱. ذخیره مستقیم و قطعی در پایگاه ابری Supabase
      await saveCentralStorageToSupabase(payload);

      // ۲. همچنین ارسال به سرور داخلی
      await fetch(getApiUrl('/api/portal/force-upload'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      setCentralSyncState('synced');
      setChecklistNotice('✓ کلیه اطلاعات انبار روغن و سامانه در سرور ابری Supabase ذخیره شد و اکنون روی هر لینک و گوشی در دسترس است.');
      setTimeout(() => setChecklistNotice(null), 5000);
    } catch (e) {
      console.warn(e);
      setChecklistNotice('⚠️ خطا در ارسال داده‌ها به سرور ابری Supabase.');
      setTimeout(() => setChecklistNotice(null), 4000);
    }
  };

  useEffect(() => {
    fetchAndApplyCentralState();

    // همگام‌سازی دوره‌ای هوشمند هر ۵ ثانیه بین کامپیوتر و گوشی
    const interval = setInterval(fetchAndApplyCentralState, 5000);

    // همگام‌سازی فوری هنگام باز کردن صفحه روی گوشی یا تغییر تب
    const onVis = () => {
      if (document.visibilityState === 'visible') {
        fetchAndApplyCentralState();
      }
    };
    window.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', fetchAndApplyCentralState);

    return () => {
      clearInterval(interval);
      window.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', fetchAndApplyCentralState);
    };
  }, [fetchAndApplyCentralState]);

  useEffect(() => {
    const syncAutoPm = () => {
      try {
        syncDuePmWorkOrders();
      } catch {}
    };

    syncAutoPm();
    const pmTimer = window.setInterval(syncAutoPm, 20000);
    window.addEventListener('focus', syncAutoPm);
    return () => {
      window.clearInterval(pmTimer);
      window.removeEventListener('focus', syncAutoPm);
    };
  }, []);

  const [operatorSearchQuery, setOperatorSearchQuery] = useState<string>('');
  const [newOperatorPersonnelCode, setNewOperatorPersonnelCode] = useState<string>('');

  // Inspection UI Modals & Forms State
  const [isChecklistDrawerOpen, setIsChecklistDrawerOpen] = useState(false);
  const [isFactoryLocationsModalOpen, setIsFactoryLocationsModalOpen] = useState(false);
  const [activeFactoryLocations, setActiveFactoryLocations] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('pm_studio_locations_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultFactoryLocations;
  });
  // Modal locations are collapsed by default; click to expand and see subsystems
  const [modalExpandedLocations, setModalExpandedLocations] = useState<Record<string, boolean>>({});
  const [newSubLocInputsInApp, setNewSubLocInputsInApp] = useState<Record<string, string>>({});
  const [appLocationSearch, setAppLocationSearch] = useState<string>('');
  const [isCategoryManageModalOpen, setIsCategoryManageModalOpen] = useState(false);
  const [isInspectionHistoryModalOpen, setIsInspectionHistoryModalOpen] = useState(false);
  const [isLeaderboardModalOpen, setIsLeaderboardModalOpen] = useState(false);
  const [isOperatorsModalOpen, setIsOperatorsModalOpen] = useState(false);
  const [isAddOperatorModalOpen, setIsAddOperatorModalOpen] = useState(false);
  const [isAddEquipmentModalOpen, setIsAddEquipmentModalOpen] = useState(false);
  const [inspectingEquipment, setInspectingEquipment] = useState<EquipmentItem | null>(null);
  const [inspectingOperator, setInspectingOperator] = useState<string>('');
  const [inspectionResult, setInspectionResult] = useState<'conforming' | 'non_conforming'>('conforming');
  const [inspectionDefects, setInspectionDefects] = useState<string[]>([]);
  const [inspectionNotes, setInspectionNotes] = useState<string>('');
  const [inspectionPhoto, setInspectionPhoto] = useState<string | null>(null);
  const [inspectionAutoWorkOrder, setInspectionAutoWorkOrder] = useState<boolean>(true);
  const [selectedPhotoLightbox, setSelectedPhotoLightbox] = useState<string | null>(null);
  const [historyFilterResult, setHistoryFilterResult] = useState<'all' | 'conforming' | 'non_conforming'>('all');
  const [historyDateFilter, setHistoryDateFilter] = useState<string>('all');
  const [historyEquipmentSearch, setHistoryEquipmentSearch] = useState<string>('');
  const [selectedHistoryEquipCode, setSelectedHistoryEquipCode] = useState<string | null>(null);
  const [isHistoryEquipDropdownOpen, setIsHistoryEquipDropdownOpen] = useState<boolean>(false);
  const [leaderboardPage, setLeaderboardPage] = useState<number>(1);
  const [hoveredTrendDayIdx, setHoveredTrendDayIdx] = useState<number | null>(null);
  const [checklistPrintMode, setChecklistPrintMode] = useState<'all' | 'conforming' | 'non_conforming' | null>(null);
  const [checklistNotice, setChecklistNotice] = useState<string | null>(null);

  // Category Detail Modal State (مورد دوم کاربر: باز شدن تجهیزات هر دسته با کد و نام اپراتور و چک‌لیست درجا)
  const [selectedCategoryForModal, setSelectedCategoryForModal] = useState<ChecklistCategory | null>(null);
  const [activeMainCategory, setActiveMainCategory] = useState<ChecklistCategory>(() => checklistCategories[0] || EXACT_9_MAIN_CATEGORIES[0] || { id: 'cat-default', name: 'تجهیزات عمومی', equipmentCount: 0 });
  const [mainPageEquipmentView, setMainPageEquipmentView] = useState<'3dRoll' | 'table'>('3dRoll');
  const [categoryViewMode, setCategoryViewMode] = useState<'accordion' | '3dRoll' | 'grid'>('accordion');
  const [expandedAccordionEqId, setExpandedAccordionEqId] = useState<string | null>(null);
  const [operatorSearchMap, setOperatorSearchMap] = useState<Record<string, string>>({});
  const [operatorPickerOpenId, setOperatorPickerOpenId] = useState<string | null>(null);
  const [categoryModalSearch, setCategoryModalSearch] = useState<string>('');
  const [categoryModalFilterStatus, setCategoryModalFilterStatus] = useState<'all' | 'healthy' | 'issue'>('all');
  const [categoryQuickSuccessToast, setCategoryQuickSuccessToast] = useState<string | null>(null);
  const [inlineExpandedDefectsEqId, setInlineExpandedDefectsEqId] = useState<string | null>(null);
  const [inlineInspectionDefectsMap, setInlineInspectionDefectsMap] = useState<Record<string, string[]>>({});
  const [inlineInspectionNotesMap, setInlineInspectionNotesMap] = useState<Record<string, string>>({});
  const [inlineInspectionPhotosMap, setInlineInspectionPhotosMap] = useState<Record<string, string | null>>({});
  const [inlineInspectionAutoWoMap, setInlineInspectionAutoWoMap] = useState<Record<string, boolean>>({});
  
  // Equipment assignment to category state (درخواست کاربر: جستجوی کد/نام تجهیز از اکسل یا انبار و ورود به دسته همراه با تعیین اپراتور)
  const [isAssignPanelOpen, setIsAssignPanelOpen] = useState<boolean>(false);
  const [assignSearchQuery, setAssignSearchQuery] = useState<string>('');
  const [assignTargetOperator, setAssignTargetOperator] = useState<string>('');
  const [assignFastCode, setAssignFastCode] = useState<string>('');
  const [assignFastName, setAssignFastName] = useState<string>('');
  const [assignFilterPool, setAssignFilterPool] = useState<'unassigned' | 'all'>('all');

  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState<string>('');
  const [editingCatCount, setEditingCatCount] = useState<number>(0);
  const [isAddingNewCategory, setIsAddingNewCategory] = useState<boolean>(false);
  const [newCatName, setNewCatName] = useState<string>('');
  const [newCatCount, setNewCatCount] = useState<number>(0);

  // مداد ویرایش تکی نام و عکس پس‌زمینه دسته (مورد مؤکد کاربر: فقط و فقط نام و عکس پس‌زمینه)
  const [categoryToQuickEdit, setCategoryToQuickEdit] = useState<ChecklistCategory | null>(null);
  const [quickEditCatName, setQuickEditCatName] = useState<string>('');
  const [quickEditCatImage, setQuickEditCatImage] = useState<string>('');
  const [rawImageForFraming, setRawImageForFraming] = useState<string | null>(null);

  // Equipment code inline edit state (مورد اول کاربر: مداد ویرایش کد تجهیز)
  const [editingEquipmentCodeId, setEditingEquipmentCodeId] = useState<string | null>(null);
  const [editingEquipmentCodeValue, setEditingEquipmentCodeValue] = useState<string>('');

  // New Operator state
  const [newOperatorName, setNewOperatorName] = useState<string>('');
  
  // New Equipment state
  const [newEqCode, setNewEqCode] = useState<string>('');
  const [newEqName, setNewEqName] = useState<string>('');
  const [newEqCategory, setNewEqCategory] = useState<string>('تراش');
  const [newEqHall, setNewEqHall] = useState<string>(FACTORY_LOCATIONS[0] || 'سالن ۱');

  // مودال تخصیص و افزودن گروهی تجهیزات از دیتابیس نگهداری پیشگیرانه PM به دسته‌های چک‌لیست
  const [isPmEquipmentPickerOpen, setIsPmEquipmentPickerOpen] = useState<boolean>(false);
  const [pmPickerSearch, setPmPickerSearch] = useState<string>('');
  const [pmPickerTargetCategory, setPmPickerTargetCategory] = useState<string>('تراش');
  const [pmPickerSelectedIds, setPmPickerSelectedIds] = useState<string[]>([]);
  const [pmPickerGroupFilter, setPmPickerGroupFilter] = useState<string>('all');
  const [pmPickerLocationFilter, setPmPickerLocationFilter] = useState<string>('all');

  // Equipment Excel Import State
  const [isEquipmentExcelModalOpen, setIsEquipmentExcelModalOpen] = useState<boolean>(false);
  const [excelParsedEquipments, setExcelParsedEquipments] = useState<EquipmentItem[]>([]);
  const [excelFileName, setExcelFileName] = useState<string>('');
  const [excelParseError, setExcelParseError] = useState<string | null>(null);
  const [excelImportMode, setExcelImportMode] = useState<'merge' | 'replace'>('merge');
  const [isExcelParsing, setIsExcelParsing] = useState<boolean>(false);

  // Sync Factory Locations across PM Studio, Technical Services & Checklists
  useEffect(() => {
    if (isFactoryLocationsModalOpen) {
      try {
        const saved = localStorage.getItem('pm_studio_locations_v2');
        if (saved) {
          setActiveFactoryLocations(JSON.parse(saved));
        }
      } catch {}
    }
  }, [isFactoryLocationsModalOpen]);

  const toggleModalLocationExpand = (locId: string) => {
    setModalExpandedLocations(prev => ({ ...prev, [locId]: !prev[locId] }));
  };

  const handleAddSubLocationFromModal = (locId: string) => {
    const textVal = (newSubLocInputsInApp[locId] || '').trim();
    if (!textVal) return;
    const updated = activeFactoryLocations.map(loc => {
      if (loc.id === locId) {
        const subList = loc.subLocations || [];
        if (subList.some((s: any) => s.name === textVal)) return loc;
        const newSub = { id: `${loc.id}-${Date.now()}`, name: textVal };
        return { ...loc, subLocations: [...subList, newSub] };
      }
      return loc;
    });
    setActiveFactoryLocations(updated);
    try {
      localStorage.setItem('pm_studio_locations_v2', JSON.stringify(updated));
    } catch {}
    setNewSubLocInputsInApp(prev => ({ ...prev, [locId]: '' }));
  };

  const handleDeleteSubLocationFromModal = (locId: string, subId: string) => {
    const updated = activeFactoryLocations.map(loc => {
      if (loc.id === locId) {
        return {
          ...loc,
          subLocations: (loc.subLocations || []).filter((s: any) => s.id !== subId)
        };
      }
      return loc;
    });
    setActiveFactoryLocations(updated);
    try {
      localStorage.setItem('pm_studio_locations_v2', JSON.stringify(updated));
    } catch {}
  };

  // Modal State
  const [modalType, setModalType] = useState<
    'none' | 'unifiedForm' | 'viewRequest' | 'addTech' | 'editTech' | 'cardCode' | 'toolbarChecklist' | 'toolbarOil' | 'toolbarReport' | 'supabaseSettings' | 'tankTx' | 'consumablesReport' | 'offlineInfo' | 'addPmSchedule' | 'viewPmDetails' | 'installDesktop' | 'videoPreview'
  >('none');

  // ========================================================
  // BROWSER HISTORY & MOBILE HARDWARE BACK BUTTON NAVIGATION
  // (حل مشکل خروج کامل از سایت با زدن دکمه بازگشت در گوشی موبایل)
  // ========================================================
  useEffect(() => {
    try {
      if (!window.history.state || !window.history.state.portalApp) {
        window.history.replaceState({ portalApp: true, view: 'portal', depth: 0 }, '');
      }
    } catch {}
  }, []);

  // با هر تغییر نما، یک استیت در تاریخچه ثبت می‌شود تا بازگشت به جای بستن برنامه، به صفحه قبل برگردد
  const prevViewForHistoryRef = useRef(currentView);
  useEffect(() => {
    if (currentView !== prevViewForHistoryRef.current) {
      if (currentView !== 'portal') {
        try {
          window.history.pushState({ portalApp: true, view: currentView }, '');
        } catch {}
      }
      prevViewForHistoryRef.current = currentView;
    }
  }, [currentView]);

  const isAnyModalActive = Boolean(
    selectedPhotoLightbox ||
    isFactoryLocationsModalOpen ||
    inspectingEquipment ||
    isInspectionHistoryModalOpen ||
    isLeaderboardModalOpen ||
    isOperatorsModalOpen ||
    isAddOperatorModalOpen ||
    isAddEquipmentModalOpen ||
    isCategoryManageModalOpen ||
    isPmEquipmentPickerOpen ||
    isEquipmentExcelModalOpen ||
    selectedCategoryForModal ||
    categoryToQuickEdit ||
    isSideToolbarOpen ||
    isChecklistDrawerOpen ||
    isOilOfficialPrintModalOpen ||
    oilModalMode !== 'none' ||
    modalType !== 'none'
  );

  const prevModalActiveRef = useRef(isAnyModalActive);
  useEffect(() => {
    if (isAnyModalActive && !prevModalActiveRef.current) {
      try {
        window.history.pushState({ portalApp: true, modal: true }, '');
      } catch {}
    }
    prevModalActiveRef.current = isAnyModalActive;
  }, [isAnyModalActive]);

  useEffect(() => {
    const handlePopState = () => {
      // ۱. اگر هر نوع لایت‌باکس عکس باز است، اول آن را ببند
      if (selectedPhotoLightbox) {
        setSelectedPhotoLightbox(null);
        return;
      }
      // ۲. بستن مدال‌های چک‌لیست و دسته‌ها
      if (inspectingEquipment) {
        setInspectingEquipment(null);
        return;
      }
      if (selectedCategoryForModal) {
        setSelectedCategoryForModal(null);
        return;
      }
      if (categoryToQuickEdit) {
        setCategoryToQuickEdit(null);
        return;
      }
      if (isInspectionHistoryModalOpen) {
        setIsInspectionHistoryModalOpen(false);
        return;
      }
      if (isLeaderboardModalOpen) {
        setIsLeaderboardModalOpen(false);
        return;
      }
      if (isOperatorsModalOpen) {
        setIsOperatorsModalOpen(false);
        return;
      }
      if (isAddOperatorModalOpen) {
        setIsAddOperatorModalOpen(false);
        return;
      }
      if (isAddEquipmentModalOpen) {
        setIsAddEquipmentModalOpen(false);
        return;
      }
      if (isCategoryManageModalOpen) {
        setIsCategoryManageModalOpen(false);
        return;
      }
      if (isPmEquipmentPickerOpen) {
        setIsPmEquipmentPickerOpen(false);
        return;
      }
      if (isEquipmentExcelModalOpen) {
        setIsEquipmentExcelModalOpen(false);
        return;
      }
      // ۳. بستن نوارهای کناری
      if (isSideToolbarOpen) {
        setIsSideToolbarOpen(false);
        return;
      }
      if (isChecklistDrawerOpen) {
        setIsChecklistDrawerOpen(false);
        return;
      }
      if (isFactoryLocationsModalOpen) {
        setIsFactoryLocationsModalOpen(false);
        return;
      }
      // ۴. مدال‌های خدمات فنی و انبار روغن
      if (oilModalMode !== 'none') {
        setOilModalMode('none');
        return;
      }
      if (isOilOfficialPrintModalOpen) {
        setIsOilOfficialPrintModalOpen(false);
        return;
      }
      if (modalType !== 'none') {
        setModalType('none');
        return;
      }
      // ۵. اگر هیچ مدالی باز نیست و کاربر در صفحه‌ای به جز صفحه اصلی است، یک مرحله به صفحه اصلی برگرد
      if (currentView !== 'portal') {
        setCurrentView('portal');
        return;
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [
    selectedPhotoLightbox,
    inspectingEquipment,
    selectedCategoryForModal,
    categoryToQuickEdit,
    isInspectionHistoryModalOpen,
    isLeaderboardModalOpen,
    isOperatorsModalOpen,
    isAddOperatorModalOpen,
    isAddEquipmentModalOpen,
    isCategoryManageModalOpen,
    isPmEquipmentPickerOpen,
    isEquipmentExcelModalOpen,
    isSideToolbarOpen,
    isChecklistDrawerOpen,
    isFactoryLocationsModalOpen,
    oilModalMode,
    isOilOfficialPrintModalOpen,
    modalType,
  ]);

  // پیش‌بارگذاری آنی پوستر لوگو و تصاویر پس‌زمینه در حافظه مرورگر جهت تعویض آنی و بدون لگ بین صفحات
  useEffect(() => {
    try {
      const darkBgWebp = new Image();
      darkBgWebp.src = '/assets/aistudio/bg-silver-dark.webp';
      const lightBgWebp = new Image();
      lightBgWebp.src = '/assets/aistudio/bg-silver-light.webp';
    } catch {}
  }, []);

  // ========================================================
  // رتبه‌بندی اپراتورها فقط و منحصراً بر اساس تجهیزاتی که تا الان واقعاً بازرسی شده‌اند
  // (درخواست کاربر: فقط تجهیزات ثبت‌شده حساب شود نه ۶ اپراتور فرضی)
  // ========================================================
  const activeOperatorLeaderboard = useMemo(() => {
    const operatorStats: Record<string, {
      id: string;
      name: string;
      inspectionsCount: number;
      conformingCount: number;
      nonConformingCount: number;
    }> = {};

    // استخراج دقیق از گزارش‌های بازرسی ثبت‌شده
    inspectionLogs.forEach(log => {
      const opName = (log.operator || '').trim();
      if (!opName) return;
      if (!operatorStats[opName]) {
        operatorStats[opName] = {
          id: `op-${opName}`,
          name: opName,
          inspectionsCount: 0,
          conformingCount: 0,
          nonConformingCount: 0
        };
      }
      operatorStats[opName].inspectionsCount += 1;
      if (log.result === 'conforming') {
        operatorStats[opName].conformingCount += 1;
      } else {
        operatorStats[opName].nonConformingCount += 1;
      }
    });

    // بررسی تجهیزاتی که آخرین تاریخ بازرسی دارند
    equipments.forEach(eq => {
      if (eq.lastInspectionDate && eq.lastInspectionDate !== 'ثبت نشده') {
        const opName = (eq.operatorName || '').trim();
        if (opName && !operatorStats[opName]) {
          operatorStats[opName] = {
            id: `op-${opName}`,
            name: opName,
            inspectionsCount: 1,
            conformingCount: eq.status === 'سالم' ? 1 : 0,
            nonConformingCount: eq.status === 'تعمیر_اضطراری' || eq.status === 'نیازمند_سرویس' ? 1 : 0
          };
        }
      }
    });

    // اضافه کردن اپراتورهایی از استیت که بازرسی واقعی > 0 دارند
    operatorLeaderboard.forEach(op => {
      if (op.inspectionsCount > 0 && !operatorStats[op.name]) {
        operatorStats[op.name] = {
          id: op.id || `op-${op.name}`,
          name: op.name,
          inspectionsCount: op.inspectionsCount,
          conformingCount: op.status === 'بدون مشکل' ? op.inspectionsCount : Math.max(0, op.inspectionsCount - 1),
          nonConformingCount: op.status === 'دارای عدم انطباق' ? 1 : 0
        };
      }
    });

    const result = Object.values(operatorStats)
      .filter(item => item.inspectionsCount > 0)
      .map(item => {
        const perf = item.inspectionsCount > 0
          ? item.nonConformingCount === 0
            ? 100
            : Math.min(99, Math.round((item.conformingCount / item.inspectionsCount) * 100))
          : 100;
        const status: 'بدون مشکل' | 'دارای عدم انطباق' = item.nonConformingCount > 0 ? 'دارای عدم انطباق' : 'بدون مشکل';
        return {
          id: item.id,
          name: item.name,
          inspectionsCount: item.inspectionsCount,
          status,
          performancePct: perf
        };
      });

    return result.sort((a, b) =>
      b.performancePct - a.performancePct ||
      b.inspectionsCount - a.inspectionsCount ||
      a.name.localeCompare(b.name, 'fa')
    );
  }, [inspectionLogs, equipments, operatorLeaderboard]);
  
  // Supabase Database Sync State
  const [supabaseConnected, setSupabaseConnected] = useState(false);
  const [supabaseLoading, setSupabaseLoading] = useState(false);
  const [supabaseStatusMsg, setSupabaseStatusMsg] = useState<{ text: string; isError: boolean } | null>(null);
  const [supabaseUrlInput, setSupabaseUrlInput] = useState(() => getStoredSupabaseConfig().url);
  const [supabaseKeyInput, setSupabaseKeyInput] = useState(() => getStoredSupabaseConfig().anonKey);
  const [sqlCopied, setSqlCopied] = useState(false);

  // Check and sync Supabase on initial load
  useEffect(() => {
    const initSupabaseSync = async () => {
      const client = getSupabase();
      if (!client) {
        setSupabaseConnected(false);
        return;
      }
      setSupabaseLoading(true);
      const res = await fetchWorkRequestsFromSupabase();
      if (res.data && res.data.length > 0) {
        setWorkRequests(res.data);
        setSupabaseConnected(true);
      } else if (!res.error) {
        setSupabaseConnected(true);
        // اگر جدول تازه ساخته شده و خالی است، رکوردهای فعلی را در سوپابیس ذخیره کن
        INITIAL_WORK_REQUESTS.forEach(item => {
          upsertWorkRequestInSupabase(item).catch(() => {});
        });
      } else {
        setSupabaseConnected(false);
      }

      // همچنین مخازن روغن را نیز از دیتابیس Supabase همگام کن
      try {
        const tanksRes = await fetchTanksFromSupabase();
        const lastLocalWrite = parseInt(localStorage.getItem('portal_central_last_write_ts') || '0', 10);
        const localSavedTanksStr = localStorage.getItem('portal_oil_tanks');
        const localSavedTanks: OilTank[] = localSavedTanksStr ? JSON.parse(localSavedTanksStr) : [];

        if (tanksRes.data && tanksRes.data.length > 0) {
          const mappedTanks: OilTank[] = tanksRes.data.map((row: any) => ({
            id: Number(row.id),
            name: row.name || 'مخزن روغن',
            subName: row.sub_name || '',
            type: row.type || '',
            capacityLiters: Number(row.capacity_liters || 1000),
            currentLiters: Number(row.current_liters || 0),
            minAlertLiters: Number(row.min_alert_liters || 200),
            lastRefill: row.last_refill || '',
            colorClass: row.color_class || 'amber'
          }));

          // اگر دیتای محلی دارای تغییرات و ثبت تراکنش است، دیتای محلی را حفظ و سوپابیس را با آن به‌روز کن
          if (localSavedTanks.length > 0 && lastLocalWrite > 0) {
            setOilTanks(localSavedTanks);
            localSavedTanks.forEach(t => {
              updateTankInSupabase({
                id: Number(t.id),
                name: t.name,
                capacity_liters: t.capacityLiters,
                current_liters: t.currentLiters,
                last_refill: t.lastRefill
              }).catch(() => {});
            });
          } else {
            // اطمینان از تنظیم دقیق موجودی مخزن آب صابون روی ۶۳۰ لیتر
            const sanitized = mappedTanks.map(t => {
              if (String(t.id) === '2' || (t.name && t.name.includes('آب صابون'))) {
                return { ...t, currentLiters: 630, lastRefill: '1405/08/16' };
              }
              return t;
            });
            setOilTanks(sanitized);
            try { localStorage.setItem('portal_oil_tanks', JSON.stringify(sanitized)); } catch {}
            sanitized.forEach(t => {
              updateTankInSupabase({
                id: Number(t.id),
                name: t.name,
                capacity_liters: t.capacityLiters,
                current_liters: t.currentLiters,
                last_refill: t.lastRefill
              }).catch(() => {});
            });
          }
        } else if (!tanksRes.error && client) {
          // در صورتی که جدول مخازن در سوپابیس خالی است، مقادیر محلی یا پیش‌فرض را درج کن
          const tanksToSeed = localSavedTanks.length > 0 ? localSavedTanks : INITIAL_OIL_TANKS;
          tanksToSeed.forEach(t => {
            updateTankInSupabase({
              id: t.id,
              name: t.name,
              sub_name: t.subName,
              type: t.type,
              capacity_liters: t.capacityLiters,
              current_liters: t.currentLiters,
              min_alert_liters: t.minAlertLiters,
              last_refill: t.lastRefill,
              color_class: t.colorClass
            }).catch(() => {});
          });
        }
      } catch (e) {
        console.warn('Supabase tanks sync skipped:', e);
      }

      setSupabaseLoading(false);
    };

    initSupabaseSync();
  }, []);

  // مدیر هوشمند حالت آفلاین و همگام‌سازی دائمی با دیتابیس ابری
  const [isOnline, setIsOnline] = useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncNotice, setSyncNotice] = useState<{ text: string; type: 'success' | 'info' | 'warning' } | null>(null);
  const [pendingSyncQueue, setPendingSyncQueue] = useState<Array<{ type: 'upsert' | 'status'; data: any; timestamp: number }>>(() => {
    try {
      const saved = localStorage.getItem('technicalServiceOfflineQueue');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // ذخیره دائمی صف کارهای در انتظار در حافظه سیستم (بدون محدودیت زمانی)
  useEffect(() => {
    try {
      localStorage.setItem('technicalServiceOfflineQueue', JSON.stringify(pendingSyncQueue));
    } catch (e) {
      console.error('Failed to save offline queue:', e);
    }
  }, [pendingSyncQueue]);

  // افزودن یا به‌روزرسانی در صف همگام‌سازی آفلاین
  const enqueueOfflineAction = (action: { type: 'upsert' | 'status'; data: any }) => {
    setPendingSyncQueue(prev => {
      const filtered = prev.filter(item => {
        if (action.type === 'upsert' && item.type === 'upsert') {
          return item.data.code !== action.data.code;
        }
        if (action.type === 'status' && item.type === 'status') {
          return item.data.code !== action.data.code;
        }
        return true;
      });
      return [...filtered, { ...action, timestamp: Date.now() }];
    });
  };

  // تابع اجرای همگام‌سازی خودکار و دستی رکوردهای آفلاین با دیتابیس ابری
  const syncOfflineQueueToSupabase = async () => {
    if (!navigator.onLine || isSyncing) return;

    let currentQueue: Array<{ type: 'upsert' | 'status' | 'tank_update'; data: any; timestamp: number }> = [];
    try {
      const saved = localStorage.getItem('technicalServiceOfflineQueue');
      currentQueue = saved ? JSON.parse(saved) : [];
    } catch {
      currentQueue = [];
    }

    if (currentQueue.length === 0) return;

    setIsSyncing(true);
    let syncedCount = 0;
    const remainingQueue: typeof currentQueue = [];

    for (const item of currentQueue) {
      try {
        if (item.type === 'upsert') {
          const res = await upsertWorkRequestInSupabase(item.data);
          if (res.success) {
            syncedCount++;
          } else {
            remainingQueue.push(item);
          }
        } else if (item.type === 'status') {
          const res = await updateStatusInSupabase(item.data.code, item.data.status, item.data.completedAt);
          if (res.success) {
            syncedCount++;
          } else {
            remainingQueue.push(item);
          }
        } else if (item.type === 'tank_update') {
          const res = await updateTankInSupabase(item.data);
          if (res.success) {
            syncedCount++;
          } else {
            remainingQueue.push(item);
          }
        }
      } catch {
        remainingQueue.push(item);
      }
    }

    setPendingSyncQueue(remainingQueue as any);
    try {
      localStorage.setItem('technicalServiceOfflineQueue', JSON.stringify(remainingQueue));
    } catch {}
    setIsSyncing(false);

    if (syncedCount > 0) {
      setSyncNotice({
        text: `✓ همگام‌سازی خودکار موفق: تعداد ${toFaDigits(syncedCount)} عملیات ذخیره‌شده در حالت آفلاین، با سرور ابری ثبت شد.`,
        type: 'success'
      });
      setTimeout(() => setSyncNotice(null), 7000);
    }
  };

  // پایش لحظه‌ای وضعیت شبکه (اتصال یا قطع اینترنت)
  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      setSyncNotice({
        text: 'اتصال به اینترنت برقرار شد. در حال همگام‌سازی تضمینی اطلاعات و مخازن با سرور ابری...',
        type: 'info'
      });
      syncOfflineQueueToSupabase();

      // همگام‌سازی تضمینی وضعیت مخازن محلی با سرور ابری
      try {
        const localSavedTanksStr = localStorage.getItem('portal_oil_tanks');
        if (localSavedTanksStr) {
          const localSavedTanks: OilTank[] = JSON.parse(localSavedTanksStr);
          for (const t of localSavedTanks) {
            await updateTankInSupabase({
              id: Number(t.id),
              name: t.name,
              current_liters: t.currentLiters,
              last_refill: t.lastRefill
            }).catch(() => {});
          }
        }
      } catch {}

      fetchAndApplyCentralState();
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncNotice({
        text: 'دستگاه در حالت آفلاین است. نرم‌افزار بدون محدودیت زمانی کار می‌کند و کلیه داده‌ها در حافظه دستگاه ذخیره می‌شوند.',
        type: 'warning'
      });
      setTimeout(() => setSyncNotice(null), 8000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // بررسی دوره‌ای هر ۳۰ ثانیه برای اطمینان از ارسال صف آفلاین هنگام وصل بودن
    const interval = setInterval(() => {
      if (navigator.onLine && pendingSyncQueue.length > 0 && !isSyncing) {
        syncOfflineQueueToSupabase();
      }
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [pendingSyncQueue, isSyncing]);

  // Unified Form (2-in-1: Request + Work Order)
  const [editingItemCode, setEditingItemCode] = useState<string | null>(null);
  const [formSection, setFormSection] = useState<'both' | 'requestOnly' | 'workOrderOnly'>('both');
  const [includeWorkOrderActions, setIncludeWorkOrderActions] = useState(false);
  
  // تبدیل تمام ارقام به انگلیسی
  const toEnDigits = (str: string | number): string => {
    return String(str ?? '')
      .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
      .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584));
  };

  const getEnDateNow = () => {
    return getTodayShamsiDateStringPm();
  };

  const getEnTimeNow = () => {
    return toEnDigits(new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }));
  };

  const PERSIAN_MONTH_NAMES = [
    '', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
  ];

  const formatPersianDateBadge = (rawDate?: string) => {
    if (!rawDate) return { day: '۲۵', month: 'مهر' };
    const cleaned = toEnDigits(rawDate).trim();
    const parts = cleaned.split('/');
    if (parts.length >= 3) {
      const m = parseInt(parts[1], 10);
      const d = parseInt(parts[2], 10);
      const monthName = PERSIAN_MONTH_NAMES[m] || 'مهر';
      return { day: toFaDigits(d), month: monthName };
    }
    return { day: toFaDigits(cleaned.slice(-2) || '۲۵'), month: 'مهر' };
  };

  // محاسبه اختلاف دقیق ساعت شروع و پایان دستور کار به دقیقه
  const computeMinutesDiff = (startStr: string, endStr: string): number => {
    if (!startStr || !endStr) return 0;
    const cleanStart = toEnDigits(startStr).trim();
    const cleanEnd = toEnDigits(endStr).trim();
    const sParts = cleanStart.split(':').map(p => parseInt(p, 10));
    const eParts = cleanEnd.split(':').map(p => parseInt(p, 10));
    if (sParts.length < 2 || eParts.length < 2) return 0;
    const [h1, m1] = sParts;
    const [h2, m2] = eParts;
    if (isNaN(h1) || isNaN(m1) || isNaN(h2) || isNaN(m2)) return 0;
    const startMins = h1 * 60 + m1;
    let endMins = h2 * 60 + m2;
    if (endMins < startMins) {
      endMins += 24 * 60; // در صورت گذشتن از نیمه‌شب یا تعویض شیفت
    }
    return Math.max(0, endMins - startMins);
  };

  const formatDurationFriendly = (minutes: number): string => {
    const mins = Math.max(0, Math.floor(minutes || 0));
    if (mins === 0) return '0 دقیقه';
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    if (hours > 0 && remMins > 0) {
      return `${hours} ساعت و ${remMins} دقیقه (${mins} دقیقه)`;
    } else if (hours > 0) {
      return `${hours} ساعت (${mins} دقیقه)`;
    } else {
      return `${mins} دقیقه`;
    }
  };

  // Phase 1 Form Fields: Work Request
  const [reqTitle, setReqTitle] = useState('');
  const [reqPlace, setReqPlace] = useState((FACTORY_LOCATIONS[0] || ''));
  const [reqPriority, setReqPriority] = useState<string>('ایمنی');
  const [reqDate, setReqDate] = useState(() => getEnDateNow());
  const [reqTime, setReqTime] = useState(() => getEnTimeNow());
  const [reqDesc, setReqDesc] = useState('');
  
  // Phase 2 Form Fields: Work Order Actions (شامل تاریخ، ساعت شروع، ساعت پایان و محاسبه خودکار زمان)
  const [woTechnician, setWoTechnician] = useState('');
  const [woCoTechnicians, setWoCoTechnicians] = useState<string[]>([]);
  const [woComplexityLevel, setWoComplexityLevel] = useState<'آسان' | 'معمولی' | 'دشوار'>('معمولی');
  const [woOperationType, setWoOperationType] = useState('مکانیک');
  const [woActionDetails, setWoActionDetails] = useState('');
  const [woDate, setWoDate] = useState(() => getEnDateNow());
  const [woStartTime, setWoStartTime] = useState('08:30');
  const [woEndTime, setWoEndTime] = useState('09:45');
  const [woDuration, setWoDuration] = useState<number>(75);
  const [woCloseImmediately, setWoCloseImmediately] = useState(true);

  // Phase 2 Form Fields: لوازم مصرفی (قطعات مصرف‌شده در دستور کار)
  const [woConsumables, setWoConsumables] = useState<ConsumableItem[]>([]);
  const [consumableTab, setConsumableTab] = useState<'برقی' | 'مکانیکی' | 'سایر'>('برقی');
  const [newPartName, setNewPartName] = useState('');
  const [newPartCount, setNewPartCount] = useState<number>(1);
  const [newPartUnit, setNewPartUnit] = useState('عدد');
  const [showPresetsBar, setShowPresetsBar] = useState(false);

  // فیلترهای گزارش جامع لوازم مصرفی کارخانه
  const [consumablesReportTab, setConsumablesReportTab] = useState<'همه' | 'برقی' | 'مکانیکی' | 'سایر'>('همه');
  const [consumablesSearch, setConsumablesSearch] = useState('');
  const [consumablesHallFilter, setConsumablesHallFilter] = useState('همه');
  const [consumablesTechFilter, setConsumablesTechFilter] = useState('همه');

  // --- سامانه یکپارچه انبار و لوازم یدکی کارخانه (مشترک خدمات فنی و نگهداری پیشگیرانه PM) ---
  const [unifiedSpareParts, setUnifiedSpareParts] = useState<UnifiedSparePart[]>(() => getUnifiedSpareParts());
  const [consumablesMainTab, setConsumablesMainTab] = useState<'inventory' | 'report'>('inventory');
  const [sparePartsSourceFilter, setSparePartsSourceFilter] = useState<SparePartFilterSource>('all');
  const [sparePartsCategoryFilter, setSparePartsCategoryFilter] = useState<string>('all');
  const [sparePartsSearch, setSparePartsSearch] = useState('');
  const [isAddPartModalOpen, setIsAddPartModalOpen] = useState(false);
  const [newPartForm, setNewPartForm] = useState({
    name: '',
    category: 'برقی' as SparePartCategory,
    source: 'technical' as SparePartSource,
    stock: 5,
    minStock: 2,
    unit: 'عدد',
    price: '',
    eqFamily: '',
    location: '',
    notes: ''
  });

  // همگام‌سازی آنی دوطرفه با PMStudio از طریق اشتراک در رویدادهای حافظه و ارسال به سرور
  useEffect(() => {
    const unsubscribe = subscribeToSpareParts(parts => {
      setUnifiedSpareParts(parts);
      pushStateToServer({ unifiedSpareParts: parts });
    });
    return () => unsubscribe();
  }, [pushStateToServer]);

  // افزودن سریع قلم مصرفی از لیست پیش‌فرض و ثبت خودکار در انبار یکپارچه
  const handleAddConsumablePreset = (name: string, category: 'برقی' | 'مکانیکی' | 'سایر', unit = 'عدد') => {
    setWoConsumables(prev => {
      const existing = prev.find(item => item.name === name && item.category === category);
      if (existing) {
        return prev.map(item => item.id === existing.id ? { ...item, count: item.count + 1 } : item);
      }
      return [
        ...prev,
        {
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name,
          count: 1,
          category,
          unit
        }
      ];
    });

    // ثبت یا به‌روزرسانی قطعه در انبار یکپارچه با برچسب خدمات فنی
    try {
      addOrUpdateSparePart({
        name,
        category: category === 'برقی' ? 'برقی' : category === 'مکانیکی' ? 'مکانیکی' : 'عمومی و سایر',
        source: 'technical',
        unit
      });
    } catch {}
  };

  // افزودن قلم مصرفی دلخواه و سفارشی و ثبت تضمینی در انبار یکپارچه
  const handleAddCustomConsumable = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newPartName.trim();
    if (!trimmed) return;
    const countToAdd = Math.max(1, newPartCount);
    const unitToAdd = newPartUnit.trim() || 'عدد';

    setWoConsumables(prev => {
      const existing = prev.find(item => item.name.toLowerCase() === trimmed.toLowerCase() && item.category === consumableTab);
      if (existing) {
        return prev.map(item => item.id === existing.id ? { ...item, count: item.count + countToAdd } : item);
      }
      return [
        ...prev,
        {
          id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name: trimmed,
          count: countToAdd,
          category: consumableTab,
          unit: unitToAdd
        }
      ];
    });

    // ثبت قطعه دستی در انبار یکپارچه کارخانه با منبع «خدمات فنی»
    try {
      addOrUpdateSparePart({
        name: trimmed,
        category: consumableTab === 'برقی' ? 'برقی' : consumableTab === 'مکانیکی' ? 'مکانیکی' : 'عمومی و سایر',
        source: 'technical',
        stock: Math.max(4, countToAdd + 2),
        minStock: 2,
        unit: unitToAdd,
        eqFamily: reqPlace || 'خدمات فنی'
      });
    } catch {}

    setNewPartName('');
    setNewPartCount(1);
  };

  // افزایش یا کاهش موجودی قطعه در انبار یکپارچه
  const handleStockChange = (id: string, delta: number) => {
    const updated = adjustSparePartStock(id, delta);
    setUnifiedSpareParts(updated);
  };

  // حذف قطعه از انبار یکپارچه
  const handleDeleteSparePart = (id: string) => {
    if (window.confirm('آیا از حذف این قطعه یدکی از انبار اطمینان دارید؟')) {
      const updated = deleteSparePart(id);
      setUnifiedSpareParts(updated);
    }
  };

  // پاکسازی کامل کلیه گزارش‌های مصرف لوازم یدکی و شروع از نو
  const handleClearAllSparePartsReports = () => {
    if (window.confirm('آیا از حذف کامل تمام گزارش‌ها و سوابق مصرف لوازم یدکی اطمینان دارید؟\nتمام گزارش‌های گذشته پاک شده و از این لحظه به بعد اقلام جدید ذخیره خواهند شد.')) {
      clearAllSparePartsReports();
      const cleaned = workRequests.map(r => ({ ...r, consumables: [], partsUsed: '' }));
      setWorkRequests(cleaned);
      try {
        localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(cleaned));
      } catch {}
      setUnifiedSpareParts(getUnifiedSpareParts());
      setCategoryQuickSuccessToast('✓ کلیه گزارش‌های لوازم یدکی با موفقیت حذف شدند و سیستم آماده ذخیره اقلام جدید می‌باشد.');
      setTimeout(() => setCategoryQuickSuccessToast(null), 4500);
    }
  };

  // ثبت قطعه جدید دستی از درون انبار یکپارچه
  const handleCreateNewSparePart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPartForm.name.trim()) return;
    addOrUpdateSparePart({
      name: newPartForm.name.trim(),
      category: newPartForm.category,
      source: newPartForm.source,
      stock: Math.max(0, Number(newPartForm.stock) || 0),
      minStock: Math.max(0, Number(newPartForm.minStock) || 0),
      unit: newPartForm.unit.trim() || 'عدد',
      price: newPartForm.price.trim() || '—',
      eqFamily: newPartForm.eqFamily.trim() || (newPartForm.source === 'pm' ? 'تجهیزات PM' : 'خدمات فنی'),
      location: newPartForm.location.trim() || 'انبار قطعات فنی',
      notes: newPartForm.notes.trim() || ''
    });
    setIsAddPartModalOpen(false);
    setNewPartForm({
      name: '',
      category: 'برقی',
      source: 'technical',
      stock: 5,
      minStock: 2,
      unit: 'عدد',
      price: '',
      eqFamily: '',
      location: '',
      notes: ''
    });
  };

  // خروجی اکسل (CSV) از انبار یکپارچه قطعات یدکی با تفکیک منبع
  const exportSparePartsToCsv = () => {
    try {
      const filtered = unifiedSpareParts.filter(item => {
        if (sparePartsSourceFilter !== 'all' && item.source !== sparePartsSourceFilter) return false;
        if (sparePartsCategoryFilter !== 'all' && item.category !== sparePartsCategoryFilter) return false;
        if (sparePartsSearch.trim()) {
          const q = sparePartsSearch.trim().toLowerCase();
          return item.name.toLowerCase().includes(q) || (item.code || '').toLowerCase().includes(q) || (item.eqFamily || '').toLowerCase().includes(q);
        }
        return true;
      });

      const headers = ['ردیف', 'کد قطعه', 'نام قطعه یدکی', 'منبع / بخش', 'گروه تخصصی', 'موجودی', 'حداقل نقطه سفارش', 'واحد', 'وضعیت', 'قیمت (تومان)', 'تجهیز مرتبط', 'محل انبار'];
      const rows = filtered.map((item, idx) => {
        const sourceName = item.source === 'pm' ? 'نگهداری پیشگیرانه PM' : item.source === 'technical' ? 'خدمات فنی' : 'مشترک سامانه';
        const status = item.stock === 0 ? 'ناموجود' : item.stock <= item.minStock ? 'رو به اتمام' : 'موجودی کافی';
        return [
          idx + 1,
          `"${item.code || item.id}"`,
          `"${item.name}"`,
          `"${sourceName}"`,
          `"${item.category}"`,
          item.stock,
          item.minStock,
          `"${item.unit}"`,
          `"${status}"`,
          `"${item.price || '—'}"`,
          `"${item.eqFamily || '—'}"`,
          `"${item.location || '—'}"`
        ];
      });

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `spare_parts_inventory_${sparePartsSourceFilter}_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export spare parts error:', err);
    }
  };

  // حذف قلم مصرفی از فرم دستور کار
  const handleRemoveConsumable = (id: string) => {
    setWoConsumables(prev => prev.filter(c => c.id !== id));
  };

  // کاهش / افزایش تعداد قلم مصرفی در فرم
  const handleUpdateConsumableCount = (id: string, delta: number) => {
    setWoConsumables(prev => prev.map(c => {
      if (c.id !== id) return c;
      const nextCount = c.count + delta;
      return nextCount > 0 ? { ...c, count: nextCount } : c;
    }));
  };

  // تابع کمکی استخراج جامع کلیه قطعات و لوازم مصرفی و یدکی از هر درخواست کار یا پرونده
  const extractAllConsumablesFromRequest = (req: any): Array<{
    name: string;
    category: 'برقی' | 'مکانیکی' | 'سایر';
    unit: string;
    count: number;
  }> => {
    const result: Array<{
      name: string;
      category: 'برقی' | 'مکانیکی' | 'سایر';
      unit: string;
      count: number;
    }> = [];
    if (!req) return result;

    // ۱. بررسی آرایه یا متن ساختاریافته consumables
    if (Array.isArray(req.consumables) && req.consumables.length > 0) {
      req.consumables.forEach((c: any) => {
        if (!c) return;
        const name = String(c.name || c.partName || '').trim();
        if (!name) return;
        let cat: 'برقی' | 'مکانیکی' | 'سایر' = 'سایر';
        const rawCat = String(c.category || '').trim();
        if (rawCat.includes('برق')) cat = 'برقی';
        else if (rawCat.includes('مکانیک')) cat = 'مکانیکی';
        else if (rawCat === 'سایر') cat = 'سایر';
        else if (req.operationType?.includes('برق')) cat = 'برقی';
        else if (req.operationType?.includes('مکانیک')) cat = 'مکانیکی';

        const count = Math.max(1, Number(c.count || c.quantity || 1) || 1);
        const unit = c.unit || 'عدد';
        result.push({ name, category: cat, unit, count });
      });
    } else if (typeof req.consumables === 'string' && req.consumables.trim()) {
      try {
        const parsed = JSON.parse(req.consumables);
        if (Array.isArray(parsed)) {
          parsed.forEach((c: any) => {
            if (!c) return;
            const name = String(c.name || c.partName || '').trim();
            if (!name) return;
            let cat: 'برقی' | 'مکانیکی' | 'سایر' = 'سایر';
            const rawCat = String(c.category || '').trim();
            if (rawCat.includes('برق')) cat = 'برقی';
            else if (rawCat.includes('مکانیک')) cat = 'مکانیکی';
            else if (rawCat === 'سایر') cat = 'سایر';
            const count = Math.max(1, Number(c.count || c.quantity || 1) || 1);
            const unit = c.unit || 'عدد';
            result.push({ name, category: cat, unit, count });
          });
        }
      } catch {
        const tokens = req.consumables.split(/[،,;\n]+/).map((s: string) => s.trim()).filter(Boolean);
        tokens.forEach((tk: string) => {
          let cat: 'برقی' | 'مکانیکی' | 'سایر' = 'سایر';
          if (req.operationType?.includes('برق')) cat = 'برقی';
          else if (req.operationType?.includes('مکانیک')) cat = 'مکانیکی';
          result.push({ name: tk, category: cat, unit: 'عدد', count: 1 });
        });
      }
    }

    // ۲. بررسی فیلد قطعات یدکی و مصرفی (partsUsed یا parts)
    const rawParts = req.partsUsed || req.parts;
    if (rawParts) {
      if (Array.isArray(rawParts)) {
        rawParts.forEach((p: any) => {
          const name = typeof p === 'string' ? p.trim() : String(p.name || p.partName || '').trim();
          if (name && !result.some(r => r.name.toLowerCase() === name.toLowerCase())) {
            let cat: 'برقی' | 'مکانیکی' | 'سایر' = 'سایر';
            if (req.operationType?.includes('برق') || name.includes('فیوز') || name.includes('کابل') || name.includes('کلید') || name.includes('کنتاکتور')) cat = 'برقی';
            else if (req.operationType?.includes('مکانیک') || name.includes('بلبرینگ') || name.includes('تسمه') || name.includes('واشر') || name.includes('پیچ') || name.includes('بوش')) cat = 'مکانیکی';
            result.push({
              name,
              category: cat,
              unit: 'عدد',
              count: typeof p === 'object' && p.count ? Number(p.count) : 1
            });
          }
        });
      } else if (typeof rawParts === 'string' && rawParts.trim()) {
        const tokens = rawParts.split(/[،,;\n]+/).map((s: string) => s.trim()).filter(Boolean);
        tokens.forEach((tk: string) => {
          let cleanName = tk;
          let qty = 1;
          const match = tk.match(/^(.+?)\s*\((?:(\d+)\s*عدد)?\)$/);
          if (match) {
            cleanName = match[1].trim();
            if (match[2]) qty = parseInt(match[2], 10) || 1;
          }
          if (cleanName && !result.some(r => r.name.toLowerCase() === cleanName.toLowerCase())) {
            let cat: 'برقی' | 'مکانیکی' | 'سایر' = 'سایر';
            if (req.operationType?.includes('برق') || cleanName.includes('فیوز') || cleanName.includes('کابل') || cleanName.includes('کلید') || cleanName.includes('کنتاکتور')) cat = 'برقی';
            else if (req.operationType?.includes('مکانیک') || cleanName.includes('بلبرینگ') || cleanName.includes('تسمه') || cleanName.includes('واشر') || cleanName.includes('پیچ') || cleanName.includes('بوش')) cat = 'مکانیکی';
            result.push({ name: cleanName, category: cat, unit: 'عدد', count: qty });
          }
        });
      }
    }

    return result;
  };

  // محاسبه خلاصه کل مصرف قطعات در کارخانه برای کارت‌ها و سربرگ
  const getConsumablesSummary = () => {
    let grandTotal = 0;
    let electricalTotal = 0;
    let mechanicalTotal = 0;
    let otherTotal = 0;

    workRequests.forEach(req => {
      const items = extractAllConsumablesFromRequest(req);
      items.forEach(c => {
        grandTotal += c.count;
        if (c.category === 'برقی') electricalTotal += c.count;
        else if (c.category === 'مکانیکی') mechanicalTotal += c.count;
        else otherTotal += c.count;
      });
    });

    return {
      grandTotal,
      electricalTotal,
      mechanicalTotal,
      otherTotal
    };
  };

  // دریافت گزارش تجمیعی قطعات مصرفی با جزئیات دفعات و سالن‌ها
  const getAggregatedConsumables = () => {
    interface AggregatedItem {
      name: string;
      category: 'برقی' | 'مکانیکی' | 'سایر';
      unit: string;
      totalCount: number;
      usageCount: number;
      places: Set<string>;
      technicians: Set<string>;
      history: Array<{
        workOrderCode: string;
        requestTitle: string;
        place: string;
        date: string;
        count: number;
        technician: string;
      }>;
    }

    const map = new Map<string, AggregatedItem>();

    workRequests.forEach(req => {
      // اعمال فیلتر سالن و تکنسین در سطح پرونده
      if (consumablesHallFilter !== 'همه' && req.place !== consumablesHallFilter) return;
      if (consumablesTechFilter !== 'همه' && req.technician !== consumablesTechFilter && !req.coTechnicians?.includes(consumablesTechFilter)) return;

      const items = extractAllConsumablesFromRequest(req);
      items.forEach(c => {
        if (consumablesReportTab !== 'همه' && c.category !== consumablesReportTab) return;
        if (consumablesSearch.trim()) {
          const q = consumablesSearch.trim().toLowerCase();
          const matchName = c.name.toLowerCase().includes(q);
          const matchPlace = (req.place || '').toLowerCase().includes(q);
          const matchTech = (req.technician || '').toLowerCase().includes(q);
          if (!matchName && !matchPlace && !matchTech) return;
        }

        const key = `${c.name}___${c.category}`;
        const count = c.count;
        const unit = c.unit;

        if (!map.has(key)) {
          map.set(key, {
            name: c.name,
            category: c.category,
            unit,
            totalCount: 0,
            usageCount: 0,
            places: new Set<string>(),
            technicians: new Set<string>(),
            history: []
          });
        }

        const entry = map.get(key)!;
        entry.totalCount += count;
        entry.usageCount += 1;
        if (req.place) entry.places.add(req.place);
        if (req.technician) entry.technicians.add(req.technician);
        entry.history.push({
          workOrderCode: req.workOrderCode || req.code || '—',
          requestTitle: req.title,
          place: req.place,
          date: req.woDate || req.completedAt || req.created,
          count,
          technician: req.technician || 'نامشخص'
        });
      });
    });

    return Array.from(map.values()).sort((a, b) => b.totalCount - a.totalCount);
  };

  const [formError, setFormError] = useState('');
  const [desktopDownloadStatus, setDesktopDownloadStatus] = useState<'idle' | 'downloading' | 'success' | 'error'>('idle');
  const [desktopDownloadMsg, setDesktopDownloadMsg] = useState<string>('');
  const [desktopLinkCopied, setDesktopLinkCopied] = useState<boolean>(false);

  // دانلود مستقیم و آفلاین فایل مستقل دسکتاپ (نسخه کاملاً به‌روز و بدون کش مرورگر)
  const downloadDesktopHtmlFile = () => {
    setDesktopDownloadStatus('downloading');
    setDesktopDownloadMsg('در حال دریافت آخرین نسخه فایل مستقل دسکتاپ از دیتاسنتر ابری...');
    try {
      const downloadUrl = getApiUrl('/api/portal/download-desktop?v=' + Date.now());
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = 'CMMS-Factory-Desktop.html';
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try { document.body.removeChild(a); } catch {}
      }, 1500);

      setDesktopDownloadStatus('success');
      setDesktopDownloadMsg('✓ دریافت فایل آغاز شد! لطفاً پوشه Downloads سیستم خود را بررسی فرمایید.');
      setTimeout(() => {
        setDesktopDownloadStatus('idle');
      }, 7000);
    } catch (e: any) {
      setDesktopDownloadStatus('error');
      setDesktopDownloadMsg('برای دانلود، از دکمه «کپی آدرس لینک دانلود» در زیر استفاده فرمایید.');
    }
  };

  const [backupStatusMsg, setBackupStatusMsg] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const backupFileInputRef = useRef<HTMLInputElement>(null);


  // ۱. دانلود فایل پشتیبان جامع از تمام اطلاعات کارخانه (JSON کامل و ساختاریافته)
  const downloadFullSystemBackupJson = () => {
    try {
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = `${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;

      const fullBackup = {
        app: 'CMMS_FACTORY_SYSTEM',
        title: `نسخه پشتیبان جامع کلیه اطلاعات ${BRAND_CONFIG.SYSTEM_NAME}`,
        version: '2.5.0',
        exportedAt: now.toISOString(),
        exportedShamsiDate: toFaDigits(new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full', timeStyle: 'medium' }).format(now)),
        stats: {
          oilTanksCount: oilTanks.length,
          oilTransactionsCount: oilTransactions.length,
          workRequestsCount: workRequests.length,
          equipmentsCount: equipments.length,
          checklistCategoriesCount: checklistCategories.length,
          pmSchedulesCount: pmSchedules.length,
          techniciansCount: technicians.length,
          inspectionLogsCount: inspectionLogs.length,
          unifiedSparePartsCount: unifiedSpareParts.length,
          sparePartsConsumptionsCount: getSparePartConsumptions().length
        },
        data: {
          oilTanks,
          oilTransactions,
          workRequests,
          equipments,
          checklistCategories,
          technicians,
          technicianPhotos,
          inspectionLogs,
          pmSchedules,
          operatorLeaderboard,
          productionOperators,
          unifiedSpareParts,
          sparePartsConsumptions: getSparePartConsumptions(),
          offlineQueue: pendingSyncQueue,
          _updatedAt: Date.now()
        }
      };

      const jsonStr = JSON.stringify(fullBackup, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `CMMS-Full-Backup-${dateStr}_${timeStr}.json`;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try {
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        } catch {}
      }, 1000);

      setBackupStatusMsg({
        text: `✓ فایل پشتیبان جامع (${toFaDigits(oilTransactions.length)} تراکنش روغن، ${toFaDigits(workRequests.length)} دستورکار، ${toFaDigits(oilTanks.length)} مخزن، ${toFaDigits(equipments.length)} دستگاه و ${toFaDigits(unifiedSpareParts.length)} قلم قطعه یدکی) با موفقیت دانلود شد. این فایل را نگه‌داری کنید؛ همچنین می‌توانید آن را در صورت نیاز بازیابی کنید.`,
        type: 'success'
      });
      setTimeout(() => setBackupStatusMsg(null), 10000);
    } catch (e: any) {
      setBackupStatusMsg({
        text: `خطا در ایجاد فایل پشتیبان: ${e?.message || 'نامشخص'}`,
        type: 'error'
      });
    }
  };

  // خروجی اختصاصی اکسل از تجهیزات و ماشین‌آلات کارخانه
  const exportEquipmentsToExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const rows = equipments.map(e => ({
        'کد دستگاه': e.id,
        'شناسه سیستمی': e.code || '',
        'نام دستگاه': e.name,
        'دسته‌بندی (گروه دستگاه)': e.category || '',
        'سالن استقرار': e.hall || '',
        'وضعیت عملیاتی': e.status || 'فعال',
        'آخرین تاریخ بازرسی': e.lastInspectionDate || '',
        'بازرس مسئول': e.inspector || ''
      }));
      const ws = XLSX.utils.json_to_sheet(rows);
      XLSX.utils.book_append_sheet(wb, ws, 'تجهیزات و ماشین‌آلات');
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      XLSX.writeFile(wb, `CMMS-Equipments-Master-${dateStr}.xlsx`);
      setBackupStatusMsg({
        text: `✓ فایل اکسل ماشین‌آلات و تجهیزات با موفقیت دانلود شد.`,
        type: 'success'
      });
      setTimeout(() => setBackupStatusMsg(null), 6000);
    } catch (e: any) {
      setBackupStatusMsg({
        text: `خطا در صدور فایل اکسل تجهیزات: ${e?.message || 'نامشخص'}`,
        type: 'error'
      });
    }
  };

  // ۲. صدور فایل چندبرگه‌ای جامع اکسل از تمامی بخش‌های کارخانه (Excel Multi-Sheet XLSX با شیت راهنما در ابتدا)
  const downloadFullSystemBackupExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);

      // شیت ۱: داشبورد و خلاصه جامع سامانه (اولین شیت که مستقیماً روی صفحه باز می‌شود تا کاربر کل بخش‌ها را ببیند)
      const overviewRows = [
        {
          'ردیف': '۱',
          'عنوان بخش سامانه': '🛠️ دستورکارها و خدمات فنی',
          'نام زبانه در اکسل (Sheet)': 'دستورکارها و خدمات فنی',
          'تعداد رکوردها': `${toFaDigits(workRequests.length)} دستورکار`,
          'محتوای این برگه': 'پرونده‌های فنی، شرح عیوب، اقدامات اصلاحی، ساعت شروع و پایان، قطعات مصرفی و وضعیت اختتام',
          'راهنمای دسترسی': 'روی زبانه «دستورکارها و خدمات فنی» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۲',
          'عنوان بخش سامانه': '⚙️ ماشین‌آلات و تجهیزات',
          'نام زبانه در اکسل (Sheet)': 'ماشین‌آلات و تجهیزات',
          'تعداد رکوردها': `${toFaDigits(equipments.length)} دستگاه`,
          'محتوای این برگه': 'فهرست کامل ماشین‌آلات و تجهیزات ثبت‌شده با کد یکتا',
          'راهنمای دسترسی': 'روی زبانه «ماشین‌آلات و تجهیزات» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۳',
          'عنوان بخش سامانه': '📋 نگهداری پیشگیرانه (PM)',
          'نام زبانه در اکسل (Sheet)': 'نگهداری پیشگیرانه PM',
          'تعداد رکوردها': `${toFaDigits(pmSchedules.length)} برنامه`,
          'محتوای این برگه': 'برنامه‌های دوره‌ای PM، چک‌لیست‌های پیشگیرانه، اولویت و تکنسین‌های مسئول',
          'راهنمای دسترسی': 'روی زبانه «نگهداری پیشگیرانه PM» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۴',
          'عنوان بخش سامانه': '🔩 انبار قطعات یدکی و لوازم مصرفی',
          'نام زبانه در اکسل (Sheet)': 'انبار قطعات یدکی',
          'تعداد رکوردها': `${toFaDigits(unifiedSpareParts.length)} قلم کالا`,
          'محتوای این برگه': 'انبار یکپارچه قطعات، کدهای تخصصی، موجودی، محل قفسه و دستگاه مرتبط',
          'راهنمای دسترسی': 'روی زبانه «انبار قطعات یدکی» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۵',
          'عنوان بخش سامانه': '📝 سوابق مصرف قطعات یدکی',
          'نام زبانه در اکسل (Sheet)': 'سوابق مصرف قطعات',
          'تعداد رکوردها': `${toFaDigits(getSparePartConsumptions().length)} سابقه`,
          'محتوای این برگه': 'رهگیری دقیق قطعات مصرف‌شده در خدمات فنی و نگهداری PM به همراه نام دستگاه',
          'راهنمای دسترسی': 'روی زبانه «سوابق مصرف قطعات» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۶',
          'عنوان بخش سامانه': '🛢️ موجودی مخازن روغن',
          'نام زبانه در اکسل (Sheet)': 'مخازن روغن',
          'تعداد رکوردها': `${toFaDigits(oilTanks.length)} مخزن`,
          'محتوای این برگه': 'مشخصات مخازن ۴ گانه، ظرفیت کل، موجودی فعلی، درصد پرشدگی و حداقل هشدار شارژ',
          'راهنمای دسترسی': 'روی زبانه «مخازن روغن» در نوار پایین صفحه کلیک کنید'
        },
        {
          'ردیف': '۷',
          'عنوان بخش سامانه': '🔄 تراکنش‌های انبار روغن',
          'نام زبانه در اکسل (Sheet)': 'تراکنش‌های روغن',
          'تعداد رکوردها': `${toFaDigits(oilTransactions.length)} تراکنش`,
          'محتوای این برگه': 'ریز کلیه تراکنش‌های ورود (شارژ) و خروج (برداشت) روغن با نام اپراتور، دستگاه و تاریخ دقیق',
          'راهنمای دسترسی': 'روی زبانه «تراکنش‌های روغن» در نوار پایین صفحه کلیک کنید'
        }
      ];
      const wsOverview = XLSX.utils.json_to_sheet(overviewRows);
      XLSX.utils.book_append_sheet(wb, wsOverview, '📊 خلاصه کل سامانه');

      // شیت ۲: درخواست‌ها و دستورکارهای فنی (خدمات فنی)
      const wrRows = workRequests.map(r => ({
        'کد درخواست': r.code,
        'کد دستور کار': r.workOrderCode || '',
        'مکان / سالن': r.place,
        'تاریخ ثبت': r.created,
        'عنوان کار': r.title,
        'اولویت': r.priority,
        'وضعیت': r.status,
        'تکنسین مسئول': r.technician || '',
        'نوع عملیات': r.operationType || '',
        'شرح عیب اولیه': r.description || '',
        'اقدامات انجام‌شده': r.actionDetails || '',
        'تاریخ اختتام': r.completedAt || ''
      }));
      const wsWR = XLSX.utils.json_to_sheet(wrRows);
      XLSX.utils.book_append_sheet(wb, wsWR, 'دستورکارها و خدمات فنی');

      // شیت ۳: تجهیزات و ماشین‌آلات کارخانه
      const eqRows = equipments.map(e => ({
        'کد دستگاه': e.id,
        'شناسه سیستمی': e.code || '',
        'نام دستگاه': e.name,
        'دسته‌بندی (گروه دستگاه)': e.category || '',
        'سالن': e.hall || '',
        'وضعیت': e.status || '',
        'آخرین بازرسی': e.lastInspectionDate || '',
        'بازرس': e.inspector || ''
      }));
      const wsEq = XLSX.utils.json_to_sheet(eqRows);
      XLSX.utils.book_append_sheet(wb, wsEq, 'ماشین‌آلات و تجهیزات');

      // شیت ۴: برنامه‌های PM
      const pmRows = pmSchedules.map(p => ({
        'کد برنامه': p.id,
        'عنوان PM': p.title,
        'دستگاه': p.equipmentName,
        'کد دستگاه': p.equipmentCode,
        'سالن': p.hall,
        'دوره تکرار': p.periodicity,
        'اولویت': p.priority,
        'تکنسین مسئول': p.assignedTechnician,
        'وضعیت': p.status
      }));
      const wsPM = XLSX.utils.json_to_sheet(pmRows);
      XLSX.utils.book_append_sheet(wb, wsPM, 'نگهداری پیشگیرانه PM');

      // شیت ۵: قطعات یدکی و اقلام مصرفی
      const partRows = unifiedSpareParts.map(p => ({
        'کد قطعه': p.code || p.id,
        'نام قطعه': p.name,
        'گروه تخصصی': p.category,
        'موجودی فعلی': p.stock ?? 0,
        'حداقل سفارش': p.minStock ?? 0,
        'واحد شمارش': p.unit || 'عدد',
        'قیمت تخمینی': p.price || '—',
        'تجهیز یا دستگاه مرتبط': p.eqFamily || '',
        'محل در انبار': p.location || '',
        'مشخصات فنی و توضیحات': p.notes || '',
        'آخرین ویرایش': p.lastUpdated || ''
      }));
      const wsParts = XLSX.utils.json_to_sheet(partRows);
      XLSX.utils.book_append_sheet(wb, wsParts, 'انبار قطعات یدکی');

      // شیت ۶: سوابق مصرف قطعات (PM و خدمات فنی)
      const consRows = getSparePartConsumptions().map(c => ({
        'شناسه سابقه': c.id,
        'کد قطعه': c.partCode || '',
        'نام قطعه': c.partName,
        'نوع عملیات': c.workType === 'pm' ? 'نگهداری پیشگیرانه PM' : 'خدمات فنی',
        'کد دستورکار / شماره کار': c.workCode || '',
        'عنوان اقدام': c.workTitle || '',
        'دستگاه / مکان': c.equipment || '',
        'تعداد مصرفی': c.count,
        'واحد': c.unit || 'عدد',
        'تاریخ مصرف': c.date || '',
        'تکنسین اقدام‌کننده': c.technician || '',
        'یادداشت و جزئیات': c.notes || ''
      }));
      const wsCons = XLSX.utils.json_to_sheet(consRows);
      XLSX.utils.book_append_sheet(wb, wsCons, 'سوابق مصرف قطعات');

      // شیت ۷: مخازن روغن
      const tankRows = oilTanks.map(tank => ({
        'کد مخزن': tank.id,
        'نام مخزن': tank.name,
        'عنوان فرعی': tank.subName || '',
        'کاربرد / نوع': tank.type || '',
        'ظرفیت کل (لیتر)': tank.capacityLiters,
        'موجودی فعلی (لیتر)': tank.currentLiters,
        'درصد پرشدگی': ((tank.currentLiters / (tank.capacityLiters || 1)) * 100).toFixed(1) + '%',
        'حداقل هشدار': tank.minAlertLiters,
        'آخرین شارژ': tank.lastRefill || ''
      }));
      const wsTanks = XLSX.utils.json_to_sheet(tankRows);
      XLSX.utils.book_append_sheet(wb, wsTanks, 'مخازن روغن');

      // شیت ۸: تراکنش‌های مخازن روغن
      const txRows = oilTransactions.map(t => ({
        'شناسه تراکنش': t.id,
        'نوع عملیات': t.type === 'in' ? 'شارژ / ورود روغن' : 'برداشت از مخزن',
        'نام مخزن': t.tank_name || '',
        'کد مخزن': t.tank_id || '',
        'مقدار (لیتر)': t.amount_l,
        'اپراتور / مسئول': t.operator,
        'دستگاه / مکان': t.equipment || '',
        'تاریخ و ساعت ثبت': t.created_at || ''
      }));
      const wsTx = XLSX.utils.json_to_sheet(txRows);
      XLSX.utils.book_append_sheet(wb, wsTx, 'تراکنش‌های روغن');

      XLSX.writeFile(wb, `CMMS-Factory-Master-Report-${dateStr}.xlsx`);

      setBackupStatusMsg({
        text: '✓ گزارش اکسل جامع سامانه با موفقیت دانلود شد. این فایل دارای ۸ برگه (Sheet) تفکیک‌شده است: در برگه اول خلاصه کل بخش‌ها و در برگه‌های بعدی (پایین اکسل) دستورکارها، تجهیزات، PM، قطعات یدکی و روغن قرار دارند.',
        type: 'success'
      });
      setTimeout(() => setBackupStatusMsg(null), 10000);
    } catch (e: any) {
      setBackupStatusMsg({
        text: `خطا در صدور فایل اکسل: ${e?.message || 'نامشخص'}`,
        type: 'error'
      });
    }
  };

  // ۳. بازگردانی هوشمند کلیه اطلاعات کارخانه از روی فایل پشتیبان JSON
  const restoreFullSystemBackupJson = (file: File) => {
    if (!file) return;
    setBackupStatusMsg({
      text: 'در حال خواندن و بررسی ساختار فایل پشتیبان...',
      type: 'info'
    });

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const rawContent = e.target?.result as string;
        if (!rawContent) throw new Error('فایل خالی است.');
        const parsed = JSON.parse(rawContent);

        const sourceData = parsed.data || parsed;

        let restoredTanks = 0;
        let restoredTx = 0;
        let restoredWR = 0;
        let restoredEq = 0;
        let restoredPM = 0;
        let restoredTech = 0;
        let restoredParts = 0;

        const updatedState: any = { _updatedAt: Date.now() };

        if (Array.isArray(sourceData.oilTanks) && sourceData.oilTanks.length > 0) {
          setOilTanks(sourceData.oilTanks);
          try { localStorage.setItem('portal_oil_tanks', JSON.stringify(sourceData.oilTanks)); } catch {}
          updatedState.oilTanks = sourceData.oilTanks;
          restoredTanks = sourceData.oilTanks.length;
        }

        if (Array.isArray(sourceData.oilTransactions) && sourceData.oilTransactions.length > 0) {
          setOilTransactions(sourceData.oilTransactions);
          try {
            localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(sourceData.oilTransactions));
            localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(sourceData.oilTransactions));
          } catch {}
          updatedState.oilTransactions = sourceData.oilTransactions;
          restoredTx = sourceData.oilTransactions.length;
        }

        if (Array.isArray(sourceData.workRequests)) {
          setWorkRequests(sourceData.workRequests);
          try { localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(sourceData.workRequests)); } catch {}
          updatedState.workRequests = sourceData.workRequests;
          restoredWR = sourceData.workRequests.length;
        }

        if (Array.isArray(sourceData.equipments) && sourceData.equipments.length > 0) {
          setEquipments(sourceData.equipments);
          try { localStorage.setItem('portal_equipments_v9', JSON.stringify(sourceData.equipments)); } catch {}
          updatedState.equipments = sourceData.equipments;
          restoredEq = sourceData.equipments.length;
        }

        if (Array.isArray(sourceData.checklistCategories) && sourceData.checklistCategories.length > 0) {
          setChecklistCategories(sourceData.checklistCategories);
          try { localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(sourceData.checklistCategories)); } catch {}
          updatedState.checklistCategories = sourceData.checklistCategories;
        }

        if (Array.isArray(sourceData.technicians) && sourceData.technicians.length > 0) {
          setTechnicians(sourceData.technicians);
          try { localStorage.setItem('technicalServiceTechnicians', JSON.stringify(sourceData.technicians)); } catch {}
          updatedState.technicians = sourceData.technicians;
          restoredTech = sourceData.technicians.length;
        }

        if (sourceData.technicianPhotos && typeof sourceData.technicianPhotos === 'object') {
          setTechnicianPhotos(sourceData.technicianPhotos);
          try { localStorage.setItem('technicalServiceTechnicianPhotos', JSON.stringify(sourceData.technicianPhotos)); } catch {}
          updatedState.technicianPhotos = sourceData.technicianPhotos;
        }

        if (Array.isArray(sourceData.inspectionLogs)) {
          setInspectionLogs(sourceData.inspectionLogs);
          try { localStorage.setItem('portal_inspections_v5', JSON.stringify(sourceData.inspectionLogs)); } catch {}
          updatedState.inspectionLogs = sourceData.inspectionLogs;
        }

        if (Array.isArray(sourceData.pmSchedules)) {
          setPmSchedules(sourceData.pmSchedules);
          try { localStorage.setItem('app_pm_schedules_v1', JSON.stringify(sourceData.pmSchedules)); } catch {}
          updatedState.pmSchedules = sourceData.pmSchedules;
          restoredPM = sourceData.pmSchedules.length;
        }

        if (Array.isArray(sourceData.operatorLeaderboard)) {
          setOperatorLeaderboard(sourceData.operatorLeaderboard);
          try { localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(sourceData.operatorLeaderboard)); } catch {}
          updatedState.operatorLeaderboard = sourceData.operatorLeaderboard;
        }

        if (Array.isArray(sourceData.productionOperators)) {
          setProductionOperators(sourceData.productionOperators);
          try { localStorage.setItem('portal_production_operators_v2', JSON.stringify(sourceData.productionOperators)); } catch {}
          updatedState.productionOperators = sourceData.productionOperators;
        }

        if (Array.isArray(sourceData.unifiedSpareParts)) {
          saveUnifiedSpareParts(sourceData.unifiedSpareParts);
          setUnifiedSpareParts(sourceData.unifiedSpareParts);
          updatedState.unifiedSpareParts = sourceData.unifiedSpareParts;
          restoredParts = sourceData.unifiedSpareParts.length;
        }

        if (Array.isArray(sourceData.sparePartsConsumptions)) {
          try {
            localStorage.setItem('factory_spare_parts_consumptions_v1', JSON.stringify(sourceData.sparePartsConsumptions));
          } catch {}
          updatedState.sparePartsConsumptions = sourceData.sparePartsConsumptions;
        }

        try {
          await pushStateToServerImmediate(updatedState);
        } catch (syncErr) {
          console.warn('Sync after restore error:', syncErr);
        }

        setBackupStatusMsg({
          text: `✓ بازگردانی ۱۰۰٪ موفق بود: ${toFaDigits(restoredTx)} تراکنش روغن، ${toFaDigits(restoredTanks)} مخزن، ${toFaDigits(restoredWR)} دستورکار، ${toFaDigits(restoredEq)} دستگاه، ${toFaDigits(restoredPM)} برنامه PM و ${toFaDigits(restoredParts)} قلم قطعه یدکی با موفقیت بازیابی و با دیتاسنتر ابری همگام شدند!`,
          type: 'success'
        });
        setTimeout(() => setBackupStatusMsg(null), 10000);
      } catch (err: any) {
        setBackupStatusMsg({
          text: `خطا در بازگردانی پشتیبان: فرمت فایل صحیح نیست یا محتوا آسیب دیده است. (${err?.message || ''})`,
          type: 'error'
        });
      }
    };
    reader.onerror = () => {
      setBackupStatusMsg({
        text: 'خطا در خواندن فایل از حافظه سیستم.',
        type: 'error'
      });
    };
    reader.readAsText(file);
  };

  // خروجی استاندارد اکسل (CSV) از پرونده‌های خدمات فنی
  const exportTechnicalOrdersToCsv = () => {
    try {
      const headers = [
        'کد درخواست',
        'کد دستور کار',
        'مکان / سالن',
        'تاریخ ثبت',
        'عنوان کار',
        'اولویت',
        'وضعیت',
        'تکنسین مجری',
        'نوع عملیات',
        'لوازم مصرفی',
        'شرح عیب اولیه',
        'شرح اقدامات تکنسین',
        'ساعت شروع',
        'ساعت پایان',
        'مدت کارکرد (دقیقه)',
        'تاریخ اختتام'
      ];
      const rows = workRequests.map(r => {
        const consumablesText = Array.isArray(r.consumables) && r.consumables.length > 0
          ? r.consumables.map(c => `${c.name} (${c.count || (c as any).quantity || 1} ${c.unit || 'عدد'})`).join('، ')
          : '';

        return [
          r.code,
          r.workOrderCode || '',
          r.place,
          r.created,
          `"${(r.title || '').replace(/"/g, '""')}"`,
          r.priority,
          r.status,
          r.technician || '',
          r.operationType || '',
          `"${consumablesText.replace(/"/g, '""')}"`,
          `"${(r.description || '').replace(/"/g, '""')}"`,
          `"${(r.actionDetails || '').replace(/"/g, '""')}"`,
          r.woStartTime || '',
          r.woEndTime || '',
          r.durationMinutes || 0,
          r.completedAt || ''
        ];
      });
      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `technical_services_orders_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    }
  };

  // خروجی اختصاصی اکسل (CSV) از کلیه اقلام و لوازم مصرفی کارخانه
  const exportConsumablesToCsv = () => {
    try {
      const items = getAggregatedConsumables();
      const headers = [
        'ردیف',
        'نام قطعه / قلم مصرفی',
        'دسته‌بندی (برق / مکانیک / سایر)',
        'مجموع تعداد مصرف‌شده',
        'واحد',
        'تعداد دفعات استفاده',
        'سالن‌ها و محل‌های مصرف',
        'تکنسین‌های مجری مصرف‌کننده'
      ];
      const rows = items.map((it, idx) => [
        idx + 1,
        `"${it.name.replace(/"/g, '""')}"`,
        it.category,
        it.totalCount,
        it.unit,
        it.usageCount,
        `"${Array.from(it.places).join(' - ').replace(/"/g, '""')}"`,
        `"${Array.from(it.technicians).join(' - ').replace(/"/g, '""')}"`
      ]);
      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `consumables_inventory_report_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    }
  };

  // ========================================================
  // PREVENTIVE MAINTENANCE (نگهداری پیشگیرانه PM) STATE & LOGIC
  // ========================================================
  const [pmSchedules, setPmSchedules] = useState<PmSchedule[]>(() => {
    try {
      const saved = localStorage.getItem('app_pm_schedules_v1');
      return saved ? JSON.parse(saved) : INITIAL_PM_SCHEDULES;
    } catch (e) {
      return INITIAL_PM_SCHEDULES;
    }
  });

  const [pmSearch, setPmSearch] = useState('');
  const [pmPeriodFilter, setPmPeriodFilter] = useState('همه');
  const [pmCategoryFilter, setPmCategoryFilter] = useState('همه');
  const [pmStatusFilter, setPmStatusFilter] = useState('همه');
  const [pmHallFilter, setPmHallFilter] = useState('همه');
  const [selectedPmSchedule, setSelectedPmSchedule] = useState<PmSchedule | null>(null);

  // فرم ثبت برنامه PM جدید
  const [pmEqCode, setPmEqCode] = useState('');
  const [pmEqName, setPmEqName] = useState('');
  const [pmHall, setPmHall] = useState(FACTORY_LOCATIONS[0] || 'سالن ۱');
  const [pmTitle, setPmTitle] = useState('');
  const [pmCategory, setPmCategory] = useState<PmCategory>('مکانیک');
  const [pmPeriodicity, setPmPeriodicity] = useState<PmPeriodicity>('ماهانه');
  const [pmIntervalDays, setPmIntervalDays] = useState(30);
  const [pmIntervalHours, setPmIntervalHours] = useState(300);
  const [pmTech, setPmTech] = useState('مهندس مرادی');
  const [pmPriority, setPmPriority] = useState<PmPriority>('مهم');
  const [pmEstMinutes, setPmEstMinutes] = useState(60);
  const [pmInstructions, setPmInstructions] = useState('');
  const [pmChecklistInput, setPmChecklistInput] = useState('');
  const [pmPartsInput, setPmPartsInput] = useState('');

  // ذخیره دائم PM در localStorage و همگام‌سازی با سرور
  useEffect(() => {
    try {
      localStorage.setItem('app_pm_schedules_v1', JSON.stringify(pmSchedules));
      pushStateToServer({ pmSchedules });
    } catch (e) {
      console.warn('Failed to save PM', e);
    }
  }, [pmSchedules, pushStateToServer]);

  // ثبت بازرسی انجام‌شده و تمدید خودکار تاریخ بعدی
  const handleMarkPmDone = (id: string) => {
    const today = getEnDateNow();
    setPmSchedules(prev => prev.map(item => {
      if (item.id !== id) return item;
      const parts = today.split('/').map(p => parseInt(toEnDigits(p), 10));
      let nextDue = today;
      if (parts.length === 3) {
        let [y, m, d] = parts;
        const addMonths = item.periodicity === 'ماهانه' ? 1 :
                          item.periodicity === 'سه ماهه' ? 3 :
                          item.periodicity === 'شش ماهه' ? 6 :
                          item.periodicity === 'سالانه' ? 12 : 0;
        if (addMonths > 0) {
          m += addMonths;
          while (m > 12) {
            m -= 12;
            y += 1;
          }
          nextDue = `${y}/${String(m).padStart(2, '0')}/${String(d).padStart(2, '0')}`;
        } else {
          const addDays = item.periodicity === 'روزانه' ? 1 : item.periodicity === 'هفتگی' ? 7 : 14;
          d += addDays;
          if (d > 30) {
            d = (d % 30) || 1;
            m += 1;
            if (m > 12) { m = 1; y += 1; }
          }
          nextDue = `${y}/${String(m).padStart(2, '0')}/${String(d).padStart(2, '0')}`;
        }
      }
      return {
        ...item,
        lastPerformedDate: today,
        nextDueDate: nextDue,
        status: 'انجام‌شده' as PmStatus,
        checklist: item.checklist.map(c => ({ ...c, completed: true }))
      };
    }));
    setArchiveNotice(`بازرسی پیشگیرانه با موفقیت در تاریخ ${today} انجام شد و موعد بعدی زمان‌بندی گردید.`);
    setTimeout(() => setArchiveNotice(null), 5000);
  };

  // تبدیل اقدام PM به یک دستور کار کامل در خدمات فنی
  const handleConvertPmToWorkOrder = (pm: PmSchedule) => {
    setEditingItemCode(null);
    setFormSection('both');
    setReqPlace(pm.hall);
    setReqTitle(`[PM] ${pm.title} - تجهیز ${pm.equipmentName} (${pm.equipmentCode})`);
    setReqDesc(`سرویس پیشگیرانه ${pm.periodicity} تجهیز ${pm.equipmentName} (${pm.equipmentCode})\nدستورالعمل: ${pm.instructions}`);
    setReqPriority(pm.priority === 'بحرانی' ? 'ایمنی (اولویت بالا)' : 'عادی');
    setWoTechnician(pm.assignedTechnician);
    setWoOperationType(pm.category === 'برق' ? 'برق' : 'مکانیک');
    setWoActionDetails(`دستورالعمل اجرایی بازرسی پیشگیرانه PM:\n${pm.instructions}\n\nچک‌لیست بازرسی:\n${pm.checklist.map(c => `• ${c.title}`).join('\n')}\n\nقطعات و ملزومات مورد نیاز: ${pm.requiredParts?.join('، ') || 'ندارد'}`);
    setIncludeWorkOrderActions(true);
    setWoDate(getEnDateNow());
    const nowTime = getEnTimeNow();
    setReqTime(nowTime);
    setWoStartTime(nowTime);
    setWoEndTime(nowTime);
    setWoDuration(pm.estimatedMinutes || 60);
    setWoCloseImmediately(false);
    setCurrentView('technical');
    setModalType('unifiedForm');
  };

  // ذخیره تعریف برنامه PM جدید
  const handleSaveNewPm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pmTitle.trim() || !pmEqName.trim()) {
      alert('لطفاً عنوان بازرسی و نام تجهیز را تکمیل نمایید.');
      return;
    }
    const today = getEnDateNow();
    const checklistItems = pmChecklistInput
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean)
      .map((t, idx) => ({ id: `c-${Date.now()}-${idx}`, title: t, completed: false }));

    const parts = pmPartsInput
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean);

    const newSchedule: PmSchedule = {
      id: `PM-${Math.floor(100 + Math.random() * 900)}`,
      equipmentCode: pmEqCode.trim() || `EQ-${Math.floor(10 + Math.random() * 90)}`,
      equipmentName: pmEqName.trim(),
      hall: pmHall,
      title: pmTitle.trim(),
      category: pmCategory,
      periodicity: pmPeriodicity,
      intervalDays: pmIntervalDays,
      intervalHours: pmIntervalHours,
      lastPerformedDate: today,
      nextDueDate: today,
      assignedTechnician: pmTech,
      priority: pmPriority,
      status: 'در انتظار',
      estimatedMinutes: pmEstMinutes,
      instructions: pmInstructions.trim() || 'بازرسی طبق استانداردهای فنی و ایمنی صورت گیرد.',
      checklist: checklistItems.length > 0 ? checklistItems : [{ id: 'c1', title: 'بازرسی عمومی، تست کارکرد و نظافت تجهیز', completed: false }],
      requiredParts: parts.length > 0 ? parts : undefined
    };

    setPmSchedules(prev => [newSchedule, ...prev]);
    setModalType('none');
    setPmTitle('');
    setPmEqCode('');
    setPmEqName('');
    setPmInstructions('');
    setPmChecklistInput('');
    setPmPartsInput('');
  };

  // حذف برنامه PM
  const handleDeletePm = (id: string) => {
    if (window.confirm('آیا از حذف این برنامه نگهداری پیشگیرانه اطمینان دارید؟')) {
      setPmSchedules(prev => prev.filter(p => p.id !== id));
      if (selectedPmSchedule?.id === id) {
        setSelectedPmSchedule(null);
      }
    }
  };

  // خروجی اکسل (CSV) نگهداری پیشگیرانه
  const exportPmToCsv = () => {
    try {
      const headers = [
        'شناسه PM',
        'کد تجهیز',
        'نام تجهیز',
        'سالن و بخش',
        'عنوان بازرسی',
        'دسته',
        'دوره تناوب',
        'کارکرد ساعتی',
        'تکنسین مسئول',
        'اولویت',
        'وضعیت',
        'آخرین تاریخ انجام',
        'موعد سررسید بعدی',
        'قطعات مورد نیاز'
      ];

      const rows = pmSchedules.map(p => [
        `"${p.id}"`,
        `"${p.equipmentCode}"`,
        `"${p.equipmentName}"`,
        `"${p.hall}"`,
        `"${p.title.replace(/"/g, '""')}"`,
        `"${p.category}"`,
        `"${p.periodicity}"`,
        `"${p.intervalHours || '-'}"`,
        `"${p.assignedTechnician}"`,
        `"${p.priority}"`,
        `"${p.status}"`,
        `"${p.lastPerformedDate}"`,
        `"${p.nextDueDate}"`,
        `"${(p.requiredParts || []).join(' - ')}"`
      ]);

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `PM_Preventive_Maintenance_${getEnDateNow().replace(/\//g, '-')}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Error exporting PM CSV', e);
    }
  };

  // افزودن تکنسین جدید به تیم خدمات فنی
  const handleAddTechnician = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTechName.trim();
    if (!trimmed) return;
    if (technicians.includes(trimmed)) {
      alert('این تکنسین قبلاً در لیست ثبت شده است.');
      return;
    }
    const updated = [...technicians, trimmed];
    setTechnicians(updated);
    try {
      localStorage.setItem('technicalServiceTechnicians', JSON.stringify(updated));
    } catch (err) {
      console.warn(err);
    }
    setNewTechName('');
    setModalType('none');
  };

  // آژیر هشدار صوتی صنعتی (Industrial Siren Web Audio)
  const triggerSirenTest = () => {
    if (isSirenActive) {
      if (sirenAudioCtxRef.current) {
        sirenAudioCtxRef.current.close().catch(() => {});
        sirenAudioCtxRef.current = null;
      }
      setIsSirenActive(false);
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      sirenAudioCtxRef.current = ctx;
      setIsSirenActive(true);

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(650, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + 0.35);
      osc.frequency.exponentialRampToValueAtTime(650, ctx.currentTime + 0.7);
      osc.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + 1.05);
      osc.frequency.exponentialRampToValueAtTime(650, ctx.currentTime + 1.4);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 1.6);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 1.6);

      setTimeout(() => {
        setIsSirenActive(false);
        sirenAudioCtxRef.current = null;
      }, 1600);
    } catch (e) {
      console.warn('AudioContext not allowed or supported', e);
      setIsSirenActive(false);
    }
  };

  // عملیات شارژ یا مصرف روغن
  const handleSaveTankTx = () => {
    if (!selectedTankForTx) return;
    const amt = parseFloat(toEnDigits(tankTxAmount)) || 0;
    if (amt <= 0) return;

    let calculatedLiters = selectedTankForTx.currentLiters;
    const updatedTanks = oilTanks.map(t => {
      if (t.id !== selectedTankForTx.id) return t;
      let nextLiters = t.currentLiters;
      if (tankTxType === 'refill') {
        nextLiters = Math.min(t.capacityLiters, t.currentLiters + amt);
      } else {
        nextLiters = Math.max(0, t.currentLiters - amt);
      }
      calculatedLiters = Math.round(nextLiters);
      return {
        ...t,
        currentLiters: calculatedLiters,
        lastRefill: getEnDateNow()
      };
    });
    setOilTanks(updatedTanks);

    const newOp: OilOperation = {
      id: `tx-${Date.now()}`,
      tank_id: selectedTankForTx.id,
      tank_name: selectedTankForTx.name,
      type: tankTxType === 'refill' ? 'in' : 'out',
      amount_l: amt,
      operator: 'اپراتور خط',
      equipment: tankTxHall || '—',
      created_at: new Date().toLocaleString('fa-IR')
    };
    const updatedTx = [newOp, ...oilTransactions];
    setOilTransactions(updatedTx);

    const nowTs = Date.now();
    try {
      localStorage.setItem('portal_oil_tanks', JSON.stringify(updatedTanks));
      localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(updatedTx));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
      pushStateToServerImmediate({ oilTanks: updatedTanks, oilTransactions: updatedTx, _updatedAt: nowTs });
    } catch (e) {
      console.warn('Local save error:', e);
    }

    updateTankInSupabase({
      id: Number(selectedTankForTx.id),
      name: selectedTankForTx.name,
      current_liters: calculatedLiters,
      last_refill: getEnDateNow()
    }).catch(() => {});

    setModalType('none');
  };

  // عملیات برداشت روغن از مخزن (مطابق سامانه انبار روغن با همگام‌سازی تضمینی ابری)
  const handlePerformOilWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingOilOp) return;

    const cleanAmt = toEnDigits(oilOpAmount).replace(/[^0-9.]/g, '');
    const amt = parseFloat(cleanAmt) || 0;
    if (amt <= 0) {
      setOilOpError('لطفاً مقداری معتبر و بزرگتر از صفر وارد کنید.');
      return;
    }
    const tank = oilTanks.find(t => String(t.id) === String(oilTargetTankId));
    if (!tank) {
      setOilOpError('مخزن انتخاب‌شده نامعتبر است.');
      return;
    }
    if (tank.currentLiters < amt) {
      setOilOpError(`موجودی مخزن (${fa(tank.currentLiters)} لیتر) کمتر از مقدار درخواستی است.`);
      return;
    }

    setIsSubmittingOilOp(true);
    setOilOpError(null);

    const newStock = Math.max(0, Math.round((tank.currentLiters - amt) * 10) / 10);
    const updatedTanks = oilTanks.map(t => String(t.id) === String(tank.id) ? { ...t, currentLiters: newStock, lastRefill: getEnDateNow() } : t);
    
    // ۱. اعمال بلادرنگ در وضعیت حافظه و ظاهر برنامه
    setOilTanks(updatedTanks);

    const now = new Date();
    const faDate = now.toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' });
    const faTime = now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newOp: OilOperation = {
      id: `tx-${now.getTime()}`,
      tank_id: Number(tank.id),
      tank_name: tank.name,
      type: 'out',
      amount_l: amt,
      operator: oilOpOperator.trim() || 'نامشخص',
      equipment: oilOpEquipment.trim() || '—',
      created_at: `${faDate} ${faTime}`,
      timestamp: now.getTime()
    } as any;
    const updatedTx = [newOp, ...oilTransactions].sort((a, b) => getOilTxSortScore(b) - getOilTxSortScore(a));
    setOilTransactions(updatedTx);

    const nowTs = Date.now();
    try {
      // ۲. ذخیره فوری در حافظه دستگاه جهت تضمین ۱۰۰٪ آفلاین
      localStorage.setItem('portal_oil_tanks', JSON.stringify(updatedTanks));
      localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(updatedTx));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));

      // ۳. به‌روزرسانی جدول اختصاصی tanks در Supabase
      updateTankInSupabase({
        id: Number(tank.id),
        name: tank.name,
        current_liters: newStock,
        last_refill: getEnDateNow()
      }).catch(err => {
        console.warn('Supabase tank update deferred (offline):', err);
        try {
          const q = JSON.parse(localStorage.getItem('technicalServiceOfflineQueue') || '[]');
          q.push({
            type: 'tank_update',
            data: {
              id: Number(tank.id),
              name: tank.name,
              current_liters: newStock,
              last_refill: getEnDateNow()
            }
          });
          localStorage.setItem('technicalServiceOfflineQueue', JSON.stringify(q));
        } catch {}
      });

      // ۴. بستن فوری مودال و همگام‌سازی پس‌زمینه با سرور ابری بدون معطلی کاربر
      isSyncingFromServerRef.current = true;
      pushStateToServerImmediate({ 
        oilTanks: updatedTanks, 
        newTransaction: newOp, 
        oilTransactions: updatedTx,
        _updatedAt: nowTs
      }).catch(err => console.warn('Background oil withdraw sync error:', err));

      setChecklistNotice(`✓ برداشت ${fa(amt)} لیتر از ${tank.name} ثبت شد. موجودی جدید: ${fa(newStock)} لیتر.`);
      setTimeout(() => setChecklistNotice(null), 5000);
    } catch (e) {
      console.warn('Save error:', e);
      setChecklistNotice(`✓ برداشت ${fa(amt)} لیتر در حافظه دستگاه (آفلاین) ثبت شد. موجودی جدید: ${fa(newStock)} لیتر.`);
      setTimeout(() => setChecklistNotice(null), 5000);
    } finally {
      setIsSubmittingOilOp(false);
      setOilModalMode('none');
    }
  };

  // عملیات ورود و شارژ روغن به مخزن (مطابق سامانه انبار روغن با همگام‌سازی تضمینی ابری)
  const handlePerformOilEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingOilOp) return;

    const cleanAmt = toEnDigits(oilOpAmount).replace(/[^0-9.]/g, '');
    const amt = parseFloat(cleanAmt) || 0;
    if (amt <= 0) {
      setOilOpError('لطفاً مقداری معتبر و بزرگتر از صفر وارد کنید.');
      return;
    }
    const tank = oilTanks.find(t => String(t.id) === String(oilTargetTankId));
    if (!tank) {
      setOilOpError('مخزن انتخاب‌شده نامعتبر است.');
      return;
    }

    setIsSubmittingOilOp(true);
    setOilOpError(null);

    const newStock = Math.min(tank.capacityLiters, Math.round((tank.currentLiters + amt) * 10) / 10);
    const updatedTanks = oilTanks.map(t => String(t.id) === String(tank.id) ? { ...t, currentLiters: newStock, lastRefill: getEnDateNow() } : t);
    
    // ۱. اعمال بلادرنگ در وضعیت حافظه و ظاهر برنامه
    setOilTanks(updatedTanks);

    const now = new Date();
    const faDate = now.toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' });
    const faTime = now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newOp: OilOperation = {
      id: `tx-${now.getTime()}`,
      tank_id: Number(tank.id),
      tank_name: tank.name,
      type: 'in',
      amount_l: amt,
      operator: 'انبار مرکزی',
      equipment: 'شارژ تانکر',
      created_at: `${faDate} ${faTime}`,
      timestamp: now.getTime()
    } as any;
    const updatedTx = [newOp, ...oilTransactions].sort((a, b) => getOilTxSortScore(b) - getOilTxSortScore(a));
    setOilTransactions(updatedTx);

    const nowTs = Date.now();
    try {
      // ۲. ذخیره فوری در حافظه دستگاه جهت تضمین ۱۰۰٪ آفلاین
      localStorage.setItem('portal_oil_tanks', JSON.stringify(updatedTanks));
      localStorage.setItem('portal_oil_transactions_v8', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v7', JSON.stringify(updatedTx));
      localStorage.setItem('portal_oil_transactions_v12', JSON.stringify(updatedTx));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));

      // ۳. به‌روزرسانی جدول اختصاصی tanks در Supabase
      updateTankInSupabase({
        id: Number(tank.id),
        name: tank.name,
        current_liters: newStock,
        last_refill: getEnDateNow()
      }).catch(err => {
        console.warn('Supabase tank update deferred (offline):', err);
        try {
          const q = JSON.parse(localStorage.getItem('technicalServiceOfflineQueue') || '[]');
          q.push({
            type: 'tank_update',
            data: {
              id: Number(tank.id),
              name: tank.name,
              current_liters: newStock,
              last_refill: getEnDateNow()
            }
          });
          localStorage.setItem('technicalServiceOfflineQueue', JSON.stringify(q));
        } catch {}
      });

      // ۴. بستن فوری مودال و همگام‌سازی پس‌زمینه با سرور ابری بدون معطلی کاربر
      isSyncingFromServerRef.current = true;
      pushStateToServerImmediate({ 
        oilTanks: updatedTanks, 
        newTransaction: newOp, 
        oilTransactions: updatedTx,
        _updatedAt: nowTs
      }).catch(err => console.warn('Background oil entry sync error:', err));

      setChecklistNotice(`✓ ورود و شارژ ${fa(amt)} لیتر در ${tank.name} ثبت شد. موجودی جدید: ${fa(newStock)} لیتر.`);
      setTimeout(() => setChecklistNotice(null), 5000);
    } catch (e) {
      console.warn('Save error:', e);
      setChecklistNotice(`✓ ورود و شارژ ${fa(amt)} لیتر در حافظه دستگاه (آفلاین) ثبت شد. موجودی جدید: ${fa(newStock)} لیتر.`);
      setTimeout(() => setChecklistNotice(null), 5000);
    } finally {
      setIsSubmittingOilOp(false);
      setOilModalMode('none');
    }
  };

  // فیلتر هوشمند تراکنش‌های روغن بر اساس مخزن، نوع عملیات، بازه دقیق تاریخ شمسی و متن جستجو
  const getFilteredOilTransactions = () => {
    return oilTransactions.filter(tx => {
      if (tx.type !== oilReportTab) return false;
      if (oilReportFilterTank !== 'all' && String(tx.tank_id) !== String(oilReportFilterTank)) return false;
      
      const txNormalizedDate = normalizeShamsiDateStr(tx.created_at);
      if (oilReportStartDate) {
        const startNorm = normalizeShamsiDateStr(oilReportStartDate);
        if (startNorm && txNormalizedDate && txNormalizedDate < startNorm) return false;
      }
      if (oilReportEndDate) {
        const endNorm = normalizeShamsiDateStr(oilReportEndDate);
        if (endNorm && txNormalizedDate && txNormalizedDate > endNorm) return false;
      }

      if (oilReportSearch.trim()) {
        const q = oilReportSearch.trim().toLowerCase();
        const matchesEq = (tx.equipment || '').toLowerCase().includes(q);
        const matchesOp = (tx.operator || '').toLowerCase().includes(q);
        const matchesTank = (tx.tank_name || '').toLowerCase().includes(q);
        if (!matchesEq && !matchesOp && !matchesTank) return false;
      }

      return true;
    }).sort((a, b) => getOilTxSortScore(b) - getOilTxSortScore(a));
  };

  // چاپ استاندارد و رسمی گزارش تراکنش‌های روغن با فرمت سازمانی شبیه PDF
  const handlePrintOilReport = () => {
    setIsOilOfficialPrintModalOpen(true);
  };

  // دانلود گزارش فیلترشده در قالب اکسل (CSV)
  const exportOilReportCsv = () => {
    try {
      const filtered = getFilteredOilTransactions();
      const headers = ['ردیف', 'نام مخزن', 'نوع تراکنش', 'مقدار (لیتر)', 'اپراتور تحویل‌گیرنده / ثبت‌کننده', 'کد یا نام تجهیز مقصد', 'تاریخ و ساعت'];
      const rows = filtered.map((tx, idx) => [
        idx + 1,
        `"${tx.tank_name}"`,
        tx.type === 'out' ? 'برداشت' : 'ورود',
        tx.amount_l,
        `"${tx.operator || ''}"`,
        `"${tx.equipment || ''}"`,
        `"${tx.created_at || ''}"`
      ]);
      const csv = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `oil_warehouse_report_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    }
  };

  // ثبت چک‌لیست موفق (سالم بودن تجهیز)
  const handleMarkEquipmentChecked = (eqId: string) => {
    setEquipments(prev => prev.map(eq => {
      if (eq.id !== eqId) return eq;
      return {
        ...eq,
        status: 'سالم',
        lastInspectionDate: getEnDateNow()
      };
    }));
  };

  // صدور آنی درخواست خدمات فنی از درون چک‌لیست برای یک تجهیز خاص
  const handleReportEquipmentIssue = (eq: EquipmentItem) => {
    setCurrentView('technical');
    setEditingItemCode(null);
    setFormSection('both');
    setIncludeWorkOrderActions(false);
    setReqTitle(`تعمیر و سرویس ${eq.name} (${eq.code})`);
    setReqPlace(eq.hall || (FACTORY_LOCATIONS[0] || ''));
    setReqPriority('ایمنی');
    setReqDate(getEnDateNow());
    setReqTime(getEnTimeNow());
    setReqDesc(`گزارش در بازرسی دوره‌ای ۲۲۰ تجهیز: بررسی اضطراری آیتم‌های [${eq.criticalChecks.join('، ')}]`);
    setWoTechnician(technicians[0] || '');
    setWoOperationType('مکانیک');
    setModalType('unifiedForm');
  };

  // Tech state
  const [selectedTechIndex, setSelectedTechIndex] = useState<number | null>(null);
  const [techNameInput, setTechNameInput] = useState('');
  const [techFormError, setTechFormError] = useState('');
  const [selectedWorkRequest, setSelectedWorkRequest] = useState<WorkRequest | null>(null);

  // تبدیل اعداد انگلیسی به فارسی برای متون و کارت‌ها
  const toFaDigits = (str: string | number): string => {
    return String(str ?? '').replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)]);
  };

  const fa = (n: number | string) => toFaDigits(Number(n || 0).toLocaleString('en-US'));

  // الگوریتم تبدیل تاریخ شمسی به میلادی برای پردازش دقیق تایم‌استمپ
  const jalaliToGregorian = (jy: number, jm: number, jd: number): [number, number, number] => {
    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + (Math.floor(((jy % 33) + 3) / 4)) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor(--days / 36524);
      days %= 36524;
      if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const sal_b = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    for (gm = 0; gm < 13 && gd > sal_b[gm]; gm++) gd -= sal_b[gm];
    return [gy, gm, gd];
  };

  // پارس کردن تاریخ و ساعت شمسی به تایم‌استمپ میلی‌ثانیه جهت محاسبه اختلاف با لحظه کنونی
  const parseShamsiDateTime = (str?: string): number => {
    if (!str) return 0;
    const clean = String(str)
      .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
      .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584));
    
    const dateMatch = clean.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
    if (!dateMatch) return 0;
    const jy = parseInt(dateMatch[1], 10);
    const jm = parseInt(dateMatch[2], 10);
    const jd = parseInt(dateMatch[3], 10);
    
    let hour = 12;
    let minute = 0;
    const timeMatch = clean.match(/(\d{1,2}):(\d{2})/);
    if (timeMatch) {
      hour = parseInt(timeMatch[1], 10);
      minute = parseInt(timeMatch[2], 10);
    }
    
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
    const d = new Date(gy, gm - 1, gd, hour, minute);
    return d.getTime();
  };

  // فرمت دقیق مدت زمان سپری شده از آخرین اقدام خاتمه‌یافته تکنسین (مثلاً «۳ روز و ۲ ساعت پیش»)
  const formatElapsedSince = (timestampMs: number): string => {
    if (!timestampMs || timestampMs <= 0 || isNaN(timestampMs)) return 'نامشخص';
    const now = Date.now();
    const diffMs = Math.max(0, now - timestampMs);
    
    const totalMinutes = Math.floor(diffMs / (60 * 1000));
    if (totalMinutes < 1) return 'هم‌اکنون (لحظاتی پیش)';
    if (totalMinutes < 60) return `${toFaDigits(totalMinutes)} دقیقه پیش`;
    
    const totalHours = Math.floor(totalMinutes / 60);
    const remMinutes = totalMinutes % 60;
    
    if (totalHours < 24) {
      if (remMinutes > 0) {
        return `${toFaDigits(totalHours)} ساعت و ${toFaDigits(remMinutes)} دقیقه پیش`;
      }
      return `${toFaDigits(totalHours)} ساعت پیش`;
    }
    
    const totalDays = Math.floor(totalHours / 24);
    const remHours = totalHours % 24;
    
    if (totalDays < 30) {
      if (remHours > 0) {
        return `${toFaDigits(totalDays)} روز و ${toFaDigits(remHours)} ساعت پیش`;
      }
      return `${toFaDigits(totalDays)} روز پیش`;
    }
    
    const months = Math.floor(totalDays / 30);
    const remDays = totalDays % 30;
    if (remDays > 0) {
      return `${toFaDigits(months)} ماه و ${toFaDigits(remDays)} روز پیش`;
    }
    return `${toFaDigits(months)} ماه پیش`;
  };

  // تایمر تیک هر ۶۰ ثانیه برای بروزرسانی خودکار زمان سپری‌شده بدون نیاز به رفرش صفحه
  const [timeElapsedTick, setTimeElapsedTick] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setTimeElapsedTick(Date.now()), 60000);
    return () => clearInterval(timer);
  }, []);

  // تابع واکشی هوشمند آخرین اقدام هر تکنسین و محاسبه مدت زمان سپری شده
  const getTechnicianLastActionInfo = (name: string) => {
    void timeElapsedTick;

    // ۱. بررسی پرونده‌های انجام شده در وضعیت جاری کارتابل
    const doneRequests = workRequests.filter(r => 
      (
        r.technician === name ||
        (Array.isArray(r.coTechnicians) && r.coTechnicians.includes(name)) ||
        (Array.isArray(r.woTechnicians) && r.woTechnicians.some(t => String(t?.name || '').trim() === name))
      ) && 
      r.status === 'انجام شد'
    );
    if (doneRequests.length > 0) {
      const sorted = [...doneRequests].sort((a, b) => {
        const tsA = a.completedTimestamp || parseShamsiDateTime(a.completedAt || (a.woDate ? `${a.woDate} — ${a.woEndTime || '12:00'}` : a.created));
        const tsB = b.completedTimestamp || parseShamsiDateTime(b.completedAt || (b.woDate ? `${b.woDate} — ${b.woEndTime || '12:00'}` : b.created));
        return tsB - tsA;
      });
      const latest = sorted[0];
      const ts = latest.completedTimestamp || parseShamsiDateTime(latest.completedAt || (latest.woDate ? `${latest.woDate} — ${latest.woEndTime || '12:00'}` : latest.created));
      return {
        title: latest.title,
        code: latest.workOrderCode || latest.code,
        place: latest.place,
        details: latest.actionDetails,
        timestamp: ts,
        timeAgoText: formatElapsedSince(ts),
        rawDateStr: latest.completedAt || latest.created,
        isRealRecord: true,
        requestObj: latest
      };
    }

    // ۲. استفاده از دیتابیس پایدار سوابق تکنسین‌های فنی کارخانه
    const fallback = DEFAULT_TECH_HISTORICAL_ACTIONS[name];
    if (fallback) {
      const ts = Date.now() - fallback.hoursAgo * 60 * 60 * 1000;
      return {
        title: fallback.title,
        code: fallback.code,
        place: fallback.place,
        details: fallback.details,
        timestamp: ts,
        timeAgoText: formatElapsedSince(ts),
        rawDateStr: fallback.hoursAgo >= 24 
          ? `${toFaDigits(Math.floor(fallback.hoursAgo / 24))} روز قبل` 
          : `${toFaDigits(Math.floor(fallback.hoursAgo))} ساعت قبل`,
        isRealRecord: false,
        requestObj: null
      };
    }

    return null;
  };

  // محاسبه مجموع کارهای انجام شده و مجموع زمان صرف‌شده برای هر تکنسین (از صفر و منحصراً بر اساس کارهای واقعی)
  const getTechnicianStats = (name: string) => {
    const currentDoneReqs = workRequests.filter(r => 
      (
        r.technician === name ||
        (Array.isArray(r.coTechnicians) && r.coTechnicians.includes(name)) ||
        (Array.isArray(r.woTechnicians) && r.woTechnicians.some(t => String(t?.name || '').trim() === name))
      ) && 
      r.status === 'انجام شد'
    );
    const totalMinutes = currentDoneReqs.reduce((sum, r) => {
      if (Array.isArray(r.woTechnicians) && r.woTechnicians.length > 0) {
        const matchedWoTechs = r.woTechnicians.filter(t => String(t?.name || '').trim() === name);
        if (matchedWoTechs.length > 0) {
          return sum + Math.round(matchedWoTechs.reduce((s, t) => s + (Number(t?.hours) || 0), 0) * 60);
        }
      }
      if (r.durationMinutes && r.durationMinutes > 0) return sum + r.durationMinutes;
      if (r.woStartTime && r.woEndTime) return sum + computeMinutesDiff(r.woStartTime, r.woEndTime);
      return sum + 0;
    }, 0);

    return {
      totalDoneCount: currentDoneReqs.length,
      totalMinutes
    };
  };

  // فرمت کوتاه و تمیز زمان کل برای کارت تکنسین
  const formatTotalTechTime = (minutes: number): string => {
    const mins = Math.max(0, Math.floor(minutes || 0));
    if (mins === 0) return '۰ ساعت';
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    if (hours > 0 && remMins > 0) {
      return `${toFaDigits(hours)} ساعت ${toFaDigits(remMins)} د`;
    } else if (hours > 0) {
      return `${toFaDigits(hours)} ساعت`;
    } else {
      return `${toFaDigits(mins)} دقیقه`;
    }
  };

  const saveTechs = (next: string[]) => {
    setTechnicians(next);
    try {
      localStorage.setItem('technicalServiceTechnicians', JSON.stringify(next));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
  };

  // تابع فراخوانی تحلیل هوش مصنوعی برای تکنسین منتخب
  const handleRunAiTechnicianAnalysis = async (techName: string) => {
    setIsAiAnalysisOpen(true);
    setAiAnalysisLoading(true);
    setAiAnalysisCopied(false);

    try {
      const techTasks = getTechnicianAllTasks(techName, workRequests);
      const totalPlantTasks = workRequests.length;
      const plantTotalMinutes = workRequests.reduce((sum, r) => sum + (r.durationMinutes || 0), 0);

      let serverData: any = null;
      const isFileProtocol = typeof window !== 'undefined' && window.location.protocol === 'file:';

      // تنها در صورتی که در محیط وب‌سرور ابری فعال باشیم، از API سرور با محدودیت زمانی ۵ ثانیه بهره می‌گیریم
      if (!isFileProtocol) {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5000);
        try {
          const res = await fetch(getApiUrl('/api/technician-ai-analysis'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              technicianName: techName,
              tasks: techTasks,
              totalPlantTasks,
              plantTotalMinutes,
            }),
          });
          clearTimeout(tid);

          if (res.ok) {
            const parsed = await res.json();
            if (parsed && parsed.analysisText) {
              serverData = parsed;
            }
          }
        } catch (fetchErr) {
          clearTimeout(tid);
          console.warn('Server AI API fetch failed or timed out:', fetchErr);
        }
      }

      if (serverData && serverData.analysisText) {
        setAiAnalysisResults(prev => ({ ...prev, [techName]: serverData }));
        return;
      }

      // در نسخه مستقل دسکتاپ، وقفه کوتاه و طبیعی جهت حس پردازش هوش مصنوعی
      await new Promise(r => setTimeout(r, 400));
      throw new Error('RunLocalAIEngine');
    } catch {
      const techTasks = getTechnicianAllTasks(techName, workRequests);
      const totalPlantTasks = workRequests.length;
      const techTaskCount = techTasks.length;
      const doneTasks = techTasks.filter(t => t.status === 'انجام شد');
      const activeTasks = techTasks.filter(t => t.status !== 'انجام شد');
      const totalMinutes = techTasks.reduce((sum, t) => sum + (Number(t.durationMinutes) || 0), 0);
      const avgMinutes = techTaskCount > 0 ? Math.round(totalMinutes / techTaskCount) : 0;
      const shareOfPlant = totalPlantTasks > 0 ? Math.round((techTaskCount / totalPlantTasks) * 100) : (techTaskCount > 0 ? 100 : 0);
      
      let soloTasksCount = 0;
      let teamTasksCount = 0;
      const opCountMap: Record<string, number> = { 'برق صنعتی': 0, 'مکانیک': 0, 'تاسیسات': 0, 'روشنایی': 0, 'عمومی': 0 };

      techTasks.forEach(t => {
        const anyT = t as any;
        const text = `${t.title || ''} ${anyT.description || ''} ${t.details || ''} ${anyT.actionDetails || ''}`;
        const hasHelpers = 
          (Array.isArray(t.coTechnicians) && t.coTechnicians.length > 0) ||
          (Array.isArray(anyT.coTechnicians) && anyT.coTechnicians.length > 0) ||
          (Array.isArray(anyT.technicians) && anyT.technicians.length > 1) ||
          Boolean(anyT.assistant || anyT.helper || anyT.assistantTechnician || anyT.coTechnician || anyT.secondTechnician) ||
          (t.technician && t.technician !== techName);
        const isTeam = hasHelpers || text.includes('کمکی') || text.includes('شاگرد') || text.includes('همراه') || text.includes('تیم') || text.includes('نفرات') || text.includes('دسته جمعی') || text.includes('با همکاری') || text.includes('دونفره') || text.includes('دو نفره') || text.includes('۲ نفره') || text.includes('تیمی');
        if (isTeam) teamTasksCount++; else soloTasksCount++;
        const op = t.operationType || 'عمومی';
        if (opCountMap[op] !== undefined) opCountMap[op]++;
        else if (op.includes('برق')) opCountMap['برق صنعتی']++;
        else if (op.includes('مکانیک')) opCountMap['مکانیک']++;
        else if (op.includes('تاسیسات')) opCountMap['تاسیسات']++;
        else opCountMap['عمومی']++;
      });

      const soloPercent = techTaskCount > 0 ? Math.round((soloTasksCount / techTaskCount) * 100) : 0;
      const teamPercent = techTaskCount > 0 ? Math.round((teamTasksCount / techTaskCount) * 100) : 0;
      const completionRate = techTaskCount > 0 ? Math.round((doneTasks.length / techTaskCount) * 100) : 0;

      let topOp = 'عمومی';
      let topOpCount = 0;
      Object.entries(opCountMap).forEach(([op, count]) => {
        if (count > topOpCount) { topOp = op; topOpCount = count; }
      });

      // سنجش انطباق با استانداردهای سطوح پیچیدگی:
      // آسان: سقف ۲ ساعت و ۱ تکنسین | معمولی: سقف ۴ ساعت و تا ۲ تکنسین | دشوار: سقف ۸ ساعت و تا ۳ تکنسین
      let easyCount = 0;
      let normalCount = 0;
      let hardCount = 0;
      let onTimeCount = 0;
      let teamConformCount = 0;

      techTasks.forEach((t: any) => {
        const comp = t.complexityLevel || 'معمولی';
        const dur = Number(t.durationMinutes) || 45;
        const coList = Array.isArray(t.coTechnicians) ? t.coTechnicians : [];
        const teamSize = 1 + coList.length;

        let limit = 240;
        let maxTechs = 2;
        if (comp === 'آسان') {
          easyCount++;
          limit = 120;
          maxTechs = 1;
        } else if (comp === 'دشوار') {
          hardCount++;
          limit = 480;
          maxTechs = 3;
        } else {
          normalCount++;
          limit = 240;
          maxTechs = 2;
        }

        if (dur <= limit) onTimeCount++;
        if (teamSize <= maxTechs) teamConformCount++;
      });

      const onTimePercent = techTaskCount > 0 ? Math.round((onTimeCount / techTaskCount) * 100) : 100;
      const teamConformPercent = techTaskCount > 0 ? Math.round((teamConformCount / techTaskCount) * 100) : 100;

      let speedLabel = 'منطبق بر سقف استاندارد زمانی';
      if (onTimePercent === 100 && avgMinutes <= 60) speedLabel = 'سریع و چابک (زودتر از سقف استاندارد)';
      else if (onTimePercent >= 85) speedLabel = 'سریع و استاندارد در سطوح کار';
      else if (onTimePercent >= 60) speedLabel = 'متعادل (پروژه‌ای)';
      else speedLabel = 'طولانی‌تر از سقف زمانی استاندارد';

      // محاسبه ستاره کیفیت عملکرد تکنسین (از ۱ تا ۵ ستاره) با احتساب استانداردهای پیچیدگی
      let fallbackStarRating = 5;
      let fallbackStarRatingLabel = 'کیفیت عالی و بی‌نقص (۵ ستاره)';

      if (techTaskCount > 0) {
        const compQuality = (completionRate / 100) * 50;
        const spdQuality = (onTimePercent / 100) * 30;
        const teamScore = (teamConformPercent / 100) * 15;
        const hardBonus = Math.min(5, hardCount * 2.5);
        const autoQuality = Math.min(20, teamScore + (soloPercent >= 50 ? 5 : 3) + hardBonus);
        const totalQuality = compQuality + spdQuality + autoQuality;

        if (totalQuality >= 90) {
          fallbackStarRating = 5;
          fallbackStarRatingLabel = 'کیفیت عالی و بی‌نقص (۵ ستاره)';
        } else if (totalQuality >= 80) {
          fallbackStarRating = 4.5;
          fallbackStarRatingLabel = 'بسیار مطلوب و حرفه‌ای (۴.۵ ستاره)';
        } else if (totalQuality >= 70) {
          fallbackStarRating = 4;
          fallbackStarRatingLabel = 'کیفیت خوب و مورد تأیید (۴ ستاره)';
        } else if (totalQuality >= 60) {
          fallbackStarRating = 3.5;
          fallbackStarRatingLabel = 'کیفیت متوسط روبه‌بالا (۳.۵ ستاره)';
        } else if (totalQuality >= 50) {
          fallbackStarRating = 3;
          fallbackStarRatingLabel = 'کیفیت متوسط و قابل‌قبول (۳ ستاره)';
        } else {
          fallbackStarRating = 2.5;
          fallbackStarRatingLabel = 'نیازمند همراهی و نظارت کیفی (۲.۵ ستاره)';
        }
      }

      const fallbackText = techTaskCount === 0 
        ? `چکیده تحلیلی عملکرد تکنسین ${techName}:\n• در حال حاضر هیچ درخواست کاری برای این نیرو ثبت نشده است.\n• پس از ثبت اولین کار، کیفیت اجرا و گرایش فنی مورد ارزیابی قرار خواهد گرفت.`
        : `• بازده کلی: ${toFaDigits(onTimePercent)}٪ کارها طبق چارچوب استاندارد فنی بوده است.\n• تناسب و توان فنی: در بخش «${topOp}» به خصوص در اجرای کارهای سطح ${hardCount > 0 ? 'دشوار و پروژه‌ای' : 'معمولی و اضطراری'} تمرکز بالا و بازدهی اثبات‌شده دارد.\n• استقلال و کار تیمی: منطبق بر استانداردهای نت (اجرای مستقل کارهای آسان و هماهنگی ${teamPercent > 0 ? 'تیمی ۲ الی ۳ نفره در کارهای دشوارتر' : 'تک‌نفره با سرعت بالا'}).\n• تموم‌کنندگی فردی: ضریب بستن و تحویل کامل کارها ${toFaDigits(completionRate)}٪ بوده که نشان‌دهنده دقت بالا و مسئولیت‌پذیری در تحویل نهایی است.\n• توصیه سرپرستی: اولویت‌دهی به واگذاری دستورکارهای ${hardCount > 0 ? 'دشوار و حساس' : 'تخصصی'} حوزه ${topOp} متناسب با سرعت و ظرفیت کاری.`;

      setAiAnalysisResults(prev => ({
        ...prev,
        [techName]: {
          technicianName: techName,
          taskCount: techTaskCount,
          doneCount: doneTasks.length,
          activeCount: activeTasks.length,
          totalMinutes,
          avgMinutes,
          shareOfPlantPercent: shareOfPlant,
          soloPercent,
          teamPercent,
          completionRate,
          topSpecialty: topOp,
          speedLabel,
          starRating: fallbackStarRating,
          starRatingLabel: fallbackStarRatingLabel,
          analysisText: fallbackText,
        }
      }));
    } finally {
      setAiAnalysisLoading(false);
    }
  };

  // Open Unified Form for a Brand New Entry
  const openNewUnifiedForm = () => {
    setEditingItemCode(null);
    setFormSection('both');
    setIncludeWorkOrderActions(false);
    setReqTitle('');
    setReqPlace((FACTORY_LOCATIONS[0] || ''));
    setReqPriority('ایمنی (اولویت بالا)');
    setReqDate(getEnDateNow());
    const nowTime = getEnTimeNow();
    setReqTime(nowTime);
    setReqDesc('');
    setWoTechnician(technicians[0] || '');
    setWoCoTechnicians([]);
    setWoComplexityLevel('معمولی');
    setWoOperationType('مکانیک');
    setWoActionDetails('');
    setWoConsumables([]);
    setConsumableTab('برقی');
    setNewPartName('');
    setNewPartCount(1);
    setShowPresetsBar(false);
    setWoDate(getEnDateNow());
    setWoStartTime(nowTime); // به صورت پیش‌فرض برابر با ساعت درخواست
    setWoEndTime(nowTime);
    setWoDuration(45);
    setWoCloseImmediately(true);
    setFormError('');
    setModalType('unifiedForm');
  };

  // Open Unified Form for Existing Request to add/complete Work Order Actions
  const openCompleteWorkOrder = (req: WorkRequest) => {
    setEditingItemCode(req.code);
    setFormSection('workOrderOnly');
    setIncludeWorkOrderActions(true);
    setReqTitle(req.title);
    setReqPlace(req.place || (FACTORY_LOCATIONS[0] || ''));
    setReqPriority(req.priority?.includes('ایمنی') ? 'ایمنی (اولویت بالا)' : 'عادی');
    const parts = req.created ? req.created.split(' — ') : [];
    const parsedDate = toEnDigits(parts[0] || getEnDateNow());
    const parsedTime = toEnDigits(parts[1] || getEnTimeNow());
    setReqDate(parsedDate);
    setReqTime(parsedTime);
    setReqDesc(req.description);
    setWoTechnician(req.technician || technicians[0] || '');
    setWoCoTechnicians(req.coTechnicians || []);
    setWoComplexityLevel(req.complexityLevel || 'معمولی');
    setWoOperationType(req.operationType || 'مکانیک');
    setWoActionDetails(req.actionDetails || '');
    setWoConsumables(Array.isArray(req.consumables) ? JSON.parse(JSON.stringify(req.consumables)) : []);
    setConsumableTab('برقی');
    setNewPartName('');
    setNewPartCount(1);
    setShowPresetsBar(false);

    const initialWoDate = req.woDate || parsedDate;
    const initialStart = req.woStartTime || parsedTime; // به صورت پیش‌فرض برابر با ساعت درخواست
    const initialEnd = req.woEndTime || getEnTimeNow();
    setWoDate(initialWoDate);
    setWoStartTime(initialStart);
    setWoEndTime(initialEnd);
    const diff = computeMinutesDiff(initialStart, initialEnd);
    setWoDuration(req.durationMinutes || (diff > 0 ? diff : 45));

    setWoCloseImmediately(true);
    setFormError('');
    setModalType('unifiedForm');
  };

  // Handle Save Unified Form
  const handleSaveUnified = () => {
    setFormError('');
    if (!reqTitle.trim()) {
      setFormError('لطفاً عنوان کار / خرابی را وارد کنید.');
      return;
    }

    if (includeWorkOrderActions && woCloseImmediately && !woActionDetails.trim()) {
      setFormError('برای بستن دستور کار، لطفاً شرح اقدامات و عملیات انجام‌شده را بنویسید.');
      return;
    }

    const customDateTime = `${toEnDigits(reqDate.trim() || getEnDateNow())} — ${toEnDigits(reqTime.trim() || getEnTimeNow())}`;
    const cleanWoDate = toEnDigits(woDate.trim() || getEnDateNow());
    const cleanWoStartTime = toEnDigits(woStartTime.trim() || '08:30');
    const cleanWoEndTime = toEnDigits(woEndTime.trim() || getEnTimeNow());
    const woCompletedDateTime = `${cleanWoDate} — ${cleanWoEndTime}`;

    // آماده‌سازی قطعات مصرفی و متن خلاصه آنها (تضمین ذخیره‌سازی حتی در صورت عدم تیک‌زدن اقدامات تکنسین)
    const effectiveConsumables = (woConsumables && woConsumables.length > 0)
      ? woConsumables
      : (editingItemCode ? (workRequests.find(r => r.code === editingItemCode)?.consumables || []) : []);

    const partsUsedSummary = effectiveConsumables && effectiveConsumables.length > 0
      ? effectiveConsumables.map(c => `${c.name} (${toFaDigits(c.count)} ${c.unit || 'عدد'})`).join('، ')
      : (editingItemCode ? (workRequests.find(r => r.code === editingItemCode)?.partsUsed || '') : '');

    // ثبت یا به‌روزرسانی قطعات در انبار یکپارچه کارخانه با برچسب خدمات فنی
    if (effectiveConsumables.length > 0) {
      effectiveConsumables.forEach(c => {
        try {
          addOrUpdateSparePart({
            name: c.name,
            category: c.category === 'برقی' ? 'برقی' : c.category === 'مکانیکی' ? 'مکانیکی' : 'عمومی و سایر',
            source: 'technical',
            unit: c.unit || 'عدد',
            eqFamily: reqPlace || 'خدمات فنی'
          });
        } catch {}
      });
    }

    if (editingItemCode) {
      // Update existing request
      let targetObj: WorkRequest | null = null;
      const updated = workRequests.map(r => {
        if (r.code !== editingItemCode) return r;
        const modified: WorkRequest = {
          ...r,
          place: reqPlace,
          priority: reqPriority,
          created: customDateTime,
          technician: includeWorkOrderActions ? woTechnician : r.technician,
          coTechnicians: includeWorkOrderActions ? woCoTechnicians : r.coTechnicians,
          complexityLevel: includeWorkOrderActions ? woComplexityLevel : r.complexityLevel,
          operationType: includeWorkOrderActions ? woOperationType : r.operationType,
          actionDetails: includeWorkOrderActions ? woActionDetails.trim() : r.actionDetails,
          consumables: effectiveConsumables.length > 0 ? effectiveConsumables : r.consumables,
          partsUsed: partsUsedSummary || r.partsUsed,
          woDate: includeWorkOrderActions ? cleanWoDate : r.woDate,
          woStartTime: includeWorkOrderActions ? cleanWoStartTime : r.woStartTime,
          woEndTime: includeWorkOrderActions ? cleanWoEndTime : r.woEndTime,
          durationMinutes: includeWorkOrderActions ? woDuration : r.durationMinutes,
          status: includeWorkOrderActions ? (woCloseImmediately ? 'انجام شد' : 'در حال انجام') : r.status,
          completedAt: (includeWorkOrderActions && woCloseImmediately) ? woCompletedDateTime : r.completedAt,
          completedTimestamp: (includeWorkOrderActions && woCloseImmediately) ? (r.completedTimestamp || Date.now()) : r.completedTimestamp,
          workOrderCode: r.workOrderCode || `WO${r.code.replace('WR', '')}`
        };
        targetObj = modified;
        return modified;
      });
      setWorkRequests(updated);
      if (targetObj) {
        if (navigator.onLine && supabaseConnected) {
          upsertWorkRequestInSupabase(targetObj).then(res => {
            if (!res.success) enqueueOfflineAction({ type: 'upsert', data: targetObj });
          }).catch(() => enqueueOfflineAction({ type: 'upsert', data: targetObj }));
        } else {
          enqueueOfflineAction({ type: 'upsert', data: targetObj });
        }
      }
    } else {
      // Create new record
      const codeNum = String(Math.floor(Math.random() * 900000) + 100000);
      const newCode = `WR${codeNum}`;
      const newWoCode = includeWorkOrderActions ? `WO${codeNum}` : undefined;

      const newRecord: WorkRequest = {
        code: newCode,
        workOrderCode: newWoCode,
        place: reqPlace || (FACTORY_LOCATIONS[0] || ''),
        created: customDateTime,
        title: reqTitle.trim(),
        priority: reqPriority,
        description: reqDesc.trim() || '—',
        status: includeWorkOrderActions ? (woCloseImmediately ? 'انجام شد' : 'در حال اقدام') : 'در حال اقدام',
        technician: includeWorkOrderActions ? woTechnician : undefined,
        coTechnicians: includeWorkOrderActions ? woCoTechnicians : undefined,
        complexityLevel: includeWorkOrderActions ? woComplexityLevel : undefined,
        operationType: includeWorkOrderActions ? woOperationType : undefined,
        actionDetails: includeWorkOrderActions ? woActionDetails.trim() : undefined,
        consumables: effectiveConsumables.length > 0 ? effectiveConsumables : undefined,
        partsUsed: partsUsedSummary || undefined,
        woDate: includeWorkOrderActions ? cleanWoDate : undefined,
        woStartTime: includeWorkOrderActions ? cleanWoStartTime : undefined,
        woEndTime: includeWorkOrderActions ? cleanWoEndTime : undefined,
        durationMinutes: includeWorkOrderActions ? woDuration : undefined,
        completedAt: (includeWorkOrderActions && woCloseImmediately) ? woCompletedDateTime : undefined,
        completedTimestamp: (includeWorkOrderActions && woCloseImmediately) ? Date.now() : undefined
      };
      setWorkRequests([newRecord, ...workRequests]);
      if (navigator.onLine && supabaseConnected) {
        upsertWorkRequestInSupabase(newRecord).then(res => {
          if (!res.success) enqueueOfflineAction({ type: 'upsert', data: newRecord });
        }).catch(() => enqueueOfflineAction({ type: 'upsert', data: newRecord }));
      } else {
        enqueueOfflineAction({ type: 'upsert', data: newRecord });
      }
    }

    const isClosed = includeWorkOrderActions && woCloseImmediately;
    if (isClosed) {
      setArchiveNotice('✓ گزارش بسته شد و با موفقیت به «بایگانی کارهای مختومه» منتقل گردید (از جدول اصلی خارج شد).');
      setTimeout(() => setArchiveNotice(null), 6000);
    }

    setModalType('none');
  };

  const restoreFromArchive = (code: string) => {
    setWorkRequests(prev => prev.map(r => {
      if (r.code !== code) return r;
      return {
        ...r,
        status: 'در حال اقدام',
        completedAt: undefined,
        completedTimestamp: undefined
      };
    }));
    if (navigator.onLine && supabaseConnected) {
      updateStatusInSupabase(code, 'در حال اقدام').then(res => {
        if (!res.success) enqueueOfflineAction({ type: 'status', data: { code, status: 'در حال اقدام' } });
      }).catch(() => enqueueOfflineAction({ type: 'status', data: { code, status: 'در حال اقدام' } }));
    } else {
      enqueueOfflineAction({ type: 'status', data: { code, status: 'در حال اقدام' } });
    }
    setArchiveNotice(`درخواست ${code} از بایگانی خارج شد و به جدول اصلی کارهای جاری بازگشت.`);
    setTimeout(() => setArchiveNotice(null), 5000);
  };

  const handleSaveAndTestSupabase = async () => {
    setSupabaseLoading(true);
    setSupabaseStatusMsg(null);
    saveSupabaseConfig(supabaseUrlInput, supabaseKeyInput);
    
    const client = getSupabase();
    if (!client) {
      setSupabaseStatusMsg({ text: 'لطفاً آدرس پروژه و کلید امنیتی (anon key) را وارد کنید.', isError: true });
      setSupabaseLoading(false);
      return;
    }

    const res = await fetchWorkRequestsFromSupabase();
    if (res.error) {
      if (res.error.includes('relation') && res.error.includes('does not exist')) {
        setSupabaseStatusMsg({ 
          text: 'اتصال برقرار شد اما جدول work_requests در پایگاه داده پیدا نشد. لطفاً کد اسکریپت SQL زیر را در بخش SQL Editor سوپابیس اجرا کنید.', 
          isError: true 
        });
      } else {
        setSupabaseStatusMsg({ text: `خطا در برقراری ارتباط: ${res.error}`, isError: true });
      }
      setSupabaseConnected(false);
    } else {
      setSupabaseConnected(true);
      if (res.data && res.data.length > 0) {
        setWorkRequests(res.data);
      }
      setSupabaseStatusMsg({ text: '✓ با موفقیت به Supabase متصل شد! جدول همگام‌سازی شد.', isError: false });
    }
    setSupabaseLoading(false);
  };

  const activeRequests = workRequests.filter(r =>
    !r.isArchivedWorkOrder && r.status !== 'انجام شد' && r.status !== 'لغو' && r.status !== 'لغو شده'
  );
  const archivedRequests = workRequests.filter(r =>
    Boolean(r.isArchivedWorkOrder) || r.status === 'انجام شد' || r.status === 'لغو' || r.status === 'لغو شده'
  );

  // شاخص‌های کلیدی عملکرد (KPIs) خدمات فنی
  const totalDurationMinutes = workRequests.reduce((sum, r) => sum + (r.durationMinutes || 0), 0);
  const totalHoursLogged = Math.round(totalDurationMinutes / 60);
  const safetyCount = workRequests.filter(r => r.priority && r.priority.includes('ایمنی')).length;
  const completionRate = workRequests.length > 0 ? Math.round((archivedRequests.length / workRequests.length) * 100) : 0;

  // آمار جامع انبار روغن و مخازن خط تولید
  const totalOilLiters = oilTanks.reduce((sum, t) => sum + t.currentLiters, 0);
  const totalOilCapacity = oilTanks.reduce((sum, t) => sum + t.capacityLiters, 0);
  const lowOilTanksCount = oilTanks.filter(t => t.currentLiters <= t.minAlertLiters).length;

  const todayWithdrawTotal = oilTransactions
    .filter(t => t.type === 'out')
    .reduce((sum, t) => sum + t.amount_l, 0);

  const todayEntryTotal = oilTransactions
    .filter(t => t.type === 'in')
    .reduce((sum, t) => sum + t.amount_l, 0);

  const rankedConsumers = (() => {
    let outOps = oilTransactions.filter(t => t.type === 'out');

    if (topConsumptionPeriod === 'monthly') {
      outOps = outOps.filter(t => {
        const norm = normalizeShamsiDateStr(t.created_at);
        return norm.startsWith('1405/08') || norm.startsWith('1404/08');
      });
    } else if (topConsumptionPeriod === '3months') {
      outOps = outOps.filter(t => {
        const norm = normalizeShamsiDateStr(t.created_at);
        return norm >= '1405/06/01' || (norm >= '1404/06/01' && norm < '1404/09/01');
      });
    } else if (topConsumptionPeriod === '6months') {
      outOps = outOps.filter(t => {
        const norm = normalizeShamsiDateStr(t.created_at);
        return norm >= '1405/03/01' || (norm >= '1404/03/01' && norm < '1404/09/01');
      });
    } else if (topConsumptionPeriod === 'yearly') {
      outOps = outOps.filter(t => {
        const norm = normalizeShamsiDateStr(t.created_at);
        return norm.startsWith('1405') || norm.startsWith('1404');
      });
    }

    const rankMap: Record<string, number> = {};
    outOps.forEach(op => {
      let key = '';
      if (topConsumptionMode === 'equipment') {
        key = (op.equipment || '').trim() || 'سایر / بدون تجهیز';
      } else {
        key = (op.operator || '').trim() || 'نامشخص';
      }
      rankMap[key] = (rankMap[key] || 0) + op.amount_l;
    });
    return Object.entries(rankMap).sort((a, b) => b[1] - a[1]);
  })();

  const topConsumptionTotalPages = Math.max(1, Math.ceil(rankedConsumers.length / 5));
  const currentRankedPageItems = rankedConsumers.slice((topConsumptionPage - 1) * 5, topConsumptionPage * 5);

  // فیلتر و مرتب‌سازی هوشمند جدول کارهای خدمات فنی
  const filterWorkOrderList = (list: WorkRequest[]) => {
    let result = list.filter(r => {
      // جستجوی متنی زنده
      if (techSearch.trim()) {
        const q = techSearch.trim().toLowerCase();
        const combined = `${r.code} ${r.workOrderCode || ''} ${r.title} ${r.place} ${r.technician || ''} ${r.description} ${r.actionDetails || ''} ${r.operationType || ''}`.toLowerCase();
        if (!combined.includes(q)) return false;
      }
      // فیلتر سالن / مکان
      if (filterPlace !== 'همه' && r.place !== filterPlace) return false;
      // فیلتر اولویت
      if (filterPriority !== 'همه') {
        const isSafetySelected = filterPriority.includes('ایمنی');
        const isReqSafety = Boolean(r.priority && r.priority.includes('ایمنی'));
        if (isSafetySelected !== isReqSafety) return false;
      }
      // فیلتر تکنسین
      if (filterTechnician !== 'همه' && r.technician !== filterTechnician) return false;
      // فیلتر زمینه عملیات
      if (filterOpType !== 'همه' && r.operationType !== filterOpType) return false;
      return true;
    });

    if (sortBy === 'duration') {
      result = [...result].sort((a, b) => (b.durationMinutes || 0) - (a.durationMinutes || 0));
    } else if (sortBy === 'oldest') {
      result = [...result].reverse();
    }
    return result;
  };

  const isAnyFilterActive = techSearch.trim() !== '' || filterPlace !== 'همه' || filterPriority !== 'همه' || filterTechnician !== 'همه' || filterOpType !== 'همه' || sortBy !== 'newest';

  const resetAllFilters = () => {
    setTechSearch('');
    setFilterPlace('همه');
    setFilterPriority('همه');
    setFilterTechnician('همه');
    setFilterOpType('همه');
    setSortBy('newest');
  };

  // شاخص‌های کلیدی بازرسی و چک‌لیست تجهیزات (محاسبه بر اساس تجهیزات واقعی در سیستم)
  const totalEquipmentsCount = equipments.filter(e => Boolean(e.category)).length || equipments.length;

  // تخصیص تجهیز به دسته و تعیین اپراتور (مورد درخواستی کاربر با ذخیره و همگام‌سازی بلادرنگ)
  const handleAssignEquipmentToCategory = async (eqId: string, categoryName: string, opName?: string) => {
    const nowTs = Date.now();
    const assignedItem = equipments.find(e => e.id === eqId);

    const nextEquipments = equipments.map(item => {
      if (item.id !== eqId) return item;
      return {
        ...item,
        category: categoryName as any,
        inspector: opName !== undefined ? opName : item.inspector,
        updatedAt: nowTs
      };
    });

    const nextCategories = checklistCategories.map(cat => {
      if (cat.name === categoryName) {
        return { ...cat, equipmentCount: cat.equipmentCount + 1, updatedAt: nowTs };
      }
      return cat;
    });

    setEquipments(nextEquipments);
    setChecklistCategories(nextCategories);

    // ذخیره آنی در localStorage
    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCategories));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch (e) {
      console.warn('LocalStorage save error in handleAssignEquipmentToCategory:', e);
    }

    // ارسال فوری و بدون تاخیر به سرور ابری و مرکزی
    await pushStateToServerImmediate({
      equipments: nextEquipments,
      checklistCategories: nextCategories,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`✓ تجهیز «${assignedItem?.code || ''}» با موفقیت به دسته «${categoryName}»${opName ? ` و اپراتور ${opName}` : ''} تخصیص یافت.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
  };

  // خروج تجهیز از دسته فعلی با ذخیره آنی
  const handleRemoveEquipmentFromCategory = async (eqId: string) => {
    const item = equipments.find(e => e.id === eqId);
    if (!item) return;
    const oldCat = item.category;
    const nowTs = Date.now();

    const nextEquipments = equipments.map(e => e.id === eqId ? { ...e, category: '' as any, updatedAt: nowTs } : e);
    const nextCategories = checklistCategories.map(cat => {
      if (cat.name === oldCat) {
        return { ...cat, equipmentCount: Math.max(0, cat.equipmentCount - 1), updatedAt: nowTs };
      }
      return cat;
    });

    setEquipments(nextEquipments);
    setChecklistCategories(nextCategories);

    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCategories));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }

    await pushStateToServerImmediate({
      equipments: nextEquipments,
      checklistCategories: nextCategories,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`تجهیز «${item.code}» از دسته «${oldCat}» خارج شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
  };

  // ثبت سریع تجهیز جدید و تخصیص درجا به این دسته با ذخیره آنی
  const handleFastAddAndAssign = async (categoryName: string) => {
    if (!assignFastCode.trim() && !assignFastName.trim()) {
      alert('لطفاً کد یا عنوان تجهیز را وارد کنید.');
      return;
    }
    const code = assignFastCode.trim().toUpperCase() || assignFastName.trim().slice(0, 8).toUpperCase();
    const name = assignFastName.trim() || code;
    // دسته مقصد دقیقاً دسته‌ای است که کاربر در حال حاضر مودال آن را باز کرده و انتخاب نموده است
    const targetCat = categoryName;
    const nowTs = Date.now();
    const newEq: EquipmentItem = {
      id: `eq-${nowTs}-${Math.random().toString(36).substring(2, 6)}`,
      code,
      name,
      category: targetCat as any,
      hall: (FACTORY_LOCATIONS[0] || ''),
      status: 'سالم',
      lastInspectionDate: getEnDateNow(),
      inspector: assignTargetOperator || '',
      criticalChecks: ['فشار روغن گیج', 'تمیزی بدنه و اطراف', 'سیستم روانکاری'],
      updatedAt: nowTs
    };

    const nextEquipments = [newEq, ...equipments];
    const nextCategories = checklistCategories.map(c => {
      if (c.name === targetCat) {
        return { ...c, equipmentCount: c.equipmentCount + 1, updatedAt: nowTs };
      }
      return c;
    });

    setEquipments(nextEquipments);
    setChecklistCategories(nextCategories);
    setAssignFastCode('');
    setAssignFastName('');

    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCategories));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }

    await pushStateToServerImmediate({
      equipments: nextEquipments,
      checklistCategories: nextCategories,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`✓ تجهیز جدید «${code}» با موفقیت در دسته «${targetCat}» ثبت شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
  };
  const todayNormalizedDate = getTodayShamsiDateStringPm();
  const todayInspectionsCount = inspectionLogs.filter(i => {
    const logDateNorm = normalizeShamsiDatePm(i.date) || toEnDigits(i.date || '').trim();
    return logDateNorm === todayNormalizedDate;
  }).length;
  const totalNonConformitiesCount = inspectionLogs.filter(i => i.result === 'non_conforming').length;
  const conformingInspectionsCount = inspectionLogs.filter(i => i.result === 'conforming').length;
  const conformingPercentage = inspectionLogs.length > 0 
    ? Math.round((conformingInspectionsCount / inspectionLogs.length) * 100) 
    : 100;

  // سری ۸ روزه زنده روند بازرسی‌ها تا امروز (تفکیک بدون مشکل و عدم انطباق)
  const inspectionTrendSeries = useMemo(() => {
    const dayCounts: Record<string, { conforming: number; nonConforming: number }> = {};
    inspectionLogs.forEach(log => {
      const norm = normalizeShamsiDatePm(log.date) || toEnDigits(log.date || '').trim();
      if (!norm) return;
      if (!dayCounts[norm]) {
        dayCounts[norm] = { conforming: 0, nonConforming: 0 };
      }
      if (log.result === 'conforming') {
        dayCounts[norm].conforming += 1;
      } else {
        dayCounts[norm].nonConforming += 1;
      }
    });

    const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });

    const days: Array<{
      fullDate: string;
      shortLabel: string;
      isToday: boolean;
      conformingCount: number;
      nonConformingCount: number;
      totalCount: number;
    }> = [];

    for (let offset = 7; offset >= 0; offset--) {
      const d = new Date();
      d.setDate(d.getDate() - offset);
      let fullDate = '';
      try {
        const parts = fmt.formatToParts(d);
        const y = toEnDigits(parts.find(p => p.type === 'year')?.value || '');
        const m = toEnDigits(parts.find(p => p.type === 'month')?.value || '');
        const day = toEnDigits(parts.find(p => p.type === 'day')?.value || '');
        fullDate = normalizeShamsiDatePm(`${y}/${m}/${day}`) || '';
      } catch {}
      if (!fullDate) {
        fullDate = normalizeShamsiDatePm(toEnDigits(d.toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' }))) || '';
      }
      const counts = dayCounts[fullDate] || { conforming: 0, nonConforming: 0 };
      days.push({
        fullDate,
        shortLabel: fullDate ? fullDate.slice(5) : '',
        isToday: offset === 0,
        conformingCount: counts.conforming,
        nonConformingCount: counts.nonConforming,
        totalCount: counts.conforming + counts.nonConforming
      });
    }

    return days;
  }, [inspectionLogs]);

  // دایرکتوری و آمار تجمیعی بازرسی هر تجهیز برای جستجوی سریع در تاریخچه کامل
  const historyEquipmentDirectory = useMemo(() => {
    const map = new Map<string, {
      code: string;
      name: string;
      category: string;
      hall: string;
      status: string;
      operatorName: string;
      totalInspections: number;
      nonConformingCount: number;
      conformingCount: number;
      healthPct: number;
      lastDate: string;
      lastTime: string;
      lastOperator: string;
      defectCounts: Array<{ name: string; count: number }>;
      linkedWorkOrdersCount: number;
    }>();

    equipments.forEach(eq => {
      const codeKey = (eq.code || '').trim().toUpperCase();
      if (!codeKey) return;
      map.set(codeKey, {
        code: eq.code.trim(),
        name: eq.name || eq.code,
        category: eq.category || '—',
        hall: eq.hall || '—',
        status: eq.status || 'سالم',
        operatorName: eq.inspector || eq.operatorName || '—',
        totalInspections: 0,
        nonConformingCount: 0,
        conformingCount: 0,
        healthPct: 100,
        lastDate: eq.lastInspectionDate && eq.lastInspectionDate !== 'ثبت نشده' ? eq.lastInspectionDate : 'ثبت نشده',
        lastTime: '',
        lastOperator: eq.inspector || eq.operatorName || '—',
        defectCounts: [],
        linkedWorkOrdersCount: 0
      });
    });

    const defectMap = new Map<string, Record<string, number>>();
    const woSetMap = new Map<string, Set<string>>();

    inspectionLogs.forEach(log => {
      const rawCode = (log.equipmentCode || '').trim();
      const codeKey = rawCode.toUpperCase() || `__ID_${log.equipmentId}`;
      let entry = map.get(codeKey);
      if (!entry) {
        entry = {
          code: rawCode || log.equipmentId || '—',
          name: log.equipmentName || rawCode || '—',
          category: log.category || '—',
          hall: '—',
          status: log.result === 'conforming' ? 'سالم' : 'نیازمند_سرویس',
          operatorName: log.operator || '—',
          totalInspections: 0,
          nonConformingCount: 0,
          conformingCount: 0,
          healthPct: 100,
          lastDate: log.date || 'ثبت نشده',
          lastTime: log.time || '',
          lastOperator: log.operator || '—',
          defectCounts: [],
          linkedWorkOrdersCount: 0
        };
        map.set(codeKey, entry);
      }
      entry.totalInspections += 1;
      if (log.result === 'conforming') {
        entry.conformingCount += 1;
      } else {
        entry.nonConformingCount += 1;
        if (!defectMap.has(codeKey)) defectMap.set(codeKey, {});
        const dRec = defectMap.get(codeKey)!;
        const dList = log.defects && log.defects.length > 0 ? log.defects : ['عدم انطباق عمومی'];
        dList.forEach(d => {
          const dKey = d.trim();
          if (dKey) dRec[dKey] = (dRec[dKey] || 0) + 1;
        });
      }
      if (log.workOrderCode) {
        if (!woSetMap.has(codeKey)) woSetMap.set(codeKey, new Set());
        woSetMap.get(codeKey)!.add(log.workOrderCode);
      }
      if (entry.totalInspections === 1 && log.date) {
        entry.lastDate = log.date;
        entry.lastTime = log.time || '';
        entry.lastOperator = log.operator || entry.lastOperator;
      }
    });

    map.forEach((entry, codeKey) => {
      entry.healthPct = entry.totalInspections > 0
        ? Math.round((entry.conformingCount / entry.totalInspections) * 100)
        : 100;
      const dRec = defectMap.get(codeKey) || {};
      entry.defectCounts = Object.entries(dRec)
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count);
      entry.linkedWorkOrdersCount = woSetMap.get(codeKey)?.size || 0;
    });

    return Array.from(map.values()).sort((a, b) =>
      b.nonConformingCount - a.nonConformingCount ||
      b.totalInspections - a.totalInspections ||
      a.code.localeCompare(b.code)
    );
  }, [equipments, inspectionLogs]);

  // نگهداری ۵ بازرسی اخیر هر تجهیز برای نمایش سریع دایره‌های رنگی کنار نام تجهیز
  const recentInspectionsByEquipmentKey = useMemo(() => {
    const map = new Map<string, InspectionRecord[]>();
    const addTo = (k: string, log: InspectionRecord) => {
      if (!k) return;
      let list = map.get(k);
      if (!list) {
        list = [];
        map.set(k, list);
      }
      if (list.length < 5 && !list.some(item => item.id === log.id)) {
        list.push(log);
      }
    };
    for (const log of inspectionLogs) {
      const codeKey = (log.equipmentCode || '').trim().toUpperCase();
      const idKey = (log.equipmentId || '').trim();
      if (codeKey) addTo(`CODE:${codeKey}`, log);
      if (idKey) addTo(`ID:${idKey}`, log);
    }
    return map;
  }, [inspectionLogs]);

  const escapeChecklistPrintHtml = (raw: string) =>
    String(raw ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const getChecklistLogsForPrintMode = (mode: 'all' | 'conforming' | 'non_conforming') => {
    const q = toEnDigits(historyEquipmentSearch).trim().toLowerCase();
    const scoped = inspectionLogs.filter(log => {
      if (historyDateFilter !== 'all') {
        const logDateNorm = normalizeShamsiDatePm(log.date) || toEnDigits(log.date || '').trim();
        if (logDateNorm !== historyDateFilter) return false;
      }
      if (selectedHistoryEquipCode) {
        return (log.equipmentCode || '').trim().toUpperCase() === selectedHistoryEquipCode.trim().toUpperCase();
      }
      if (q) {
        return (
          (log.equipmentCode || '').toLowerCase().includes(q) ||
          (log.equipmentName || '').toLowerCase().includes(q) ||
          (log.operator || '').toLowerCase().includes(q) ||
          (log.category || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
    if (mode === 'all') return scoped;
    return scoped.filter(log => log.result === mode);
  };

  const getChecklistPrintModeMeta = (mode: 'all' | 'conforming' | 'non_conforming') => {
    if (mode === 'conforming') {
      return {
        badge: 'گزارش بازرسی‌های بدون مشکل',
        fileSlug: 'Conforming',
        accent: '#059669',
        bgSoft: '#ecfdf5',
        borderSoft: '#a7f3d0'
      };
    }
    if (mode === 'non_conforming') {
      return {
        badge: 'گزارش موارد دارای عدم انطباق',
        fileSlug: 'NonConforming',
        accent: '#e11d48',
        bgSoft: '#fff1f2',
        borderSoft: '#fecdd3'
      };
    }
    return {
      badge: 'گزارش جامع همه موارد بازرسی',
      fileSlug: 'All',
      accent: '#0284c7',
      bgSoft: '#f0f9ff',
      borderSoft: '#bae6fd'
    };
  };

  const buildChecklistInspectionPrintHtml = (
    mode: 'all' | 'conforming' | 'non_conforming',
    options?: { autoPrint?: boolean }
  ) => {
    const chkCfg = printSettings.checklistInspectionReport;
    const meta = getChecklistPrintModeMeta(mode);
    const rows = getChecklistLogsForPrintMode(mode);
    const todayDate = getEnDateNow();
    const nowTime = getEnTimeNow();
    const rowsHtml = rows.length === 0
      ? `<tr><td colspan="9" style="text-align:center; padding:22px; color:#64748b; font-weight:bold;">هیچ سابقه‌ای در دسته «${escapeChecklistPrintHtml(meta.badge)}» ثبت نشده است.</td></tr>`
      : rows.map((log, idx) => {
          const isOk = log.result === 'conforming';
          const defectsText = log.defects && log.defects.length > 0
            ? log.defects.map(d => `<span style="display:inline-block;background:#ffe4e6;color:#9f1239;border:1px solid #fda4af;border-radius:4px;padding:1px 6px;margin:1px;font-size:9.5px;font-weight:bold;">${escapeChecklistPrintHtml(d)}</span>`).join('')
            : '<span style="color:#94a3b8;">—</span>';
          const notesParts: string[] = [];
          if (log.notes) notesParts.push(escapeChecklistPrintHtml(log.notes));
          if (log.workOrderCode) {
            notesParts.push(`<div style="margin-top:2px;color:#0369a1;font-family:monospace;font-size:9.5px;font-weight:bold;">دستور کار مرتبط: ${escapeChecklistPrintHtml(log.workOrderCode)}</div>`);
          }
          const notesHtml = notesParts.length > 0 ? notesParts.join('') : '<span style="color:#94a3b8;">—</span>';
          const photoHtml = log.photoUrl
            ? `<img src="${log.photoUrl}" alt="تصویر" style="width:42px;height:42px;object-fit:cover;border-radius:6px;border:1px solid #cbd5e1;" />`
            : '<span style="color:#94a3b8;">—</span>';
          return `
            <tr>
              <td style="text-align:center;font-family:monospace;font-weight:bold;">${toFaDigits(idx + 1)}</td>
              <td>
                <div style="font-family:monospace;font-weight:bold;color:#0f172a;">${escapeChecklistPrintHtml(log.equipmentCode || '—')}</div>
                <div style="font-size:10px;color:#334155;">${escapeChecklistPrintHtml(log.equipmentName || '—')}</div>
              </td>
              <td style="text-align:center;font-weight:bold;color:#1e293b;">${escapeChecklistPrintHtml(log.category || '—')}</td>
              <td style="text-align:center;white-space:nowrap;">
                <span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:bold;background:${isOk ? '#dcfce7' : '#ffe4e6'};color:${isOk ? '#166534' : '#9f1239'};border:1px solid ${isOk ? '#86efac' : '#fda4af'};">
                  ${isOk ? 'بدون مشکل ✓' : 'عدم انطباق ⚠️'}
                </span>
              </td>
              <td style="font-weight:bold;">${escapeChecklistPrintHtml(log.operator || '—')}</td>
              <td>${defectsText}</td>
              <td style="max-width:190px;word-break:break-word;">${notesHtml}</td>
              <td style="text-align:center;">${photoHtml}</td>
              <td style="text-align:center;font-family:monospace;white-space:nowrap;">
                <div>${escapeChecklistPrintHtml(toFaDigits(log.date || '—'))}</div>
                <div style="font-size:9.5px;color:#64748b;">${escapeChecklistPrintHtml(toFaDigits(log.time || ''))}</div>
              </td>
            </tr>
          `;
        }).join('');

    return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>${escapeChecklistPrintHtml(chkCfg.docTitle)} - ${escapeChecklistPrintHtml(meta.badge)} (${escapeChecklistPrintHtml(chkCfg.docCode)})</title>
  <style>
    @page { size: A4 landscape; margin: 10mm; }
    * { box-sizing: border-box; }
    body { font-family: Tahoma, 'Vazirmatn', system-ui, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 14px; font-size: 11px; }
    .toolbar { display: flex; justify-content: flex-end; gap: 8px; margin-bottom: 12px; }
    .btn-print { background: #0f172a; color: #ffffff; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Tahoma, sans-serif; font-size: 12px; }
    .header-box { display: flex; justify-content: space-between; align-items: center; border: 2px solid #0f172a; border-radius: 10px; padding: 10px 14px; margin-bottom: 12px; }
    .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 12px; }
    .kpi-card { border: 1px solid #cbd5e1; border-radius: 8px; padding: 7px 10px; text-align: center; background: #f8fafc; }
    table { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 10.5px; }
    th, td { border: 1px solid #475569; padding: 6px 7px; text-align: right; vertical-align: middle; }
    th { background: #e2e8f0; color: #0f172a; font-weight: bold; }
    .sign-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 18px; }
    .sign-box { border: 1px dashed #64748b; border-radius: 8px; padding: 10px; min-height: 62px; display: flex; flex-direction: column; justify-content: space-between; text-align: center; font-size: 10.5px; }
    @media print { .no-print { display: none !important; } body { padding: 0; } }
  </style>
</head>
<body>
  <div class="toolbar no-print">
    <button class="btn-print" onclick="window.print()">چاپ گزارش (${escapeChecklistPrintHtml(chkCfg.docCode)})</button>
  </div>
  <div class="header-box">
    <div style="display:flex;align-items:center;gap:12px;">
      <img src="${COMPANY_LOGO_WHITEBG}" alt={BRAND_CONFIG.COMPANY_NAME} style="height:52px;width:auto;object-fit:contain;" />
      <div>
        <div style="font-size:11px;color:#475569;font-weight:bold;">${BRAND_CONFIG.COMPANY_FULL_NAME}</div>
        <h1 style="margin:2px 0;font-size:15px;font-weight:900;color:#0f172a;">${escapeChecklistPrintHtml(chkCfg.docTitle)}</h1>
        <span style="display:inline-block;margin-top:3px;padding:2px 10px;border-radius:999px;font-size:10.5px;font-weight:bold;background:${meta.bgSoft};color:${meta.accent};border:1px solid ${meta.borderSoft};">
          ${escapeChecklistPrintHtml(meta.badge)}
        </span>
      </div>
    </div>
    <div style="text-align:left;font-family:monospace;font-size:11px;line-height:1.7;color:#1e293b;">
      <div>کد سند: <strong>${escapeChecklistPrintHtml(chkCfg.docCode)}</strong></div>
      <div>تعداد پرونده: <strong>${toFaDigits(rows.length)}</strong> مورد</div>
      <div>تاریخ چاپ: <strong>${escapeChecklistPrintHtml(toFaDigits(todayDate))}</strong> — <strong>${escapeChecklistPrintHtml(toFaDigits(nowTime))}</strong></div>
    </div>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div style="font-size:10px;color:#475569;">کل تجهیزات خط</div>
      <div style="font-size:15px;font-weight:900;font-family:monospace;">${toFaDigits(totalEquipmentsCount)} دستگاه</div>
    </div>
    <div class="kpi-card">
      <div style="font-size:10px;color:#475569;">تعداد ردیف‌های این چاپ</div>
      <div style="font-size:15px;font-weight:900;font-family:monospace;color:${meta.accent};">${toFaDigits(rows.length)} پرونده</div>
    </div>
    <div class="kpi-card">
      <div style="font-size:10px;color:#047857;">کل بازرسی‌های بدون مشکل</div>
      <div style="font-size:15px;font-weight:900;font-family:monospace;color:#059669;">${toFaDigits(conformingInspectionsCount)} مورد</div>
    </div>
    <div class="kpi-card">
      <div style="font-size:10px;color:#be123c;">کل موارد عدم انطباق</div>
      <div style="font-size:15px;font-weight:900;font-family:monospace;color:#e11d48;">${toFaDigits(totalNonConformitiesCount)} مورد</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width:36px;text-align:center;">ردیف</th>
        <th style="width:135px;">کد و نام تجهیز</th>
        <th style="width:85px;text-align:center;">دسته / خط</th>
        <th style="width:95px;text-align:center;">وضعیت</th>
        <th style="width:95px;">اپراتور</th>
        <th>موارد عدم انطباق</th>
        <th>توضیحات و دستور کار</th>
        <th style="width:55px;text-align:center;">عکس</th>
        <th style="width:85px;text-align:center;">تاریخ و زمان</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml}
    </tbody>
  </table>

  <div class="sign-grid">
    <div class="sign-box">
      <span style="font-weight:bold;">بازرس کنترل و چک‌لیست</span>
      <span style="color:#64748b;font-size:9.5px;">نام، امضا و تاریخ</span>
    </div>
    <div class="sign-box">
      <span style="font-weight:bold;">سرپرست سالن تولید</span>
      <span style="color:#64748b;font-size:9.5px;">نام، امضا و تاریخ</span>
    </div>
    <div class="sign-box">
      <span style="font-weight:bold;">واحد نگهداری و تعمیرات (نت)</span>
      <span style="color:#64748b;font-size:9.5px;">نام، امضا و تاریخ</span>
    </div>
  </div>
  ${options?.autoPrint ? '<script>window.focus();setTimeout(function(){window.print();},320);</script>' : ''}
</body>
</html>`;
  };

  const downloadChecklistInspectionHtml = (mode: 'all' | 'conforming' | 'non_conforming') => {
    const chkCfg = printSettings.checklistInspectionReport;
    const meta = getChecklistPrintModeMeta(mode);
    const html = buildChecklistInspectionPrintHtml(mode, { autoPrint: false });
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Checklist-${meta.fileSlug}-${chkCfg.docCode || 'OSV-CHK-01'}.html`;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 500);
  };

  const triggerChecklistInspectionPrint = (mode: 'all' | 'conforming' | 'non_conforming') => {
    const htmlForIframe = buildChecklistInspectionPrintHtml(mode, { autoPrint: false });
    const htmlForStandalone = buildChecklistInspectionPrintHtml(mode, { autoPrint: true });
    let printedNatively = false;

    try {
      const existing = document.getElementById('checklist-inspection-print-iframe');
      if (existing) existing.remove();

      const iframe = document.createElement('iframe');
      iframe.id = 'checklist-inspection-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.top = '-9999px';
      iframe.style.left = '-9999px';
      iframe.style.width = '297mm';
      iframe.style.height = '210mm';
      iframe.style.border = '0';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const fDoc = iframe.contentWindow?.document;
      if (fDoc) {
        fDoc.open();
        fDoc.write(htmlForIframe);
        fDoc.close();
        const t0 = performance.now();
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        if (performance.now() - t0 >= 30) {
          printedNatively = true;
        }
      }
    } catch (e) {
      console.warn('checklist iframe print failed:', e);
    }

    if (printedNatively) return;

    try {
      const blob = new Blob([htmlForStandalone], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      const tabLink = document.createElement('a');
      tabLink.href = blobUrl;
      tabLink.target = '_blank';
      tabLink.style.display = 'none';
      document.body.appendChild(tabLink);
      tabLink.click();
      document.body.removeChild(tabLink);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);

      setTimeout(() => {
        try {
          if (document.hasFocus() && document.visibilityState === 'visible') {
            downloadChecklistInspectionHtml(mode);
          }
        } catch {
          downloadChecklistInspectionHtml(mode);
        }
      }, 280);
    } catch {
      downloadChecklistInspectionHtml(mode);
    }
  };

  // باز کردن مودال بازرسی تجهیز
  const handleOpenInspectModal = (eq: EquipmentItem) => {
    setInspectingEquipment(eq);
    setInspectingOperator((eq.inspector || productionOperators[0]?.name || 'اپراتور'));
    setInspectionResult('conforming');
    setInspectionDefects([]);
    setInspectionNotes('');
    setInspectionPhoto(null);
    setInspectionAutoWorkOrder(false);
  };

  // تأیید سریع بدون مشکل
  const handleQuickConfirmConforming = (eq: EquipmentItem) => {
    const todayDate = getEnDateNow();
    const nowTime = getEnTimeNow();
    const opName = (eq.inspector || productionOperators[0]?.name || 'اپراتور');

    const newLog: InspectionRecord = {
      id: `insp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      equipmentId: eq.id,
      equipmentCode: eq.code,
      equipmentName: eq.name,
      category: eq.category,
      operator: opName,
      inspector: 'بازرس فنی',
      date: todayDate,
      time: nowTime,
      result: 'conforming',
      defects: [],
      notes: 'تأیید سریع سلامت — تجهیز بدون مشکل و در شرایط کاری پایدار'
    };

    const nextLogs = [newLog, ...inspectionLogs];
    setInspectionLogs(nextLogs);

    const nextEquipments = equipments.map(item => {
      const isMatch = (item.id && eq.id && item.id === eq.id) ||
        (Boolean(item.code && eq.code) && item.code.trim().toUpperCase() === eq.code.trim().toUpperCase());
      if (!isMatch) return item;
      return { ...item, status: 'سالم' as const, lastInspectionDate: todayDate };
    });
    setEquipments(nextEquipments);

    const exists = operatorLeaderboard.find(o => o.name === opName);
    const nextLeaderboard = exists
      ? operatorLeaderboard.map(o => {
          if (o.name !== opName) return o;
          return { ...o, inspectionsCount: o.inspectionsCount + 1, status: 'بدون مشکل' as const, performancePct: 100 };
        })
      : [
          ...operatorLeaderboard,
          {
            id: `op-${Date.now()}`,
            name: opName,
            inspectionsCount: 1,
            status: 'بدون مشکل' as const,
            performancePct: 100
          }
        ];
    setOperatorLeaderboard(nextLeaderboard);

    // ذخیره مستقیم، بلادرنگ و قطعی در دیتابیس محلی و ارسال به سرور
    try {
      localStorage.setItem('portal_inspections_v5', JSON.stringify(nextLogs));
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(nextLeaderboard));
    } catch {}

    pushStateToServerImmediate({
      inspectionLogs: nextLogs,
      equipments: nextEquipments,
      operatorLeaderboard: nextLeaderboard
    });

    setChecklistNotice(`✓ سلامت تجهیز ${eq.code} (${eq.name}) با موفقیت تأیید شد.`);
    setCategoryQuickSuccessToast(`✓ سلامت تجهیز ${eq.code} با موفقیت ثبت و ذخیره گردید.`);
    setTimeout(() => {
      setChecklistNotice(null);
      setCategoryQuickSuccessToast(null);
    }, 4500);
  };

  // مدیریت انتخاب عکس و خواندن به صورت Base64 با فشرده‌سازی خودکار جهت ذخیره تضمینی
  const handleInspectionPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 15 * 1024 * 1024) {
        alert('حجم عکس انتخابی بیش از ۱۵ مگابایت است. لطفاً عکس کم‌حجم‌تری انتخاب فرمایید.');
        return;
      }
      const reader = new FileReader();
      reader.onload = async (uploadEvt) => {
        if (typeof uploadEvt.target?.result === 'string') {
          const compressed = await compressImageDataUrl(uploadEvt.target.result, 720, 0.72);
          setInspectionPhoto(compressed);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // ثبت فرم بازرسی (دارای عدم انطباق یا بدون مشکل)
  const handleSubmitInspection = () => {
    if (!inspectingEquipment) return;

    const todayDate = getEnDateNow();
    const nowTime = getEnTimeNow();

    let autoWoCode: string | undefined = undefined;

    if (inspectionResult === 'non_conforming') {
      const activeDefects = inspectionDefects.length > 0 ? inspectionDefects : ['عدم انطباق در بازرسی'];
      // عدم انطباق در چک‌لیست ثبت می‌شود بدون صدور ناخواسته دستورکار فنی مگر در موارد اضطراری
      if (inspectionAutoWorkOrder) {
        const codeNum = String(Math.floor(Math.random() * 900000) + 100000);
        const newCode = `WR${codeNum}`;
        autoWoCode = `WO${codeNum}`;
        const newRecord: WorkRequest = {
          code: newCode,
          workOrderCode: autoWoCode,
          place: inspectingEquipment.hall || (FACTORY_LOCATIONS[0] || ''),
          created: `${todayDate} — ${nowTime}`,
          title: `رفع عدم انطباق بازرسی: ${inspectingEquipment.code} (${activeDefects.join('، ')})`,
          priority: activeDefects.includes('خرابی تجهیز') ? 'فوری/اضطراری' : 'ایمنی',
          description: `گزارش ثبت‌شده در سامانه چک‌لیست و بازرسی تجهیزات:\nدستگاه: ${inspectingEquipment.name} (${inspectingEquipment.code})\nاپراتور: ${inspectingOperator}\nبازرس: بازرس فنی\nایرادات: ${activeDefects.join('، ')}\nتوضیحات بازرس: ${inspectionNotes.trim() || 'نیازمند رسیدگی فنی فوری'}`,
          status: 'در حال اقدام',
          technician: (technicians[0] || ''),
          operationType: 'مکانیک'
        };
        setWorkRequests(prev => [newRecord, ...prev]);
      }
    }

    const newLog: InspectionRecord = {
      id: `insp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      equipmentId: inspectingEquipment.id,
      equipmentCode: inspectingEquipment.code,
      equipmentName: inspectingEquipment.name,
      category: inspectingEquipment.category,
      operator: inspectingOperator,
      inspector: 'بازرس فنی',
      date: todayDate,
      time: nowTime,
      result: inspectionResult,
      defects: inspectionResult === 'non_conforming' ? (inspectionDefects.length > 0 ? inspectionDefects : ['عدم انطباق در بازرسی']) : [],
      notes: inspectionNotes.trim() || (inspectionResult === 'conforming' ? 'تجهیز بدون مشکل تأیید شد.' : 'عدم انطباق در بازرسی ثبت گردید.'),
      photoUrl: inspectionPhoto || undefined,
      workOrderCode: autoWoCode
    };

    const nextLogs = [newLog, ...inspectionLogs];
    setInspectionLogs(nextLogs);

    // بروزرسانی وضعیت دستگاه در لیست تجهیزات با انطباق کد و آیدی
    const nextEquipments = equipments.map(eq => {
      const isMatch = (eq.id && inspectingEquipment.id && eq.id === inspectingEquipment.id) ||
        (Boolean(eq.code && inspectingEquipment.code) && eq.code.trim().toUpperCase() === inspectingEquipment.code.trim().toUpperCase());
      if (!isMatch) return eq;
      return {
        ...eq,
        status: inspectionResult === 'conforming' 
          ? ('سالم' as const)
          : inspectionDefects.includes('خرابی تجهیز') 
          ? ('تعمیر_اضطراری' as const)
          : ('نیازمند_سرویس' as const),
        lastInspectionDate: todayDate,
        inspector: inspectingOperator
      };
    });
    setEquipments(nextEquipments);

    // بروزرسانی رتبه‌بندی اپراتور
    const exists = operatorLeaderboard.find(o => o.name === inspectingOperator);
    const nextLeaderboard = exists
      ? operatorLeaderboard.map(o => {
          if (o.name !== inspectingOperator) return o;
          const newCount = o.inspectionsCount + 1;
          const newStatus = inspectionResult === 'conforming' ? o.status : ('دارای عدم انطباق' as const);
          const newPct = inspectionResult === 'conforming' ? Math.min(100, o.performancePct) : Math.max(70, o.performancePct - 2);
          return { ...o, inspectionsCount: newCount, status: newStatus, performancePct: newPct };
        })
      : [
          ...operatorLeaderboard,
          {
            id: `op-${Date.now()}`,
            name: inspectingOperator,
            inspectionsCount: 1,
            status: inspectionResult === 'conforming' ? ('بدون مشکل' as const) : ('دارای عدم انطباق' as const),
            performancePct: inspectionResult === 'conforming' ? 100 : 90
          }
        ];
    setOperatorLeaderboard(nextLeaderboard);

    // ذخیره محلی و همگام‌سازی فوری
    try {
      localStorage.setItem('portal_inspections_v5', JSON.stringify(nextLogs));
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(nextLeaderboard));
    } catch {}

    pushStateToServerImmediate({
      inspectionLogs: nextLogs,
      equipments: nextEquipments,
      operatorLeaderboard: nextLeaderboard
    });

    setChecklistNotice(
      inspectionResult === 'conforming'
        ? `✓ بازرسی تجهیز ${inspectingEquipment.code} به عنوان «بدون مشکل» با موفقیت ثبت شد.`
        : `⚠️ عدم انطباق تجهیز ${inspectingEquipment.code} با موفقیت ثبت شد${autoWoCode ? ` و دستورکار ${autoWoCode} در کارتابل فنی صادر گردید.` : '.'}`
    );
    setTimeout(() => setChecklistNotice(null), 6000);

    setInspectingEquipment(null);
  };

  // تغییر اپراتور مستقیم روی کارت تجهیز
  const handleUpdateEquipmentOperator = (eqId: string, newOperator: string) => {
    setEquipments(prev => {
      const updated = prev.map(eq => {
        if (eq.id !== eqId) return eq;
        return { ...eq, inspector: newOperator };
      });
      try { localStorage.setItem('portal_equipments_v9', JSON.stringify(updated)); } catch {}
      pushStateToServer({ equipments: updated });
      return updated;
    });
  };

  // دریافت عکس برای ثبت عدم انطباق روی کارت هر تجهیز با فشرده‌سازی خودکار
  const handleInlinePhotoChange = (eqId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 15 * 1024 * 1024) {
        alert('حجم عکس انتخابی بیش از ۱۵ مگابایت است.');
        return;
      }
      const reader = new FileReader();
      reader.onload = async (uploadEvt) => {
        if (typeof uploadEvt.target?.result === 'string') {
          const compressed = await compressImageDataUrl(uploadEvt.target.result, 720, 0.72);
          setInlineInspectionPhotosMap(prev => ({
            ...prev,
            [eqId]: compressed
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // ثبت عدم انطباق مستقیم درون کارت تجهیز
  const handleInlineSubmitNonConforming = (eq: EquipmentItem) => {
    const defects = inlineInspectionDefectsMap[eq.id] || inlineInspectionDefectsMap[eq.code] || [];
    const notes = inlineInspectionNotesMap[eq.id] || inlineInspectionNotesMap[eq.code] || '';
    const photo = inlineInspectionPhotosMap[eq.id] || inlineInspectionPhotosMap[eq.code] || null;
    const opName = (eq.inspector || productionOperators[0]?.name || 'اپراتور');

    // در صورتی که کاربری ایرادی تیک نزد یا توضیحی ننوشت، یک مقدار پیش‌فرض معتبر ثبت کن تا عملیات با موفقیت انجام شود
    const finalDefects = defects.length > 0 ? defects : ['نیاز به سرویس / بازبینی فنی'];
    const finalNotes = notes.trim() || 'عدم انطباق در بازرسی خط تولید ثبت گردید.';

    const todayDate = getEnDateNow();
    const nowTime = getEnTimeNow();

    let autoWoCode: string | undefined = undefined;
    if (finalDefects.includes('خرابی تجهیز')) {
      const codeNum = String(Math.floor(Math.random() * 900000) + 100000);
      const newCode = `WR${codeNum}`;
      autoWoCode = `WO${codeNum}`;
      const newRecord: WorkRequest = {
        code: newCode,
        workOrderCode: autoWoCode,
        place: eq.hall || (FACTORY_LOCATIONS[0] || ''),
        created: `${todayDate} — ${nowTime}`,
        title: `رفع عدم انطباق بازرسی: ${eq.code} (${finalDefects.join('، ')})`,
        priority: 'فوری/اضطراری',
        description: `گزارش ثبت‌شده در سامانه چک‌لیست و بازرسی تجهیزات:\nدستگاه: ${eq.name} (${eq.code})\nاپراتور: ${opName}\nبازرس: بازرس فنی\nایرادات: ${finalDefects.join('، ')}\nتوضیحات بازرس: ${finalNotes}`,
        status: 'در حال اقدام',
        technician: (technicians[0] || ''),
        operationType: 'مکانیک'
      };
      setWorkRequests(prev => [newRecord, ...prev]);
    }

    const newLog: InspectionRecord = {
      id: `insp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      equipmentId: eq.id,
      equipmentCode: eq.code,
      equipmentName: eq.name,
      category: eq.category,
      operator: opName,
      inspector: 'بازرس فنی',
      date: todayDate,
      time: nowTime,
      result: 'non_conforming',
      defects: finalDefects,
      notes: finalNotes,
      photoUrl: photo || undefined,
      workOrderCode: autoWoCode
    };

    const nextLogs = [newLog, ...inspectionLogs];
    setInspectionLogs(nextLogs);

    const nextEquipments = equipments.map(item => {
      const isMatch = (item.id && eq.id && item.id === eq.id) ||
        (Boolean(item.code && eq.code) && item.code.trim().toUpperCase() === eq.code.trim().toUpperCase());
      if (!isMatch) return item;
      return {
        ...item,
        status: finalDefects.includes('خرابی تجهیز') ? ('تعمیر_اضطراری' as const) : ('نیازمند_سرویس' as const),
        lastInspectionDate: todayDate
      };
    });
    setEquipments(nextEquipments);

    const exists = operatorLeaderboard.find(o => o.name === opName);
    const nextLeaderboard = exists
      ? operatorLeaderboard.map(o => {
          if (o.name !== opName) return o;
          return {
            ...o,
            inspectionsCount: o.inspectionsCount + 1,
            status: 'دارای عدم انطباق' as const,
            performancePct: Math.max(70, o.performancePct - 2)
          };
        })
      : [
          ...operatorLeaderboard,
          {
            id: `op-${Date.now()}`,
            name: opName,
            inspectionsCount: 1,
            status: 'دارای عدم انطباق' as const,
            performancePct: 90
          }
        ];
    setOperatorLeaderboard(nextLeaderboard);

    // پاکسازی کشویی عدم انطباق این تجهیز
    setInlineExpandedDefectsEqId(null);
    setInlineInspectionDefectsMap(prev => ({ ...prev, [eq.id]: [], [eq.code]: [] }));
    setInlineInspectionNotesMap(prev => ({ ...prev, [eq.id]: '', [eq.code]: '' }));
    setInlineInspectionPhotosMap(prev => ({ ...prev, [eq.id]: null, [eq.code]: null }));

    // ذخیره مستقیم، بلادرنگ و قطعی در دیتابیس محلی و ارسال به سرور
    try {
      localStorage.setItem('portal_inspections_v5', JSON.stringify(nextLogs));
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_operator_leaderboard_v5', JSON.stringify(nextLeaderboard));
    } catch {}

    pushStateToServerImmediate({
      inspectionLogs: nextLogs,
      equipments: nextEquipments,
      operatorLeaderboard: nextLeaderboard
    });

    setCategoryQuickSuccessToast(`⚠️ عدم انطباق تجهیز ${eq.code} با موفقیت ثبت شد${autoWoCode ? ` و دستورکار ${autoWoCode} صادر گردید.` : '.'}`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 5000);
  };

  // ویرایش کد تجهیز (مورد اول کاربر)
  const handleSaveEquipmentCode = (eqId: string) => {
    const trimmed = editingEquipmentCodeValue.trim().toUpperCase();
    if (!trimmed) {
      alert('لطفاً کد تجهیز را وارد نمایید.');
      return;
    }
    setEquipments(prev => prev.map(eq => {
      if (eq.id === eqId) {
        return { ...eq, code: trimmed };
      }
      return eq;
    }));
    setEditingEquipmentCodeId(null);
    setCategoryQuickSuccessToast(`✓ کد تجهیز به «${trimmed}» با موفقیت به‌روزرسانی شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
  };

  // پیشوند شناسه کد بر اساس نام دسته
  const getCategoryPrefix = (catName: string, existingList: EquipmentItem[]): string => {
    for (const eq of existingList) {
      const match = eq.code.match(/^([A-Za-z]+)/);
      if (match && match[1]) {
        return match[1].toUpperCase();
      }
    }
    if (catName.includes('تورنوس')) return 'TUTN';
    if (catName.includes('تراش')) return 'TR';
    if (catName.includes('فرز')) return 'FR';
    if (catName.includes('سینتک')) return 'SYN';
    if (catName.includes('مایر')) return 'MY';
    if (catName.includes('استار')) return 'ST';
    if (catName.includes('متفرقه') || catName.includes('پرس')) return 'MSC';
    if (catName.includes('دریل')) return 'DR';
    if (catName.includes('سنگ')) return 'GR';
    if (catName.includes('اره')) return 'SAW';
    if (catName.includes('جوش')) return 'WLD';
    const enMatch = catName.match(/[A-Za-z]+/);
    if (enMatch && enMatch[0]) return enMatch[0].toUpperCase().slice(0, 4);
    return 'EQ';
  };

  // مدیریت دسته‌بندی تجهیزات با اعمال کامل و فوری به لیست تجهیزات (مورد دوم کاربر)
  const handleCategoryDelete = async (catId: string) => {
    if (checklistCategories.length <= 1) {
      alert('حداقل یک دسته‌بندی باید در سامانه باقی بماند.');
      return;
    }
    const catToDelete = checklistCategories.find(c => c.id === catId);
    if (!catToDelete) return;

    const nowTs = Date.now();
    const nextCats = checklistCategories.filter(c => c.id !== catId);
    const nextEqs = equipments.filter(eq => eq.category !== catToDelete.name);

    setChecklistCategories(nextCats);
    setEquipments(nextEqs);
    if (selectedCategoryForModal?.id === catId || selectedCategoryForModal?.name === catToDelete.name) {
      setSelectedCategoryForModal(null);
    }

    try {
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCats));
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEqs));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch {}

    await pushStateToServerImmediate({
      checklistCategories: nextCats,
      equipments: nextEqs,
      _updatedAt: nowTs
    });
  };

  const handleCategorySaveEdit = async () => {
    if (!editingCatId || !editingCatName.trim()) return;
    const targetCat = checklistCategories.find(c => c.id === editingCatId);
    if (!targetCat) return;

    const oldName = targetCat.name;
    const newName = editingCatName.trim();
    const newCount = Math.max(0, Number(editingCatCount) || 0);
    const nowTs = Date.now();

    // تجهیزات فعلی این دسته
    const existingInCat = equipments.filter(eq => eq.category === oldName);
    const currentCount = existingInCat.length;

    let updatedEquipments = [...equipments];

    // اگر نام دسته تغییر کرده، دسته تمام تجهیزات آن را نیز تغییر دهیم
    if (oldName !== newName) {
      updatedEquipments = updatedEquipments.map(eq =>
        eq.category === oldName ? { ...eq, category: newName, updatedAt: nowTs } : eq
      );
    }

    if (newCount > currentCount) {
      const diff = newCount - currentCount;
      const prefix = getCategoryPrefix(newName, existingInCat);

      const existingNumbers = updatedEquipments
        .map(eq => {
          const match = eq.code.match(new RegExp(`^${prefix}(\\d+)$`, 'i'));
          return match ? parseInt(match[1], 10) : null;
        })
        .filter((n): n is number => n !== null && !isNaN(n));

      let nextNum = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
      const defaultOp = (operatorLeaderboard[0]?.name || 'اپراتور');
      const defaultHall = existingInCat[0]?.hall || FACTORY_LOCATIONS[0] || 'سالن ۱';

      const newItems: EquipmentItem[] = [];
      for (let i = 0; i < diff; i++) {
        const numStr = String(nextNum).padStart(2, '0');
        const code = `${prefix}${numStr}`;
        nextNum++;

        newItems.push({
          id: `eq-${nowTs}-${Math.random().toString(36).substring(2, 7)}-${i}`,
          code: code,
          name: `${newName} شماره ${numStr}`,
          category: newName,
          hall: defaultHall,
          status: 'سالم',
          lastInspectionDate: '1405/08/03',
          inspector: defaultOp,
          criticalChecks: ['فشار روغن گیج', 'تمیزی بدنه و اطراف', 'سیستم خنک‌کاری'],
          updatedAt: nowTs
        });
      }

      updatedEquipments = [...updatedEquipments, ...newItems];
    } else if (newCount < currentCount) {
      const excessCount = currentCount - newCount;
      const idsToRemove = new Set(existingInCat.slice(-excessCount).map(e => e.id));
      updatedEquipments = updatedEquipments.filter(eq => !idsToRemove.has(eq.id));
    }

    const updatedCategories = checklistCategories.map(c => {
      if (c.id !== editingCatId) return c;
      return { ...c, name: newName, equipmentCount: newCount, updatedAt: nowTs };
    });

    setEquipments(updatedEquipments);
    setChecklistCategories(updatedCategories);

    if (selectedCategoryForModal && (selectedCategoryForModal.id === editingCatId || selectedCategoryForModal.name === oldName)) {
      setSelectedCategoryForModal({
        ...selectedCategoryForModal,
        id: editingCatId,
        name: newName,
        equipmentCount: newCount,
        updatedAt: nowTs
      });
    }

    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(updatedEquipments));
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(updatedCategories));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch {}

    await pushStateToServerImmediate({
      equipments: updatedEquipments,
      checklistCategories: updatedCategories,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`✓ دسته «${newName}» با موفقیت با ${toFaDigits(newCount)} تجهیز ذخیره و به سامانه اضافه شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);

    setEditingCatId(null);
  };

  // ذخیره ویرایش اختصاصی نام و عکس پس‌زمینه دسته با ذخیره و همگام‌سازی بلادرنگ
  const handleSaveCategoryQuickEdit = async () => {
    if (!categoryToQuickEdit || !quickEditCatName.trim()) return;
    const oldName = categoryToQuickEdit.name;
    const newName = quickEditCatName.trim();
    let newImg = quickEditCatImage.trim() || undefined;

    // فشرده‌سازی خودکار تصویر در صورت بالا بودن حجم جهت ممانعت از پر شدن حافظه localStorage
    if (newImg && newImg.startsWith('data:image') && newImg.length > 35000) {
      newImg = await compressImageDataUrl(newImg, 480, 0.72);
    }

    const nowTs = Date.now();

    // ذخیره دائمی و ضد پاک‌شدن تصویر در استور مستقل تصاویر
    try {
      const photoStore = JSON.parse(localStorage.getItem('portal_category_persistent_photos_v1') || '{}');
      if (newImg) {
        photoStore[newName] = newImg;
        photoStore[oldName] = newImg;
        photoStore[categoryToQuickEdit.id] = newImg;
      } else {
        delete photoStore[newName];
        delete photoStore[oldName];
        delete photoStore[categoryToQuickEdit.id];
      }
      localStorage.setItem('portal_category_persistent_photos_v1', JSON.stringify(photoStore));
    } catch (e) {
      console.warn('Persistent photo store write error:', e);
    }

    const updatedCategories = checklistCategories.map(c => {
      if (c.id !== categoryToQuickEdit.id && c.name !== oldName) return c;
      return { ...c, name: newName, image: newImg, updatedAt: nowTs };
    });

    let updatedEquipments = equipments;
    if (oldName !== newName) {
      updatedEquipments = equipments.map(eq =>
        eq.category === oldName ? { ...eq, category: newName as any, updatedAt: nowTs } : eq
      );
    }

    setChecklistCategories(updatedCategories);
    if (oldName !== newName) {
      setEquipments(updatedEquipments);
    }

    if (selectedCategoryForModal && (selectedCategoryForModal.id === categoryToQuickEdit.id || selectedCategoryForModal.name === oldName)) {
      setSelectedCategoryForModal(prev => prev ? { ...prev, name: newName, image: newImg, updatedAt: nowTs } : null);
    }

    if (activeMainCategory && (activeMainCategory.id === categoryToQuickEdit.id || activeMainCategory.name === oldName)) {
      setActiveMainCategory(prev => ({ ...prev, name: newName, image: newImg, updatedAt: nowTs }));
    }

    // ذخیره آنی و قطعی در localStorage
    try {
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(updatedCategories));
      if (oldName !== newName) {
        localStorage.setItem('portal_equipments_v9', JSON.stringify(updatedEquipments));
      }
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }

    // ارسال فوری به دیتابیس کلاود و سرور
    await pushStateToServerImmediate({
      checklistCategories: updatedCategories,
      equipments: updatedEquipments,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`✓ تغییرات نام و عکس پس‌زمینه دسته «${newName}» با موفقیت ذخیره شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);

    setCategoryToQuickEdit(null);
  };

  const handleCategoryAddNew = async () => {
    if (!newCatName.trim()) return;
    const catName = newCatName.trim();
    const count = Math.max(0, Number(newCatCount) || 0);
    const nowTs = Date.now();
    const newCatId = `cat-${nowTs}`;

    const newCat: ChecklistCategory = {
      id: newCatId,
      name: catName,
      equipmentCount: count,
      updatedAt: nowTs
    };

    const nextCats = [...checklistCategories, newCat];
    let nextEquipments = equipments;

    if (count > 0) {
      const prefix = getCategoryPrefix(catName, []);
      const existingNumbers = equipments
        .map(eq => {
          const match = eq.code.match(new RegExp(`^${prefix}(\\d+)$`, 'i'));
          return match ? parseInt(match[1], 10) : null;
        })
        .filter((n): n is number => n !== null && !isNaN(n));

      let nextNum = existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
      const defaultOp = (operatorLeaderboard[0]?.name || 'اپراتور');
      const defaultHall = FACTORY_LOCATIONS[0] || 'سالن ۱';

      const newItems: EquipmentItem[] = [];
      for (let i = 0; i < count; i++) {
        const numStr = String(nextNum).padStart(2, '0');
        const code = `${prefix}${numStr}`;
        nextNum++;

        newItems.push({
          id: `eq-${nowTs}-${Math.random().toString(36).substring(2, 7)}-${i}`,
          code: code,
          name: `${catName} شماره ${numStr}`,
          category: catName,
          hall: defaultHall,
          status: 'سالم',
          lastInspectionDate: '1405/08/03',
          inspector: defaultOp,
          criticalChecks: ['فشار روغن گیج', 'تمیزی بدنه و اطراف', 'سیستم خنک‌کاری'],
          updatedAt: nowTs
        });
      }
      nextEquipments = [...equipments, ...newItems];
    }

    setChecklistCategories(nextCats);
    if (count > 0) setEquipments(nextEquipments);

    try {
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCats));
      if (count > 0) {
        localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      }
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch {}

    await pushStateToServerImmediate({
      checklistCategories: nextCats,
      equipments: nextEquipments,
      _updatedAt: nowTs
    });

    setCategoryQuickSuccessToast(`✓ دسته جدید «${catName}» با ${toFaDigits(count)} تجهیز ایجاد شد.`);
    setTimeout(() => setCategoryQuickSuccessToast(null), 4000);

    setNewCatName('');
    setNewCatCount(0);
    setIsAddingNewCategory(false);
  };

  // افزودن اپراتور جدید همراه با کد پرسنلی
  const handleAddNewOperator = () => {
    if (!newOperatorName.trim()) return;
    const pCode = newOperatorPersonnelCode.trim() || String(Math.floor(1000 + Math.random() * 9000));
    const newOp: ProductionOperator = {
      id: `op-${pCode}-${Date.now()}`,
      name: newOperatorName.trim(),
      personnelCode: pCode,
      netCode: '',
      department: 'تولید',
      inspectionsCount: 0,
      status: 'بدون مشکل',
      performancePct: 100
    };
    setProductionOperators(prev => [newOp, ...prev]);
    setOperatorLeaderboard(prev => [newOp, ...prev]);
    setNewOperatorName('');
    setNewOperatorPersonnelCode('');
    setIsAddOperatorModalOpen(false);
    setChecklistNotice(`✓ اپراتور جدید «${newOp.name}» (کد پرسنلی: ${toFaDigits(pCode)}) با موفقیت اضافه شد.`);
    setTimeout(() => setChecklistNotice(null), 4000);
  };

  // افزودن تجهیز جدید با ذخیره و همگام‌سازی بلادرنگ
  const handleAddNewEquipment = async () => {
    if (!newEqCode.trim() || !newEqName.trim()) {
      alert('لطفاً کد دستگاه و نام دستگاه را وارد کنید.');
      return;
    }
    const cleanCode = newEqCode.trim().toUpperCase();
    // دسته‌ای که کاربر در فرم انتخاب کرده با اولویت مطلق لحاظ می‌شود
    const assignedCategory = newEqCategory;
    const nowTs = Date.now();
    const newEq: EquipmentItem = {
      id: `eq-${nowTs}`,
      code: cleanCode,
      name: newEqName.trim(),
      category: assignedCategory as any,
      hall: newEqHall,
      status: 'سالم',
      lastInspectionDate: getEnDateNow(),
      inspector: '', // خالی می‌ماند تا کاربر خودش دستی ثبت کند
      criticalChecks: ['فشار روغن', 'تمیزی بدنه و اطراف', 'سیستم خنک‌کاری'],
      updatedAt: nowTs
    };

    const nextEquipments = [newEq, ...equipments];
    const nextCategories = checklistCategories.map(c => {
      if (c.name === assignedCategory) {
        return { ...c, equipmentCount: c.equipmentCount + 1, updatedAt: nowTs };
      }
      return c;
    });

    setEquipments(nextEquipments);
    setChecklistCategories(nextCategories);

    try {
      localStorage.setItem('portal_equipments_v9', JSON.stringify(nextEquipments));
      localStorage.setItem('portal_exact9_categories_v9_data', JSON.stringify(nextCategories));
      localStorage.setItem('portal_central_last_write_ts', String(nowTs));
    } catch {}

    await pushStateToServerImmediate({
      equipments: nextEquipments,
      checklistCategories: nextCategories,
      _updatedAt: nowTs
    });

    setNewEqCode('');
    setNewEqName('');
    setIsAddEquipmentModalOpen(false);
    setChecklistNotice(`✓ تجهیز ${newEq.code} (${newEq.name}) با موفقیت به دسته «${assignedCategory}» افزوده شد.`);
    setTimeout(() => setChecklistNotice(null), 4000);
  };

  // لیست ۲۵۲ تجهیز کارخانه برگرفته از دیتابیس نگهداری پیشگیرانه PM
  const allPmEquipments = useMemo(() => {
    try {
      const s = localStorage.getItem('pm_studio_equipments_v13');
      return s ? JSON.parse(s) : defaultPlantEquipment;
    } catch {
      return defaultPlantEquipment;
    }
  }, [isPmEquipmentPickerOpen]);

  // فیلتر هوشمند تجهیزات PM برای تخصیص چندتایی به دسته‌های چک‌لیست
  const filteredPmEquipments = useMemo(() => {
    return allPmEquipments.filter((item: any) => {
      const codeUpper = (item.id || '').toUpperCase();

      // ۱. فیلتر گروهی
      if (pmPickerGroupFilter === 'TULT') {
        if (!codeUpper.startsWith('TULT') && !codeUpper.startsWith('TUTL')) return false;
      } else if (pmPickerGroupFilter === 'TUTN') {
        if (!codeUpper.startsWith('TUTN')) return false;
      } else if (pmPickerGroupFilter === 'MICN') {
        // فرز CNC (به جز دریل فرزهای دستی MIDR)
        if ((!codeUpper.startsWith('MICN') && !codeUpper.startsWith('FR')) || codeUpper.startsWith('MIDR')) return false;
      } else if (pmPickerGroupFilter === 'MANUAL') {
        // تجهیزات دستی: دریل فرز (MIDR)، دریل دستی (MIMN)، تراش دستی (TUMN)، سندبلاست (SBMU, WBMN)
        const isManual =
          codeUpper.startsWith('TUMN') ||
          codeUpper.startsWith('MIDR') ||
          codeUpper.startsWith('MIMN') ||
          codeUpper.startsWith('SBMU') ||
          codeUpper.startsWith('WBMN') ||
          (item.name && (item.name.includes('دستی') || item.name.includes('دریل'))) ||
          (item.family && (item.family.includes('دستی') || item.family.includes('Manual')));
        if (!isManual) return false;
      } else if (pmPickerGroupFilter === 'TUMA') {
        if (!codeUpper.startsWith('TUMA')) return false;
      } else if (pmPickerGroupFilter === 'SY') {
        if (!codeUpper.startsWith('SY')) return false;
      } else if (pmPickerGroupFilter === 'PR') {
        if (!codeUpper.startsWith('PR')) return false;
      } else if (pmPickerGroupFilter === 'other') {
        if (
          codeUpper.startsWith('TULT') ||
          codeUpper.startsWith('TUTL') ||
          codeUpper.startsWith('TUTN') ||
          codeUpper.startsWith('MICN') ||
          codeUpper.startsWith('TUMA') ||
          codeUpper.startsWith('SY') ||
          codeUpper.startsWith('PR') ||
          codeUpper.startsWith('TUMN') ||
          codeUpper.startsWith('MIDR') ||
          codeUpper.startsWith('MIMN') ||
          codeUpper.startsWith('SBMU') ||
          codeUpper.startsWith('WBMN')
        ) {
          return false;
        }
      }

      // ۲. فیلتر مکان/سالن
      if (pmPickerLocationFilter !== 'all') {
        if (!item.location || !item.location.includes(pmPickerLocationFilter)) {
          return false;
        }
      }

      // ۳. سرچ متنی
      if (pmPickerSearch.trim()) {
        const q = pmPickerSearch.trim().toLowerCase();
        const matchesId = (item.id || '').toLowerCase().includes(q);
        const matchesName = (item.name || '').toLowerCase().includes(q);
        const matchesFamily = (item.family || '').toLowerCase().includes(q);
        const matchesLoc = (item.location || '').toLowerCase().includes(q);
        if (!matchesId && !matchesName && !matchesFamily && !matchesLoc) return false;
      }

      return true;
    });
  }, [allPmEquipments, pmPickerGroupFilter, pmPickerLocationFilter, pmPickerSearch]);

  // تیک زدن همه تجهیزات فیلتر شده PM
  const handleSelectAllFilteredPm = () => {
    const ids = filteredPmEquipments.map((e: any) => e.id);
    setPmPickerSelectedIds(prev => Array.from(new Set([...prev, ...ids])));
  };

  // لغو تیک موارد فیلتر شده PM
  const handleDeselectFilteredPm = () => {
    const filterIdSet = new Set(filteredPmEquipments.map((e: any) => e.id));
    setPmPickerSelectedIds(prev => prev.filter(id => !filterIdSet.has(id)));
  };

  // ثبت و تخصیص قطعی تجهیزات انتخاب شده PM به دسته مشخص چک‌لیست با ذخیره فوری و همگام‌سازی ابری
  const handleBatchAddFromPm = () => {
    if (pmPickerSelectedIds.length === 0) {
      alert('لطفاً حداقل یک تجهیز را با تیک زدن انتخاب کنید.');
      return;
    }
    if (!pmPickerTargetCategory) {
      alert('لطفاً دسته مقصد در چک‌لیست را مشخص فرمایید.');
      return;
    }

    const selectedPmItems = allPmEquipments.filter((item: any) => pmPickerSelectedIds.includes(item.id));
    const nowTs = Date.now();
    let finalUpdated: EquipmentItem[] = [];

    setEquipments(prev => {
      const existingMap = new Map(prev.map(e => [e.code.toUpperCase(), e]));
      const updated = [...prev];

      selectedPmItems.forEach((item: any) => {
        const codeUpper = (item.id || '').toUpperCase();
        const existing = existingMap.get(codeUpper);

        if (existing) {
          const idx = updated.findIndex(e => e.id === existing.id);
          if (idx !== -1) {
            updated[idx] = {
              ...updated[idx],
              category: pmPickerTargetCategory as any,
              hall: item.location || updated[idx].hall,
              name: item.family && item.family !== item.name ? `${item.name} (${item.family})` : (updated[idx].name || item.name),
              updatedAt: nowTs
            };
          }
        } else {
          updated.push({
            id: `eq-pm-${item.id}-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
            code: item.id,
            name: item.family && item.family !== item.name ? `${item.name} (${item.family})` : item.name,
            category: pmPickerTargetCategory as any,
            hall: item.location || (FACTORY_LOCATIONS[0] || ''),
            status: 'سالم',
            lastInspectionDate: getEnDateNow(),
            inspector: '',
            criticalChecks: ['فشار روغن گیج', 'تمیزی بدنه و اطراف', 'سیستم روانکاری', 'کنترل لقی و صدا'],
            updatedAt: nowTs
          });
        }
      });

      finalUpdated = updated;
      try {
        localStorage.setItem('portal_equipments_v9', JSON.stringify(updated));
        localStorage.setItem('portal_central_last_write_ts', String(nowTs));
      } catch (e) {
        console.warn('LocalStorage save error:', e);
      }
      return updated;
    });

    pushStateToServerImmediate({
      equipments: finalUpdated,
      _updatedAt: nowTs
    });

    setChecklistNotice(`✓ تعداد ${toFaDigits(selectedPmItems.length)} تجهیز با موفقیت به دسته «${pmPickerTargetCategory}» در چک‌لیست اضافه شدند.`);
    setIsPmEquipmentPickerOpen(false);
    setPmPickerSelectedIds([]);
    setTimeout(() => setChecklistNotice(null), 5000);
  };

  // دانلود فایل نمونه استاندارد اکسل تجهیزات
  const handleDownloadEquipmentTemplate = () => {
    try {
      const templateData = [
        ['کد تجهیز', 'نام دستگاه', 'دسته‌بندی', 'سالن', 'اپراتور', 'وضعیت'],
        ['TUTN01', 'تورنوس سوئیسی Tornos DE-20 #1', 'تورنوس', 'سالن تراشکاری CNC', '', 'سالم'],
        ['TUTN02', 'تورنوس سوئیسی Deco 13 #2', 'تورنوس', 'سالن تراشکاری CNC', '', 'سالم'],
        ['FR01', 'فرز 5 محور DMG Mori #1', 'فرز CNC', 'سالن تولید1', '', 'سالم'],
        ['FR02', 'فرز عمودی هاس Haas VF-2', 'فرز CNC', 'سالن تولید1', '', 'سالم'],
        ['SY01', 'سینتک تایوان Syntec Lathe', 'سینتک', 'نیم طبقه تولید 1(ست)', '', 'نیازمند_سرویس'],
        ['TR01', 'تراش دستی تبریز TN50', 'تراش دستی', 'سالن تولید2', '', 'سالم'],
        ['MA01', 'مایر آلمان Mayer Precision #1', 'مایر', 'سالن تولید1', '', 'سالم'],
        ['ST01', 'استار ژاپن Star SB-16 #1', 'استار', 'سالن تولید3', '', 'سالم']
      ];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(templateData);
      ws['!cols'] = [
        { wch: 15 },
        { wch: 38 },
        { wch: 18 },
        { wch: 24 },
        { wch: 18 },
        { wch: 15 }
      ];
      XLSX.utils.book_append_sheet(wb, ws, 'لیست تجهیزات');
      XLSX.writeFile(wb, 'قالب_استاندارد_لیست_تجهیزات.xlsx');
      setChecklistNotice('✓ فایل نمونه اکسل (قالب_استاندارد_لیست_تجهیزات.xlsx) با موفقیت دانلود شد.');
      setTimeout(() => setChecklistNotice(null), 4000);
    } catch (err: any) {
      console.error(err);
      alert('خطا در دانلود قالب اکسل: ' + (err?.message || 'نامشخص'));
    }
  };

  // خواندن و اعتبارسنجی فایل اکسل بارگذاری‌شده
  const handleEquipmentExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFileName(file.name);
    setExcelParseError(null);
    setExcelParsedEquipments([]);
    setIsExcelParsing(true);

    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) {
          setExcelParseError('فایل اکسل خالی یا غیرقابل خواندن است.');
          setIsExcelParsing(false);
          return;
        }

        const workbook = XLSX.read(buffer, { type: 'array' });
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          setExcelParseError('فایل اکسل انتخاب‌شده هیچ برگه‌ای (Sheet) ندارد.');
          setIsExcelParsing(false);
          return;
        }

        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: '' });

        if (!rows || rows.length < 1) {
          setExcelParseError('فایل اکسل خالی است یا اطلاعاتی ندارد.');
          setIsExcelParsing(false);
          return;
        }

        // جستجوی هوشمند سطر سرستون در میان ۱۰ سطر اول فایل اکسل
        let headerRowIdx = -1;
        let codeIdx = -1;
        let nameIdx = -1;
        let catIdx = -1;
        let hallIdx = -1;
        let statusIdx = -1;

        for (let r = 0; r < Math.min(rows.length, 10); r++) {
          const row = rows[r];
          if (!Array.isArray(row) || row.length === 0) continue;

          const normCells = row.map(c =>
            String(c ?? '')
              .trim()
              .replace(/[\u200B-\u200D\uFEFF]/g, '')
              .replace(/[\u064A]/g, 'ی')
              .replace(/[\u0643]/g, 'ک')
              .toLowerCase()
              .replace(/[\s_\-:]/g, '')
          );

          // ۱. تشخیص ستون ردیف / شماره سطر (باید نادیده گرفته شود تا عدد 1 به عنوان کد برداشته نشود)
          const isRowNumberCol = (idx: number) => {
            const val = normCells[idx];
            if (!val) return false;
            return val === 'ردیف' || val === 'شماره' || val === 'شمارهرstate' || val === 'شمارهرردیف' || val === 'کدرردیف' || val === 'row' || val === 'radif' || val === 'no' || val === '#' || val === 'index';
          };

          // ۲. اولویت اول کد تجهیز: ستونی که صراحتاً «کد تجهیز» یا «کد دستگاه» یا «کد ماشین» است
          let foundExactCode = -1;
          for (let c = 0; c < normCells.length; c++) {
            const cell = normCells[c];
            if (!cell || isRowNumberCol(c)) continue;
            const hasCode = cell.includes('کد') || cell.includes('code') || cell.includes('شناسه');
            const hasEquip = cell.includes('تجهیز') || cell.includes('دستگاه') || cell.includes('ماشین') || cell.includes('اموال') || cell.includes('equipment') || cell.includes('machine') || cell.includes('device');
            if (hasCode && hasEquip) {
              foundExactCode = c;
              break;
            }
          }

          // اولویت دوم کد: هر ستونی که شامل کد، شناسه، پلاک، تگ باشد (و ستون ردیف نباشد)
          let foundFallbackCode = -1;
          if (foundExactCode === -1) {
            for (let c = 0; c < normCells.length; c++) {
              const cell = normCells[c];
              if (!cell || isRowNumberCol(c)) continue;
              if (cell.includes('کد') || cell.includes('code') || cell.includes('شناسه') || cell.includes('tag') || cell.includes('پلاک') || cell.includes('asset')) {
                foundFallbackCode = c;
                break;
              }
            }
          }

          const finalCodeCol = foundExactCode !== -1 ? foundExactCode : foundFallbackCode;

          // ۳. اولویت اول عنوان تجهیز: ستونی که شامل «عنوان تجهیز» یا «نام دستگاه» است
          let foundExactName = -1;
          for (let c = 0; c < normCells.length; c++) {
            if (c === finalCodeCol || isRowNumberCol(c)) continue;
            const cell = normCells[c];
            if (!cell) continue;
            const hasName = cell.includes('عنوان') || cell.includes('نام') || cell.includes('شرح') || cell.includes('مشخصات') || cell.includes('title') || cell.includes('name');
            const hasEquip = cell.includes('تجهیز') || cell.includes('دستگاه') || cell.includes('ماشین') || cell.includes('equipment') || cell.includes('machine');
            if (hasName && hasEquip) {
              foundExactName = c;
              break;
            }
          }

          // اولویت دوم عنوان
          let foundFallbackName = -1;
          if (foundExactName === -1) {
            for (let c = 0; c < normCells.length; c++) {
              if (c === finalCodeCol || isRowNumberCol(c)) continue;
              const cell = normCells[c];
              if (!cell) continue;
              if (cell.includes('عنوان') || cell.includes('نام') || cell.includes('شرح') || cell.includes('مشخصات') || cell.includes('title') || cell.includes('name') || cell.includes('تجهیز') || cell.includes('دستگاه')) {
                foundFallbackName = c;
                break;
              }
            }
          }

          const finalNameCol = foundExactName !== -1 ? foundExactName : foundFallbackName;

          if (finalCodeCol !== -1 || finalNameCol !== -1) {
            headerRowIdx = r;
            codeIdx = finalCodeCol;
            nameIdx = finalNameCol;

            // تشخیص سایر ستون‌ها در همان سطر
            for (let c = 0; c < normCells.length; c++) {
              if (c === codeIdx || c === nameIdx || isRowNumberCol(c)) continue;
              const cell = normCells[c];
              if (catIdx === -1 && (cell.includes('دسته') || cell.includes('گروه') || cell.includes('نوع') || cell.includes('category'))) {
                catIdx = c;
              } else if (hallIdx === -1 && (cell.includes('سالن') || cell.includes('استقرار') || cell.includes('مکان') || cell.includes('محل') || cell.includes('بخش') || cell.includes('location') || cell.includes('hall'))) {
                hallIdx = c;
              } else if (statusIdx === -1 && (cell.includes('وضعیت') || cell.includes('status'))) {
                statusIdx = c;
              }
            }

            break; // سطر سرستون پیدا شد
          }
        }

        // نقطه شروع ردیف‌های داده
        let dataStartRow = 1;
        if (headerRowIdx !== -1) {
          dataStartRow = headerRowIdx + 1;
        } else {
          codeIdx = 1; // معمولاً ستون ۰ ردیف است و ستون ۱ کد تجهیز
          nameIdx = 2;
          dataStartRow = 0;
        }

        // بررسی محافظتی: اگر ستون کد هنوز ستون ردیف (1, 2, 3...) را نشانه رفته است
        if (codeIdx !== -1) {
          let isRowSequence = true;
          let count = 0;
          for (let i = dataStartRow; i < Math.min(rows.length, dataStartRow + 5); i++) {
            const v = String(rows[i]?.[codeIdx] ?? '').trim();
            count++;
            if (v !== String(count)) {
              isRowSequence = false;
              break;
            }
          }
          // اگر ستون انتخاب شده دقیقاً ۱، ۲، ۳... است
          if (isRowSequence && count >= 2) {
            // ستون دیگری در همان سطر هدر که کلمه کد دارد را پیدا کن
            if (headerRowIdx !== -1) {
              const hRow = rows[headerRowIdx] || [];
              for (let c = 0; c < hRow.length; c++) {
                if (c === codeIdx || c === nameIdx) continue;
                const hNorm = String(hRow[c] ?? '').replace(/[\s_\-]/g, '').toLowerCase();
                if (hNorm.includes('کدتجهیز') || hNorm.includes('کددستگاه') || hNorm.includes('کد')) {
                  codeIdx = c;
                  break;
                }
              }
            }
            // اگر در هدر نبود، ستون بعد از ردیف معمولاً کد تجهیز است
            if (isRowSequence && codeIdx === 0 && (rows[dataStartRow]?.length || 0) > 1) {
              codeIdx = 1;
            }
          }
        }

        const parsed: EquipmentItem[] = [];
        for (let i = dataStartRow; i < rows.length; i++) {
          const row = rows[i];
          if (!row || !Array.isArray(row)) continue;

          // بررسی خالی نبودن سطر
          const isRowEmpty = row.every(c => String(c ?? '').trim() === '');
          if (isRowEmpty) continue;

          // خواندن مستقیم کد تجهیز از اکسل (رشته یا عدد)
          let rawCode = '';
          if (codeIdx !== -1 && row[codeIdx] !== undefined && row[codeIdx] !== null) {
            rawCode = String(row[codeIdx]).trim().replace(/[\u200B-\u200D\uFEFF]/g, '');
          }

          // خواندن مستقیم عنوان تجهیز از اکسل
          let rawName = '';
          if (nameIdx !== -1 && row[nameIdx] !== undefined && row[nameIdx] !== null) {
            rawName = String(row[nameIdx]).trim().replace(/[\u200B-\u200D\uFEFF]/g, '');
          }

          // اگر مقدار کد تصادفاً همان شماره ردیف (i - dataStartRow + 1) شد و ستون بعدی کد واقعی دارد
          const currentSeq = String(i - dataStartRow + 1);
          if (rawCode === currentSeq && row[codeIdx + 1] !== undefined && codeIdx + 1 !== nameIdx && codeIdx + 1 !== hallIdx) {
            const nextVal = String(row[codeIdx + 1]).trim().replace(/[\u200B-\u200D\uFEFF]/g, '');
            if (nextVal) {
              rawCode = nextVal;
            }
          }

          if (!rawCode && !rawName) continue;

          const rawCat = catIdx !== -1 && row[catIdx] !== undefined && row[catIdx] !== null
            ? String(row[catIdx]).trim()
            : '';
          const rawHall = hallIdx !== -1 && row[hallIdx] !== undefined && row[hallIdx] !== null
            ? String(row[hallIdx]).trim()
            : '';
          const rawStatus = statusIdx !== -1 && row[statusIdx] !== undefined && row[statusIdx] !== null
            ? String(row[statusIdx]).trim()
            : '';

          // تعیین هوشمند دسته بر اساس ۹ دسته اصلی
          let cat = rawCat;
          const codeUpper = rawCode.trim().toUpperCase();
          const lowerCombined = (rawName + ' ' + rawCode).toLowerCase();

          if (!cat) {
            // تجهیزات دستی، دریل فرز و دستی/Manual منوآل اولویت اول را دارند تا با تراش CNC یا فرز اشتباه نشوند
            if (
              codeUpper.startsWith('TUMN') ||
              codeUpper.startsWith('MIDR') ||
              codeUpper.startsWith('MIMN') ||
              codeUpper.startsWith('SBMU') ||
              codeUpper.startsWith('WBMN') ||
              lowerCombined.includes('دریل') ||
              lowerCombined.includes('دستی') ||
              lowerCombined.includes('manual') ||
              lowerCombined.includes('ابزار')
            ) cat = 'تجهیزات دستی';
            else if (codeUpper.startsWith('TULT') || codeUpper.startsWith('TUTL')) cat = 'تراش';
            else if (codeUpper.startsWith('TUTN') || (lowerCombined.includes('تورنوس') && !lowerCombined.includes('تراش'))) cat = 'تورنوس';
            else if (codeUpper.startsWith('TUMA') || lowerCombined.includes('مایر')) cat = 'مایر';
            else if ((codeUpper.startsWith('MICN') || codeUpper.startsWith('FR') || lowerCombined.includes('فرز')) && !codeUpper.startsWith('MIDR') && !lowerCombined.includes('دریل')) cat = 'فرز';
            else if (codeUpper.startsWith('SY') || lowerCombined.includes('سینتک')) cat = 'سینتک';
            else if (codeUpper.startsWith('ST') || lowerCombined.includes('استار')) cat = 'استار';
            else if (codeUpper.startsWith('PR') || lowerCombined.includes('پرس')) cat = 'پرس';
            else if (codeUpper.startsWith('TR') || lowerCombined.includes('تراش')) cat = 'تراش';
            else cat = ''; // بدون دسته / در انتظار تخصیص به دسته توسط کاربر با سرچ
          } else {
            // اگر ستون دسته در اکسل قید شده باشد
            if (
              cat.includes('دستی') ||
              cat.includes('ابزار') ||
              cat.includes('manual') ||
              codeUpper.startsWith('TUMN') ||
              codeUpper.startsWith('MIDR') ||
              codeUpper.startsWith('MIMN') ||
              codeUpper.startsWith('SBMU') ||
              codeUpper.startsWith('WBMN') ||
              lowerCombined.includes('دریل') ||
              lowerCombined.includes('دستی')
            ) cat = 'تجهیزات دستی';
            else if (codeUpper.startsWith('TULT') || codeUpper.startsWith('TUTL')) cat = 'تراش';
            else if (cat.includes('تورنوس') && !codeUpper.startsWith('TULT') && !codeUpper.startsWith('TUTL')) cat = 'تورنوس';
            else if (cat.includes('فرز') && !codeUpper.startsWith('MIDR') && !lowerCombined.includes('دریل')) cat = 'فرز';
            else if (cat.includes('سینتک')) cat = 'سینتک';
            else if (cat.includes('تراش')) cat = 'تراش';
            else if (cat.includes('مایر')) cat = 'مایر';
            else if (cat.includes('استار')) cat = 'استار';
            else if (cat.includes('پرس')) cat = 'پرس';
            else cat = 'متفرقه';
          }

          // تعیین وضعیت
          let status: 'سالم' | 'نیازمند_سرویس' | 'تعمیر_اضطراری' = 'سالم';
          const sLower = rawStatus.toLowerCase();
          if (sLower.includes('اضطرار') || sLower.includes('urgent') || sLower.includes('خراب')) {
            status = 'تعمیر_اضطراری';
          } else if (sLower.includes('سرویس') || sLower.includes('service') || sLower.includes('نیاز')) {
            status = 'نیازمند_سرویس';
          }

          parsed.push({
            id: `eq-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
            code: rawCode || (rawName ? rawName.slice(0, 10).toUpperCase() : `EQ-${i.toString().padStart(3, '0')}`),
            name: rawName || rawCode || `تجهیز ${rawCode}`,
            category: cat,
            hall: rawHall || 'سالن تولید1',
            status: status,
            lastInspectionDate: getEnDateNow(),
            inspector: '', // اپراتور کاملاً خالی
            criticalChecks: ['فشار روغن گیج', 'وضعیت کلت گیرنده', 'سیستم روانکاری']
          });
        }

        if (parsed.length === 0) {
          setExcelParseError('هیچ ردیف معتبری در فایل اکسل شناسایی نشد. لطفاً از وجود اطلاعات در سطرهای زیرِ عناوین اطمینان حاصل فرمایید.');
          setIsExcelParsing(false);
          return;
        }

        setExcelParsedEquipments(parsed);
        setIsExcelParsing(false);
      } catch (err: any) {
        console.error(err);
        setExcelParseError('خطا در پردازش فایل: ' + (err?.message || 'فرمت یا ساختار فایل با اکسل استاندارد سازگار نیست.'));
        setIsExcelParsing(false);
      }
    };

    reader.onerror = () => {
      setExcelParseError('خطا در خواندن فایل از حافظه دستگاه.');
      setIsExcelParsing(false);
    };

    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  // تأیید و ذخیره تجهیزات خوانده‌شده از اکسل
  const handleConfirmEquipmentImport = () => {
    if (excelParsedEquipments.length === 0) return;

    let finalEquipments: EquipmentItem[] = [];

    if (excelImportMode === 'replace') {
      finalEquipments = [...excelParsedEquipments];
    } else {
      // حالت ادغام (Merge): اگر کد تکراری باشد، مشخصات آن را به‌روزرسانی می‌کنیم، و کدهای جدید را اضافه می‌کنیم
      const excelMap = new Map<string, EquipmentItem>();
      excelParsedEquipments.forEach(item => {
        excelMap.set(item.code.toUpperCase(), item);
      });

      const updatedExisting = equipments.map(eq => {
        const match = excelMap.get(eq.code.toUpperCase());
        if (match) {
          excelMap.delete(eq.code.toUpperCase());
          return {
            ...eq,
            code: match.code, // کد دقیق از اکسل
            name: match.name,
            category: match.category,
            hall: match.hall,
            status: match.status,
            inspector: '' // اپراتور خالی می‌ماند تا کاربر خودش دستی ثبت کند
          };
        }
        return eq;
      });

      const remainingNew = Array.from(excelMap.values());
      finalEquipments = [...remainingNew, ...updatedExisting];
    }

    setEquipments(finalEquipments);

    // به‌روزرسانی تعداد ماشین‌آلات در دسته‌بندی‌ها و اضافه کردن دسته‌های جدید احتمالی
    const categoryCounts: Record<string, number> = {};
    finalEquipments.forEach(eq => {
      if (eq.category) {
        categoryCounts[eq.category] = (categoryCounts[eq.category] || 0) + 1;
      }
    });

    setChecklistCategories(prev => {
      return prev.map(c => ({
        ...c,
        equipmentCount: categoryCounts[c.name] ?? 0
      }));
    });

    setIsEquipmentExcelModalOpen(false);
    setChecklistNotice(`✓ تعداد ${toFaDigits(excelParsedEquipments.length)} دستگاه با موفقیت از فایل اکسل درون‌ریزی شدند.`);
    setTimeout(() => setChecklistNotice(null), 5000);
    setExcelParsedEquipments([]);
    setExcelFileName('');
    setExcelParseError(null);
  };


  return (
    <div className={`min-h-screen text-slate-100 selection:bg-blue-600 selection:text-white relative overflow-x-hidden font-sans transition-all duration-300 ${
      currentView === 'portal'
        ? 'portal-ambient-bg'
        : 'bg-transparent'
    } ${
      systemTheme === 'light' ? 'system-light-mode' : 'system-dark-mode'
    }`} dir="rtl">
      

      {/* Background Ambient Video & Logo - فقط و فقط برای صفحه اول با هر دو تم طبق درخواست کاربر */}
      {currentView === 'portal' && (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 select-none bg-[#030816]">
          {/* ویدیوی سینمایی پس‌زمینه با لوگو در صفحه اول - بهینه‌شده با لود فوق‌سریع و پوستر آنی */}
          <div
            className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-500 ${
              systemTheme === 'light' ? 'opacity-90' : 'opacity-65'
            }`}
            style={{
              backgroundImage: `url('${systemTheme === 'light' ? '/assets/aistudio/bg-silver-light.webp' : '/assets/aistudio/bg-silver-dark.webp'}')`,
            }}
          />

          {/* لایه ملایم تن رنگی و گرادیانت حاشیه‌ها برای صفحه اول */}
          <div className={`absolute inset-0 pointer-events-none transition-all duration-500 ${
            systemTheme === 'light' ? 'bg-transparent opacity-0' : 'bg-[#030816]/35'
          }`} />
          <div className={`absolute inset-0 pointer-events-none transition-all duration-500 ${
            systemTheme === 'light' ? 'bg-transparent opacity-0' : 'bg-gradient-to-t from-[#02050e]/75 via-transparent to-[#02050e]/50'
          }`} />
          <div className={`absolute inset-0 pointer-events-none transition-all duration-500 ${
            systemTheme === 'light' ? 'bg-transparent opacity-0' : 'bg-[radial-gradient(circle_at_center,transparent_40%,rgba(2,5,14,0.6)_100%)]'
          }`} />

          {/* هاله‌های رنگی نور محیطی نوی/سرمه‌ای در صفحه اول */}
          <div className={`absolute -top-40 -left-40 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none transition-opacity duration-500 ${systemTheme === 'light' ? 'opacity-0' : 'animate-pulse'}`}></div>
          <div className={`absolute top-1/4 -right-40 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none transition-opacity duration-500 ${systemTheme === 'light' ? 'opacity-0' : 'opacity-100'}`}></div>
          <div className={`absolute -bottom-40 left-1/3 w-96 h-96 bg-indigo-700/10 rounded-full blur-3xl pointer-events-none transition-opacity duration-500 ${systemTheme === 'light' ? 'opacity-0' : 'opacity-100'}`}></div>
        </div>
      )}

      {/* پس‌زمینه تصاویر اختصاصی ارسالی کاربر برای تمام بخش‌های دیگر با لود فوق‌سریع و تعویض آنی و روان بدون هیچ لگ */}
      {currentView !== 'portal' && (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 select-none bg-[#050608]">
          {/* لایه تم تیره: عکس مشکی نقره‌ای شیک ارسالی کاربر */}
          <div 
            className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-300 ease-in-out section-bg-dark ${
              systemTheme === 'dark' ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            style={{ 
              backgroundImage: `url('/assets/aistudio/bg-silver-dark.webp')`,
              backgroundColor: '#08090d'
            }}
          />
          {/* لایه تم روشن: عکس سفید نقره‌ای شیک ارسالی کاربر */}
          <div 
            className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-300 ease-in-out section-bg-light ${
              systemTheme === 'light' ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            style={{ 
              backgroundImage: `url('/assets/aistudio/bg-silver-light.webp')`,
              backgroundColor: '#f8fafc'
            }}
          />
        </div>
      )}

      {/* Floating Side Toolbar Trigger (فقط در سامانه خدمات فنی فعال است) */}
      {currentView === 'technical' && (
        <button
          onClick={() => setIsSideToolbarOpen(true)}
          className="fixed right-0 top-1/2 -translate-y-1/2 z-40 bg-[#0c1322]/95 border-t border-b border-l border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-white py-3.5 px-2 rounded-l-2xl shadow-2xl backdrop-blur-xl hover:px-2.5 transition-all flex flex-col items-center gap-1.5 group cursor-pointer"
          title="نوار ابزار خدمات فنی"
        >
          <Menu className="w-5 h-5 group-hover:scale-110 text-cyan-400 transition-transform" />
          <span className="text-[11px] font-bold tracking-wider [writing-mode:vertical-rl] rotate-180">
            نوار ابزار خدمات فنی
          </span>
        </button>
      )}

      {currentView === 'checklist' && (
        <button
          onClick={() => setIsChecklistDrawerOpen(true)}
          className="fixed right-0 top-1/2 -translate-y-1/2 z-40 bg-gradient-to-l from-emerald-700 via-teal-600 to-cyan-500 text-white py-3.5 px-2 rounded-l-2xl shadow-2xl shadow-emerald-950/80 border-t border-b border-l border-emerald-400/50 hover:px-3 transition-all flex flex-col items-center gap-1.5 group cursor-pointer"
          title="نوار ابزار چک‌لیست"
        >
          <Menu className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[11px] font-black tracking-wider [writing-mode:vertical-rl] rotate-180">
            نوار ابزار چک‌لیست
          </span>
        </button>
      )}

      {/* Slide-out Hidden Side Toolbar (مخصوص خدمات فنی - مرتب، شیک و هماهنگ با چک‌لیست) */}
      {isSideToolbarOpen && currentView === 'technical' && (
        <>
          <div onClick={() => setIsSideToolbarOpen(false)} className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 transition-opacity" />
          <aside className="fixed top-0 right-0 h-full w-84 max-w-[88vw] z-50 bg-[#0c1322]/95 backdrop-blur-2xl border-l border-slate-800 p-5 flex flex-col justify-between shadow-2xl text-right animate-in slide-in-from-right duration-300 overflow-y-auto">
            <div className="space-y-5">
              {/* هدر نوار ابزار */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-800/80">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-cyan-400">
                    <Wrench className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">نوار ابزار خدمات فنی</h3>
                    <p className="text-[10px] text-slate-400">سامانه دستورکار و نگهداری فنی</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSideToolbarOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* خلاصه شاخص‌های آماری دستورکارها (کارت یک‌دست و مرتب) */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-2.5 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-xs font-bold">شاخص‌های آماری دستورکارها</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setIsSideToolbarOpen(false); setModalType('toolbarReport'); }}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-bold cursor-pointer transition-colors"
                  >
                    <span>نمودار هفتگی</span>
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">کل کارها</span>
                    <strong className="text-sm font-bold text-white font-mono">{toFaDigits(workRequests.length)}</strong>
                    <span className="text-[9px] text-slate-500 block">پرونده</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">درحال اقدام</span>
                    <strong className="text-sm font-bold text-cyan-400 font-mono">{toFaDigits(activeRequests.length)}</strong>
                    <span className="text-[9px] text-slate-500 block">دستورکار</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">بایگانی شده</span>
                    <strong className="text-sm font-bold text-emerald-400 font-mono">{toFaDigits(archivedRequests.length)}</strong>
                    <span className="text-[9px] text-slate-500 block">تکمیل‌شده</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">نرخ پیشرفت</span>
                    <strong className="text-sm font-bold text-slate-200 font-mono">{toFaDigits(completionRate)}٪</strong>
                    <span className="text-[9px] text-slate-500 block">اختتام</span>
                  </div>
                </div>
              </div>

              {/* بخش ۱: بخش‌های اصلی کارخانه */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 px-1 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  بخش‌های اصلی سامانه
                </span>

                {/* بازگشت به صفحه اصلی */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setCurrentView('portal'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Home className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
                    <span>صفحه اصلی پرتال (Home)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* نگهداری پیشگیرانه PM */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setCurrentView('pm'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-slate-400 group-hover:text-purple-400 transition-colors" />
                    <span>نگهداری پیشگیرانه (PM)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* سامانه چک‌لیست و بازرسی */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setCurrentView('checklist'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <ClipboardCheck className="w-4 h-4 text-slate-400 group-hover:text-emerald-400 transition-colors" />
                    <span>سامانه چک‌لیست و بازرسی خط تولید</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* انبار روغن و مخازن */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setCurrentView('oil'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Droplet className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors" />
                    <span>انبار روغن و مخازن خط تولید</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* سالن‌ها و مکان‌های کارخانه */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setIsFactoryLocationsModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
                    <span>مکان‌ها و سالن‌ها (S01 - S08)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>
              </div>

              {/* بخش ۲: ابزارها و گزارش‌های تخصصی */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 px-1 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-slate-500" />
                  ابزارها و گزارش‌های تخصصی
                </span>

                {/* ثبت درخواست کار جدید */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); openNewUnifiedForm(); }}
                  className="w-full p-2.5 rounded-xl bg-cyan-950/40 hover:bg-cyan-950/60 border border-cyan-500/40 text-right flex items-center justify-between text-xs font-bold text-cyan-300 hover:text-cyan-200 transition-all cursor-pointer group shadow-sm"
                >
                  <div className="flex items-center gap-2.5">
                    <Plus className="w-4 h-4 text-cyan-400" />
                    <span>ثبت فوری درخواست کار</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-cyan-400 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* گزارش و نمودار هفتگی */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setModalType('toolbarReport'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <BarChart2 className="w-4 h-4 text-slate-400" />
                    <span>گزارش و نمودار هفتگی کارکرد</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* انبار قطعات یدکی و اقلام مصرفی (یکپارچه با PM) */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); setConsumablesMainTab('inventory'); setModalType('consumablesReport'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Package className="w-4 h-4 text-amber-400" />
                    <span>انبار و لوازم یدکی (یکپارچه)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-950/80 text-amber-300 font-mono border border-amber-500/30">
                      {toFaDigits(unifiedSpareParts.length)} قلم
                    </span>
                    <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                  </div>
                </button>

                {/* دریافت گزارش اکسل جامع کارخانه */}
                <button
                  type="button"
                  onClick={() => { setIsSideToolbarOpen(false); downloadFullSystemBackupExcel(); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <span>دانلود گزارش جامع اکسل (۸ شیت)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* نصب دسکتاپ و وضعیت شبکه */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => { setIsSideToolbarOpen(false); setModalType('installDesktop'); }}
                    className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-center text-[11px] font-bold text-slate-300 hover:text-white transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Monitor className="w-3.5 h-3.5 text-cyan-400" />
                    <span>نسخه دسکتاپ</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setIsSideToolbarOpen(false); setModalType('offlineInfo'); }}
                    className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-center text-[11px] font-bold text-slate-300 hover:text-white transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                    <span>وضعیت اتصال</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 flex items-center justify-between">
              <span>{BRAND_CONFIG.SYSTEM_NAME}</span>
              <span className="font-mono text-cyan-400/80">v5.0</span>
            </div>
          </aside>
        </>
      )}

      

      {/* دکمه شناور بازگشت به پرتال (فقط در صفحات داخلی، در گوشه پایین راست بدون تداخل با نوار ابزارها) */}
      {currentView !== 'portal' && (
        <div className="fixed bottom-5 right-5 z-40 select-none">
          <button
            type="button"
            onClick={() => setCurrentView('portal')}
            className="p-3 rounded-2xl bg-[#0c162e]/90 hover:bg-cyan-600 text-cyan-300 hover:text-white border border-cyan-500/40 shadow-2xl backdrop-blur-md flex items-center gap-2 group transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95 shadow-cyan-950/60"
            title="بازگشت به صفحه اصلی پرتال"
            aria-label="بازگشت به پرتال"
          >
            <Home className="w-5 h-5 text-cyan-300 group-hover:text-white transition-colors" />
            <span className="text-xs font-bold hidden group-hover:inline transition-all duration-200">صفحه اصلی</span>
          </button>
        </div>
      )}

      {/* منوی شناور سه نقطه در سمت چپ پایین صفحه (مورد دوم: دیتابیس ابری، نصب روی دسکتاپ، خورشید و ماه) */}
      <div className="fixed bottom-5 left-5 z-50 select-none">
        {/* منوی بازشونده ابزارها */}
        {isBottomToolsOpen && (
          <>
            <div 
              onClick={() => setIsBottomToolsOpen(false)}
              className="fixed inset-0 z-40 bg-black/25 backdrop-blur-[1px]" 
            />
            <div className="no-invert absolute bottom-14 left-0 z-50 w-64 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-3 shadow-2xl backdrop-blur-2xl space-y-2.5 animate-in slide-in-from-bottom-2 fade-in duration-200 text-right text-slate-100" dir="rtl">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs font-bold text-slate-300">
                <span>ابزارهای سامانه</span>
                <button
                  type="button"
                  onClick={() => setIsBottomToolsOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* ۱. سوئیچر خورشید و ماه (فقط شکلی بدون متن اضافه) */}
              <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">حالت تم:</span>
                <div className="flex items-center bg-slate-900 border border-slate-700/70 rounded-xl p-0.5 gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleSystemTheme('light')}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
                      systemTheme === 'light'
                        ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/40 ring-1 ring-amber-400 scale-105'
                        : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/70'
                    }`}
                    title="نمای روشن (خورشید)"
                    aria-label="نمای روشن"
                  >
                    <Sun className={`w-4 h-4 ${systemTheme === 'light' ? 'text-slate-950 fill-amber-500 stroke-[2.5]' : 'stroke-[2]'}`} />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleSystemTheme('dark')}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
                      systemTheme === 'dark'
                        ? 'bg-gradient-to-tr from-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-600/40 ring-1 ring-indigo-400 scale-105'
                        : 'text-slate-400 hover:text-indigo-400 hover:bg-slate-800/70'
                    }`}
                    title="نمای تیره (ماه)"
                    aria-label="نمای تیره"
                  >
                    <Moon className={`w-4 h-4 ${systemTheme === 'dark' ? 'text-white fill-blue-300 stroke-[2.5]' : 'stroke-[2]'}`} />
                  </button>
                </div>
              </div>

              {/* ۲. وضعیت دیتابیس ابری */}
              <button
                type="button"
                onClick={() => {
                  setSupabaseUrlInput(getStoredSupabaseConfig().url);
                  setSupabaseKeyInput(getStoredSupabaseConfig().anonKey);
                  setSupabaseStatusMsg(null);
                  setModalType('supabaseSettings');
                  setIsBottomToolsOpen(false);
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  supabaseConnected
                    ? 'bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-300 border-emerald-500/40'
                    : 'bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border-amber-500/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400" />
                  <span>دیتابیس ابری Supabase</span>
                </div>
                <span className={`w-2 h-2 rounded-full ${supabaseConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
              </button>

              {/* ۳. نصب روی دسکتاپ */}
              <button
                type="button"
                onClick={() => {
                  setModalType('installDesktop');
                  setIsBottomToolsOpen(false);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer bg-slate-950/60 hover:bg-slate-800/80 text-cyan-300 border-cyan-500/30 hover:border-cyan-400"
              >
                <div className="flex items-center gap-2">
                  <Monitor className="w-4 h-4 text-cyan-400" />
                  <span>نصب روی دسکتاپ (ویندوز)</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
              </button>
            </div>
          </>
        )}

        {/* دکمه ۳ نقطه شکیل */}
        <button
          type="button"
          onClick={() => setIsBottomToolsOpen(!isBottomToolsOpen)}
          className={`no-invert p-3 rounded-2xl border transition-all cursor-pointer shadow-xl flex items-center justify-center ${
            isBottomToolsOpen
              ? 'bg-cyan-600 text-white border-cyan-400 shadow-cyan-900/50 scale-105'
              : 'bg-slate-900/90 text-slate-300 hover:text-white border-slate-700/80 hover:border-cyan-500/50 backdrop-blur-xl hover:scale-105'
          }`}
          title="ابزارهای سامانه (تم، دیتابیس، نصب)"
          aria-label="ابزارهای سامانه"
        >
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Main Content Area */}
      <main className={`mx-auto relative z-10 ${currentView === 'portal' ? 'w-full max-w-[1920px] px-2 sm:px-4 lg:px-6 py-2' : 'max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8'}`}>
        
        {/* ======================================================== */}
        {/* VIEW 1: PORTAL ENTRY - 3D ROTARY CAROUSEL */}
        {/* ======================================================== */}
        {currentView === 'portal' && (
          <div className="min-h-[calc(100vh-76px)] flex flex-col justify-center items-center py-2 animate-in fade-in duration-300 w-full">
            {/* THE 5 GRAPHICAL ENTRY CARDS (ALL 5 IN ONE ROW ON DESKTOP/LAPTOP) */}
            <div className="w-full flex-1 flex flex-col items-center justify-center my-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 xl:gap-3 max-w-[1020px] xl:max-w-[1080px] 2xl:max-w-[1100px] mx-auto w-full py-2">
              
              {/* CARD 1: خدمات فنی و دستور کار (GRAPHICAL) */}
              <div 
                onClick={() => setCurrentView('technical')}
                className="relative overflow-hidden rounded-2xl xl:rounded-3xl p-3 sm:p-3.5 xl:p-3.5 min-h-[390px] xl:min-h-[405px] bg-[#050b18]/15 hover:bg-[#050b18]/25 backdrop-blur-[2.5px] border border-cyan-400/35 hover:border-cyan-300 shadow-2xl hover:shadow-[0_20px_50px_rgba(6,182,212,0.35)] transition-all duration-300 ease-out cursor-pointer group flex flex-col justify-between transform hover:scale-[1.03] hover:-translate-y-2 hover:z-30"
              >
                {/* Subtle Ambient Glow */}
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500 pointer-events-none" />
                <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-blue-600/10 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 xl:w-11 xl:h-11 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 text-white flex items-center justify-center font-bold shadow-xl shadow-cyan-500/30 ring-2 ring-cyan-400/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                      <Wrench className="w-5 h-5 xl:w-5.5 xl:h-5.5 text-white" />
                    </div>
                    <span className="text-[9.5px] xl:text-[10px] font-bold text-cyan-300 bg-cyan-950/40 px-2 py-0.5 rounded-full border border-cyan-500/40 flex items-center gap-1 shadow-lg backdrop-blur-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                      <span>کارتابل فعال</span>
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white group-hover:text-cyan-300 transition-colors flex items-center justify-between">
                      <span className="truncate">خدمات فنی و دستورکار</span>
                      <ChevronLeft className="w-4 h-4 text-cyan-400 transform group-hover:-translate-x-1 transition-transform shrink-0" />
                    </h3>
                  </div>

                  {/* Graphical Preview Card */}
                  <div className="rounded-xl border border-cyan-500/20 bg-black/15 backdrop-blur-[2px] p-2.5 space-y-2">
                    {/* Visual Progress / Activity Meter */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-cyan-300 font-bold flex items-center gap-1">
                          <Activity className="w-3 h-3 text-cyan-400" />
                          <span>توزیع پرونده‌ها</span>
                        </span>
                        <span className="text-[9.5px] text-blue-300 font-mono">
                          {fa(activeRequests.length)} جاری • {fa(archivedRequests.length)} بایگانی
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-black/30 overflow-hidden flex p-0.5 border border-cyan-500/20">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500"
                          style={{
                            width: `${workRequests.length > 0 ? Math.max(15, (activeRequests.length / workRequests.length) * 100) : 50}%`
                          }}
                        />
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 ml-1"
                          style={{
                            width: `${workRequests.length > 0 ? (archivedRequests.length / workRequests.length) * 100 : 50}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>

                </div>

                {/* Tactile Action Button */}
                <div className="pt-2.5 mt-2.5 border-t border-cyan-500/20 relative z-10">
                  <div className="w-full py-2 xl:py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-600/85 via-blue-600/85 to-indigo-600/85 hover:from-cyan-500 hover:to-indigo-500 text-white font-black text-xs flex items-center justify-between shadow-lg shadow-cyan-950/60 group-hover:shadow-cyan-500/30 transition-all">
                    <span>ورود به کارتابل</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180 transform group-hover:-translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

              {/* CARD 2: نگهداری پیشگیرانه PM (GRAPHICAL) */}
              <div 
                onClick={() => setCurrentView('pm')}
                className="relative overflow-hidden rounded-2xl xl:rounded-3xl p-3 sm:p-3.5 xl:p-3.5 min-h-[390px] xl:min-h-[405px] bg-[#0b081a]/15 hover:bg-[#0b081a]/25 backdrop-blur-[2.5px] border border-indigo-400/35 hover:border-indigo-300 shadow-2xl hover:shadow-[0_20px_50px_rgba(129,140,248,0.35)] transition-all duration-300 ease-out cursor-pointer group flex flex-col justify-between transform hover:scale-[1.03] hover:-translate-y-2 hover:z-30"
              >
                {/* Subtle Ambient Glow */}
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-indigo-500/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500 pointer-events-none" />
                <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-purple-600/10 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 xl:w-11 xl:h-11 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white flex items-center justify-center font-bold shadow-xl shadow-purple-500/30 ring-2 ring-purple-400/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                      <ShieldCheck className="w-5 h-5 xl:w-5.5 xl:h-5.5 text-white" />
                    </div>
                    <span className="text-[9.5px] xl:text-[10px] font-bold text-indigo-300 bg-indigo-950/40 px-2 py-0.5 rounded-full border border-indigo-500/40 flex items-center gap-1 shadow-lg backdrop-blur-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                      <span>پیشگیرانه PM</span>
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white group-hover:text-indigo-300 transition-colors flex items-center justify-between">
                      <span className="truncate">نگهداری پیشگیرانه</span>
                      <ChevronLeft className="w-4 h-4 text-indigo-400 transform group-hover:-translate-x-1 transition-transform shrink-0" />
                    </h3>
                  </div>

                  {/* Graphical Preview Card */}
                  <div className="rounded-xl border border-indigo-500/20 bg-black/15 backdrop-blur-[2px] p-2.5 space-y-2">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-indigo-300 font-bold flex items-center gap-1">
                          <CalendarCheck className="w-3 h-3 text-indigo-400" />
                          <span>پوشش زمان‌بندی</span>
                        </span>
                        <span className="text-[9.5px] text-indigo-300 font-mono">
                          {fa(pmSchedules.filter(p => p.status === 'سررسید شده').length)} سررسید • {fa(pmSchedules.filter(p => p.status === 'انجام‌شده').length)} انجام
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-black/30 overflow-hidden flex p-0.5 border border-indigo-500/20">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                          style={{
                            width: `${pmSchedules.length > 0 ? Math.max(20, (pmSchedules.filter(p => p.status === 'انجام‌شده').length / pmSchedules.length) * 100) : 50}%`
                          }}
                        />
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-rose-500 to-amber-500 transition-all duration-500 ml-1"
                          style={{
                            width: `${pmSchedules.length > 0 ? (pmSchedules.filter(p => p.status === 'سررسید شده').length / pmSchedules.length) * 100 : 30}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>

                </div>

                {/* Tactile Action Button */}
                <div className="pt-2.5 mt-2.5 border-t border-indigo-500/20 relative z-10">
                  <div className="w-full py-2 xl:py-2.5 px-3 rounded-xl bg-gradient-to-r from-indigo-600/85 via-purple-600/85 to-pink-600/85 hover:from-indigo-500 hover:to-pink-500 text-white font-black text-xs flex items-center justify-between shadow-lg shadow-indigo-950/60 group-hover:shadow-indigo-500/30 transition-all">
                    <span>ورود به سامانه PM</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180 transform group-hover:-translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

              {/* CARD 3 (CENTER): درخواست کار (WORK REQUEST) */}
              <div 
                onClick={() => setCurrentView('workRequest')}
                className="relative overflow-hidden rounded-2xl xl:rounded-3xl p-3 sm:p-3.5 xl:p-3.5 min-h-[390px] xl:min-h-[405px] bg-[#051121]/15 hover:bg-[#051121]/25 backdrop-blur-[2.5px] border-2 border-cyan-400/50 hover:border-cyan-300 shadow-2xl hover:shadow-[0_20px_50px_rgba(6,182,212,0.4)] transition-all duration-300 ease-out cursor-pointer group flex flex-col justify-between transform hover:scale-[1.03] hover:-translate-y-2 hover:z-30 ring-1 ring-cyan-500/30"
              >
                {/* Subtle Ambient Glow */}
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/15 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500 pointer-events-none" />
                <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-blue-600/15 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 xl:w-11 xl:h-11 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold shadow-xl shadow-cyan-500/30 ring-2 ring-cyan-400/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                      <FileText className="w-5 h-5 xl:w-5.5 xl:h-5.5 text-white" />
                    </div>
                    <span className="text-[9.5px] xl:text-[10px] font-bold text-cyan-300 bg-cyan-950/40 px-2 py-0.5 rounded-full border border-cyan-500/40 flex items-center gap-1 shadow-lg backdrop-blur-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                      <span>درخواست کار</span>
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white group-hover:text-cyan-300 transition-colors flex items-center justify-between">
                      <span className="truncate">درخواست کار</span>
                      <ChevronLeft className="w-4 h-4 text-cyan-400 transform group-hover:-translate-x-1 transition-transform shrink-0" />
                    </h3>
                  </div>

                  {/* Graphical Preview Card */}
                  <div className="rounded-xl border border-cyan-500/20 bg-black/15 backdrop-blur-[2px] p-2.5 space-y-2">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-cyan-300 font-bold flex items-center gap-1">
                          <Activity className="w-3 h-3 text-cyan-400" />
                          <span>فرم چاپی و ارجاع</span>
                        </span>
                        <span className="text-[9.5px] text-cyan-300 font-mono">
                          اعلام عیب و ثبت
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-black/30 overflow-hidden flex p-0.5 border border-cyan-500/20">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400 transition-all duration-500 w-full"
                        />
                      </div>
                    </div>
                  </div>

                </div>

                {/* Tactile Action Button */}
                <div className="pt-2.5 mt-2.5 border-t border-cyan-500/20 relative z-10">
                  <div className="w-full py-2 xl:py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-600/85 via-cyan-600/85 to-teal-600/85 hover:from-blue-500 hover:to-cyan-500 text-white font-black text-xs flex items-center justify-between shadow-lg shadow-cyan-950/60 group-hover:shadow-cyan-500/30 transition-all">
                    <span>ورود به کارتابل</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180 transform group-hover:-translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

              {/* CARD 4: سامانه چک‌لیست و بازرسی تجهیزات خط تولید (GRAPHICAL) */}
              <div 
                onClick={() => setCurrentView('checklist')}
                className="relative overflow-hidden rounded-2xl xl:rounded-3xl p-3 sm:p-3.5 xl:p-3.5 min-h-[390px] xl:min-h-[405px] bg-[#03130d]/15 hover:bg-[#03130d]/25 backdrop-blur-[2.5px] border border-emerald-400/35 hover:border-emerald-300 shadow-2xl hover:shadow-[0_20px_50px_rgba(16,185,129,0.35)] transition-all duration-300 ease-out cursor-pointer group flex flex-col justify-between transform hover:scale-[1.03] hover:-translate-y-2 hover:z-30"
              >
                {/* Subtle Ambient Glow */}
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500 pointer-events-none" />
                <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-teal-600/10 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 xl:w-11 xl:h-11 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-500 text-white flex items-center justify-center font-bold shadow-xl shadow-emerald-500/30 ring-2 ring-emerald-400/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                      <ClipboardCheck className="w-5 h-5 xl:w-5.5 xl:h-5.5 text-white" />
                    </div>
                    <span className="text-[9.5px] xl:text-[10px] font-bold text-emerald-300 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/40 flex items-center gap-1 shadow-lg backdrop-blur-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>بازرسی تجهیزات</span>
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white group-hover:text-emerald-300 transition-colors flex items-center justify-between">
                      <span className="truncate">چک‌لیست و بازرسی</span>
                      <ChevronLeft className="w-4 h-4 text-emerald-400 transform group-hover:-translate-x-1 transition-transform shrink-0" />
                    </h3>
                  </div>

                  {/* Graphical Preview Card */}
                  <div className="rounded-xl border border-emerald-500/20 bg-black/15 backdrop-blur-[2px] p-2.5 space-y-2">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-emerald-300 font-bold flex items-center gap-1">
                          <CheckCircle className="w-3 h-3 text-emerald-400" />
                          <span>شاخص سلامت</span>
                        </span>
                        <span className="text-[9.5px] text-emerald-300 font-mono">
                          {toFaDigits(conformingPercentage)}٪ بدون مشکل
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-black/30 overflow-hidden flex p-0.5 border border-emerald-500/20">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                          style={{
                            width: `${conformingPercentage}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>

                </div>

                {/* Tactile Action Button */}
                <div className="pt-2.5 mt-2.5 border-t border-emerald-500/20 relative z-10">
                  <div className="w-full py-2 xl:py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600/85 via-teal-600/85 to-cyan-600/85 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-xs flex items-center justify-between shadow-lg shadow-emerald-950/60 group-hover:shadow-emerald-500/30 transition-all">
                    <span>ورود به چک‌لیست</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180 transform group-hover:-translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

              {/* CARD 5: انبار روغن و مخازن خط تولید */}
              <div 
                onClick={() => setCurrentView('oil')}
                className="relative overflow-hidden rounded-2xl xl:rounded-3xl p-3 sm:p-3.5 xl:p-3.5 min-h-[390px] xl:min-h-[405px] bg-[#140b03]/15 hover:bg-[#140b03]/25 backdrop-blur-[2.5px] border border-amber-400/35 hover:border-amber-300 shadow-2xl hover:shadow-[0_20px_50px_rgba(245,158,11,0.35)] transition-all duration-300 ease-out cursor-pointer group flex flex-col justify-between transform hover:scale-[1.03] hover:-translate-y-2 hover:z-30"
              >
                {/* Subtle Ambient Glow */}
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none group-hover:bg-amber-500/20 transition-all" />
                <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-yellow-500/5 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-3 relative z-10">
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 xl:w-11 xl:h-11 rounded-xl bg-gradient-to-tr from-amber-600 via-orange-600 to-yellow-500 text-white flex items-center justify-center font-bold shadow-xl shadow-amber-500/30 ring-2 ring-amber-400/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                      <Droplet className="w-5 h-5 xl:w-5.5 xl:h-5.5 text-white" />
                    </div>
                    <span className={`text-[9.5px] xl:text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 shadow-lg backdrop-blur-sm ${
                      lowOilTanksCount > 0 
                        ? 'text-rose-300 bg-rose-950/40 border-rose-500/40' 
                        : 'text-amber-300 bg-amber-950/40 border-amber-500/40'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${lowOilTanksCount > 0 ? 'bg-rose-400 animate-ping' : 'bg-amber-400 animate-pulse'}`}></span>
                      <span>{lowOilTanksCount > 0 ? `${toFaDigits(lowOilTanksCount)} کسری` : 'انبار روغن'}</span>
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white group-hover:text-amber-300 transition-colors flex items-center justify-between">
                      <span className="truncate">انبار روغن و مخازن</span>
                      <ChevronLeft className="w-4 h-4 text-amber-400 transform group-hover:-translate-x-1 transition-transform shrink-0" />
                    </h3>
                  </div>

                  {/* Graphical Preview Card */}
                  <div className="rounded-xl border border-amber-500/20 bg-black/15 backdrop-blur-[2px] p-2.5 space-y-1.5">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-amber-300 font-bold flex items-center gap-1">
                          <Activity className="w-3 h-3 text-amber-400" />
                          <span>سطح ۴ مخزن</span>
                        </span>
                        <span className="text-[9.5px] text-amber-300 font-mono">
                          {fa(totalOilLiters)} / {fa(totalOilCapacity)} L
                        </span>
                      </div>

                      {/* ۴ مخزن مینیاتوری */}
                      <div className="grid grid-cols-4 gap-1 pt-0.5">
                        {oilTanks.map((tank) => {
                          const pct = Math.max(0, Math.min(100, Math.round((tank.currentLiters / tank.capacityLiters) * 100)));
                          const isCrit = pct < 15;
                          const isWarn = pct < 30;
                          return (
                            <div key={tank.id} className="p-0.5 rounded-md bg-black/20 border border-white/10 flex flex-col items-center gap-0.5 text-center">
                              <div className="relative w-5 h-8 rounded bg-black/40 border border-slate-700/60 overflow-hidden flex flex-col justify-end p-0.5">
                                <div 
                                  className={`w-full rounded-xs transition-all duration-500 ${
                                    isCrit ? 'bg-gradient-to-t from-rose-600 to-rose-400' : isWarn ? 'bg-gradient-to-t from-amber-600 to-yellow-400' : 'bg-gradient-to-t from-amber-500 to-orange-400'
                                  }`}
                                  style={{ height: `${pct}%` }}
                                />
                              </div>
                              <span className="text-[8px] font-bold text-white truncate max-w-full">
                                {tank.name.replace('مخزن شماره ', 'M')}
                              </span>
                              <span className={`text-[8px] font-mono font-bold ${isCrit ? 'text-rose-400' : 'text-amber-300'}`}>
                                {toFaDigits(pct)}٪
                              </span>
                            </div>
                          );
                        })}
                      </div>

                      {/* نوار مجموع ظرفیت کل */}
                      <div className="w-full h-1.5 rounded-full bg-black/30 overflow-hidden flex p-0.5 border border-amber-500/20 mt-0.5">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            lowOilTanksCount > 0
                              ? 'bg-gradient-to-r from-rose-500 to-amber-500'
                              : 'bg-gradient-to-r from-amber-500 to-yellow-400'
                          }`}
                          style={{
                            width: `${totalOilCapacity > 0 ? (totalOilLiters / totalOilCapacity) * 100 : 60}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>

                </div>

                {/* Tactile Action Button */}
                <div className="pt-2.5 mt-2.5 border-t border-amber-500/20 relative z-10">
                  <div className="w-full py-2 xl:py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-600/85 via-orange-600/85 to-yellow-600/85 hover:from-amber-500 hover:to-yellow-500 text-white font-black text-xs flex items-center justify-between shadow-lg shadow-amber-950/60 group-hover:shadow-amber-500/30 transition-all">
                    <span>ورود به انبار روغن</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180 transform group-hover:-translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

            </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 2: OIL WAREHOUSE (سامانه مدیریت انبار روغن و مخازن) */}
        {/* ======================================================== */}
        {currentView === 'oil' && (
          <div className="w-full space-y-6 animate-in fade-in duration-300 -mt-2">
            
            {/* نوار ابزار بالای انبار روغن شامل گزارش‌ها، وضعیت همگام‌سازی ابری و ساعت زنده */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              {/* دکمه باز کردن گزارش‌ها و چاپ رسمی */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsOilReportModalOpen(true)}
                  className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#751118] to-[#3b0d12] hover:from-[#8d1820] hover:to-[#4e1117] text-white text-xs font-black shadow-lg shadow-red-950/60 flex items-center gap-2 cursor-pointer transition-all border border-[#a9141b] active:scale-95"
                  title="مشاهده گزارش‌ها و صدور چاپ رسمی A4"
                >
                  <span className="text-base">📊</span>
                  <span>گزارش‌ها و چاپ رسمی</span>
                </button>

                {/* دکمه همگام‌سازی فوری با گوشی و سرور مرکزی کارخانه */}
                <button
                  type="button"
                  onClick={() => {
                    fetchAndApplyCentralState();
                    setChecklistNotice('🔄 در حال دریافت آخرین برداشت‌ها و شارژهای ثبت‌شده از گوشی و سرور...');
                    setTimeout(() => setChecklistNotice(null), 3000);
                  }}
                  className="px-3 py-2.5 rounded-2xl bg-[#11161f] hover:bg-[#1a222e] text-slate-200 hover:text-white border border-[#303844] hover:border-cyan-500/60 text-xs font-bold shadow-md flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                  title="کلیک برای دریافت آنی تراکنش‌های ثبت‌شده در گوشی یا سیستم دیگر"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${centralSyncState === 'syncing' ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">همگام‌سازی زنده</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="متصل به سرور مرکزی"></span>
                </button>
              </div>

              {/* ساعت و تاریخ زنده شمسی */}
              <div className="px-3.5 py-2.5 rounded-2xl bg-[#0d1117]/85 border border-[#303844] text-xs font-bold text-slate-200 shadow-inner flex items-center gap-2">
                <span className="text-amber-400">🕒</span>
                <span className="font-mono">{persianClock}</span>
              </div>
            </div>

            {/* 4 TOP KPI METRICS CARDS IN A ROW */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#171c24] to-[#0d1117] border border-[#303844] space-y-1">
                <div className="text-xs text-[#9aa4b0] font-medium">ظرفیت کل</div>
                <div className="text-xl sm:text-2xl font-black text-white font-mono">{fa(totalOilCapacity)} لیتر</div>
                <div className="text-[11px] text-[#9aa4b0]">۴ مخزن فعال خط</div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#171c24] to-[#0d1117] border border-[#303844] space-y-1">
                <div className="text-xs text-[#9aa4b0] font-medium">موجودی کل فعلی</div>
                <div className="text-xl sm:text-2xl font-black text-white font-mono">{fa(totalOilLiters)} لیتر</div>
                <div className="text-[11px] text-amber-300 font-bold">
                  {totalOilCapacity > 0 ? toFaDigits(((totalOilLiters / totalOilCapacity) * 100).toFixed(1)) : '۰'}٪ کل ظرفیت
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#171c24] to-[#0d1117] border border-[#303844] space-y-1">
                <div className="text-xs text-[#9aa4b0] font-medium">برداشت ثبت‌شده</div>
                <div className="text-xl sm:text-2xl font-black text-rose-400 font-mono">{fa(todayWithdrawTotal)} لیتر</div>
                <div className="text-[11px] text-[#9aa4b0]">مجموع برداشت‌ها</div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#171c24] to-[#0d1117] border border-[#303844] space-y-1">
                <div className="text-xs text-[#9aa4b0] font-medium">ورود و شارژ ثبت‌شده</div>
                <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">{fa(todayEntryTotal)} لیتر</div>
                <div className="text-[11px] text-[#9aa4b0]">مجموع شارژ مخازن</div>
              </div>
            </div>

            {/* 4 ENLARGED REALISTIC CYLINDRICAL OIL TANKS (صفحه‌های مخزن بزرگتر) */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
              {oilTanks.map((tank, idx) => {
                const pct = Math.max(0, Math.min(100, Math.round((tank.currentLiters / tank.capacityLiters) * 100)));
                const isCritical = pct < 15;
                const isWarn = pct < 30;
                const color = tank.colorClass && tank.colorClass.startsWith('#') ? tank.colorClass : '#d88b12';

                return (
                  <div
                    key={tank.id}
                    className="rounded-3xl bg-gradient-to-b from-[#181e28] via-[#12161f] to-[#0c1016] border border-[#323b48] hover:border-amber-500/60 p-6 flex flex-col justify-between space-y-5 shadow-2xl transition-all group"
                  >
                    {/* Tank Head */}
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-base sm:text-lg font-black text-white flex items-center gap-1.5">
                          <span>{tank.name}</span>
                          {isCritical && (
                            <span className="flex items-center gap-0.5 text-rose-400 animate-pulse text-xs" title="موجودی کمتر از ۱۵٪">
                              🚨
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-[#9aa4b0] mt-0.5 font-medium">
                          ظرفیت مخزن: <span className="font-mono text-slate-200 font-bold">{fa(tank.capacityLiters)} لیتر</span>
                        </div>
                      </div>

                      <span className={`px-3 py-1 rounded-full text-[11px] font-black border ${
                        isCritical
                          ? 'bg-[#4b0d13] text-[#ff8c94] border-[#8d2029] animate-pulse'
                          : isWarn
                          ? 'bg-amber-950 text-amber-300 border-amber-600/50'
                          : 'bg-[#2a1519] text-[#ffb9bd] border-[#64232a]'
                      }`}>
                        {isCritical ? 'بحرانی' : isWarn ? 'هشدار' : 'عادی'}
                      </span>
                    </div>

                    {/* Enlarged Cylindrical SVG Visualization with Scale Ruler, Valve and Inside Badge */}
                    <div className="flex flex-col items-center justify-center relative py-2">
                      <div className="w-full h-72 sm:h-80 flex items-center justify-center">
                        <TankSvgVisual tank={tank} index={idx} />
                      </div>
                    </div>

                    {/* Stats Box & Meter */}
                    <div className="space-y-2.5">
                      <div className="p-3.5 rounded-2xl bg-[#11161d] border border-[#303844] flex items-center justify-between text-xs">
                        <div>
                          <div className="text-[11px] text-[#9aa4b0]">موجودی فعلی مخزن</div>
                          <div className="font-mono font-black text-white text-base sm:text-lg mt-0.5">
                            {fa(tank.currentLiters)} لیتر
                          </div>
                        </div>
                        <div className="text-left">
                          <div className="text-[11px] text-[#9aa4b0]">درصد پرشدگی</div>
                          <div className="font-mono font-black text-amber-300 text-base sm:text-lg mt-0.5">
                            ٪{toFaDigits(Number.isInteger((tank.currentLiters / tank.capacityLiters) * 100) ? ((tank.currentLiters / tank.capacityLiters) * 100).toFixed(0) : ((tank.currentLiters / tank.capacityLiters) * 100).toFixed(1))}
                          </div>
                        </div>
                      </div>

                      {/* Linear Meter */}
                      <div className="w-full h-2.5 rounded-full bg-[#2a3038] overflow-hidden p-0.5">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: color
                          }}
                        />
                      </div>
                    </div>

                    {/* Action Buttons: برداشت از مخزن / ورود روغن */}
                    <div className="space-y-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setOilTargetTankId(tank.id);
                          setOilOpAmount('5');
                          setOilOpError(null);
                          setOilModalMode('withdraw');
                        }}
                        className="w-full py-3 px-3 rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all hover:brightness-110 active:scale-95"
                        style={{
                          backgroundColor: color,
                          color: idx === 0 || idx === 3 ? '#0d1117' : '#ffffff'
                        }}
                      >
                        <span className="text-cyan-400 text-sm">💧</span>
                        <span>برداشت از مخزن</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOilTargetTankId(tank.id);
                          setOilOpAmount('100');
                          setOilOpError(null);
                          setOilModalMode('entry');
                        }}
                        className="w-full py-3 px-3 rounded-2xl text-white font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all hover:brightness-110 active:scale-95 bg-gradient-to-r from-[#16834b] to-[#0f5c36]"
                      >
                        <span className="text-sm">＋</span>
                        <span>ورود و شارژ روغن</span>
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>

            {/* BOTTOM SECTION: 5 AMALIAT AKHIR (LEFT) + PAGINATED BISHTARIN MASRAF (RIGHT) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
              
              {/* PANEL 1: ۵ عملیات اخیر (تغییر از ۱۰ به ۵ عملیات) */}
              <div className="rounded-3xl bg-gradient-to-b from-[#171c24] to-[#0d1117] border border-[#303844] p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-base font-black text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>۵ عملیات اخیر</span>
                  </h2>
                  <span className="text-[11px] text-[#9aa4b0]">
                    آخرین تراکنش‌های ثبت‌شده در سیستم
                  </span>
                </div>

                <div className="overflow-x-auto rounded-2xl border border-[#303844]">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-[#11161d] border-b border-[#303844] text-[#9aa4b0]">
                        <th className="py-3 px-3">نوع</th>
                        <th className="py-3 px-3">اپراتور</th>
                        <th className="py-3 px-3">مخزن</th>
                        <th className="py-3 px-3">مقدار</th>
                        <th className="py-3 px-3">زمان</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#303844]/50 bg-[#0d1117]/60">
                      {sortedRecentOilTransactions.slice(0, 5).map((tx, idx) => (
                        <tr key={tx.id || idx} className="hover:bg-[#171c24] transition-colors">
                          <td className="py-3 px-3">
                            {tx.type === 'in' ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400 font-bold">
                                <span>🟢</span> ورود
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-rose-400 font-bold">
                                <span>🔴</span> برداشت
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-white font-medium">
                            {tx.operator || '—'}
                          </td>
                          <td className="py-3 px-3 text-slate-300">
                            {tx.tank_name || '—'}
                          </td>
                          <td className="py-3 px-3 font-mono font-bold text-amber-300">
                            {fa(tx.amount_l)} لیتر
                          </td>
                          <td className="py-3 px-3 font-mono text-[11px] text-[#9aa4b0]">
                            {tx.created_at}
                          </td>
                        </tr>
                      ))}
                      {oilTransactions.length === 0 && (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-[#9aa4b0] text-xs">
                            هنوز عملیاتی ثبت نشده است.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* PANEL 2: بیشترین مصرف (صفحه‌بندی ۵ تایی + نمایش بر اساس تجهیز و نفر) */}
              <div className="rounded-3xl bg-gradient-to-b from-[#171c24] to-[#0d1117] border border-[#303844] p-6 space-y-4 shadow-xl">
                <div className="flex flex-col gap-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h2 className="text-base font-black text-white flex items-center gap-2">
                      <BarChart2 className="w-4 h-4 text-cyan-400" />
                      <span>بیشترین مصرف</span>
                    </h2>

                    {/* سوئیچ نمایش بر اساس تجهیزات یا نفرات */}
                    <div className="flex items-center gap-1 p-1 rounded-xl bg-[#11161d] border border-[#303844] text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          setTopConsumptionMode('equipment');
                          setTopConsumptionPage(1);
                        }}
                        className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                          topConsumptionMode === 'equipment'
                            ? 'bg-gradient-to-r from-blue-700 to-indigo-800 text-white border border-blue-500 shadow-sm'
                            : 'text-[#9aa4b0] hover:text-white'
                        }`}
                      >
                        ⚙️ بر اساس تجهیزات
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTopConsumptionMode('operator');
                          setTopConsumptionPage(1);
                        }}
                        className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                          topConsumptionMode === 'operator'
                            ? 'bg-gradient-to-r from-[#751118] to-[#3b0d12] text-white border border-[#a9141b] shadow-sm'
                            : 'text-[#9aa4b0] hover:text-white'
                        }`}
                      >
                        👤 بر اساس نفرات
                      </button>
                    </div>
                  </div>

                  {/* فیلتر دوره زمانی: کلی | ماهانه | ۳ ماهه | ۶ ماهه | ۱ ساله */}
                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#11161d] border border-[#303844] text-[11px] overflow-x-auto">
                    {(
                      [
                        { id: 'all', label: 'کلی' },
                        { id: 'monthly', label: 'ماهانه' },
                        { id: '3months', label: '۳ ماهه' },
                        { id: '6months', label: '۶ ماهه' },
                        { id: 'yearly', label: '۱ ساله' }
                      ] as const
                    ).map(t => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => {
                          setTopConsumptionPeriod(t.id);
                          setTopConsumptionPage(1);
                        }}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer shrink-0 ${
                          topConsumptionPeriod === t.id
                            ? 'bg-amber-600/30 text-amber-300 border border-amber-500/50'
                            : 'text-[#9aa4b0] hover:text-white'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* فهرست بیشترین مصرف (صفحه‌بندی هر صفحه ۵ مورد) */}
                <div className="space-y-2.5 min-h-[260px]">
                  {currentRankedPageItems.map(([name, liters], itemIdx) => {
                    const absoluteRank = (topConsumptionPage - 1) * 5 + itemIdx + 1;
                    const maxLit = rankedConsumers[0] ? rankedConsumers[0][1] : 1;
                    const pct = Math.min(100, Math.round((liters / (maxLit || 1)) * 100));

                    return (
                      <div
                        key={name}
                        className="p-3 rounded-2xl bg-[#11161d] border border-[#303844] flex items-center justify-between gap-3 hover:border-slate-600 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <span className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-600 to-orange-700 text-white font-mono font-black text-xs flex items-center justify-center shrink-0">
                            {toFaDigits(absoluteRank)}
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-bold text-white truncate flex items-center gap-1.5">
                                <span>{topConsumptionMode === 'equipment' ? '🔧' : '👤'}</span>
                                <span>{name}</span>
                              </span>
                              <span className="font-mono font-black text-amber-300">
                                {fa(liters)} لیتر
                              </span>
                            </div>
                            <div className="w-full h-1.5 rounded-full bg-[#2a3038] mt-1.5 overflow-hidden">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-500"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {currentRankedPageItems.length === 0 && (
                    <div className="py-12 text-center text-[#9aa4b0] text-xs">
                      آماری برای فیلتر انتخابی ثبت نشده است.
                    </div>
                  )}
                </div>

                {/* نوار کوچک صفحه‌بندی بیشترین مصرف */}
                {rankedConsumers.length > 5 && (
                  <div className="pt-3 border-t border-[#303844] flex items-center justify-between text-xs">
                    <button
                      type="button"
                      disabled={topConsumptionPage === 1}
                      onClick={() => setTopConsumptionPage(p => Math.max(1, p - 1))}
                      className="px-3 py-1.5 rounded-xl bg-[#11161d] border border-[#303844] text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1 text-[11px] font-bold transition-all"
                    >
                      <span>‹</span>
                      <span>صفحه قبل</span>
                    </button>

                    <div className="flex items-center gap-1.5 text-[11px]">
                      <span className="text-[#9aa4b0]">صفحه</span>
                      <span className="px-2 py-0.5 rounded-lg bg-amber-950/80 border border-amber-600/40 text-amber-300 font-mono font-bold">
                        {toFaDigits(topConsumptionPage)}
                      </span>
                      <span className="text-[#9aa4b0]">از</span>
                      <span className="font-mono text-slate-300 font-bold">{toFaDigits(topConsumptionTotalPages)}</span>
                      <span className="text-[#9aa4b0] text-[10px] mr-1">({toFaDigits(rankedConsumers.length)} مورد)</span>
                    </div>

                    <button
                      type="button"
                      disabled={topConsumptionPage >= topConsumptionTotalPages}
                      onClick={() => setTopConsumptionPage(p => Math.min(topConsumptionTotalPages, p + 1))}
                      className="px-3 py-1.5 rounded-xl bg-[#11161d] border border-[#303844] text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1 text-[11px] font-bold transition-all"
                    >
                      <span>صفحه بعد</span>
                      <span>›</span>
                    </button>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 3: CHECKLIST & EQUIPMENT INSPECTION (سامانه بازرسی) */}
        {/* ======================================================== */}
        {currentView === 'checklist' && (
          <div className="space-y-7 animate-in fade-in duration-300 -mt-2">
            
            {/* پیام اعلان ثبت بازرسی */}
            {checklistNotice && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-cyan-950 border border-emerald-500/60 shadow-xl flex items-center justify-between animate-in slide-in-from-top-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold text-white">{checklistNotice}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setChecklistNotice(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* اسلایدر مستطیلی افقی دسته‌بندی تجهیزات با قابلیت Drag ماوس (بر اساس کد نمونه کاربر) */}
            <CategoryHorizontalSlider
              categories={checklistCategories}
              equipments={equipments}
              onSelectCategory={(cat) => {
                setActiveMainCategory(cat);
                setSelectedCategoryForModal(cat);
                setCategoryModalSearch('');
                setCategoryModalFilterStatus('all');
              }}
              onEditCategory={(cat) => {
                setCategoryToQuickEdit(cat);
                setQuickEditCatName(cat.name);
                setQuickEditCatImage(cat.image || '');
              }}
              onOpenManageModal={() => setIsCategoryManageModalOpen(true)}
              toFaDigits={toFaDigits}
            />

            {/* BOTTOM 2-COLUMN SECTION: تاریخچه بازرسی‌ها + رتبه‌بندی اپراتورها (مطابق عکس ۱) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* ستون راست: تاریخچه بازرسی‌ها (روند بازرسی‌های اخیر) */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0c1824] via-[#08121c] to-[#040a10] border border-blue-900/50 shadow-2xl flex flex-col justify-between space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
                  <div>
                    <h3 className="text-base font-black text-white flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-emerald-400" />
                      <span>تاریخچه بازرسی‌ها</span>
                    </h3>
                    <p className="text-xs text-blue-300/70 mt-0.5">روند بازرسی‌های اخیر خط تولید (به‌روزرسانی زنده تا امروز)</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setHistoryDateFilter('all');
                      setHistoryFilterResult('all');
                      setSelectedHistoryEquipCode(null);
                      setHistoryEquipmentSearch('');
                      setIsInspectionHistoryModalOpen(true);
                    }}
                    className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors cursor-pointer group"
                  >
                    <span>مشاهده همه ←</span>
                  </button>
                </div>

                {/* Legend + آمار لحظه‌ای قابل کلیک */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 text-[11px] text-slate-400">
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryDateFilter(todayNormalizedDate);
                        setHistoryFilterResult('all');
                        setSelectedHistoryEquipCode(null);
                        setHistoryEquipmentSearch('');
                        setIsInspectionHistoryModalOpen(true);
                      }}
                      title="مشاهده لیست همه بازرسی‌های امروز"
                      className="text-slate-300 hover:text-cyan-300 font-bold cursor-pointer transition-colors"
                    >
                      امروز:
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryDateFilter(todayNormalizedDate);
                        setHistoryFilterResult('conforming');
                        setSelectedHistoryEquipCode(null);
                        setHistoryEquipmentSearch('');
                        setIsInspectionHistoryModalOpen(true);
                      }}
                      title="مشاهده لیست تجهیزات سالم امروز"
                      className="px-2.5 py-0.5 rounded-md bg-emerald-950/70 hover:bg-emerald-900/90 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 font-mono font-bold cursor-pointer transition-all"
                    >
                      {toFaDigits(inspectionTrendSeries[inspectionTrendSeries.length - 1]?.conformingCount || 0)} سالم
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryDateFilter(todayNormalizedDate);
                        setHistoryFilterResult('non_conforming');
                        setSelectedHistoryEquipCode(null);
                        setHistoryEquipmentSearch('');
                        setIsInspectionHistoryModalOpen(true);
                      }}
                      title="مشاهده لیست عدم انطباق‌های امروز"
                      className="px-2.5 py-0.5 rounded-md bg-rose-950/70 hover:bg-rose-900/90 border border-rose-500/40 hover:border-rose-400 text-rose-300 font-mono font-bold cursor-pointer transition-all"
                    >
                      {toFaDigits(inspectionTrendSeries[inspectionTrendSeries.length - 1]?.nonConformingCount || 0)} عدم انطباق
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                      <span className="text-slate-300">تجهیزات بدون مشکل</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                      <span className="text-slate-300">تجهیزات دارای مشکل</span>
                    </div>
                  </div>
                </div>

                {/* نمودار خطی زنده ۸ روز اخیر (بدون مشکل + عدم انطباق‌ها) */}
                {(() => {
                  const maxVal = Math.max(
                    1,
                    ...inspectionTrendSeries.map(d => Math.max(d.conformingCount, d.nonConformingCount))
                  );
                  const yTop = 20;
                  const yBottom = 104;
                  const chartH = yBottom - yTop;
                  const points = inspectionTrendSeries.map((day, idx) => {
                    const x = 32 + idx * ((568 - 32) / Math.max(1, inspectionTrendSeries.length - 1));
                    const yOk = yBottom - (day.conformingCount / maxVal) * chartH;
                    const yIssue = yBottom - (day.nonConformingCount / maxVal) * chartH;
                    return { ...day, idx, x, yOk, yIssue };
                  });

                  const okPath = points
                    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.yOk.toFixed(1)}`)
                    .join(' ');
                  const okAreaPath = `${okPath} L ${points[points.length - 1].x.toFixed(1)} ${yBottom} L ${points[0].x.toFixed(1)} ${yBottom} Z`;
                  const issuePath = points
                    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.yIssue.toFixed(1)}`)
                    .join(' ');
                  const issueAreaPath = `${issuePath} L ${points[points.length - 1].x.toFixed(1)} ${yBottom} L ${points[0].x.toFixed(1)} ${yBottom} Z`;

                  const activeHover =
                    hoveredTrendDayIdx !== null && points[hoveredTrendDayIdx]
                      ? points[hoveredTrendDayIdx]
                      : null;

                  return (
                    <div
                      className="w-full h-48 rounded-2xl bg-slate-950/80 border border-blue-900/30 p-3 flex flex-col justify-between relative overflow-hidden"
                      onMouseLeave={() => setHoveredTrendDayIdx(null)}
                    >
                      {/* Tooltip روز انتخاب‌شده */}
                      {activeHover && (
                        <div className="absolute top-2 left-3 z-10 px-2.5 py-1 rounded-lg bg-slate-900/95 border border-cyan-500/40 shadow-lg text-[10px] flex items-center gap-2.5 pointer-events-none">
                          <span className="font-mono font-bold text-cyan-300">
                            {toFaDigits(activeHover.fullDate)}{activeHover.isToday ? ' (امروز)' : ''}
                          </span>
                          <span className="text-emerald-400 font-bold">
                            سالم: {toFaDigits(activeHover.conformingCount)}
                          </span>
                          <span className="text-rose-400 font-bold">
                            عدم انطباق: {toFaDigits(activeHover.nonConformingCount)}
                          </span>
                        </div>
                      )}

                      <svg className="w-full h-full" viewBox="0 0 600 120" preserveAspectRatio="none">
                        <defs>
                          <linearGradient id="okAreaGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#10b981" stopOpacity="0.22" />
                            <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                          </linearGradient>
                          <linearGradient id="issueAreaGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.22" />
                            <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>

                        {/* Background Grid Lines & Y-Axis Labels */}
                        <line x1="24" y1="20" x2="585" y2="20" stroke="#1e293b" strokeDasharray="4 4" strokeWidth="1" />
                        <line x1="24" y1="48" x2="585" y2="48" stroke="#1e293b" strokeDasharray="4 4" strokeWidth="1" />
                        <line x1="24" y1="76" x2="585" y2="76" stroke="#1e293b" strokeDasharray="4 4" strokeWidth="1" />
                        <line x1="24" y1="104" x2="585" y2="104" stroke="#334155" strokeWidth="1" />

                        <text x="18" y="24" textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                          {toFaDigits(maxVal)}
                        </text>
                        <text x="18" y="65" textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                          {toFaDigits(Math.round(maxVal / 2))}
                        </text>
                        <text x="18" y="106" textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                          ۰
                        </text>

                        {/* Area Fills */}
                        <path d={okAreaPath} fill="url(#okAreaGrad)" />
                        <path d={issueAreaPath} fill="url(#issueAreaGrad)" />

                        {/* Line for Problem-Free Equipment (Emerald) */}
                        <path
                          d={okPath}
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />

                        {/* Line for Non-Conforming Equipment (Rose) */}
                        <path
                          d={issuePath}
                          fill="none"
                          stroke="#f43f5e"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />

                        {/* Interactive Vertical Hover Zones + Dots */}
                        {points.map((pt) => (
                          <g
                            key={pt.idx}
                            onMouseEnter={() => setHoveredTrendDayIdx(pt.idx)}
                            className="cursor-pointer"
                          >
                            <rect x={pt.x - 32} y={0} width={64} height={120} fill="transparent" />
                            {hoveredTrendDayIdx === pt.idx && (
                              <line x1={pt.x} y1={14} x2={pt.x} y2={106} stroke="#38bdf8" strokeDasharray="3 3" strokeWidth="1.2" opacity="0.6" />
                            )}
                            {/* Conforming dot */}
                            <circle
                              cx={pt.x}
                              cy={pt.yOk}
                              r={hoveredTrendDayIdx === pt.idx ? 5.5 : 4}
                              fill="#10b981"
                              stroke="#042f2e"
                              strokeWidth="2"
                            />
                            {/* Non-conforming dot */}
                            <circle
                              cx={pt.x}
                              cy={pt.yIssue}
                              r={hoveredTrendDayIdx === pt.idx ? 5.5 : 4}
                              fill="#f43f5e"
                              stroke="#4c0519"
                              strokeWidth="2"
                            />
                            {/* Count labels on non-zero points */}
                            {pt.conformingCount > 0 && (
                              <text
                                x={pt.x}
                                y={Math.max(12, pt.yOk - 8)}
                                textAnchor="middle"
                                fill="#34d399"
                                fontSize="10"
                                fontWeight="bold"
                              >
                                {toFaDigits(pt.conformingCount)}
                              </text>
                            )}
                            {pt.nonConformingCount > 0 && (
                              <text
                                x={pt.x}
                                y={Math.min(115, pt.yIssue + (pt.yIssue === pt.yOk ? 14 : -8))}
                                textAnchor="middle"
                                fill="#fb7185"
                                fontSize="10"
                                fontWeight="bold"
                              >
                                {toFaDigits(pt.nonConformingCount)}
                              </text>
                            )}
                          </g>
                        ))}
                      </svg>

                      {/* Dates Axis Labels (پویا تا تاریخ امروز) */}
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1.5 border-t border-slate-800/80 px-2">
                        {points.map((pt) => (
                          <button
                            key={pt.fullDate || pt.idx}
                            type="button"
                            onMouseEnter={() => setHoveredTrendDayIdx(pt.idx)}
                            onClick={() => setHoveredTrendDayIdx(pt.idx)}
                            className={`cursor-pointer transition-colors ${
                              pt.isToday
                                ? 'text-emerald-400 font-black'
                                : hoveredTrendDayIdx === pt.idx
                                ? 'text-cyan-300 font-bold'
                                : 'text-slate-400 hover:text-slate-200'
                            }`}
                            title={pt.fullDate}
                          >
                            {toFaDigits(pt.shortLabel)}
                            {pt.isToday ? ' (امروز)' : ''}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })()}

                {/* پیش‌نمایش آخرین بازرسی‌های ثبت‌شده */}
                <div className="space-y-2 pt-1">
                  <div className="text-xs text-blue-300 font-bold flex items-center justify-between">
                    <span>آخرین موارد بررسی‌شده:</span>
                    <span className="text-[10px] text-slate-400 font-mono">{toFaDigits(inspectionLogs.length)} بازرسی ثبت‌شده</span>
                  </div>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {inspectionLogs.slice(0, 3).map((log) => (
                      <div
                        key={log.id}
                        className="p-2.5 rounded-xl bg-slate-950/70 border border-blue-900/30 flex items-center justify-between gap-2 hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${log.result === 'conforming' ? 'bg-emerald-400' : 'bg-rose-500 animate-pulse'}`} />
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-white truncate block">
                              {log.equipmentCode} — {log.equipmentName}
                            </span>
                            <span className="text-[10px] text-slate-400 block truncate">
                              اپراتور: {log.operator} • {log.notes}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {log.photoUrl && (
                            <button
                              type="button"
                              onClick={() => setSelectedPhotoLightbox(log.photoUrl || null)}
                              className="px-2 py-1 rounded-lg bg-red-950/60 border border-red-500/40 text-red-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <Camera className="w-3 h-3" />
                              <span>عکس</span>
                            </button>
                          )}
                          <span className="font-mono text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md">
                            {toFaDigits(log.date)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* ستون چپ: رتبه‌بندی اپراتورها (صفحه‌بندی ۵ تایی) */}
              {(() => {
                const LEADERBOARD_PAGE_SIZE = 5;
                const totalOps = activeOperatorLeaderboard.length;
                const totalPages = Math.max(1, Math.ceil(totalOps / LEADERBOARD_PAGE_SIZE));
                const currentPage = Math.min(Math.max(1, leaderboardPage), totalPages);
                const startIdx = (currentPage - 1) * LEADERBOARD_PAGE_SIZE;
                const pageItems = activeOperatorLeaderboard.slice(startIdx, startIdx + LEADERBOARD_PAGE_SIZE);

                return (
                  <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0c1824] via-[#08121c] to-[#040a10] border border-blue-900/50 shadow-2xl flex flex-col justify-between space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
                      <div>
                        <h3 className="text-base font-black text-white flex items-center gap-2">
                          <span className="text-amber-400 text-lg">🏆</span>
                          <span>رتبه‌بندی اپراتورها</span>
                        </h3>
                        <p className="text-xs text-blue-300/70 mt-0.5">عملکرد بر اساس بازرسی‌های ثبت‌شده (۵ نفر در هر صفحه)</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIsAddOperatorModalOpen(true)}
                          className="px-2.5 py-1 rounded-xl bg-cyan-950/70 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>افزودن اپراتور</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsLeaderboardModalOpen(true)}
                          className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors cursor-pointer group"
                        >
                          <span>مشاهده همه ←</span>
                        </button>
                      </div>
                    </div>

                    {/* جدول رتبه‌بندی اپراتورها (۵ مورد در هر صفحه) */}
                    <div className="overflow-x-auto rounded-2xl border border-blue-900/30">
                      <table className="w-full text-right text-xs">
                        <thead>
                          <tr className="bg-slate-950/90 text-blue-300/80 border-b border-blue-900/40">
                            <th className="py-2.5 px-3 text-center w-10 font-bold">#</th>
                            <th className="py-2.5 px-3 font-bold">اپراتور</th>
                            <th className="py-2.5 px-3 text-center font-bold">بازرسی</th>
                            <th className="py-2.5 px-3 text-center font-bold">وضعیت</th>
                            <th className="py-2.5 px-3 text-center font-bold">عملکرد</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-blue-900/30 bg-slate-950/60">
                          {totalOps === 0 ? (
                            <tr>
                              <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                                هنوز بازرسی توسط اپراتورها ثبت نشده است. پس از ثبت بازرسی تجهیزات، رتبه‌بندی اپراتورهای دارای بازرسی در اینجا نمایش داده می‌شود.
                              </td>
                            </tr>
                          ) : (
                            pageItems.map((op, idx) => {
                              const globalIdx = startIdx + idx;
                              const rankColor =
                                globalIdx === 0 ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400/50' :
                                globalIdx === 1 ? 'bg-slate-300 text-slate-950 ring-2 ring-slate-200/50' :
                                globalIdx === 2 ? 'bg-amber-700 text-white ring-2 ring-amber-600/50' :
                                'bg-slate-800 text-slate-300';

                              return (
                                <tr key={op.id || globalIdx} className="hover:bg-blue-950/40 transition-colors">
                                  {/* # رتبه */}
                                  <td className="py-3 px-3 text-center">
                                    <span className={`w-6 h-6 rounded-full inline-flex items-center justify-center font-mono font-black text-xs ${rankColor}`}>
                                      {toFaDigits(globalIdx + 1)}
                                    </span>
                                  </td>

                                  {/* نام اپراتور */}
                                  <td className="py-3 px-3 font-bold text-white whitespace-nowrap">
                                    {op.name}
                                  </td>

                                  {/* تعداد بازرسی */}
                                  <td className="py-3 px-3 text-center font-mono font-bold text-cyan-300">
                                    {toFaDigits(op.inspectionsCount)}
                                  </td>

                                  {/* برچسب وضعیت سبز یا قرمز */}
                                  <td className="py-3 px-3 text-center whitespace-nowrap">
                                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                      op.status === 'بدون مشکل'
                                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                        : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                                    }`}>
                                      {op.status}
                                    </span>
                                  </td>

                                  {/* نوار عملکرد و درصد */}
                                  <td className="py-3 px-3 text-center min-w-[120px]">
                                    <div className="flex items-center justify-center gap-2">
                                      <span className="font-mono font-bold text-emerald-400 text-xs w-9 text-left">
                                        {toFaDigits(op.performancePct)}٪
                                      </span>
                                      <div className="w-20 h-2 rounded-full bg-slate-900 border border-blue-900/30 overflow-hidden">
                                        <div
                                          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                                          style={{ width: `${op.performancePct}%` }}
                                        />
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>

                    {/* صفحه‌بندی ۵ تایی + میانگین شاخص کیفی زنده */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      {totalOps > LEADERBOARD_PAGE_SIZE ? (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={currentPage <= 1}
                            onClick={() => setLeaderboardPage(Math.max(1, currentPage - 1))}
                            className="px-2.5 py-1 rounded-lg bg-slate-900 border border-blue-900/50 text-[11px] font-bold text-slate-200 hover:bg-blue-950/60 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                          >
                            قبلی
                          </button>
                          <div className="flex items-center gap-1">
                            {Array.from({ length: totalPages }, (_, i) => i + 1)
                              .filter(p => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                              .map((p, idx, arr) => {
                                const prev = arr[idx - 1];
                                return (
                                  <React.Fragment key={p}>
                                    {prev && p - prev > 1 && (
                                      <span className="text-[11px] text-slate-500 px-0.5">…</span>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() => setLeaderboardPage(p)}
                                      className={`w-6 h-6 rounded-lg font-mono text-[11px] font-bold transition-colors cursor-pointer ${
                                        p === currentPage
                                          ? 'bg-cyan-500 text-slate-950 shadow'
                                          : 'bg-slate-900 text-slate-300 border border-blue-900/40 hover:bg-slate-800'
                                      }`}
                                    >
                                      {toFaDigits(p)}
                                    </button>
                                  </React.Fragment>
                                );
                              })}
                          </div>
                          <button
                            type="button"
                            disabled={currentPage >= totalPages}
                            onClick={() => setLeaderboardPage(Math.min(totalPages, currentPage + 1))}
                            className="px-2.5 py-1 rounded-lg bg-slate-900 border border-blue-900/50 text-[11px] font-bold text-slate-200 hover:bg-blue-950/60 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                          >
                            بعدی
                          </button>
                          <span className="text-[10px] text-slate-400 font-mono mr-1">
                            {toFaDigits(startIdx + 1)}–{toFaDigits(Math.min(startIdx + LEADERBOARD_PAGE_SIZE, totalOps))} از {toFaDigits(totalOps)}
                          </span>
                        </div>
                      ) : (
                        <div className="text-[10px] text-slate-400 font-mono">
                          {totalOps > 0 ? `نمایش ${toFaDigits(totalOps)} اپراتور فعال` : ''}
                        </div>
                      )}

                      <div className="text-[11px] text-blue-300/70">
                        میانگین شاخص کیفی خط تولید:{' '}
                        <span className="text-emerald-400 font-bold font-mono">{toFaDigits(conformingPercentage)}٪</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

            </div>

          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 4: TECHNICAL SERVICES (خدمات فنی و دستور کار ۲ در ۱)  */}
        {/* ======================================================== */}
        {currentView === 'technical' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Top KPI Metrics Dashboard (مخفی شده در حالت پیش‌فرض برای بهینه‌سازی و آزادسازی فضای دید کارت‌ها) */}
            {showKpiMetrics && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 animate-in fade-in duration-200">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950/80 via-slate-900 to-blue-900/40 border border-blue-500/30 text-center shadow-lg">
                  <span className="text-[11px] text-blue-300 block mb-1">کل پرونده‌ها</span>
                  <strong className="text-2xl font-black text-white font-mono">{fa(workRequests.length)}</strong>
                  <span className="text-[10px] text-blue-300/60 block mt-1">درخواست و دستور کار</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950/90 via-slate-900 to-cyan-950/60 border border-cyan-500/40 text-center shadow-lg relative overflow-hidden">
                  <div className="absolute top-2 left-2 w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
                  <span className="text-[11px] text-cyan-300 block mb-1">کارهای جاری باز</span>
                  <strong className="text-2xl font-black text-cyan-300 font-mono">{fa(activeRequests.length)}</strong>
                  <span className="text-[10px] text-cyan-400/70 block mt-1">در انتظار اقدام</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 via-slate-900 to-teal-950/60 border border-emerald-500/40 text-center shadow-lg">
                  <span className="text-[11px] text-emerald-300 block mb-1">بایگانی مختومه</span>
                  <strong className="text-2xl font-black text-emerald-300 font-mono">{fa(archivedRequests.length)}</strong>
                  <span className="text-[10px] text-emerald-400/70 block mt-1">انجام شده</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-950/70 via-slate-900 to-pink-950/50 border border-rose-500/40 text-center shadow-lg">
                  <span className="text-[11px] text-rose-300 block mb-1">اولویت ایمنی</span>
                  <strong className="text-2xl font-black text-rose-300 font-mono">{fa(safetyCount)}</strong>
                  <span className="text-[10px] text-rose-400/70 block mt-1">موارد اضطراری</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-purple-950/50 border border-indigo-500/40 text-center shadow-lg">
                  <span className="text-[11px] text-indigo-300 block mb-1">مجموع کارکرد</span>
                  <strong className="text-2xl font-black text-indigo-200 font-mono">{fa(totalHoursLogged)}</strong>
                  <span className="text-[10px] text-indigo-300/70 block mt-1">ساعت ثبت‌شده</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-950/80 via-slate-900 to-cyan-950/60 border border-teal-500/40 text-center shadow-lg">
                  <span className="text-[11px] text-teal-300 block mb-1">نرخ پیشرفت</span>
                  <strong className="text-2xl font-black text-teal-200 font-mono">{fa(completionRate)}٪</strong>
                  <span className="text-[10px] text-teal-300/70 block mt-1">درصد اختتام</span>
                </div>
              </div>
            )}

        {/* Box: خدمات فنی */}
        <div className="glass-panel-navy p-5 rounded-2xl border border-blue-500/40">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src={COMPANY_LOGO}
                alt={BRAND_CONFIG.COMPANY_NAME}
                className="h-12 w-auto object-contain rounded-xl p-1 bg-black/60 border border-cyan-500/40 shadow-md shrink-0"
              />
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-white flex items-center justify-center font-bold shadow-lg shadow-blue-600/30 shrink-0">
                <Wrench className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">خدمات فنی و مهندسی</h2>
                <span className="text-[11px] text-cyan-300/80 block">{BRAND_CONFIG.COMPANY_FULL_NAME}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => { setConsumablesMainTab('inventory'); setModalType('consumablesReport'); }}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-500 hover:from-amber-500 hover:to-orange-400 text-white text-xs sm:text-sm font-bold shrink-0 shadow-lg shadow-amber-600/30 cursor-pointer transition-all"
                title="انبار و مدیریت لوازم یدکی (یکپارچه با نگهداری پیشگیرانه PM)"
              >
                <Package className="w-4 h-4" />
                <span>انبار و لوازم یدکی</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-black/40 border border-amber-300/40 text-amber-200">
                  {toFaDigits(unifiedSpareParts.length)}
                </span>
              </button>

              <button
                onClick={openNewUnifiedForm}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs sm:text-sm font-bold shrink-0 shadow-lg shadow-blue-600/30 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>درخواست کار</span>
              </button>
            </div>
          </div>
        </div>

        {/* Work Requests & Work Orders Table Section */}
        <div id="work-orders-table-section" className="glass-panel-navy p-6 rounded-2xl space-y-4">
          
          {/* اعلان رویدادهای همگام‌سازی و اتصال آفلاین */}
          {syncNotice && (
            <div className={`p-3.5 rounded-2xl border text-xs flex flex-wrap items-center justify-between gap-3 shadow-lg animate-in fade-in slide-in-from-top-2 ${
              syncNotice.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200 shadow-emerald-950/60'
                : syncNotice.type === 'warning'
                ? 'bg-amber-950/90 border-amber-500/50 text-amber-200 shadow-amber-950/60'
                : 'bg-blue-950/90 border-cyan-500/50 text-cyan-200 shadow-blue-950/60'
            }`}>
              <div className="flex items-center gap-2.5">
                {syncNotice.type === 'success' ? (
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                ) : syncNotice.type === 'warning' ? (
                  <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
                ) : (
                  <RefreshCw className="w-5 h-5 text-cyan-400 animate-spin shrink-0" />
                )}
                <span className="font-medium leading-relaxed">{syncNotice.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setSyncNotice(null)}
                className="text-white/60 hover:text-white px-2 py-0.5 rounded text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}
          
          {/* Notification when item gets closed and archived */}
          {archiveNotice && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-cyan-950/60 border border-cyan-500/50 text-white text-xs flex flex-wrap items-center justify-between gap-3 shadow-lg shadow-blue-950/60 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center font-bold">
                  <Archive className="w-4 h-4" />
                </div>
                <div>
                  <strong className="block text-cyan-200">عملیات انتقال به بایگانی:</strong>
                  <span className="text-slate-300 text-[11px]">{archiveNotice}</span>
                </div>
              </div>
              <button
                onClick={() => setMainTableTab('archive')}
                className="text-xs font-bold text-white hover:text-cyan-200 px-3.5 py-1.5 rounded-xl bg-cyan-600/30 border border-cyan-400/50 hover:bg-cyan-600/50 transition-all flex items-center gap-1.5"
              >
                <span>مشاهده در جدول بایگانی</span>
                <ArrowRight className="w-3.5 h-3.5 rotate-180" />
              </button>
            </div>
          )}

          {/* نوار اصلی تب‌ها: فقط نمایش دستورکارهای جاری و بایگانی + دکمه سه‌نقطه برای منوی کشویی */}
          <div className="bg-[#091124] border border-[#1b2b52] rounded-3xl p-3 sm:px-5 flex items-center justify-between shadow-2xl transition-all">
            {/* تب‌های اصلی (تنها المان‌های همیشه نمایان) */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setMainTableTab('active')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                  mainTableTab === 'active'
                    ? 'bg-[#13203c] text-white border border-blue-500/50 shadow-md shadow-blue-950/60'
                    : 'bg-[#0c162d] text-blue-300/70 hover:text-white border border-[#1b2b52]'
                }`}
              >
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>درخواست کارهای جاری (باز)</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#080f20] text-cyan-300 border border-blue-600/30 font-mono">
                  {fa(activeRequests.length)}
                </span>
              </button>

              <button
                onClick={() => setMainTableTab('archive')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                  mainTableTab === 'archive'
                    ? 'bg-[#13203c] text-white border border-blue-500/50 shadow-md shadow-blue-950/60'
                    : 'bg-[#0c162d] text-blue-300/70 hover:text-white border border-[#1b2b52]'
                }`}
              >
                <Archive className="w-4 h-4 text-cyan-400" />
                <span>بایگانی دستورکارها</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#080f20] text-blue-300/80 border border-blue-600/30 font-mono">
                  {fa(archivedRequests.length)}
                </span>
              </button>
            </div>

            {/* دکمه سه نقطه (...) برای باز و بسته شدن منوی کشویی ابزارها، جستجو و فیلترها */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsWorkOrdersMenuOpen(prev => !prev)}
                className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all cursor-pointer relative ${
                  isWorkOrdersMenuOpen
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-400/60 shadow-lg shadow-cyan-950/50 rotate-90 scale-105'
                    : isAnyFilterActive || techSearch.trim()
                    ? 'bg-[#13203c] text-cyan-300 border border-cyan-500/50 hover:bg-[#1a2d54]'
                    : 'bg-[#0c162d] text-blue-300/80 hover:text-white border border-[#1b2b52] hover:border-blue-500/50'
                }`}
                title={isWorkOrdersMenuOpen ? 'بستن منوی کشویی' : 'منوی کشویی ابزارها، جستجو و فیلترها (...)'}
                aria-expanded={isWorkOrdersMenuOpen}
              >
                <MoreHorizontal className="w-5 h-5" />
                
                {/* نشانگر نورانی در صورت فعال بودن جستجو یا هر یک از فیلترها */}
                {(isAnyFilterActive || techSearch.trim()) && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 border-2 border-[#091124] animate-pulse" />
                )}
              </button>
            </div>
          </div>

          {/* منوی کشویی مات سرمه‌ای (شامل جستجو، انتخاب نما، خروجی اکسل و فیلترهای پیشرفته) */}
          {isWorkOrdersMenuOpen && (
            <div className="bg-[#091124]/95 border border-[#1d2d52] rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4 animate-in fade-in slide-in-from-top-2 duration-300 backdrop-blur-md">
              {/* بخش اول منوی کشویی: جستجو + تغییر نما + خروجی اکسل */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#1b2b52]">
                {/* جستجوی زنده */}
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-3.5 h-3.5 text-blue-400 absolute right-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={techSearch}
                    onChange={e => setTechSearch(e.target.value)}
                    placeholder={mainTableTab === 'active' ? 'جستجوی دستورکار، مکان، تکنسین...' : 'جستجوی پرونده بایگانی...'}
                    className="w-full bg-[#0c162d] border border-[#1b2b52] text-slate-100 text-xs rounded-xl pr-9 pl-3 py-2.5 outline-none focus:border-cyan-500 transition-all placeholder:text-blue-300/40"
                  />
                  {techSearch && (
                    <button
                      type="button"
                      onClick={() => setTechSearch('')}
                      className="absolute left-3 top-2.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                      title="پاک کردن متن جستجو"
                    >
                      ✕
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  {/* تغییر حالت نما (کارت‌های سه‌بعدی / جدول) */}
                  <div className="flex items-center p-0.5 rounded-xl bg-[#080f20] border border-[#1b2b52]">
                    <button
                      type="button"
                      onClick={() => setTechDisplayView('3dCards')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                        techDisplayView === '3dCards'
                          ? 'bg-[#13203c] text-cyan-300 shadow-sm border border-blue-600/40 font-bold'
                          : 'text-blue-300/60 hover:text-white'
                      }`}
                      title="نمایش کارت‌های چرخشی ۳ بعدی"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                      <span>کارت‌های سه‌بعدی</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTechDisplayView('table')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                        techDisplayView === 'table'
                          ? 'bg-[#13203c] text-cyan-300 shadow-sm border border-blue-600/40 font-bold'
                          : 'text-blue-300/60 hover:text-white'
                      }`}
                      title="نمایش جدول فشرده"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>جدول</span>
                    </button>
                  </div>

                  {/* خروجی اکسل */}
                  <button
                    type="button"
                    onClick={exportTechnicalOrdersToCsv}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0c162d] hover:bg-[#13203c] text-blue-200 hover:text-white border border-[#1b2b52] text-xs font-medium transition-all cursor-pointer"
                    title="دانلود خروجی کامل در قالب فایل اکسل CSV"
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>خروجی اکسل</span>
                  </button>

                  {/* کلید نمایش یا مخفی‌سازی کارت‌های آماری */}
                  <button
                    type="button"
                    onClick={() => setShowKpiMetrics(prev => !prev)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      showKpiMetrics
                        ? 'bg-cyan-900/60 text-cyan-200 border-cyan-500/40'
                        : 'bg-[#0c162d] hover:bg-[#13203c] text-blue-200 hover:text-white border border-[#1b2b52]'
                    }`}
                    title="نمایش یا عدم نمایش ۶ کارت شاخص‌های کلان"
                  >
                    <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{showKpiMetrics ? 'مخفی‌سازی آمار' : 'کارت‌های آماری'}</span>
                  </button>

                  {/* دکمه بستن منوی کشویی */}
                  <button
                    type="button"
                    onClick={() => setIsWorkOrdersMenuOpen(false)}
                    className="text-xs text-blue-300/70 hover:text-white px-2.5 py-1.5 rounded-xl border border-[#1b2b52] hover:bg-[#13203c] transition-all cursor-pointer"
                    title="بستن منوی کشویی"
                  >
                    بستن ✕
                  </button>
                </div>
              </div>

              {/* بخش دوم منوی کشویی: نوار فیلترهای پیشرفته چندگانه */}
              <div className="flex flex-wrap items-center gap-3 text-xs pt-1">
                {/* فیلتر سالن */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-blue-300/80 font-medium">مکان/سالن:</span>
                  <select
                    value={filterPlace}
                    onChange={e => setFilterPlace(e.target.value)}
                    className="bg-[#0c162d] border border-[#1b2b52] text-blue-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                  >
                    <option value="همه" className="bg-[#0c162d] text-white">همه سالن‌ها</option>
                    {FACTORY_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc} className="bg-[#0c162d] text-white">{loc}</option>
                    ))}
                  </select>
                </div>

                {/* فیلتر اولویت */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-blue-300/80 font-medium">اولویت:</span>
                  <select
                    value={filterPriority}
                    onChange={e => setFilterPriority(e.target.value)}
                    className="bg-[#0c162d] border border-[#1b2b52] text-blue-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                  >
                    <option value="همه" className="bg-[#0c162d] text-white">همه اولویت‌ها</option>
                    <option value="ایمنی (اولویت بالا)" className="bg-[#0c162d] text-amber-300">ایمنی (اولویت بالا)</option>
                    <option value="عادی" className="bg-[#0c162d] text-cyan-200">عادی</option>
                  </select>
                </div>

                {/* فیلتر نوع عملیات */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-blue-300/80 font-medium">عملیات:</span>
                  <select
                    value={filterOpType}
                    onChange={e => setFilterOpType(e.target.value)}
                    className="bg-[#0c162d] border border-[#1b2b52] text-blue-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                  >
                    <option value="همه" className="bg-[#0c162d] text-white">همه زمینه‌ها</option>
                    <option value="مکانیک" className="bg-[#0c162d] text-white">مکانیک</option>
                    <option value="برق صنعتی" className="bg-[#0c162d] text-white">برق صنعتی</option>
                    <option value="تاسیسات" className="bg-[#0c162d] text-white">تاسیسات</option>
                    <option value="عمومی" className="bg-[#0c162d] text-white">عمومی</option>
                  </select>
                </div>

                {/* فیلتر تکنسین */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-blue-300/80 font-medium">تکنسین:</span>
                  <select
                    value={filterTechnician}
                    onChange={e => setFilterTechnician(e.target.value)}
                    className="bg-[#0c162d] border border-[#1b2b52] text-blue-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                  >
                    <option value="همه" className="bg-[#0c162d] text-white">همه تکنسین‌ها</option>
                    {technicians.map((t, idx) => (
                      <option key={idx} value={t} className="bg-[#0c162d] text-white">{t}</option>
                    ))}
                  </select>
                </div>

                {/* مرتب‌سازی */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-blue-300/80 font-medium">ترتیب:</span>
                  <select
                    value={sortBy}
                    onChange={e => setSortBy(e.target.value as 'newest' | 'oldest' | 'duration')}
                    className="bg-[#0c162d] border border-[#1b2b52] text-blue-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-cyan-500 transition-colors cursor-pointer"
                  >
                    <option value="newest" className="bg-[#0c162d] text-white">جدیدترین پرونده‌ها</option>
                    <option value="oldest" className="bg-[#0c162d] text-white">قدیمی‌ترین‌ها</option>
                    <option value="duration" className="bg-[#0c162d] text-white">بیشترین مدت کارکرد</option>
                  </select>
                </div>

                {/* دکمه پاک کردن فیلترها */}
                {isAnyFilterActive && (
                  <button
                    type="button"
                    onClick={resetAllFilters}
                    className="mr-auto px-3 py-1 rounded-xl bg-[#13203c] hover:bg-rose-950/50 text-rose-300 border border-rose-500/30 text-[11px] font-medium transition-all cursor-pointer"
                    title="بازنشانی تمام فیلترها و نمایش همه موارد"
                  >
                    پاک کردن فیلترها ✕
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ------------------------------------------------------------- */}
          {/* TAB 1: ACTIVE REQUESTS (دستورکارهای جاری — کارت‌های سه‌بعدی مداری) */}
          {/* ------------------------------------------------------------- */}
          {mainTableTab === 'active' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>درخواست‌های کار فعال و در دست اقدام</span>
                <span className="text-[11px] text-slate-300 font-medium">
                  نمایش {fa(filterWorkOrderList(activeRequests).length)} از {fa(activeRequests.length)} کار جاری
                </span>
              </div>

              {activeRequests.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-slate-850 border border-dashed border-slate-700/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-slate-400">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-slate-100">جدول درخواست‌های کار خالی است</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                    برای شروع و ثبت کار جدید، روی دکمه «درخواست کار» کلیک نمایید.
                  </p>
                </div>
              ) : filterWorkOrderList(activeRequests).length === 0 ? (
                <div className="p-10 text-center rounded-2xl bg-slate-850 border border-dashed border-slate-700/80 space-y-2">
                  <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="text-sm font-bold text-slate-100">تمامی کارهای باز انجام و به بایگانی منتقل شده‌اند!</h4>
                  <p className="text-xs text-slate-400">
                    برای ثبت کار جدید می‌توانید از دکمه بالای صفحه «درخواست کار» استفاده کنید.
                  </p>
                </div>
              ) : techDisplayView === '3dCards' ? (
                /* لیست چرخشی عمودی ۵ کارتی سه‌بعدی مداری (Vertical 3D Carousel) */
                <VerticalCarousel3D
                  items={filterWorkOrderList(activeRequests)}
                  isArchive={false}
                  flippedCards={flippedCards}
                  toggleCardFlip={toggleCardFlip}
                  onCompleteWorkOrder={openCompleteWorkOrder}
                  formatPersianDateBadge={formatPersianDateBadge}
                  fa={fa}
                  toFaDigits={toFaDigits}
                />
              ) : (
                /* نمای جایگزین جدول فشرده (Table Fallback Mode) */
                <div className="overflow-x-auto rounded-2xl border border-slate-700/80 bg-slate-900/60">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="border-b border-slate-700/80 text-slate-300 bg-slate-800/60">
                        <th className="py-3 px-3">کد درخواست</th>
                        <th className="py-3 px-3">مکان / سالن</th>
                        <th className="py-3 px-3">عنوان کار</th>
                        <th className="py-3 px-3">تکنسین مسئول</th>
                        <th className="py-3 px-3">اولویت</th>
                        <th className="py-3 px-3">وضعیت</th>
                        <th className="py-3 px-3 text-center">اقدام</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {filterWorkOrderList(activeRequests).map((req, i) => (
                        <tr key={i} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-3">
                            <span className="font-mono font-bold text-cyan-300 block">{req.code}</span>
                            <span className="text-[10px] text-slate-400 block">{req.created}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-medium text-slate-200">{req.place}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-semibold text-slate-100 block">{req.title}</span>
                            <span className="text-[10px] text-slate-400 line-clamp-1">{req.description}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-slate-200">{req.technician || 'بدون تکنسین'}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                              {req.priority}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-950/70 text-amber-300 border border-amber-600/40">
                              {req.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => openCompleteWorkOrder(req)}
                              className="bg-cyan-700 hover:bg-cyan-600 text-white text-xs px-3 py-1.5 rounded-xl font-bold transition-all"
                            >
                              ثبت فعالیت
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ------------------------------------------------------------- */}
          {/* TAB 2: ARCHIVED REQUESTS (بایگانی دستورکارها — کارت‌های سه‌بعدی مداری) */}
          {/* ------------------------------------------------------------- */}
          {mainTableTab === 'archive' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>بایگانی پرونده‌ها و کارهای مختومه</span>
                <span className="text-[11px] text-slate-300 font-medium font-mono">
                  نمایش {fa(filterWorkOrderList(archivedRequests).length)} از {fa(archivedRequests.length)} پرونده مختومه
                </span>
              </div>

              {archivedRequests.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-slate-850 border border-dashed border-slate-700/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-slate-400">
                    <Archive className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-slate-100">بایگانی کارهای مختومه خالی است</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                    با ثبت عملیات و بستن هر دستور کار در بخش کارهای جاری، پرونده به این بخش منتقل خواهد شد.
                  </p>
                </div>
              ) : filterWorkOrderList(archivedRequests).length === 0 ? (
                <div className="p-10 text-center rounded-2xl bg-slate-850 border border-dashed border-slate-700/80 space-y-2">
                  <Archive className="w-10 h-10 text-slate-400 mx-auto" />
                  <h4 className="text-sm font-bold text-slate-100">هیچ پرونده‌ای مطابق فیلتر یافت نشد</h4>
                  <p className="text-xs text-slate-400">
                    می‌توانید فیلترها را بازنشانی کنید یا عبارت جستجو را تغییر دهید.
                  </p>
                </div>
              ) : techDisplayView === '3dCards' ? (
                /* لیست چرخشی عمودی ۵ کارتی سه‌بعدی مداری بایگانی (Vertical 3D Carousel) */
                <VerticalCarousel3D
                  items={filterWorkOrderList(archivedRequests)}
                  isArchive={true}
                  flippedCards={flippedCards}
                  toggleCardFlip={toggleCardFlip}
                  onViewRequestDetails={(req) => {
                    setSelectedWorkRequest(req);
                    setModalType('viewRequest');
                  }}
                  onRestoreFromArchive={restoreFromArchive}
                  formatPersianDateBadge={formatPersianDateBadge}
                  fa={fa}
                  toFaDigits={toFaDigits}
                />
              ) : (
                /* نمای جایگزین جدول بایگانی (Table Fallback Mode) */
                <div className="overflow-x-auto rounded-2xl border border-slate-700/80 bg-slate-900/60">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="border-b border-slate-700/80 text-slate-300 bg-slate-800/60">
                        <th className="py-3 px-3">کد درخواست / دستور</th>
                        <th className="py-3 px-3">مکان</th>
                        <th className="py-3 px-3">عنوان کار</th>
                        <th className="py-3 px-3">تکنسین مجری</th>
                        <th className="py-3 px-3">شرح عملیات انجام‌شده</th>
                        <th className="py-3 px-3">تاریخ و زمان</th>
                        <th className="py-3 px-3 text-center">اقدامات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {filterWorkOrderList(archivedRequests).map((req, i) => (
                        <tr key={i} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-3">
                            <span className="font-mono font-bold text-cyan-300 block">{req.code}</span>
                            {req.workOrderCode && (
                              <span className="font-mono text-[10px] text-slate-400 block">{req.workOrderCode}</span>
                            )}
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-medium text-slate-200">{req.place}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-semibold text-slate-100 block">{req.title}</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-slate-200">{req.technician || '—'}</span>
                          </td>
                          <td className="py-3 px-3 max-w-xs">
                            <span className="text-slate-300 text-xs block line-clamp-2 leading-relaxed">
                              {req.actionDetails || '—'}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-slate-400 text-xs block">{req.completedAt || req.created}</span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedWorkRequest(req);
                                  setModalType('viewRequest');
                                }}
                                className="bg-cyan-700 hover:bg-cyan-600 text-white text-xs px-2.5 py-1 rounded-lg font-bold transition-all"
                              >
                                شناسنامه
                              </button>
                              <button
                                type="button"
                                onClick={() => restoreFromArchive(req.code)}
                                className="bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs px-2 py-1 rounded-lg transition-all"
                              >
                                بازگردانی
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Technicians Vertical Accordion Team Panel (تیم تکنسین‌های فنی و پایش آخرین اقدام) */}
        <div id="technicians-team-section" className="bg-[#091124] border border-[#1b2b52] rounded-3xl p-6 space-y-4 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1d2d52]">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2.5">
                <Users className="w-5 h-5 text-cyan-400" />
                <span>تیم تکنسین‌های فنی و پایش آخرین اقدام</span>
              </h3>
              <p className="text-xs text-blue-300/70 mt-0.5">
                برای مشاهده آمار و جزئیات، نشانگر ماوس را روی نام افراد ببرید
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => { setNewTechName(''); setModalType('addTech'); }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-700 hover:bg-cyan-600 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>افزودن تکنسین جدید</span>
              </button>
              <span className="text-xs text-blue-200 bg-[#0c162d] px-3 py-1 rounded-xl border border-blue-600/30 font-mono font-bold">
                {toFaDigits(technicians.length)} تکنسین
              </span>
            </div>
          </div>

          {filterTechnician !== 'همه' && (
            <div className="p-3 rounded-xl bg-[#0c162d] border border-cyan-500/40 text-cyan-200 text-xs flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                <span>فیلتر فعال: نمایش کارهای مربوط به تکنسین <strong>{filterTechnician}</strong></span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setFilterTechnician('همه');
                }}
                className="text-xs text-blue-300 hover:text-white px-2.5 py-1 rounded-lg bg-[#13203c] border border-blue-600/40 font-medium transition-all cursor-pointer"
              >
                حذف فیلتر و نمایش همه ✕
              </button>
            </div>
          )}

          {/* ساختار آکاردئون عمودی تکنسین‌ها */}
          <div className="flex flex-col gap-3 pt-1">
            {technicians.map((name, idx) => {
              const activeCount = workRequests.filter(r => (
                r.technician === name ||
                (Array.isArray(r.coTechnicians) && r.coTechnicians.includes(name)) ||
                (Array.isArray(r.woTechnicians) && r.woTechnicians.some(t => String(t?.name || '').trim() === name))
              ) && r.status !== 'انجام شد').length;
              const isSelected = filterTechnician === name;
              const lastAction = getTechnicianLastActionInfo(name);
              const stats = getTechnicianStats(name);
              const techNames = getTechNames(name);
              const photo = technicianPhotos[name];

              const isExpanded = expandedTech === name;

              return (
                <div
                  key={name || idx}
                  onClick={() => setExpandedTech(prev => prev === name ? null : name)}
                  className={`group relative bg-[#0c162d] border rounded-2xl p-4 cursor-pointer shadow-md transition-all duration-200 ${
                    isExpanded ? 'is-expanded ring-1 ring-blue-500/30' : ''
                  } ${
                    isSelected ? 'border-cyan-500 bg-[#0e1b38] ring-1 ring-cyan-500/40' : 'border-[#1d2d52] hover:border-blue-500/50'
                  }`}
                >
                  {/* بخش همیشه نمایان (Header) */}
                  <div className="flex justify-between items-center h-11">
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-full bg-[#111e3b] border-2 border-blue-500/80 text-white font-bold flex items-center justify-center text-sm shadow-md shadow-blue-500/20 shrink-0 overflow-hidden">
                        {photo ? (
                          <img
                            src={photo}
                            alt={techNames.full}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <span>
                            {techNames.last ? techNames.last.slice(0, 2) : 'تک'}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-white flex items-center gap-2">
                          <span>{techNames.full}</span>
                          {isSelected && (
                            <span className="text-[10px] text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/40 font-medium">
                              فیلتر فعال
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-blue-300/70">
                          {techNames.first ? `تکنسین ${techNames.first} • نگهداری و تعمیرات` : 'تکنسین برق و ابزار دقیق'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {activeCount > 0 ? (
                        <span className="px-3.5 py-1.5 rounded-full text-xs font-medium bg-[#112344] text-cyan-300 border border-blue-500/40 flex items-center gap-1.5">
                          <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                          <span>در حال اقدام ({toFaDigits(activeCount)} جاری)</span>
                        </span>
                      ) : (
                        <span className="px-3.5 py-1.5 rounded-full text-xs font-medium bg-[#0f2a24] text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                          <span>آماده کار (در دسترس)</span>
                        </span>
                      )}

                      {/* دکمه فیلتر کردن کارهای این تکنسین در کارت‌ها */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setFilterTechnician(isSelected ? 'همه' : name);
                        }}
                        className={`text-xs px-2.5 py-1 rounded-lg border transition-colors hidden sm:inline-flex items-center gap-1 cursor-pointer ${
                          isSelected
                            ? 'bg-cyan-900/60 text-cyan-200 border-cyan-500/40'
                            : 'bg-[#13203c] hover:bg-blue-900/40 text-blue-200 border-blue-600/30'
                        }`}
                        title="فیلتر کارهای این تکنسین"
                      >
                        <Filter className="w-3 h-3" />
                        <span>{isSelected ? 'فیلتر شده' : 'فیلتر'}</span>
                      </button>

                      {/* آیکون وضعیت باز/بسته شدن آکاردئون */}
                      <div className="text-blue-400 transition-transform duration-300 group-hover:rotate-180 group-[.is-expanded]:rotate-180">
                        <ChevronDown className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* بخش باز شونده با انیمیشن گرید کاملاً نرم و بدون لگ (Hardware-Accelerated 60FPS Grid Accordion) */}
                  <div className="accordion-grid">
                    <div className="accordion-overflow-wrapper">
                      <div className="pt-3.5 border-t border-[#1d2d52] opacity-0 group-hover:opacity-100 group-[.is-expanded]:opacity-100 transition-opacity duration-300 ease-out grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs items-center">
                        <div>
                          <div className="text-blue-300/70 mb-1">کارهای تکمیل شده:</div>
                          <div className="text-white font-bold font-mono text-sm">{toFaDigits(stats.totalDoneCount)} مورد</div>
                        </div>
                        <div>
                          <div className="text-blue-300/70 mb-1">ساعت کارکرد ثبت‌شده:</div>
                          <div className="text-cyan-300 font-bold font-mono text-sm">{formatTotalTechTime(stats.totalMinutes)}</div>
                        </div>
                        <div>
                          <div className="text-blue-300/70 mb-1">آخرین اقدام ثبت‌شده:</div>
                          <div className="text-slate-200 font-bold truncate max-w-[200px]" title={lastAction?.timeAgoText || 'بدون اقدام ثبت‌شده'}>
                            {lastAction ? lastAction.timeAgoText : 'بدون اقدام ثبت‌شده'}
                          </div>
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSelectedTechnicianProfile(name);
                            }}
                            className="bg-[#13203c] hover:bg-cyan-700 text-blue-200 hover:text-white px-4 py-2 rounded-xl transition-all font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 border border-blue-600/30"
                          >
                            <User className="w-3.5 h-3.5" />
                            <span>مشاهده پرونده</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    )}

      {/* ======================================================== */}
      {/* VIEW 5: PREVENTIVE MAINTENANCE (سامانه جدید PM Studio)     */}
      {/* ======================================================== */}
      {currentView === 'pm' && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-transparent">
          <PMStudio 
            onBackToPortal={() => setCurrentView('portal')} 
            onGoToTechnical={() => setCurrentView('technical')} 
            technicians={technicians}
            technicianPhotos={technicianPhotos}
            systemTheme={systemTheme}
            workRequests={workRequests}
            onAddWorkRequest={(newWR: any) => {
              setWorkRequests(prev => [newWR, ...prev.filter(r => r.code !== newWR.code)]);
              try {
                const saved = localStorage.getItem('technicalServiceWorkRequests');
                const list = saved ? JSON.parse(saved) : [];
                const updated = [newWR, ...list.filter((r: any) => r.code !== newWR.code)];
                localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(updated));
              } catch {}
            }}
            onDeleteTechnician={(deletedName: string) => {
              setTechnicians(prev => {
                const next = prev.filter(t => t !== deletedName);
                try {
                  localStorage.setItem('technicalServiceTechnicians', JSON.stringify(next));
                } catch {}
                return next;
              });
            }}
          />
        </div>
      )}

      {/* ======================================================== */}
      {/* VIEW 6: WORK REQUEST MODULE (درخواست کار و اعلام عیب)    */}
      {/* ======================================================== */}
      {currentView === 'workRequest' && (
        <div className="w-full space-y-6 animate-in fade-in duration-300 -mt-2">
          <WorkRequestModule
            onBackToPortal={() => setCurrentView('portal')}
            equipments={equipments}
            operators={productionOperators}
            technicians={technicians}
            onUpdateOperators={setProductionOperators}
            onUpdateEquipments={setEquipments}
            systemTheme={systemTheme}
            onSyncWithServer={(newReq: any) => {
              const syncWr: WorkRequest = {
                code: newReq.code,
                workOrderCode: newReq.woCode || newReq.workOrderCode || '',
                place: newReq.locationName,
                created: newReq.requestTime,
                title: `${newReq.failureTitle} (${newReq.equipmentName} - ${newReq.equipmentCode})`,
                priority: newReq.priority,
                description: newReq.description,
                status:
                  newReq.status === 'انجام شد' || newReq.status === 'انجام شده'
                    ? 'انجام شد'
                    : newReq.status === 'لغو' || newReq.status === 'لغو شده'
                    ? 'لغو'
                    : newReq.status === 'در حال انجام'
                    ? 'در حال انجام'
                    : newReq.status === 'در انتظار دستور برنامه ریزی'
                    ? 'در انتظار دستور برنامه ریزی'
                    : 'در حال اقدام',
                technician: newReq.technician,
                coTechnicians: Array.isArray(newReq.coTechnicians) ? newReq.coTechnicians : undefined,
                consumables: Array.isArray(newReq.consumables) ? newReq.consumables : undefined,
                partsUsed: newReq.partsUsed,
                durationMinutes: newReq.durationMinutes,
                woStartTime: newReq.woStartTime,
                woEndTime: newReq.woEndTime,
                completedAt: newReq.completedAt,
                actionDetails: newReq.actionDetails,
                source: 'workRequest',
                originCategory: 'workRequest',
                requestType: newReq.requestType,
                equipmentCode: newReq.equipmentCode,
                equipmentName: newReq.equipmentName,
                equipmentFamilyName: newReq.equipmentFamilyName,
                failureTitle: newReq.failureTitle,
                woDate: newReq.woEndDate || newReq.woStartDate || newReq.woTechnicians?.[0]?.endDate || newReq.woTechnicians?.[0]?.startDate || undefined,
                woStartDate: newReq.woStartDate,
                woStartTimeOnly: newReq.woStartTimeOnly,
                woEndDate: newReq.woEndDate,
                woEndTimeOnly: newReq.woEndTimeOnly,
                equipmentDowntimeMinutes: newReq.equipmentDowntimeMinutes,
                downtimeMinutes: newReq.downtimeMinutes,
                woTechnicians: Array.isArray(newReq.woTechnicians) ? newReq.woTechnicians : undefined,
                woActivities: Array.isArray(newReq.woActivities) ? newReq.woActivities : undefined,
                woDelays: Array.isArray(newReq.woDelays) ? newReq.woDelays : undefined,
                isArchivedWorkOrder: Boolean(newReq.isArchivedWorkOrder)
              };
              setWorkRequests(prev => {
                const nextList = [syncWr, ...prev.filter(r => r.code !== syncWr.code)];
                try {
                  localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(nextList));
                } catch {}
                pushStateToServer({ workRequests: nextList });
                return nextList;
              });
            }}
          />
        </div>
      )}

      </main>

      {/* ======================================================== */}
      {/* MODAL / DEDICATED PAGE: صفحه اختصاصی تکنسین و لیست تمام کارهای او */}
      {/* ======================================================== */}
      {selectedTechnicianProfile && (() => {
        const techName = selectedTechnicianProfile;
        const activeCount = workRequests.filter(r => (
          r.technician === techName ||
          (Array.isArray(r.coTechnicians) && r.coTechnicians.includes(techName)) ||
          (Array.isArray(r.woTechnicians) && r.woTechnicians.some(t => String(t?.name || '').trim() === techName))
        ) && r.status !== 'انجام شد').length;
        const lastAction = getTechnicianLastActionInfo(techName);
        const stats = getTechnicianStats(techName);
        const allTasks = getTechnicianAllTasks(techName, workRequests);
        const techNames = getTechNames(techName);
        const photo = technicianPhotos[techName];

        // فیلتر بر اساس جستجو و وضعیت
        const filteredTasks = allTasks.filter(task => {
          if (techProfileStatusFilter !== 'همه' && task.status !== techProfileStatusFilter) return false;
          if (!techProfileSearch.trim()) return true;
          const q = techProfileSearch.trim().toLowerCase();
          return (
            task.title.toLowerCase().includes(q) ||
            task.code.toLowerCase().includes(q) ||
            (task.workOrderCode && task.workOrderCode.toLowerCase().includes(q)) ||
            task.place.toLowerCase().includes(q) ||
            task.details.toLowerCase().includes(q) ||
            (task.partsUsed && task.partsUsed.toLowerCase().includes(q)) ||
            task.operationType.toLowerCase().includes(q)
          );
        });

        return (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
            <div className="max-w-4xl w-full max-h-[92vh] flex flex-col glass-panel-navy rounded-3xl navy-glow-border shadow-2xl overflow-hidden border border-cyan-500/40">
              
              {/* Header صفحه اختصاصی تکنسین */}
              <div className="p-5 sm:p-6 pb-4 border-b border-blue-900/60 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  {/* عکس پرسنلی با پس‌زمینه سفید یکدست و گزینه‌های مدیریت عکس در داخل پروفایل */}
                  <div className="flex flex-col items-center gap-1.5 shrink-0">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white border-2 sm:border-4 border-slate-200 shadow-md flex items-center justify-center overflow-hidden shrink-0">
                      {photo ? (
                        <img
                          src={photo}
                          alt={techNames.full}
                          className="w-full h-full object-cover bg-white"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full bg-white flex flex-col items-center justify-center text-slate-800">
                          <User className="w-8 h-8 text-slate-400" />
                          <span className="text-[11px] font-bold text-slate-700 mt-1">{techNames.last}</span>
                        </div>
                      )}
                    </div>

                    {/* گزینه‌های تمیز مدیریت عکس داخل پروفایل (حذف کامل ضربدر روی عکس) */}
                    <div className="flex items-center gap-1">
                      <label 
                        className="px-2 py-0.5 rounded-lg bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 text-[10px] font-medium flex items-center gap-1 cursor-pointer transition-all" 
                        title="بارگذاری / تغییر عکس پرسنلی"
                      >
                        <Camera className="w-3 h-3 text-cyan-300" />
                        <span>{photo ? 'تغییر عکس' : 'افزودن عکس'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleUploadTechnicianPhoto(techName, file);
                          }}
                        />
                      </label>

                      {photo && (
                        <button
                          type="button"
                          onClick={() => handleRemoveTechnicianPhoto(techName)}
                          className="px-2 py-0.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 text-[10px] font-medium flex items-center gap-1 cursor-pointer transition-all"
                          title="حذف عکس این تکنسین"
                        >
                          <Trash2 className="w-3 h-3 text-rose-400" />
                          <span>حذف عکس</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2.5">
                      {/* نام و نام خانوادگی کامل تکنسین در پروفایل */}
                      <h3 className="text-xl sm:text-2xl font-black text-white">
                        {techNames.full}
                      </h3>
                      {activeCount > 0 ? (
                        <span className="flex items-center gap-1.5 text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                          در حال حاضر مشغول کار
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                          آماده کار بعدی (در دسترس)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-cyan-300 mt-1">
                      <span>تکنسین خدمات فنی و مهندسی نگهداری و تعمیرات</span>
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRunAiTechnicianAnalysis(techName)}
                    className="px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-950/60 hover:scale-105 active:scale-95 border border-indigo-400/50"
                    title="تحلیل هوشمند عملکرد، سرعت، تخصص و تموم‌کنندگی توسط هوش مصنوعی"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                    <span>تحلیل هوش مصنوعی کارکرد</span>
                  </button>

                  <button
                    onClick={() => setSelectedTechnicianProfile(null)}
                    className="p-2 rounded-xl text-blue-300 hover:text-white hover:bg-blue-900/40 transition-colors cursor-pointer border border-transparent hover:border-blue-700/50"
                    title="بستن صفحه"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* نوار خلاصه آمار و عملکرد تکنسین (بدون مربع‌های تو در تو) */}
              <div className="px-5 py-3.5 bg-blue-950/40 border-b border-blue-900/40 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] text-blue-300/80 block">کل کارهای انجام‌شده</span>
                    <strong className="text-white text-sm font-mono font-bold">
                      {toFaDigits(stats.totalDoneCount)} کار
                    </strong>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] text-blue-300/80 block">مجموع زمان کارکرد</span>
                    <strong className="text-cyan-300 text-sm font-mono font-bold">
                      {formatTotalTechTime(stats.totalMinutes)}
                    </strong>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                    <Timer className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] text-blue-300/80 block">آخرین اقدام ثبت‌شده</span>
                    <strong className="text-emerald-300 text-xs font-mono font-bold">
                      {lastAction ? lastAction.timeAgoText : 'ثبت نشده'}
                    </strong>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-950/60 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] text-blue-300/80 block">کارهای در حال اقدام</span>
                    <strong className="text-amber-300 text-sm font-mono font-bold">
                      {toFaDigits(activeCount)} جاری
                    </strong>
                  </div>
                </div>
              </div>

              {/* پنل جامع گزارش تحلیلی هوش مصنوعی */}
              {isAiAnalysisOpen && (
                <div className="p-4 sm:p-5 m-4 sm:mx-6 rounded-2xl bg-gradient-to-br from-indigo-950/90 via-slate-900/95 to-blue-950/90 border-2 border-indigo-500/50 shadow-2xl shadow-indigo-950/60 space-y-4 animate-in fade-in duration-300">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-indigo-500/30">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center shadow-md shadow-indigo-500/30 shrink-0">
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                          <span>گزارش تحلیلی هوش مصنوعی از عملکرد تکنسین</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 text-purple-200 border border-purple-500/40 font-mono font-bold">
                            هوش مصنوعی نت
                          </span>
                        </h4>
                        <p className="text-[11px] text-blue-200/80 mt-0.5">
                          سنجش سهم کاری، سرعت اقدام، گرایش تخصصی (برق/مکانیک/تاسیسات) و تموم‌کنندگی فردی
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleRunAiTechnicianAnalysis(techName)}
                        disabled={aiAnalysisLoading}
                        className="px-2.5 py-1.5 rounded-xl bg-indigo-900/60 hover:bg-indigo-800/70 border border-indigo-400/40 text-indigo-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        title="پردازش و به‌روزرسانی مجدد تحلیل"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${aiAnalysisLoading ? 'animate-spin' : ''}`} />
                        <span>تحلیل مجدد</span>
                      </button>

                      {aiAnalysisResults[techName]?.analysisText && (
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(aiAnalysisResults[techName].analysisText);
                            setAiAnalysisCopied(true);
                            setTimeout(() => setAiAnalysisCopied(false), 2500);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-400/40 text-cyan-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                          title="کپی متن گزارش ۱۰ خطی"
                        >
                          {aiAnalysisCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{aiAnalysisCopied ? 'کپی شد! ✓' : 'کپی متن'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => setIsAiAnalysisOpen(false)}
                        className="p-1.5 rounded-xl text-blue-300 hover:text-white hover:bg-blue-900/40 transition-colors border border-transparent hover:border-blue-700/40 cursor-pointer"
                        title="بستن کادر تحلیل هوش مصنوعی"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {aiAnalysisLoading ? (
                    <div className="py-8 flex flex-col items-center justify-center space-y-3">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-500 animate-spin flex items-center justify-center shadow-lg shadow-purple-500/40">
                          <Sparkles className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      <p className="text-xs font-bold text-cyan-200 animate-pulse text-center">
                        هوش مصنوعی در حال تحلیل فشرده سوابق، سنجش سرعت و ارزیابی کیفیت کار برای {techNames.full}...
                      </p>
                    </div>
                  ) : aiAnalysisResults[techName] ? (() => {
                    const res = aiAnalysisResults[techName];
                    return (
                      <div className="space-y-3.5">
                        {/* ردیف کارت‌های شاخص‌های کلیدی آماری تحلیل */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 text-xs">
                          {/* شاخص ۱: سهم از کل کارهای کارخانه */}
                          <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                            <span className="text-[10px] text-blue-300 block">سهم از کل کارها:</span>
                            <div className="flex items-baseline gap-1 font-mono">
                              <span className="text-lg font-black text-cyan-300">{toFaDigits(res.shareOfPlantPercent)}٪</span>
                              <span className="text-[10px] text-blue-300/70">از کل واحد نت</span>
                            </div>
                            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
                              <div
                                className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full rounded-full"
                                style={{ width: `${Math.min(100, Math.max(5, res.shareOfPlantPercent))}%` }}
                              />
                            </div>
                          </div>

                          {/* شاخص ۲: سرعت و ریتم انجام */}
                          <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                            <span className="text-[10px] text-blue-300 block">سرعت و ریتم اقدام:</span>
                            <div className="font-bold text-xs text-emerald-300 truncate" title={res.speedLabel}>
                              {res.speedLabel}
                            </div>
                            <span className="text-[10px] text-blue-300/70 block font-mono">
                              میانگین {toFaDigits(res.avgMinutes)} دقیقه / کار
                            </span>
                          </div>

                          {/* شاخص ۳: تخصص و گرایش برتر */}
                          <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                            <span className="text-[10px] text-blue-300 block">تخصص و گرایش برتر:</span>
                            <div className="font-bold text-xs text-amber-300 truncate" title={res.topSpecialty}>
                              {res.topSpecialty}
                            </div>
                            <span className="text-[10px] text-blue-300/70 block">
                              بیشترین حجم عیب‌یابی موفق
                            </span>
                          </div>

                          {/* شاخص ۴: کارهای تکی در برابر کمکی */}
                          <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1">
                            <span className="text-[10px] text-blue-300 block">سبک اجرا (تکی vs کمکی):</span>
                            <div className="flex items-center justify-between text-[11px] font-mono">
                              <span className="text-cyan-300 font-bold">{toFaDigits(res.soloPercent)}٪ تکی</span>
                              <span className="text-purple-300">{toFaDigits(res.teamPercent)}٪ کمکی</span>
                            </div>
                            <div className="w-full bg-purple-950 h-1.5 rounded-full overflow-hidden flex">
                              <div style={{ width: `${res.soloPercent}%` }} className="bg-cyan-400 h-full" />
                              <div style={{ width: `${res.teamPercent}%` }} className="bg-purple-500 h-full" />
                            </div>
                          </div>

                          {/* شاخص ۵: تموم‌کنندگی فردی */}
                          <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 space-y-1 col-span-2 sm:col-span-1">
                            <span className="text-[10px] text-blue-300 block">تموم‌کنندگی فردی:</span>
                            <div className="flex items-baseline gap-1 font-mono">
                              <span className="text-lg font-black text-emerald-400">{toFaDigits(res.completionRate)}٪</span>
                              <span className="text-[10px] text-emerald-300/70">موفقیت تحویل نهایی</span>
                            </div>
                            <span className="text-[10px] text-blue-300/70 block">
                              {toFaDigits(res.doneCount)} بسته شده از {toFaDigits(res.taskCount)}
                            </span>
                          </div>
                        </div>

                        {/* جعبه متن چکیده تحلیل هوش مصنوعی و نتیجه ۵ ستاره */}
                        <div className="p-4 rounded-xl bg-slate-950/90 border border-indigo-500/40 space-y-3">
                          <div className="flex items-center justify-between text-xs text-indigo-300 pb-1.5 border-b border-indigo-900/40">
                            <span className="font-bold flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                              <span>تحلیل هوش مصنوعی و ارزیابی کیفیت عملکرد تکنسین:</span>
                            </span>
                            <span className="text-[10px] text-cyan-300 font-medium">
                              (گزارش تحلیلی متمرکز بر کیفیت، سرعت و استقلال فنی)
                            </span>
                          </div>

                          <div className="text-xs text-slate-100 leading-relaxed font-sans whitespace-pre-line space-y-1.5 selection:bg-purple-600 selection:text-white pt-1">
                            {res.analysisText}
                          </div>

                          {/* نتیجه نهایی کیفیت کار به صورت ۵ ستاره */}
                          <div className="mt-3 pt-3 border-t border-indigo-900/50 flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-slate-900/90 via-indigo-950/60 to-slate-900/90 p-3 rounded-xl border border-indigo-500/30">
                            <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
                              <div className="flex items-center gap-1 p-1.5 bg-slate-950/80 rounded-lg border border-amber-500/30 shadow-inner shrink-0">
                                {[1, 2, 3, 4, 5].map((starIdx) => {
                                  const rating = typeof res.starRating === 'number' ? res.starRating : 5;
                                  const isFull = rating >= starIdx;
                                  const isHalf = !isFull && rating >= starIdx - 0.5;
                                  return (
                                    <Star
                                      key={starIdx}
                                      className={`w-5 h-5 sm:w-6 sm:h-6 transition-all duration-300 ${
                                        isFull
                                          ? 'text-amber-400 fill-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.7)]'
                                          : isHalf
                                          ? 'text-amber-400 fill-amber-400/50'
                                          : 'text-slate-600 fill-transparent'
                                      }`}
                                    />
                                  );
                                })}
                              </div>
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-xs font-bold text-slate-200">نتیجه کیفیت کار:</span>
                                  <span className="text-sm font-black text-amber-300 font-mono">
                                    {toFaDigits(res.starRating ?? 5)} از ۵ ستاره
                                  </span>
                                  <span className="text-xs text-emerald-300 font-semibold bg-emerald-950/70 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                                    {res.starRatingLabel || 'کیفیت عالی و بی‌نقص (۵ ستاره)'}
                                  </span>
                                </div>
                                <p className="text-[11px] text-blue-300/80 mt-0.5">
                                  ارزیابی کیفی مبتنی بر کیفیت اجرا، سرعت و تموم‌کنندگی (بدون وابستگی به تعداد کل کارها)
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="text-center py-4 text-xs text-blue-300">
                      جهت تولید گزارش تحلیلی، روی دکمه «تحلیل مجدد» کلیک نمایید.
                    </div>
                  )}
                </div>
              )}

              {/* ابزارهای فیلتر و جستجو درون کارهای تکنسین */}
              <div className="p-4 sm:px-6 border-b border-blue-900/40 bg-slate-950/40 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-1 min-w-[220px]">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-blue-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={techProfileSearch}
                      onChange={e => setTechProfileSearch(e.target.value)}
                      placeholder="جستجو در تمام کارهای تکنسین (عنوان، کد، سالن، قطعات، شرح اقدام)..."
                      className="w-full pl-8 pr-9 py-2 text-xs rounded-xl bg-blue-950/40 border border-blue-800/60 text-white placeholder-blue-400/60 focus:outline-none focus:border-cyan-400"
                    />
                    {techProfileSearch && (
                      <button
                        onClick={() => setTechProfileSearch('')}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-blue-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-blue-300/70 text-[11px] ml-1">وضعیت:</span>
                  {(['همه', 'انجام شد', 'در حال اقدام'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => setTechProfileStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        techProfileStatusFilter === st
                          ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                          : 'bg-blue-950/60 text-blue-300 hover:text-white border border-blue-900/60'
                      }`}
                    >
                      {st} {st === 'همه' ? `(${toFaDigits(allTasks.length)})` : `(${toFaDigits(allTasks.filter(t => t.status === st).length)})`}
                    </button>
                  ))}
                </div>
              </div>

              {/* لیست تمام کارهای انجام شده و سوابق تکنسین */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3.5">
                <div className="flex items-center justify-between text-xs text-blue-300 pb-1">
                  <span className="font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span>لیست تمام کارهای انجام‌شده و اقدامات ثبت‌شده ({toFaDigits(filteredTasks.length)} مورد)</span>
                  </span>
                  <span className="text-[11px] text-blue-400/80">مرتب‌سازی از جدیدترین به قدیمی‌ترین</span>
                </div>

                {allTasks.length === 0 ? (
                  <div className="py-14 px-6 text-center rounded-2xl bg-blue-950/20 border border-dashed border-blue-800/40 space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-cyan-400">
                      <FileText className="w-7 h-7" />
                    </div>
                    <h4 className="text-base font-bold text-white">هنوز سابقه‌ای برای {techNames.full} ثبت نشده است</h4>
                    <p className="text-xs text-blue-300/80 max-w-md mx-auto leading-relaxed">
                      کلیه پرونده‌ها و سوابق تستی صفر شدند تا بتوانید اطلاعات واقعی را از صفر ثبت کنید. به محض ثبت درخواست کار و ارجاع آن به {techNames.full}، اقدامات و ساعت کارکرد در این پرونده ذخیره خواهد شد.
                    </p>
                  </div>
                ) : filteredTasks.length === 0 ? (
                  <div className="py-12 text-center text-blue-400 text-xs bg-blue-950/20 rounded-2xl border border-blue-900/30 space-y-2">
                    <FileText className="w-8 h-8 text-blue-500/40 mx-auto" />
                    <p>هیچ کاری با مشخصات جستجو شده یافت نشد.</p>
                    {techProfileSearch && (
                      <button
                        onClick={() => setTechProfileSearch('')}
                        className="text-cyan-400 hover:underline text-xs"
                      >
                        پاک کردن عبارت جستجو
                      </button>
                    )}
                  </div>
                ) : (
                  filteredTasks.map((task) => {
                    const isExpanded = Boolean(expandedTechTaskIds[task.id]);
                    return (
                      <div
                        key={task.id}
                        className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                          isExpanded
                            ? 'bg-gradient-to-b from-blue-950/70 to-slate-900/90 border-cyan-500/60 shadow-lg shadow-cyan-950/40'
                            : 'bg-gradient-to-b from-blue-950/40 to-slate-900/60 border-blue-900/50 hover:border-cyan-500/40'
                        }`}
                      >
                        {/* ردیف پیش‌فرض: فقط عنوان و تاریخ همراه با کلید بازشونده جزئیات */}
                        <div className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5 flex-1 min-w-0">
                            <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border shrink-0 ${
                              task.status === 'انجام شد'
                                ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
                                : 'bg-amber-950/70 text-amber-300 border-amber-500/40 animate-pulse'
                            }`}>
                              {task.status}
                            </span>
                            {/* عنوان کار */}
                            <h4 className="text-sm font-bold text-white truncate leading-relaxed" title={task.title}>
                              {task.title}
                            </h4>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-2.5 shrink-0">
                            {/* تاریخ کار */}
                            <div className="flex items-center gap-1.5 text-xs text-cyan-300/90 font-mono bg-blue-950/70 px-2.5 py-1 rounded-xl border border-blue-800/50 shadow-inner">
                              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                              <span>{task.date}</span>
                            </div>

                            {/* کلید جزئیات آکاردئونی */}
                            <button
                              type="button"
                              onClick={() => {
                                setExpandedTechTaskIds(prev => ({
                                  ...prev,
                                  [task.id]: !prev[task.id]
                                }));
                              }}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                                isExpanded
                                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/30 font-black'
                                  : 'bg-blue-900/50 hover:bg-cyan-950 text-cyan-200 border-cyan-500/40 hover:border-cyan-400'
                              }`}
                              title="نمایش یا بستن جزئیات تکمیلی کار"
                            >
                              <span>جزئیات</span>
                              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-slate-950' : 'text-cyan-300'}`} />
                            </button>
                          </div>
                        </div>

                        {/* بخش آکاردئونی بازشونده به پایین شامل مشخصات تکمیلی */}
                        {isExpanded && (
                          <div className="px-4 pb-4 pt-1 border-t border-blue-900/40 space-y-3 bg-slate-950/60 animate-in fade-in duration-200">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 text-xs">
                              {/* ۱. محل سالن */}
                              <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-900/60 space-y-1">
                                <span className="text-[10px] text-blue-300/80 block">محل سالن:</span>
                                <strong className="text-white text-xs block truncate">{task.place || 'سالن تولید'}</strong>
                              </div>

                              {/* ۲. نوع عملیات */}
                              <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-900/60 space-y-1">
                                <span className="text-[10px] text-blue-300/80 block">نوع عملیات:</span>
                                <strong className="text-cyan-200 text-xs block truncate">{task.operationType || 'مکانیک'}</strong>
                              </div>

                              {/* ۳. کد درخواست کار */}
                              <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-900/60 space-y-1">
                                <span className="text-[10px] text-blue-300/80 block">کد درخواست کار:</span>
                                <strong className="text-amber-300 font-mono text-xs block">{task.code || '—'}</strong>
                              </div>

                              {/* ۴. کد دستور کار */}
                              <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-900/60 space-y-1">
                                <span className="text-[10px] text-blue-300/80 block">کد دستور کار:</span>
                                <strong className="text-emerald-300 font-mono text-xs block">
                                  {task.workOrderCode || (task.code ? task.code.replace('WR', 'WO') : '—')}
                                </strong>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                              {/* ۵. سطح کار */}
                              <div className="p-2.5 rounded-xl bg-blue-950/40 border border-blue-900/50 flex items-center justify-between">
                                <span className="text-[11px] text-blue-300/80">سطح کار:</span>
                                <span className={`text-[10px] px-2.5 py-0.5 rounded-md font-bold border ${
                                  task.complexityLevel === 'دشوار'
                                    ? 'bg-purple-950/80 text-amber-300 border-amber-500/40'
                                    : task.complexityLevel === 'آسان'
                                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                                    : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                                }`}>
                                  {task.complexityLevel || 'معمولی'}
                                </span>
                              </div>

                              {/* ۶. انفرادی یا تیمی */}
                              <div className="p-2.5 rounded-xl bg-blue-950/40 border border-blue-900/50 flex items-center justify-between">
                                <span className="text-[11px] text-blue-300/80">انفرادی یا تیمی:</span>
                                {task.coTechnicians && task.coTechnicians.length > 0 ? (
                                  <span className="text-[10px] px-2.5 py-0.5 rounded-md bg-purple-950/70 text-purple-200 border border-purple-500/40 font-bold flex items-center gap-1" title={`همکاران: ${task.coTechnicians.join('، ')}`}>
                                    <Users className="w-3 h-3 text-purple-300" />
                                    <span>تیمی ({toFaDigits(task.coTechnicians.length + 1)} نفره: {task.coTechnicians.join('، ')})</span>
                                  </span>
                                ) : (
                                  <span className="text-[10px] px-2.5 py-0.5 rounded-md bg-slate-900 text-blue-300 border border-slate-700/60 font-bold">
                                    انفرادی (تک‌نفره)
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* ۷. شرح اقدامات فنی */}
                            <div className="p-3 rounded-xl bg-slate-950/85 border border-blue-900/60 text-xs space-y-1">
                              <div className="text-[11px] text-cyan-400 font-bold flex items-center gap-1">
                                <FileText className="w-3.5 h-3.5" />
                                <span>شرح اقدامات فنی:</span>
                              </div>
                              <p className="text-slate-200 leading-relaxed whitespace-pre-line text-[11px] pt-0.5">
                                {task.details || 'اقدامات فنی استاندارد انجام گردید.'}
                              </p>
                            </div>

                            {/* قطعات و لوازم مصرفی (در صورت وجود) */}
                            {task.partsUsed && (
                              <div className="flex items-center gap-2 text-xs text-amber-200/90 bg-amber-950/40 border border-amber-500/30 px-3 py-2 rounded-xl">
                                <Wrench className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                <span className="text-amber-300 text-[11px] font-bold">لوازم و قطعات مصرفی:</span>
                                <span className="text-white font-medium">{task.partsUsed}</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Modal Footer */}
              <div className="p-4 sm:px-6 border-t border-blue-900/60 bg-slate-950/80 flex items-center justify-between">
                <span className="text-xs text-blue-300 font-mono">
                  نمایش {toFaDigits(filteredTasks.length)} از {toFaDigits(allTasks.length)} کار ثبت‌شده
                </span>
                <button
                  onClick={() => setSelectedTechnicianProfile(null)}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-900/60 hover:bg-blue-800 text-white border border-blue-700/50 transition-all cursor-pointer"
                >
                  بستن صفحه تکنسین
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* ======================================================== */}
      {/* THE UNIFIED FORM (فرم یکپارچه درخواست کار + دستور کار)     */}
      {/* ======================================================== */}
      {modalType === 'unifiedForm' && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-2xl w-full bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-5 max-h-[92vh] overflow-y-auto shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-700">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-slate-700 border border-slate-600 text-cyan-400 flex items-center justify-center font-bold">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-500"></span>
                    <span>{editingItemCode ? `تکمیل عملیات و بستن دستور کار (${editingItemCode})` : 'فرم یکپارچه درخواست کار و دستور کار'}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    ثبت اطلاعات عیب و ثبت همزمان اقدامات تکنسین در یک فرم واحد
                  </p>
                </div>
              </div>

              <button type="button" onClick={() => setModalType('none')} className="text-slate-400 hover:text-slate-200 transition-colors p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* PHASE 1: SECTION A - مشخصات درخواست کار (Work Request) */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>بخش اول: اطلاعات درخواست کار (WR)</span>
                </span>
                {editingItemCode && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono border border-slate-700">
                    ثبت‌شده قبلی
                  </span>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">عنوان کار / خرابی</label>
                <input
                  type="text"
                  value={reqTitle}
                  onChange={e => setReqTitle(e.target.value)}
                  placeholder="مثلاً تعمیر الکتروموتور پمپ یا تعویض بلبرینگ..."
                  disabled={formSection === 'workOrderOnly'}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 disabled:opacity-60 placeholder:text-slate-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-blue-200 mb-1 flex items-center justify-between">
                    <span>
                      نام مکان <span className="text-cyan-400">*</span>
                    </span>
                    <span className="text-[10px] text-blue-300/60">(انتخاب از زبانه)</span>
                  </label>
                  <select
                    value={reqPlace}
                    onChange={e => setReqPlace(e.target.value)}
                    disabled={formSection === 'workOrderOnly'}
                    className="w-full bg-slate-950/90 border border-blue-800/60 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 disabled:opacity-75 cursor-pointer"
                  >
                    {FACTORY_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc} className="bg-slate-900 text-white">
                        {loc}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-blue-200 mb-1 flex items-center justify-between">
                    <span>اولویت کار</span>
                    <span className="text-[10px] text-cyan-300/70">(درجه اهمیت)</span>
                  </label>
                  <select
                    value={reqPriority}
                    onChange={e => setReqPriority(e.target.value)}
                    disabled={formSection === 'workOrderOnly'}
                    className="w-full bg-slate-950/90 border border-blue-800/60 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 disabled:opacity-75 cursor-pointer"
                  >
                    <option value="ایمنی (اولویت بالا)" className="bg-slate-900 text-amber-300">
                      ایمنی (اولویت بالا)
                    </option>
                    <option value="عادی" className="bg-slate-900 text-cyan-200">
                      عادی
                    </option>
                  </select>
                </div>
              </div>

              {/* فیلدهای تاریخ و ساعت ثبت درخواست */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-blue-200 mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>تاریخ درخواست</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setReqDate(getEnDateNow())}
                      className="text-[10px] text-cyan-400 hover:text-white"
                      disabled={formSection === 'workOrderOnly'}
                    >
                      امروز
                    </button>
                  </label>
                  <input
                    type="text"
                    value={reqDate}
                    onChange={e => setReqDate(toEnDigits(e.target.value))}
                    placeholder="1405/05/23"
                    dir="ltr"
                    disabled={formSection === 'workOrderOnly'}
                    className="w-full bg-slate-950/90 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 disabled:opacity-75 font-mono text-center tracking-wider"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-blue-200 mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Timer className="w-3.5 h-3.5 text-cyan-400" />
                      <span>ساعت درخواست</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const now = getEnTimeNow();
                        setReqTime(now);
                        setWoStartTime(now);
                        const diff = computeMinutesDiff(now, woEndTime);
                        if (diff > 0) setWoDuration(diff);
                      }}
                      className="text-[10px] text-cyan-400 hover:text-white"
                      disabled={formSection === 'workOrderOnly'}
                    >
                      الان
                    </button>
                  </label>
                  <input
                    type="text"
                    value={reqTime}
                    onChange={e => {
                      const val = toEnDigits(e.target.value);
                      setReqTime(val);
                      setWoStartTime(val);
                      const diff = computeMinutesDiff(val, woEndTime);
                      if (diff > 0) setWoDuration(diff);
                    }}
                    placeholder="09:30"
                    dir="ltr"
                    disabled={formSection === 'workOrderOnly'}
                    className="w-full bg-slate-950/90 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 disabled:opacity-75 font-mono text-center tracking-wider"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-blue-200 mb-1">شرح مشکل اولیه</label>
                <textarea
                  value={reqDesc}
                  onChange={e => setReqDesc(e.target.value)}
                  placeholder="توضیح اولیه در مورد ایراد..."
                  disabled={formSection === 'workOrderOnly'}
                  className="w-full bg-slate-950/80 border border-blue-800/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none disabled:opacity-75"
                  rows={2}
                />
              </div>
            </div>

            {/* TOGGLE: ثبت همزمان عملیات تکنسین (دستور کار) */}
            {!editingItemCode && (
              <div className="p-3 rounded-xl bg-blue-900/20 border border-cyan-500/30 flex items-center justify-between">
                <div>
                  <strong className="text-xs text-white block">آیا عملیات انجام شده و می‌خواهید دستور کار هم بسته شود؟</strong>
                  <span className="text-[11px] text-blue-300/70">
                    در صورت فعال‌کردن، بخش اقدامات فنی باز می‌شود و نیازی به فرم دوم نخواهد بود.
                  </span>
                </div>
                <input
                  type="checkbox"
                  id="includeActionsToggle"
                  checked={includeWorkOrderActions}
                  onChange={e => setIncludeWorkOrderActions(e.target.checked)}
                  className="w-5 h-5 rounded border-blue-800 text-cyan-500 focus:ring-0 cursor-pointer"
                />
              </div>
            )}

            {/* PHASE 2: SECTION B - دستور کار و شرح اقدامات فنی (Work Order Execution) */}
            {includeWorkOrderActions && (
              <div className="p-4 rounded-2xl bg-gradient-to-b from-blue-950/80 to-slate-950/80 border border-cyan-500/50 space-y-3.5 shadow-lg shadow-cyan-950/30">
                <div className="flex items-center justify-between pb-2 border-b border-blue-900/40">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>بخش دوم: اقدامات تکنسین و بستن دستور کار (WO)</span>
                  </span>
                  <span className="text-[10px] text-cyan-300 font-bold bg-cyan-950/70 px-2 py-0.5 rounded border border-cyan-500/40">
                    اجرای عملیات
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-blue-200 mb-1">تکنسین مسئول انجام (مجری اصلی)</label>
                    <select
                      value={woTechnician}
                      onChange={e => {
                        const val = e.target.value;
                        setWoTechnician(val);
                        setWoCoTechnicians(prev => prev.filter(t => t !== val));
                      }}
                      className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    >
                      {technicians.map((name, i) => (
                        <option key={i} value={name}>{name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-blue-200 mb-1">تخصص / رشته عملیات</label>
                    <select
                      value={woOperationType}
                      onChange={e => setWoOperationType(e.target.value)}
                      className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    >
                      <option value="مکانیک">مکانیک و روانکاری</option>
                      <option value="برق صنعتی">برق صنعتی و کنترل</option>
                      <option value="تاسیسات">تاسیسات و آبرسانی</option>
                      <option value="روشنایی">روشنایی و نور</option>
                      <option value="عمومی">سرویس عمومی</option>
                    </select>
                  </div>
                </div>

                {/* انتخاب تکنسین‌های دیگر در صورت نیاز به ۲ یا چند تکنسین */}
                <div className="p-3 rounded-xl bg-slate-950/70 border border-blue-900/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-semibold text-blue-200 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-cyan-400" />
                      <span>تکنسین‌های کمکی / همکار (انتخاب چند تکنسین برای انجام کار):</span>
                    </label>
                    <span className="text-[10px] text-cyan-300 font-mono bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                      {woCoTechnicians.length === 0 ? '۱ تکنسین (انفرادی)' : `تیم ${toFaDigits(woCoTechnicians.length + 1)} نفره`}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {technicians
                      .filter(t => t !== woTechnician)
                      .map(tName => {
                        const isSelected = woCoTechnicians.includes(tName);
                        return (
                          <button
                            key={tName}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setWoCoTechnicians(woCoTechnicians.filter(t => t !== tName));
                              } else {
                                setWoCoTechnicians([...woCoTechnicians, tName]);
                              }
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 border cursor-pointer ${
                              isSelected
                                ? 'bg-cyan-950/90 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-900/50 ring-1 ring-cyan-400/40'
                                : 'bg-slate-900/90 border-blue-900/50 text-blue-300/80 hover:bg-slate-800 hover:text-white'
                            }`}
                          >
                            <span>{tName}</span>
                            {isSelected ? (
                              <Check className="w-3 h-3 text-cyan-400" />
                            ) : (
                              <Plus className="w-3 h-3 text-blue-400/60" />
                            )}
                          </button>
                        );
                      })}
                  </div>
                  {woCoTechnicians.length > 0 && (
                    <p className="text-[10px] text-cyan-300/90 pt-0.5 leading-relaxed">
                      ✓ تیم اجرایی: <strong>{woTechnician}</strong> + {woCoTechnicians.join('، ')} (این دستور کار در سوابق و کارنامه هر دو/چند تکنسین ثبت خواهد شد).
                    </p>
                  )}
                </div>

                {/* بخش زمان‌بندی دستور کار: تاریخ، ساعت شروع، ساعت پایان و محاسبه خودکار اختلاف */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-blue-800/60 space-y-3">
                  <div className="flex items-center justify-between pb-1.5 border-b border-blue-800/40 text-[11px]">
                    <span className="font-semibold flex items-center gap-1.5 text-cyan-300">
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>ثبت تاریخ و ساعت دستور کار</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                      محاسبه خودکار زمان کار
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {/* تاریخ دستور کار */}
                    <div>
                      <label className="block text-[11px] font-medium text-blue-200 mb-1 flex items-center justify-between">
                        <span>تاریخ دستور کار</span>
                        <button
                          type="button"
                          onClick={() => setWoDate(getEnDateNow())}
                          className="text-[10px] text-cyan-400 hover:text-white"
                        >
                          امروز
                        </button>
                      </label>
                      <input
                        type="text"
                        value={woDate}
                        onChange={e => setWoDate(toEnDigits(e.target.value))}
                        placeholder="1405/05/23"
                        dir="ltr"
                        className="w-full bg-slate-950 border border-blue-800/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono text-center tracking-wider"
                      />
                    </div>

                    {/* ساعت شروع دستور کار */}
                    <div>
                      <label className="block text-[11px] font-medium text-blue-200 mb-1 flex items-center justify-between">
                        <span>ساعت شروع دستور کار</span>
                        <button
                          type="button"
                          onClick={() => {
                            const now = getEnTimeNow();
                            setWoStartTime(now);
                            const diff = computeMinutesDiff(now, woEndTime);
                            if (diff > 0) setWoDuration(diff);
                          }}
                          className="text-[10px] text-cyan-400 hover:text-white"
                        >
                          الان
                        </button>
                      </label>
                      <input
                        type="text"
                        value={woStartTime}
                        onChange={e => {
                          const val = toEnDigits(e.target.value);
                          setWoStartTime(val);
                          const diff = computeMinutesDiff(val, woEndTime);
                          if (diff > 0) setWoDuration(diff);
                        }}
                        placeholder="08:30"
                        dir="ltr"
                        className="w-full bg-slate-950 border border-blue-800/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono text-center tracking-wider"
                      />
                    </div>

                    {/* ساعت پایان دستور کار */}
                    <div>
                      <label className="block text-[11px] font-medium text-blue-200 mb-1 flex items-center justify-between">
                        <span>ساعت پایان دستور کار</span>
                        <button
                          type="button"
                          onClick={() => {
                            const now = getEnTimeNow();
                            setWoEndTime(now);
                            const diff = computeMinutesDiff(woStartTime, now);
                            if (diff > 0) setWoDuration(diff);
                          }}
                          className="text-[10px] text-cyan-400 hover:text-white"
                        >
                          الان
                        </button>
                      </label>
                      <input
                        type="text"
                        value={woEndTime}
                        onChange={e => {
                          const val = toEnDigits(e.target.value);
                          setWoEndTime(val);
                          const diff = computeMinutesDiff(woStartTime, val);
                          if (diff > 0) setWoDuration(diff);
                        }}
                        placeholder="10:15"
                        dir="ltr"
                        className="w-full bg-slate-950 border border-blue-800/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono text-center tracking-wider"
                      />
                    </div>
                  </div>

                  {/* نوار نمایش زمان کار محاسبه‌شده از اختلاف ساعت شروع و پایان */}
                  <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-500/30 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Timer className="w-4 h-4 text-cyan-400 shrink-0" />
                      <div>
                        <span className="text-[11px] text-blue-200 block">
                          زمان کار (محاسبه خودکار از اختلاف شروع و پایان):
                        </span>
                        <span className="text-xs font-bold text-white font-mono">
                          {formatDurationFriendly(woDuration)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-cyan-300/80">دقیقه:</span>
                      <input
                        type="number"
                        min="1"
                        value={woDuration}
                        onChange={e => setWoDuration(Math.max(1, Number(e.target.value)))}
                        className="w-16 bg-slate-950 border border-cyan-500/50 rounded-lg px-2 py-1 text-xs text-center text-cyan-300 font-mono font-bold focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-blue-200 mb-1">
                    شرح کامل عملیات و اقدامات انجام‌شده (بستن دستور کار) *
                  </label>
                  <textarea
                    value={woActionDetails}
                    onChange={e => setWoActionDetails(e.target.value)}
                    placeholder="اقدامات دقیق انجام‌شده، قطعات مصرفی یا تعویض‌شده، تست‌های سلامت و نتیجه نهایی را اینجا بنویسید..."
                    className="w-full bg-slate-950 border border-cyan-500/40 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                    rows={3}
                  />
                </div>

                {/* بخش جامع لوازم مصرفی با ۳ دسته‌بندی (لوازم برقی، لوازم مکانیکی، سایر) */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-b from-slate-900/90 to-blue-950/90 border border-amber-500/40 space-y-3 shadow-lg shadow-amber-950/20">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-blue-900/40">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                        <Package className="w-4 h-4 text-amber-400" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-amber-300 block">لوازم و قطعات مصرفی دستور کار</span>
                        <span className="text-[10px] text-blue-200/70 block">ثبت اقلام مصرفی از انبار در ۳ گروه برقی، مکانیکی و سایر</span>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40">
                      {toFaDigits(woConsumables.reduce((acc, c) => acc + c.count, 0))} قلم انتخاب‌شده
                    </span>
                  </div>

                  {/* زبانه انتخاب دسته‌بندی */}
                  <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-950/80 border border-blue-900/60">
                    {(['برقی', 'مکانیکی', 'سایر'] as const).map(cat => {
                      const isActive = consumableTab === cat;
                      const catCount = woConsumables.filter(c => c.category === cat).reduce((s, c) => s + c.count, 0);
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setConsumableTab(cat)}
                          className={`py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            isActive
                              ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-md shadow-amber-950/60 border border-amber-400/50'
                              : 'text-blue-300 hover:text-white hover:bg-blue-900/30'
                          }`}
                        >
                          {cat === 'برقی' && <Zap className="w-3.5 h-3.5" />}
                          {cat === 'مکانیکی' && <Wrench className="w-3.5 h-3.5" />}
                          {cat === 'سایر' && <Box className="w-3.5 h-3.5" />}
                          <span>{cat === 'سایر' ? 'سایر اقلام' : `لوازم ${cat}`}</span>
                          {catCount > 0 && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-950/90 text-amber-200 font-mono font-bold">
                              {toFaDigits(catCount)}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* نوار مخفی‌شونده و افقی پیشنهادات سریع */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setShowPresetsBar(!showPresetsBar)}
                        className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-300 hover:text-amber-200 transition-colors cursor-pointer group"
                      >
                        <span className="p-1 rounded-md bg-amber-950/80 border border-amber-500/40 group-hover:border-amber-400">
                          {showPresetsBar ? <ChevronUp className="w-3 h-3 text-amber-400" /> : <ChevronDown className="w-3 h-3 text-amber-400" />}
                        </span>
                        <span>پیشنهادات سریع {consumableTab === 'سایر' ? 'سایر اقلام' : `لوازم ${consumableTab}`}</span>
                        <span className="text-[10px] text-blue-300/70 font-mono">({toFaDigits(DEFAULT_PRESET_CONSUMABLES[consumableTab].length)} قلم استاندارد)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShowPresetsBar(!showPresetsBar)}
                        className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-900/90 border border-amber-500/30 text-amber-300 hover:text-white hover:bg-amber-950/60 transition-all cursor-pointer font-medium"
                      >
                        {showPresetsBar ? '▲ بستن نوار' : '▼ نمایش نوار اقلام'}
                      </button>
                    </div>

                    {/* نوار افقی اسکرولی تک‌خطی (بدون انباشتگی چند سطری) */}
                    {showPresetsBar && (
                      <div className="animate-in fade-in slide-in-from-top-1 duration-150">
                        <div className="flex items-center gap-2 overflow-x-auto py-2 px-2.5 rounded-xl bg-slate-950/90 border border-amber-500/40 shadow-inner scrollbar-thin">
                          {DEFAULT_PRESET_CONSUMABLES[consumableTab].map((pName, idx) => {
                            const inList = woConsumables.find(c => c.name === pName && c.category === consumableTab);
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => handleAddConsumablePreset(pName, consumableTab)}
                                className={`shrink-0 whitespace-nowrap px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-all border cursor-pointer ${
                                  inList
                                    ? 'bg-amber-950/90 border-amber-500/80 text-amber-200 font-bold shadow-sm shadow-amber-950/60 ring-1 ring-amber-500/50'
                                    : 'bg-slate-900/90 hover:bg-amber-950/40 border-blue-800/60 hover:border-amber-500/50 text-blue-200 hover:text-white'
                                }`}
                                title="کلیک برای افزودن به دستور کار"
                              >
                                <span className="text-amber-400 font-bold">+</span>
                                <span>{pName}</span>
                                {inList && (
                                  <span className="font-mono text-[10px] px-1.5 py-0.2 bg-amber-900/90 text-amber-300 rounded-full font-bold border border-amber-500/40">
                                    ×{toFaDigits(inList.count)}
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                        <span className="text-[10px] text-blue-300/50 mt-1 block">
                          نوار را به چپ یا راست بکشید و روی هر قطعه کلیک کنید تا به لیست مصرف اضافه شود.
                        </span>
                      </div>
                    )}
                  </div>

                  {/* افزودن قطعه دستی و سفارشی */}
                  <div className="pt-2 border-t border-blue-900/40">
                    <div className="grid grid-cols-12 gap-2">
                      <div className="col-span-12 sm:col-span-6">
                        <input
                          type="text"
                          value={newPartName}
                          onChange={e => setNewPartName(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddCustomConsumable();
                            }
                          }}
                          placeholder={`نام قطعه دستی ${consumableTab}...`}
                          className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400 placeholder:text-blue-400/40"
                        />
                      </div>
                      <div className="col-span-5 sm:col-span-2">
                        <input
                          type="number"
                          min="1"
                          value={newPartCount}
                          onChange={e => setNewPartCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                          className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white font-mono text-center focus:outline-none focus:border-amber-400"
                          placeholder="تعداد"
                        />
                      </div>
                      <div className="col-span-4 sm:col-span-2">
                        <select
                          value={newPartUnit}
                          onChange={e => setNewPartUnit(e.target.value)}
                          className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-2 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                        >
                          <option value="عدد">عدد</option>
                          <option value="متر">متر</option>
                          <option value="لیتر">لیتر</option>
                          <option value="کیلوگرم">کیلوگرم</option>
                          <option value="بسته">بسته</option>
                          <option value="شاخه">شاخه</option>
                        </select>
                      </div>
                      <div className="col-span-3 sm:col-span-2">
                        <button
                          type="button"
                          onClick={() => handleAddCustomConsumable()}
                          className="w-full h-full py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>ثبت</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* لیست اقلام ثبت‌شده در این دستور کار */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[10px] text-amber-300 font-semibold flex items-center justify-between">
                      <span>اقلام اختصاص‌یافته به این دستور کار:</span>
                      {woConsumables.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setWoConsumables([])}
                          className="text-[10px] text-rose-400 hover:text-rose-300 cursor-pointer"
                        >
                          پاکسازی لیست
                        </button>
                      )}
                    </span>

                    {woConsumables.length === 0 ? (
                      <div className="p-2.5 rounded-xl bg-slate-950/40 border border-dashed border-blue-900/40 text-center text-[11px] text-blue-300/60">
                        هنوز هیچ قطعه‌ای برای این کار ثبت نشده است (در صورت عدم مصرف قطعه، این بخش خالی می‌ماند).
                      </div>
                    ) : (
                      <div className="space-y-1.5 max-h-36 overflow-y-auto">
                        {woConsumables.map(c => (
                          <div
                            key={c.id}
                            className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/80 border border-blue-900/60 hover:border-amber-500/40 transition-colors"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border shrink-0 ${
                                c.category === 'برقی'
                                  ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                                  : c.category === 'مکانیکی'
                                  ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                                  : 'bg-indigo-950/80 text-indigo-300 border-indigo-500/40'
                              }`}>
                                {c.category}
                              </span>
                              <span className="text-xs text-white font-medium truncate">{c.name}</span>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <div className="flex items-center rounded-lg bg-slate-900 border border-blue-800/60 p-0.5">
                                <button
                                  type="button"
                                  onClick={() => handleUpdateConsumableCount(c.id, -1)}
                                  className="w-5 h-5 rounded flex items-center justify-center text-blue-300 hover:text-white hover:bg-blue-800/40 cursor-pointer text-xs"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center text-xs font-mono font-bold text-amber-300">
                                  {toFaDigits(c.count)}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleUpdateConsumableCount(c.id, 1)}
                                  className="w-5 h-5 rounded flex items-center justify-center text-blue-300 hover:text-white hover:bg-blue-800/40 cursor-pointer text-xs"
                                >
                                  +
                                </button>
                              </div>
                              <span className="text-[10px] text-blue-300/80">{c.unit || 'عدد'}</span>

                              <button
                                type="button"
                                onClick={() => handleRemoveConsumable(c.id)}
                                className="w-6 h-6 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/30 text-rose-300 flex items-center justify-center transition-colors cursor-pointer"
                                title="حذف از لیست"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* انتخاب سطح پیچیدگی کار */}
                <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/70 border border-blue-900/50">
                  <span className="text-xs text-blue-200 font-medium whitespace-nowrap">
                    سطح پیچیدگی کار:
                  </span>
                  <div className="flex items-center gap-1.5 flex-1 max-w-xs justify-end">
                    <button
                      type="button"
                      onClick={() => setWoComplexityLevel('آسان')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border flex-1 text-center ${
                        woComplexityLevel === 'آسان'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-400 shadow-sm shadow-emerald-900/50 ring-1 ring-emerald-400/40'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      سطح آسان
                    </button>

                    <button
                      type="button"
                      onClick={() => setWoComplexityLevel('معمولی')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border flex-1 text-center ${
                        woComplexityLevel === 'معمولی'
                          ? 'bg-cyan-950 text-cyan-300 border-cyan-400 shadow-sm shadow-cyan-900/50 ring-1 ring-cyan-400/40'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      سطح معمولی
                    </button>

                    <button
                      type="button"
                      onClick={() => setWoComplexityLevel('دشوار')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border flex-1 text-center ${
                        woComplexityLevel === 'دشوار'
                          ? 'bg-purple-950 text-amber-300 border-amber-400 shadow-sm shadow-purple-900/50 ring-1 ring-amber-400/40'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      سطح دشوار
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="closeWoCheck"
                    checked={woCloseImmediately}
                    onChange={e => setWoCloseImmediately(e.target.checked)}
                    className="w-4 h-4 rounded border-blue-800 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <label htmlFor="closeWoCheck" className="text-xs text-emerald-300 font-medium cursor-pointer">
                    دستور کار کامل انجام شده و با وضعیت «بسته شد» بایگانی شود.
                  </label>
                </div>
              </div>
            )}

            {formError && (
              <div className="text-xs text-rose-400 bg-rose-950/30 p-2.5 rounded-xl border border-rose-900/40">
                {formError}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-700">
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="py-2.5 px-4 rounded-xl border border-slate-700 text-slate-300 text-xs hover:bg-slate-700/50 transition-colors cursor-pointer"
              >
                انصراف
              </button>

              <button
                type="button"
                onClick={handleSaveUnified}
                className="py-2.5 px-6 rounded-xl bg-cyan-700 hover:bg-cyan-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>
                  {includeWorkOrderActions && woCloseImmediately
                    ? 'ثبت و بستن فوری دستور کار (اقدام‌شده)'
                    : 'ثبت در سامانه'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: View Work Request Details */}
      {modalType === 'viewRequest' && selectedWorkRequest && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="max-w-xl w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-4 print-container my-auto">
            {/* Printable official letterhead with white background logo */}
            <div className="hidden print-only border-b-2 border-slate-800 pb-3 mb-4 text-slate-900">
              <div className="flex items-center justify-between">
                <img
                  src={COMPANY_LOGO_WHITEBG}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-14 w-auto object-contain"
                />
                <div className="text-center">
                  <h2 className="text-base font-black">{BRAND_CONFIG.COMPANY_FULL_NAME}</h2>
                  <h3 className="text-sm font-bold text-slate-700">{printSettings.techServiceSheet.docTitle}</h3>
                  <span className="text-[10px] text-slate-500">واحد فنی، مهندسی و نگهداری</span>
                </div>
                <div className="text-left text-xs font-mono space-y-1">
                  <div>کد سند: <b>{printSettings.techServiceSheet.docCode}</b></div>
                  <div>شماره: <b>{selectedWorkRequest.code}</b></div>
                  <div>تاریخ چاپ: <b>{getEnDateNow()}</b></div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between no-print">
              <div className="flex items-center gap-3">
                <img
                  src={COMPANY_LOGO}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-10 w-auto object-contain rounded-xl p-1 bg-black/60 border border-blue-500/40 shadow-md shrink-0"
                />
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-400" />
                    <span>گزارش کامل درخواست و دستور کار</span>
                  </h3>
                  <span className="text-[10px] text-cyan-300">{BRAND_CONFIG.COMPANY_FULL_NAME}</span>
                </div>
              </div>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs bg-slate-950/70 p-4 rounded-xl border border-blue-900/40 text-blue-100">
              <div className="flex justify-between">
                <span>کد درخواست:</span>
                <b className="font-mono text-cyan-300">{selectedWorkRequest.code}</b>
              </div>
              {selectedWorkRequest.workOrderCode && (
                <div className="flex justify-between">
                  <span>کد دستور کار:</span>
                  <b className="font-mono text-cyan-300">{selectedWorkRequest.workOrderCode}</b>
                </div>
              )}
              <div className="flex justify-between">
                <span>عنوان کار:</span>
                <b>{selectedWorkRequest.title}</b>
              </div>
              <div className="flex justify-between">
                <span>مکان / سالن:</span>
                <b className="text-white">{selectedWorkRequest.place}</b>
              </div>
              <div className="flex justify-between">
                <span>اولویت:</span>
                <b className={selectedWorkRequest.priority.includes('ایمنی') ? 'text-rose-400' : 'text-cyan-300'}>{selectedWorkRequest.priority}</b>
              </div>
              <div className="flex justify-between">
                <span>تاریخ و ساعت ثبت درخواست:</span>
                <b className="font-mono text-cyan-300">{selectedWorkRequest.created}</b>
              </div>
              {selectedWorkRequest.woDate && (
                <div className="flex justify-between">
                  <span>تاریخ اجرای دستور کار:</span>
                  <b className="font-mono text-cyan-300">{selectedWorkRequest.woDate}</b>
                </div>
              )}
              {selectedWorkRequest.woStartTime && selectedWorkRequest.woEndTime && (
                <div className="flex justify-between">
                  <span>ساعات شروع و پایان کار:</span>
                  <b className="font-mono text-cyan-300">
                    از {selectedWorkRequest.woStartTime} الی {selectedWorkRequest.woEndTime}
                  </b>
                </div>
              )}
              {selectedWorkRequest.durationMinutes && (
                <div className="flex justify-between text-emerald-300 text-[11px]">
                  <span>مدت زمان کارکرد (محاسبه اختلاف):</span>
                  <b className="font-mono font-bold">{formatDurationFriendly(selectedWorkRequest.durationMinutes)}</b>
                </div>
              )}
              {selectedWorkRequest.completedAt && (
                <div className="flex justify-between">
                  <span>تاریخ و ساعت اختتام پرونده:</span>
                  <b className="font-mono text-emerald-300">{selectedWorkRequest.completedAt}</b>
                </div>
              )}
              <div className="flex justify-between">
                <span>وضعیت نهایی:</span>
                <b className="text-emerald-400">{selectedWorkRequest.status}</b>
              </div>

              {selectedWorkRequest.complexityLevel && (
                <div className="pt-2 border-t border-blue-900/40 flex justify-between items-center">
                  <span>سطح پیچیدگی کار:</span>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${
                    selectedWorkRequest.complexityLevel === 'دشوار'
                      ? 'bg-purple-950 text-amber-300 border-amber-500/40'
                      : selectedWorkRequest.complexityLevel === 'آسان'
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                      : 'bg-cyan-950 text-cyan-300 border-cyan-500/40'
                  }`}>
                    {selectedWorkRequest.complexityLevel}
                    <span className="text-[10px] font-normal mr-1.5 opacity-80">
                      ({selectedWorkRequest.complexityLevel === 'آسان' ? 'سقف ۲ ساعت • ۱ تکنسین' : selectedWorkRequest.complexityLevel === 'دشوار' ? 'سقف ۸ ساعت • تا ۳ تکنسین' : 'سقف ۴ ساعت • تا ۲ تکنسین'})
                    </span>
                  </span>
                </div>
              )}

              {selectedWorkRequest.technician && (
                <div className="pt-2 border-t border-blue-900/40 flex justify-between">
                  <span>تکنسین مجری اصلی:</span>
                  <b className="text-white">{selectedWorkRequest.technician}</b>
                </div>
              )}

              {selectedWorkRequest.coTechnicians && selectedWorkRequest.coTechnicians.length > 0 && (
                <div className="pt-2 border-t border-blue-900/40 flex justify-between">
                  <span>تکنسین‌های همکار / کمکی:</span>
                  <b className="text-cyan-300">{selectedWorkRequest.coTechnicians.join('، ')}</b>
                </div>
              )}

              {selectedWorkRequest.actionDetails && (
                <div className="pt-2 border-t border-blue-900/40">
                  <span className="block font-semibold text-cyan-300 mb-1">اقدامات و شرح عملیات:</span>
                  <p className="text-slate-200 leading-relaxed bg-blue-950/40 p-2.5 rounded-lg border border-blue-900/30">
                    {selectedWorkRequest.actionDetails}
                  </p>
                </div>
              )}

              {selectedWorkRequest.consumables && selectedWorkRequest.consumables.length > 0 && (
                <div className="pt-2 border-t border-blue-900/40">
                  <span className="block font-semibold text-amber-300 mb-1.5 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-amber-400" />
                    <span>لوازم و قطعات مصرفی ثبت‌شده:</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedWorkRequest.consumables.map((c, idx) => (
                      <span key={idx} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs">
                        <span className="font-medium">{c.name}</span>
                        <span className="font-mono text-[11px] text-amber-300 font-bold">({toFaDigits(c.count || (c as any).quantity || 1)} {c.unit || 'عدد'})</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-900/80 text-amber-200 border border-amber-500/30">{c.category}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Printable Signatures Block */}
            <div className="hidden print-only pt-6 mt-4 border-t border-slate-300 text-slate-800 text-xs">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="space-y-8">
                  <div className="font-bold">تکنسین مجری: {selectedWorkRequest.technician || '—'}</div>
                  <div className="text-[10px] text-slate-400">امضاء و اثر انگشت</div>
                </div>
                <div className="space-y-8">
                  <div className="font-bold">سرپرست سالن / تحویل‌گیرنده</div>
                  <div className="text-[10px] text-slate-400">امضاء و تأیید</div>
                </div>
                <div className="space-y-8">
                  <div className="font-bold">{BRAND_CONFIG.TECHNICAL_DEPT_NAME}</div>
                  <div className="text-[10px] text-slate-400">مهر و امضاء نهایی</div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 no-print">
              <button
                onClick={() => window.print()}
                className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-blue-200 hover:text-white border border-blue-800/50 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-cyan-400" />
                <span>چاپ شناسنامه</span>
              </button>

              <button
                onClick={() => setModalType('none')}
                className="py-2 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Add New Technician */}
      {modalType === 'addTech' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <User className="w-5 h-5 text-cyan-400" />
                <span>افزودن تکنسین جدید به تیم خدمات فنی</span>
              </h3>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddTechnician} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-blue-200 mb-1">
                  نام و نام خانوادگی تکنسین *
                </label>
                <input
                  type="text"
                  value={newTechName}
                  onChange={e => setNewTechName(e.target.value)}
                  placeholder="مثلاً: علی رضایی، کامران نوری..."
                  className="w-full bg-slate-950/90 border border-blue-800/60 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  autoFocus
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/30 text-[11px] text-blue-300/80">
                با افزودن، این تکنسین بلافاصله در فرم‌های یکپارچه و فیلترهای تیم خدمات فنی ذخیره و قابل انتخاب خواهد بود.
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="py-2 px-4 rounded-xl border border-blue-800/40 text-blue-300 text-xs hover:text-white"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md shadow-blue-900/50 cursor-pointer"
                >
                  افزودن تکنسین ✓
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 1 FROM TOOLBAR: Checklist Overview */}
      {modalType === 'toolbarChecklist' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-emerald-400" />
                <span>دسترسی به بخش چک لیست</span>
              </h3>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/70 border border-blue-900/40 space-y-2 text-xs text-blue-200">
              <div className="flex justify-between"><span>تجهیزات خط تولید:</span><b className="text-cyan-300 font-mono">220 دستگاه</b></div>
              <div className="flex justify-between"><span>دسته‌ها:</span><span>تورنوس، فرز، تراش، سینتک، مایر، استار</span></div>
            </div>
            <div className="flex justify-end"><button onClick={() => setModalType('none')} className="py-2 px-5 rounded-xl bg-blue-600 text-white text-xs font-bold">بستن</button></div>
          </div>
        </div>
      )}

      {/* MODAL 2 FROM TOOLBAR: Oil Warehouse Overview */}
      {modalType === 'toolbarOil' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Droplet className="w-5 h-5 text-amber-400" />
                <span>دسترسی به بخش انبار روغن</span>
              </h3>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/70 border border-blue-900/40 space-y-2 text-xs text-blue-200">
              <div className="flex justify-between"><span>تعداد مخازن:</span><b className="text-amber-300 font-mono">4 مخزن اصلی</b></div>
              <div className="flex justify-between"><span>انواع روغن:</span><span>برش 11، آب صابون، هیدرولیک، روانکاری</span></div>
            </div>
            <div className="flex justify-end"><button onClick={() => setModalType('none')} className="py-2 px-5 rounded-xl bg-blue-600 text-white text-xs font-bold">بستن</button></div>
          </div>
        </div>
      )}

      {/* MODAL 3 FROM TOOLBAR: گزارش و نمودار مقایسه هفتگی کارها (شنبه تا پنجشنبه) */}
      {modalType === 'toolbarReport' && (() => {
        const weeklyDayData = PERSIAN_WORK_DAYS.map(d => {
          const dayReqs = workRequests.filter(r => {
            if (weeklyChartTechFilter !== 'همه' && r.technician !== weeklyChartTechFilter && (!Array.isArray(r.coTechnicians) || !r.coTechnicians.includes(weeklyChartTechFilter))) return false;
            return getWorkRequestDayKey(r) === d.key;
          });

          const totalMinutes = dayReqs.reduce((sum, r) => sum + getWorkRequestDurationMinutes(r), 0);
          const totalHours = Math.round((totalMinutes / 60) * 10) / 10;
          const taskCount = dayReqs.length;
          const doneCount = dayReqs.filter(r => r.status === 'انجام شد').length;
          const activeCount = dayReqs.filter(r => r.status !== 'انجام شد').length;

          // توزیع تکنسین‌ها در این روز
          const techMap: Record<string, { minutes: number; tasks: number }> = {};
          dayReqs.forEach(r => {
            const t = r.technician || 'نامشخص';
            if (!techMap[t]) techMap[t] = { minutes: 0, tasks: 0 };
            techMap[t].tasks += 1;
            techMap[t].minutes += getWorkRequestDurationMinutes(r);
          });

          return {
            ...d,
            requests: dayReqs,
            totalMinutes,
            totalHours,
            taskCount,
            doneCount,
            activeCount,
            techMap
          };
        });

        const maxWeeklyHours = Math.max(...weeklyDayData.map(d => d.totalHours), 1);
        const maxWeeklyTasks = Math.max(...weeklyDayData.map(d => d.taskCount), 1);
        const totalWeeklyHoursSum = Math.round(weeklyDayData.reduce((s, d) => s + d.totalHours, 0) * 10) / 10;
        const totalWeeklyTasksSum = weeklyDayData.reduce((s, d) => s + d.taskCount, 0);
        const totalDoneCount = workRequests.filter(r => r.status === 'انجام شد').length;
        const busiestDay = [...weeklyDayData].sort((a, b) => b.totalHours - a.totalHours)[0];

        // محاسبه تعداد تکنسین‌های فعال در طول هفته
        const allActiveTechsSet = new Set<string>();
        workRequests.forEach(r => {
          if (r.technician) allActiveTechsSet.add(r.technician);
        });

        // روز انتخاب شده برای مشاهده ریز کارها
        const selectedDayObj = selectedChartDay ? weeklyDayData.find(d => d.key === selectedChartDay) : null;

        return (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
            <div className="max-w-5xl w-full max-h-[92vh] flex flex-col glass-panel-navy rounded-3xl navy-glow-border shadow-2xl overflow-hidden border border-cyan-500/40 my-auto">
              
              {/* Printable official letterhead with white background logo */}
              <div className="hidden print-only border-b-2 border-slate-800 p-6 pb-4 bg-white text-slate-900">
                <div className="flex items-center justify-between">
                  <img
                    src={COMPANY_LOGO_WHITEBG}
                    alt={BRAND_CONFIG.COMPANY_NAME}
                    className="h-14 w-auto object-contain"
                  />
                  <div className="text-center">
                    <h2 className="text-lg font-black">{BRAND_CONFIG.COMPANY_FULL_NAME}</h2>
                    <h3 className="text-sm font-bold text-slate-700">{printSettings.techServiceWeekly.docTitle}</h3>
                    <span className="text-xs text-slate-500 font-mono">بازه هفتگی: شنبه تا پنجشنبه • تاریخ چاپ: {getEnDateNow()}</span>
                  </div>
                  <div className="text-left text-xs font-mono space-y-1">
                    <div>کد سند: <b>{printSettings.techServiceWeekly.docCode}</b></div>
                    <div>تکنسین انتخابی: <b>{weeklyChartTechFilter}</b></div>
                    <div>ساعت: <b>{persianClock}</b></div>
                  </div>
                </div>
              </div>

              {/* هدر مدال گزارش و نمودار هفتگی */}
              <div className="p-5 sm:p-6 pb-4 border-b border-blue-900/60 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 flex flex-wrap items-center justify-between gap-4 no-print">
                <div className="flex items-center gap-3">
                  <img
                    src={COMPANY_LOGO}
                    alt={BRAND_CONFIG.COMPANY_NAME}
                    className="h-11 w-auto object-contain rounded-xl p-1 bg-black/60 border border-cyan-500/40 shadow-md shrink-0"
                  />
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-500/20">
                    <BarChart2 className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                      <span>گزارش تحلیلی و نمودار مقایسه هفتگی کارها</span>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">
                        شنبه تا پنجشنبه
                      </span>
                    </h3>
                    <p className="text-xs text-blue-300/80 mt-0.5">
                      {BRAND_CONFIG.COMPANY_NAME} • مقایسه بلادرنگ ساعت کارکرد و کارایی تکنسین‌ها
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setModalType('consumablesReport')}
                    className="flex items-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-bold shadow-md shadow-amber-950/60 transition-all cursor-pointer"
                    title="مشاهده آمار و گزارش لوازم مصرفی"
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span>گزارش لوازم مصرفی</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md shadow-blue-950/60 transition-all cursor-pointer"
                    title="چاپ گزارش تحلیلی هفتگی"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>چاپ A4</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalType('none')}
                    className="p-2 rounded-xl text-blue-300 hover:text-white hover:bg-blue-900/50 border border-blue-800/40 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* بدنه اسکرول‌شونده مدال گزارش */}
              <div className="p-5 sm:p-6 space-y-6 overflow-y-auto">
                
                {/* ابزارهای فیلتر و تغییر شاخص نمودار */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/80 border border-blue-900/60">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-950/70 text-emerald-300 border border-emerald-500/40">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>مقایسه برخط و لحظه‌ای کارکرد</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    {/* فیلتر تکنسین در نمودار */}
                    <div className="flex items-center gap-1.5 bg-blue-950/60 p-1 rounded-xl border border-blue-800/60">
                      <span className="text-[11px] text-blue-300 pr-2">تکنسین:</span>
                      <select
                        value={weeklyChartTechFilter}
                        onChange={(e) => setWeeklyChartTechFilter(e.target.value)}
                        className="bg-slate-900 text-white text-xs px-2.5 py-1 rounded-lg border border-blue-700/60 focus:outline-none focus:border-cyan-400 cursor-pointer"
                      >
                        <option value="همه">همه تکنسین‌ها</option>
                        {technicians.map((t, idx) => (
                          <option key={idx} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>

                    {/* سوئیچ نوع شاخص */}
                    <div className="flex items-center bg-blue-950/70 p-1 rounded-xl border border-blue-800/60 text-xs">
                      <button
                        type="button"
                        onClick={() => setWeeklyChartMetric('both')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          weeklyChartMetric === 'both' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-blue-300 hover:text-white'
                        }`}
                      >
                        ترکیبی
                      </button>
                      <button
                        type="button"
                        onClick={() => setWeeklyChartMetric('hours')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          weeklyChartMetric === 'hours' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-blue-300 hover:text-white'
                        }`}
                      >
                        ساعت کار
                      </button>
                      <button
                        type="button"
                        onClick={() => setWeeklyChartMetric('count')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          weeklyChartMetric === 'count' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-blue-300 hover:text-white'
                        }`}
                      >
                        تعداد کارها
                      </button>
                    </div>
                  </div>
                </div>

                {/* کارت‌های خلاصه و شاخص‌های کلیدی مقایسه هفتگی */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-blue-950/60 to-slate-900/60 border border-blue-800/40">
                    <div className="flex items-center gap-2 text-blue-300 text-xs mb-1">
                      <Clock className="w-4 h-4 text-cyan-400" />
                      <span>کل ساعت کار هفتگی</span>
                    </div>
                    <div className="text-lg sm:text-xl font-black text-cyan-300 font-mono">
                      {toFaDigits(totalWeeklyHoursSum)} <span className="text-xs font-normal text-cyan-200">ساعت</span>
                    </div>
                    <span className="text-[10px] text-blue-300/70 mt-0.5 block">
                      معادل {toFaDigits(Math.round(totalWeeklyHoursSum * 60))} دقیقه زمان ثبت‌شده
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-blue-950/60 to-slate-900/60 border border-blue-800/40">
                    <div className="flex items-center gap-2 text-blue-300 text-xs mb-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>مجموع کارهای هفتگی</span>
                    </div>
                    <div className="text-lg sm:text-xl font-black text-white font-mono">
                      {toFaDigits(totalWeeklyTasksSum)} <span className="text-xs font-normal text-blue-200">کار</span>
                    </div>
                    <span className="text-[10px] text-blue-300/70 mt-0.5 block">
                      {toFaDigits(totalDoneCount)} انجام شده — {toFaDigits(totalWeeklyTasksSum - totalDoneCount)} جاری
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-blue-950/60 to-slate-900/60 border border-blue-800/40">
                    <div className="flex items-center gap-2 text-blue-300 text-xs mb-1">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span>پرکارترین روز هفته</span>
                    </div>
                    <div className="text-lg sm:text-xl font-black text-amber-300">
                      {busiestDay && busiestDay.totalHours > 0 ? busiestDay.name : 'در انتظار ثبت'}
                    </div>
                    <span className="text-[10px] text-amber-300/80 mt-0.5 block font-mono">
                      {busiestDay && busiestDay.totalHours > 0 ? `${toFaDigits(busiestDay.totalHours)} ساعت (${toFaDigits(busiestDay.taskCount)} کار)` : '۰ ساعت'}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-b from-blue-950/60 to-slate-900/60 border border-blue-800/40">
                    <div className="flex items-center gap-2 text-blue-300 text-xs mb-1">
                      <Users className="w-4 h-4 text-indigo-400" />
                      <span>تکنسین‌های فعال هفته</span>
                    </div>
                    <div className="text-lg sm:text-xl font-black text-indigo-300 font-mono">
                      {toFaDigits(allActiveTechsSet.size)} <span className="text-xs font-normal text-indigo-200">از {toFaDigits(technicians.length)} نیرو</span>
                    </div>
                    <span className="text-[10px] text-blue-300/70 mt-0.5 block">
                      {weeklyChartTechFilter === 'همه' ? 'تمامی نفرات فنی' : `فیلتر روی ${weeklyChartTechFilter}`}
                    </span>
                  </div>
                </div>

                {/* راهنمای رنگی میله‌ها */}
                <div className="flex flex-wrap items-center justify-between text-xs text-blue-300/80 px-2 pt-1">
                  <div className="flex items-center gap-4">
                    {(weeklyChartMetric === 'both' || weeklyChartMetric === 'hours') && (
                      <div className="flex items-center gap-1.5">
                        <span className="w-3.5 h-3.5 rounded-md bg-gradient-to-tr from-cyan-500 to-blue-600 border border-cyan-300/50 shadow-sm"></span>
                        <span className="font-semibold text-cyan-200">ساعت کارکرد (ساعت)</span>
                      </div>
                    )}
                    {(weeklyChartMetric === 'both' || weeklyChartMetric === 'count') && (
                      <div className="flex items-center gap-1.5">
                        <span className="w-3.5 h-3.5 rounded-md bg-gradient-to-tr from-emerald-500 to-teal-600 border border-emerald-300/50 shadow-sm"></span>
                        <span className="font-semibold text-emerald-200">تعداد کارهای انجام‌شده / جاری</span>
                      </div>
                    )}
                  </div>
                  <div className="text-[11px] text-blue-400">
                    روی هر ستون روز کلیک کنید تا ریز کارها در کادر پایین باز شود
                  </div>
                </div>

                {/* بوم نمودار میله‌ای دوگانه مقایسه‌ای شنبه تا پنجشنبه */}
                <div className="p-4 sm:p-6 rounded-2xl bg-slate-950/60 border border-blue-900/50 relative overflow-hidden">
                  {/* خطوط زمینه راهنما */}
                  <div className="absolute inset-x-6 top-6 bottom-14 flex flex-col justify-between pointer-events-none opacity-20 border-b border-blue-700/50">
                    <div className="border-b border-blue-400/40 w-full"></div>
                    <div className="border-b border-blue-400/40 w-full"></div>
                    <div className="border-b border-blue-400/40 w-full"></div>
                    <div className="border-b border-blue-400/40 w-full"></div>
                  </div>

                  {/* ستون‌های ۶ روزه شنبه تا پنجشنبه */}
                  <div className="grid grid-cols-6 gap-2 sm:gap-4 relative z-10 pt-4">
                    {weeklyDayData.map((day) => {
                      const isSelected = selectedChartDay === day.key;
                      const hoursPct = maxWeeklyHours > 0 && day.totalHours > 0 
                        ? Math.min(100, Math.max(12, Math.round((day.totalHours / maxWeeklyHours) * 100))) 
                        : 6;
                      const tasksPct = maxWeeklyTasks > 0 && day.taskCount > 0 
                        ? Math.min(100, Math.max(12, Math.round((day.taskCount / maxWeeklyTasks) * 100))) 
                        : 6;

                      const techNamesInDay = Object.keys(day.techMap);

                      return (
                        <div
                          key={day.key}
                          onClick={() => setSelectedChartDay(selectedChartDay === day.key ? null : day.key)}
                          className={`flex flex-col items-center justify-between p-2 sm:p-3 rounded-2xl transition-all cursor-pointer border ${
                            isSelected
                              ? 'bg-blue-900/50 border-cyan-400 ring-2 ring-cyan-400/40 shadow-lg shadow-cyan-500/20'
                              : 'bg-blue-950/30 hover:bg-blue-900/30 border-blue-800/40 hover:border-cyan-500/40'
                          }`}
                          title={`کلیک برای مشاهده جزئیات کارهای روز ${day.name}`}
                        >
                          {/* ناحیه میله‌های عمودی */}
                          <div className="h-44 sm:h-52 w-full flex items-end justify-center gap-1.5 sm:gap-2.5 px-1 pb-2 border-b border-blue-900/50">
                            {/* میله ساعت کارکرد */}
                            {(weeklyChartMetric === 'both' || weeklyChartMetric === 'hours') && (
                              <div className="flex-1 flex flex-col items-center h-full justify-end group">
                                <span className="text-[10px] sm:text-xs font-mono font-bold text-cyan-300 mb-1 transition-transform group-hover:scale-110">
                                  {day.totalHours > 0 ? `${toFaDigits(day.totalHours)}س` : '۰'}
                                </span>
                                <div
                                  style={{ height: `${hoursPct}%` }}
                                  className={`w-full rounded-t-xl transition-all duration-500 shadow-md ${
                                    day.totalHours > 0
                                      ? 'bg-gradient-to-t from-blue-700 via-cyan-600 to-cyan-400 shadow-cyan-500/30'
                                      : 'bg-blue-950/40 border border-dashed border-blue-800/40'
                                  }`}
                                />
                              </div>
                            )}

                            {/* میله تعداد کارها */}
                            {(weeklyChartMetric === 'both' || weeklyChartMetric === 'count') && (
                              <div className="flex-1 flex flex-col items-center h-full justify-end group">
                                <span className="text-[10px] sm:text-xs font-mono font-bold text-emerald-300 mb-1 transition-transform group-hover:scale-110">
                                  {day.taskCount > 0 ? `${toFaDigits(day.taskCount)}` : '۰'}
                                </span>
                                <div
                                  style={{ height: `${tasksPct}%` }}
                                  className={`w-full rounded-t-xl transition-all duration-500 shadow-md ${
                                    day.taskCount > 0
                                      ? 'bg-gradient-to-t from-emerald-700 via-teal-600 to-emerald-400 shadow-emerald-500/30'
                                      : 'bg-emerald-950/20 border border-dashed border-emerald-900/40'
                                  }`}
                                />
                              </div>
                            )}
                          </div>

                          {/* اطلاعات و برچسب روز */}
                          <div className="w-full text-center pt-2">
                            <div className="font-black text-xs sm:text-sm text-white flex items-center justify-center gap-1">
                              <span>{day.name}</span>
                            </div>
                            
                            <div className="mt-1 flex flex-col gap-0.5 text-[10px] font-mono">
                              <span className="text-cyan-300 font-bold">
                                {toFaDigits(day.totalHours)} ساعت
                              </span>
                              <span className="text-emerald-300">
                                {toFaDigits(day.taskCount)} کار
                              </span>
                            </div>

                            {/* آیکون تکنسین‌های فعال آن روز */}
                            <div className="mt-2 pt-1 border-t border-blue-900/40 flex items-center justify-center gap-0.5 flex-wrap min-h-[22px]">
                              {techNamesInDay.length > 0 ? (
                                techNamesInDay.slice(0, 3).map((t, tidx) => (
                                  <span
                                    key={tidx}
                                    className="text-[9px] px-1.5 py-0.2 rounded-md bg-cyan-950 text-cyan-200 border border-cyan-500/40"
                                    title={`${t}: ${toFaDigits(day.techMap[t].tasks)} کار (${toFaDigits(Math.round(day.techMap[t].minutes / 6) / 10)} س)`}
                                  >
                                    {getTechNames(t).last}
                                  </span>
                                ))
                              ) : (
                                <span className="text-[9px] text-blue-500/60">—</span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* بخش مشاهده ریز کارهای روز انتخابی */}
                {selectedDayObj && (
                  <div className="p-4 sm:p-5 rounded-2xl bg-blue-950/40 border border-cyan-500/40 space-y-3 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-cyan-400" />
                        <span>ریز پرونده‌ها و کارهای روز {selectedDayObj.name} ({toFaDigits(selectedDayObj.taskCount)} مورد - مجموع {toFaDigits(selectedDayObj.totalHours)} ساعت)</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setSelectedChartDay(null)}
                        className="text-xs text-blue-400 hover:text-white px-2 py-0.5 rounded-lg border border-blue-800 cursor-pointer"
                      >
                        بستن ✕
                      </button>
                    </div>

                    {selectedDayObj.requests.length === 0 ? (
                      <p className="text-xs text-blue-300/70 py-4 text-center">
                        هیچ کاری در روز {selectedDayObj.name} ثبت نشده است. با ثبت درخواست کار جدید، به صورت لحظه‌ای در این روز درج خواهد شد.
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1">
                        {selectedDayObj.requests.map((r, ridx) => (
                          <div key={ridx} className="p-3 rounded-xl bg-slate-900/80 border border-blue-900/60 text-xs space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-cyan-300">{r.code}</span>
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                r.status === 'انجام شد' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' : 'bg-amber-950 text-amber-300 border border-amber-500/40'
                              }`}>
                                {r.status}
                              </span>
                            </div>
                            <div className="font-bold text-white line-clamp-1">{r.title}</div>
                            <div className="flex items-center justify-between text-[11px] text-blue-300/80">
                              <span>مجری: {r.technician || 'نامشخص'}</span>
                              <span className="font-mono text-cyan-300">
                                {r.durationMinutes ? `${toFaDigits(r.durationMinutes)} د` : '—'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* اطلاع‌رسانی آماده‌سازی در صورت صفر بودن فعلی داده‌ها */}
                {workRequests.length === 0 && (
                  <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs text-cyan-200 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        جدول کارها با توجه به درخواست شما کاملاً صفر و آماده ورود داده‌های واقعی است. به محض اینکه اولین درخواست یا دستور کار را ثبت نمایید، این نمودار به صورت بلادرنگ ساعات کار و روز مربوطه را ترسیم می‌کند.
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const nowShamsi = '1405/07/24 — 10:00';
                        const sampleReq: WorkRequest = {
                          code: 'WR000001',
                          workOrderCode: 'WO000001',
                          place: 'سالن تولید1',
                          created: nowShamsi,
                          title: 'سرویس اضطراری خط بسته‌بندی و تعویض بلبرینگ',
                          priority: 'عادی (غیراضطراری)',
                          description: 'بررسی صدا و لرزش یاتاقان',
                          status: 'انجام شد',
                          technician: technicians[0] || 'احمد رضایی',
                          operationType: 'مکانیک',
                          actionDetails: 'بلبرینگ تعویض و گریس‌کاری انجام گرفت.',
                          woDate: '1405/07/24',
                          woStartTime: '08:30',
                          woEndTime: '11:00',
                          durationMinutes: 150,
                          completedAt: nowShamsi,
                          completedTimestamp: Date.now()
                        };
                        setWorkRequests([sampleReq]);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition-all shadow-md cursor-pointer flex items-center gap-1.5 shrink-0"
                    >
                      <span>➕ تست سریع لحظه‌ای نمودار با ۱ کار نمونه</span>
                    </button>
                  </div>
                )}

              </div>

              {/* فوتر مدال گزارش */}
              <div className="p-4 sm:p-5 border-t border-blue-900/60 bg-slate-950/80 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 py-2 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  <Printer className="w-4 h-4" />
                  <span>چاپ صفحه A4</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="py-2 px-5 rounded-xl border border-blue-800/40 text-blue-300 hover:text-white text-xs font-bold transition-all cursor-pointer"
                >
                  بستن
                </button>
              </div>

            </div>
          </div>
        );
      })()}



      {/* MODAL: Oil Tank Refill / Consume Transaction */}
      {modalType === 'tankTx' && selectedTankForTx && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                  <Droplet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {tankTxType === 'refill' ? 'ثبت ورود / شارژ روغن' : 'ثبت مصرف روغن در خط تولید'}
                  </h3>
                  <span className="text-[11px] text-amber-300">{selectedTankForTx.name}</span>
                </div>
              </div>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-blue-200 mb-1">نوع عملیات:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTankTxType('refill')}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all ${
                      tankTxType === 'refill'
                        ? 'bg-emerald-600 text-white border-emerald-400'
                        : 'bg-slate-900 text-blue-300 border-blue-900/40'
                    }`}
                  >
                    + شارژ / ورود جدید
                  </button>
                  <button
                    type="button"
                    onClick={() => setTankTxType('consume')}
                    className={`py-2 px-3 rounded-xl font-bold border transition-all ${
                      tankTxType === 'consume'
                        ? 'bg-amber-600 text-white border-amber-400'
                        : 'bg-slate-900 text-blue-300 border-blue-900/40'
                    }`}
                  >
                    - خروج / مصرف خط
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-blue-200 mb-1">مخزن هدف:</label>
                <select
                  value={selectedTankForTx.id}
                  onChange={e => {
                    const found = oilTanks.find(t => t.id === parseInt(e.target.value, 10));
                    if (found) setSelectedTankForTx(found);
                  }}
                  className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  {oilTanks.map(t => (
                    <option key={t.id} value={t.id}>{t.name} (موجودی فعلی: {fa(t.currentLiters)} لیتر)</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-blue-200 mb-1">مقدار (لیتر):</label>
                <input
                  type="number"
                  value={tankTxAmount}
                  onChange={e => setTankTxAmount(toEnDigits(e.target.value))}
                  placeholder="مثلاً 100"
                  className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono text-center"
                />
              </div>

              {tankTxType === 'consume' && (
                <div>
                  <label className="block text-blue-200 mb-1">تحویل به سالن / بخش:</label>
                  <select
                    value={tankTxHall}
                    onChange={e => setTankTxHall(e.target.value)}
                    className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    {FACTORY_LOCATIONS.map((loc, i) => (
                      <option key={i} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-blue-900/40">
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="py-2 px-4 rounded-xl border border-blue-800/40 text-blue-300 text-xs hover:bg-blue-900/30"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleSaveTankTx}
                className="py-2 px-5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold text-xs shadow-md shadow-amber-950/50"
              >
                ثبت در موجودی مخزن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Supabase Cloud Database Configuration */}
      {modalType === 'supabaseSettings' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="max-w-2xl w-full glass-panel-navy p-6 rounded-2xl navy-glow-border space-y-5 my-8 max-h-[90vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>تنظیم اتصال دیتابیس ابری Supabase</span>
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                      supabaseConnected 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {supabaseConnected ? 'متصل و فعال' : 'منتظر تنظیم کلید'}
                    </span>
                  </h3>
                  <p className="text-xs text-blue-300/70 mt-0.5">
                    ذخیره همیشگی درخواست‌ها و دستورکارها در سرور ابری Supabase
                  </p>
                </div>
              </div>
              <button onClick={() => setModalType('none')} className="text-blue-300 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Visual 3-Step Guide based on User's Dashboard Screenshot */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-blue-900/50 space-y-3">
              <h4 className="text-xs font-bold text-cyan-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>راهنمای ۳ مرحله‌ای دقیق طبق تصویر پنل Supabase شما:</span>
              </h4>

              <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-300">
                <div className="p-2.5 rounded-lg bg-blue-950/40 border border-blue-900/40 flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">1</span>
                  <div>
                    <strong className="text-white block mb-0.5">رفتن به بخش SQL Editor در داشبورد:</strong>
                    <span className="text-[11px] text-blue-200/80">
                      در تصویر داشبوردتان، از منوی سمت چپ گزینه سوم یعنی <strong>SQL Editor</strong> (با آیکون &gt;_) را کلیک کنید و یک <strong>New query</strong> باز کنید.
                    </span>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-blue-950/40 border border-blue-900/40 flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">2</span>
                  <div className="flex-1">
                    <strong className="text-white block mb-0.5">کپی و اجرای اسکریپت ساخت جدول:</strong>
                    <span className="text-[11px] text-blue-200/80 block mb-2">
                      دکمه زیر را بزنید تا کد ساخت جدول <code className="text-cyan-300">work_requests</code> کپی شود. آن را در SQL Editor پیست کرده و دکمه سبز رنگ <strong>Run</strong> را بزنید.
                    </span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(SQL_SCHEMA_SCRIPT);
                        setSqlCopied(true);
                        setTimeout(() => setSqlCopied(false), 3000);
                      }}
                      className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold transition-all"
                    >
                      {sqlCopied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{sqlCopied ? 'کد اسکریپت SQL کپی شد!' : 'کپی اسکریپت SQL ساخت جدول'}</span>
                    </button>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-blue-950/40 border border-blue-900/40 flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">3</span>
                  <div>
                    <strong className="text-white block mb-0.5">دریافت کلید API Keys:</strong>
                    <span className="text-[11px] text-blue-200/80">
                      در پایین همان صفحه اصلی داشبورد روی دکمه <strong>API Keys</strong> (یا منوی تنظیمات Project Settings &gt; API) کلیک کنید و کلید <strong>anon public</strong> را کپی کرده و در کادر زیر قرار دهید.
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Input Form */}
            <div className="space-y-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-blue-200 mb-1 flex items-center justify-between">
                  <span>آدرس پروژه (Project URL)</span>
                  <span className="text-[10px] text-cyan-300 font-mono">استخراج شده از پنل شما</span>
                </label>
                <input
                  type="text"
                  value={supabaseUrlInput}
                  onChange={e => setSupabaseUrlInput(e.target.value)}
                  placeholder="https://your-project-id.supabase.co"
                  dir="ltr"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-blue-800/60 text-slate-100 text-xs font-mono focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-blue-200 mb-1 flex items-center justify-between">
                  <span>کلید عمومی پروژه (anon public key)</span>
                  <span className="text-[10px] text-emerald-400 font-mono">public anon key</span>
                </label>
                <input
                  type="text"
                  value={supabaseKeyInput}
                  onChange={e => setSupabaseKeyInput(e.target.value)}
                  placeholder="کلید anon (رشته‌ای طولانی با فرمت eyJhbGciOi...)"
                  dir="ltr"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-blue-800/60 text-slate-100 text-xs font-mono focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Status Feedback Message */}
            {supabaseStatusMsg && (
              <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                supabaseStatusMsg.isError 
                  ? 'bg-rose-950/80 text-rose-200 border border-rose-500/40' 
                  : 'bg-emerald-950/80 text-emerald-200 border border-emerald-500/40'
              }`}>
                {supabaseStatusMsg.isError ? <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />}
                <span>{supabaseStatusMsg.text}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-blue-900/40">
              <button
                onClick={handleSaveAndTestSupabase}
                disabled={supabaseLoading}
                className="w-full sm:w-auto flex items-center justify-center gap-2 py-2 px-5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-emerald-900/50 disabled:opacity-50"
              >
                {supabaseLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>{supabaseLoading ? 'در حال تست ارتباط...' : 'تست و ذخیره اتصال به Supabase'}</span>
              </button>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setModalType('none')}
                  className="py-2 px-4 rounded-xl border border-blue-800/40 text-blue-300 text-xs hover:text-white"
                >
                  بستن
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* مدال جامع گزارش و آمار لوازم مصرفی کارخانه */}
      {modalType === 'consumablesReport' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-5xl rounded-3xl bg-gradient-to-b from-slate-900 via-[#0a1628] to-slate-950 border border-amber-500/40 shadow-2xl shadow-amber-950/40 text-right p-5 sm:p-7 space-y-6 my-auto print-container max-h-[92vh] overflow-y-auto">
            
            {/* Printable official letterhead with white background logo */}
            <div className="hidden print-only border-b-2 border-slate-800 p-6 pb-4 bg-white text-slate-900">
              <div className="flex items-center justify-between">
                <img
                  src={COMPANY_LOGO_WHITEBG}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-14 w-auto object-contain"
                />
                <div className="text-center">
                  <h2 className="text-lg font-black">{BRAND_CONFIG.COMPANY_NAME}</h2>
                  <h3 className="text-sm font-bold text-slate-700">{printSettings.consumablesReport.docTitle}</h3>
                  <span className="text-xs text-slate-500 font-mono">انبار قطعات یدکی و مصرفی • تاریخ چاپ: {getEnDateNow()}</span>
                </div>
                <div className="text-left text-xs font-mono space-y-1">
                  <div>کد سند: <b>{printSettings.consumablesReport.docCode}</b></div>
                  <div>کل اقلام: <b>{toFaDigits(getConsumablesSummary().grandTotal)} قلم</b></div>
                  <div>ساعت چاپ: <b>{persianClock}</b></div>
                </div>
              </div>
            </div>

            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-blue-900/40 no-print">
              <div className="flex items-center gap-3">
                <img
                  src={COMPANY_LOGO}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-12 w-auto object-contain rounded-2xl p-1 bg-black/60 border border-amber-500/40 shadow-lg shadow-amber-950/60 shrink-0"
                />
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-600 via-orange-600 to-amber-500 flex items-center justify-center text-white font-bold shadow-lg shadow-amber-950/60 shrink-0">
                  <Package className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                    <span>گزارش جامع لوازم و قطعات مصرفی</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-950/90 text-amber-300 border border-amber-500/40 font-mono font-bold">
                      {toFaDigits(getConsumablesSummary().grandTotal)} قلم کل
                    </span>
                  </h3>
                  <p className="text-xs text-blue-200/70 mt-0.5">
                    {BRAND_CONFIG.COMPANY_NAME} • پایش آمار اقلام مصرفی، تفکیک گروهی برق و مکانیک
                  </p>
                </div>
              </div>

              {/* Header Action Buttons */}
              <div className="flex items-center gap-2 no-print shrink-0">
                <button
                  type="button"
                  onClick={handleClearAllSparePartsReports}
                  className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/35 border border-rose-500/40 text-rose-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                  title="پاکسازی کامل گزارش‌های مصرف قطعات و شروع از صفر"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>پاکسازی کلیه گزارش‌ها</span>
                </button>

                <button
                  type="button"
                  onClick={exportConsumablesToCsv}
                  className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-950/60 transition-all cursor-pointer"
                  title="دانلود فایل اکسل قطعات مصرفی با فرمت CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>اکسل (CSV)</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold shadow-md shadow-blue-950/60 transition-all cursor-pointer"
                  title="چاپ گزارش کامل در قطع استاندارد A4"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>چاپ A4</span>
                </button>

                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="w-9 h-9 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-blue-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-blue-800/40"
                  title="بستن"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* سوئیچ اصلی میان انبار یکپارچه قطعات یدکی و گزارش آماری مصرف */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-2 rounded-2xl bg-slate-950/90 border border-blue-900/60 no-print">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setConsumablesMainTab('inventory')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    consumablesMainTab === 'inventory'
                      ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md shadow-amber-950/60 border border-amber-400/50'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Package className="w-4 h-4 text-amber-400" />
                  <span>انبار و مدیریت لوازم یدکی (یکپارچه با PM)</span>
                  <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/40 text-amber-200">
                    {toFaDigits(unifiedSpareParts.length)}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setConsumablesMainTab('report')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    consumablesMainTab === 'report'
                      ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-md shadow-blue-950/60 border border-cyan-400/50'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <BarChart2 className="w-4 h-4 text-cyan-400" />
                  <span>گزارش آماری مصرف قطعات</span>
                </button>
              </div>

            </div>

            {/* بخش ۱: انبار یکپارچه قطعات یدکی با امکان تفکیک خدمات فنی و PM */}
            {consumablesMainTab === 'inventory' && (
              <UnifiedSparePartsManager
                accentColor="amber"
              />
            )}

            {/* بخش ۲: گزارش آماری مصرف قطعات در کارخانه */}
            {consumablesMainTab === 'report' && (
              <div className="space-y-6">
            {/* KPI Cards: ۴ کارت آماری */}
            {(() => {
              const summary = getConsumablesSummary();
              return (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/60 to-slate-900 border border-amber-500/40 space-y-1">
                    <span className="text-[11px] text-amber-200/80 block font-medium">مجموع کل اقلام مصرفی</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-amber-300 font-mono">
                        {toFaDigits(summary.grandTotal)}
                      </span>
                      <span className="text-[10px] text-amber-300/70">قلم / قطعه</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-br from-yellow-950/60 to-slate-900 border border-yellow-500/40 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-yellow-200/80 font-medium">لوازم و قطعات برقی</span>
                      <Zap className="w-3.5 h-3.5 text-yellow-400" />
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-yellow-300 font-mono">
                        {toFaDigits(summary.electricalTotal)}
                      </span>
                      <span className="text-[10px] text-yellow-300/70">قلم</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-slate-900 border border-cyan-500/40 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-cyan-200/80 font-medium">لوازم و قطعات مکانیکی</span>
                      <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-cyan-300 font-mono">
                        {toFaDigits(summary.mechanicalTotal)}
                      </span>
                      <span className="text-[10px] text-cyan-300/70">قلم</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/60 to-slate-900 border border-indigo-500/40 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-indigo-200/80 font-medium">سایر اقلام و مصرفی‌ها</span>
                      <Box className="w-3.5 h-3.5 text-indigo-400" />
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-indigo-300 font-mono">
                        {toFaDigits(summary.otherTotal)}
                      </span>
                      <span className="text-[10px] text-indigo-300/70">قلم</span>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* نوار فیلتر و جستجو */}
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-blue-900/60 space-y-3 no-print">
              {/* تب‌های دسته‌بندی */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                  {(['همه', 'برقی', 'مکانیکی', 'سایر'] as const).map(tab => {
                    const isActive = consumablesReportTab === tab;
                    return (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setConsumablesReportTab(tab)}
                        className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                          isActive
                            ? 'bg-amber-600 text-white shadow-md shadow-amber-950/60 border border-amber-400/50'
                            : 'bg-slate-900/80 text-blue-300 hover:text-white hover:bg-blue-900/40 border border-blue-800/40'
                        }`}
                      >
                        {tab === 'برقی' && <Zap className="w-3 h-3 text-yellow-300" />}
                        {tab === 'مکانیکی' && <Wrench className="w-3 h-3 text-cyan-300" />}
                        {tab === 'سایر' && <Box className="w-3 h-3 text-indigo-300" />}
                        <span>{tab === 'همه' ? 'همه دسته‌بندی‌ها' : `گروه ${tab}`}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="text-xs text-blue-300/70 font-mono">
                  {toFaDigits(getAggregatedConsumables().length)} ردیف کالا یافت شد
                </div>
              </div>

              {/* فیلتر سالن، تکنسین و جستجوی متنی */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-blue-900/40">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-blue-400 absolute right-3 top-2.5" />
                  <input
                    type="text"
                    value={consumablesSearch}
                    onChange={e => setConsumablesSearch(e.target.value)}
                    placeholder="جستجو در نام قطعه، سالن یا تکنسین..."
                    className="w-full bg-slate-900 border border-blue-800/60 rounded-xl pr-8 pl-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                  {consumablesSearch && (
                    <button
                      type="button"
                      onClick={() => setConsumablesSearch('')}
                      className="absolute left-2.5 top-2 text-blue-400 hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>

                <div>
                  <select
                    value={consumablesHallFilter}
                    onChange={e => setConsumablesHallFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-blue-800/60 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="همه">همه سالن‌ها و بخش‌ها</option>
                    {FACTORY_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <select
                    value={consumablesTechFilter}
                    onChange={e => setConsumablesTechFilter(e.target.value)}
                    className="w-full bg-slate-900 border border-blue-800/60 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="همه">همه تکنسین‌های مجری</option>
                    {technicians.map((tech, idx) => (
                      <option key={idx} value={tech}>{tech}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* جدول تجمیعی اقلام مصرفی */}
            {(() => {
              const aggregatedItems = getAggregatedConsumables();

              if (aggregatedItems.length === 0) {
                return (
                  <div className="p-10 rounded-2xl bg-blue-950/20 border border-dashed border-blue-800/40 text-center space-y-2">
                    <Package className="w-10 h-10 text-amber-400/60 mx-auto" />
                    <h4 className="text-sm font-bold text-white">هیچ قلم مصرفی مطابق فیلتر یافت نشد</h4>
                    <p className="text-xs text-blue-300/70 max-w-md mx-auto">
                      برای ثبت قطعات مصرفی، هنگام بستن دستور کار در فرم یکپارچه (WR + WO)، اقلام مورد نظر را در ۳ زبانه برقی، مکانیکی و سایر انتخاب و ثبت نمایید.
                    </p>
                  </div>
                );
              }

              return (
                <div className="overflow-x-auto rounded-2xl border border-blue-900/40">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-slate-950/80 border-b border-blue-900/60 text-blue-300">
                        <th className="py-3 px-3 w-12 text-center">ردیف</th>
                        <th className="py-3 px-3">نام قطعه / قلم مصرفی</th>
                        <th className="py-3 px-3">گروه</th>
                        <th className="py-3 px-3 text-center">مجموع مصرف</th>
                        <th className="py-3 px-3 text-center">تعداد دفعات</th>
                        <th className="py-3 px-3">سالن‌ها و محل‌های مصرف</th>
                        <th className="py-3 px-3">تکنسین‌های مجری</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-blue-900/20 bg-slate-900/40">
                      {aggregatedItems.map((item, idx) => (
                        <tr key={idx} className="hover:bg-blue-950/40 transition-colors">
                          <td className="py-3 px-3 text-center font-mono text-blue-400">
                            {toFaDigits(idx + 1)}
                          </td>

                          <td className="py-3 px-3">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
                              <span className="font-bold text-white text-xs">{item.name}</span>
                            </div>
                          </td>

                          <td className="py-3 px-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              item.category === 'برقی'
                                ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                                : item.category === 'مکانیکی'
                                ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
                                : 'bg-indigo-950/80 text-indigo-300 border-indigo-500/40'
                            }`}>
                              {item.category}
                            </span>
                          </td>

                          <td className="py-3 px-3 text-center">
                            <span className="font-mono font-black text-amber-300 text-sm">
                              {toFaDigits(item.totalCount)}
                            </span>
                            <span className="text-[10px] text-blue-300/70 mr-1">{item.unit}</span>
                          </td>

                          <td className="py-3 px-3 text-center">
                            <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-blue-950 border border-blue-800/40 text-cyan-300">
                              {toFaDigits(item.usageCount)} بار
                            </span>
                          </td>

                          <td className="py-3 px-3 max-w-xs">
                            <div className="flex flex-wrap gap-1">
                              {Array.from(item.places).map((p, pi) => (
                                <span key={pi} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 text-blue-200 border border-blue-900/40">
                                  {p}
                                </span>
                              ))}
                            </div>
                          </td>

                          <td className="py-3 px-3 max-w-xs">
                            <div className="flex flex-wrap gap-1">
                              {Array.from(item.technicians).map((t, ti) => (
                                <span key={ti} className="text-[10px] px-1.5 py-0.5 rounded bg-blue-950 text-cyan-300 border border-cyan-500/30">
                                  {t}
                                </span>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
            })()}
            </div>
            )}

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-blue-900/40 text-xs text-blue-400/80">
              <span>گزارش رسمی مصرف قطعات — فرمت خروجی منطبق بر استاندارد انبار و نگهداری تعمیرات</span>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="py-2 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all cursor-pointer no-print"
              >
                بستن گزارش
              </button>
            </div>
          </div>
        </div>
      )}

      {/* مدال مدیریت حالت آفلاین و همگام‌سازی خودکار */}
      {modalType === 'offlineInfo' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl rounded-3xl bg-gradient-to-b from-slate-900 via-[#0a1628] to-slate-950 border border-blue-500/40 shadow-2xl shadow-blue-950/60 text-right p-6 sm:p-7 space-y-5 my-auto">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <div className="flex items-center gap-3">
                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold shadow-lg shrink-0 ${
                  isOnline 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-emerald-950/50' 
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-amber-950/50'
                }`}>
                  {isOnline ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                    <span>مدیریت کارکرد آفلاین و همگام‌سازی ابری</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                      isOnline
                        ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/40'
                        : 'bg-amber-950/90 text-amber-300 border-amber-500/40'
                    }`}>
                      {isOnline ? 'آنلاین' : 'آفلاین'}
                    </span>
                  </h3>
                  <p className="text-xs text-blue-300/70 mt-0.5">
                    پایش دائمی اتصال اینترنت، ثبت بدون وقفه داده‌ها و ارسال خودکار به دیتابیس
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setModalType('none')}
                className="w-8 h-8 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-blue-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-blue-800/40"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* کارت‌های راهنما و وضعیت */}
            <div className="space-y-3">
              {/* پاسخ مستقیم به مدت زمان کارکرد آفلاین */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/60 to-slate-900 border border-cyan-500/30 space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-cyan-300">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>مدت زمان کارکرد آفلاین:</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono">
                    کاملاً نامحدود (بدون انقضا)
                  </span>
                </div>
                <p className="text-xs text-blue-200/80 leading-relaxed pt-1">
                  نرم‌افزار بدون هیچ محدودیتی می‌تواند برای <strong>۱ روز، ۱ هفته، ۱ ماه یا بیشتر</strong> در حالت کاملاً آفلاین کار کند. کلیه درخواست‌ها، اقدامات تکنسین و قطعات مصرفی در حافظه محلی ذخیره می‌شوند و هیچ اطلاعاتی نمی‌پرد.
                </p>
              </div>

              {/* وضعیت صف ارسال به سرور */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-blue-900/50 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-blue-200 font-medium">رکوردهای در صف ارسال به پایگاه ابری:</span>
                  <span className="font-mono font-bold text-sm text-amber-300 bg-amber-950/80 px-2.5 py-0.5 rounded-lg border border-amber-500/40">
                    {toFaDigits(pendingSyncQueue.length)} مورد
                  </span>
                </div>
                <p className="text-[11px] text-blue-300/60 leading-relaxed">
                  هنگامی که اینترنت قطع است، کارهای جدید در این صف باقی می‌مانند و به محض برقراری اتصال مجدد شبکه، به صورت کاملاً خودکار در سرور ذخیره می‌شوند.
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-blue-900/40">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={syncOfflineQueueToSupabase}
                  disabled={isSyncing || pendingSyncQueue.length === 0}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md shadow-emerald-950/50 disabled:opacity-40 transition-all cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'در حال ارسال...' : 'همگام‌سازی دستی اکنون'}</span>
                </button>

                <button
                  type="button"
                  onClick={exportTechnicalOrdersToCsv}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 text-xs font-bold border border-cyan-500/30 transition-all cursor-pointer"
                  title="دانلود فایل پشتیبان آفلاین اکسل"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>پشتیبان اکسل</span>
                </button>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setModalType('supabaseSettings')}
                  className="py-2 px-3 rounded-xl border border-blue-800/40 text-blue-300 text-xs hover:text-white"
                >
                  تنظیمات پایگاه داده
                </button>
                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                >
                  بستن
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ثبت برنامه نگهداری پیشگیرانه جدید (Add PM Schedule) */}
      {/* ======================================================== */}
      {modalType === 'addPmSchedule' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="glass-panel-navy border border-indigo-500/50 p-6 rounded-3xl max-w-2xl w-full space-y-5 shadow-2xl animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto scrollbar-thin">
            
            <div className="flex items-center justify-between pb-3 border-b border-indigo-500/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-600 text-white flex items-center justify-center shadow-lg">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">تعریف برنامه نگهداری پیشگیرانه جدید (PM)</h3>
                  <p className="text-xs text-blue-300/70">ثبت دوره تناوب، چک‌لیست و تخصیص تکنسین جهت سرویس ادواری</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-slate-800 text-blue-300 hover:text-white flex items-center justify-center transition-colors border border-blue-800/40"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNewPm} className="space-y-4 text-xs">
              
              {/* نام و کد تجهیز */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-blue-200 font-semibold mb-1">نام تجهیز / ماشین خط تولید *:</label>
                  <input
                    type="text"
                    required
                    value={pmEqName}
                    onChange={e => setPmEqName(e.target.value)}
                    placeholder="مثلاً: تراش CNC سوئیسی تورنوس ۵ محور"
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  />
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">کد شناسایی تجهیز (تگ فنی):</label>
                  <input
                    type="text"
                    value={pmEqCode}
                    onChange={e => setPmEqCode(e.target.value)}
                    placeholder="مثلاً: TOR-05 یا CNC-02"
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400 font-mono text-center"
                  />
                </div>
              </div>

              {/* عنوان اقدام PM و سالن */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-blue-200 font-semibold mb-1">عنوان بازرسی و اقدام PM *:</label>
                  <input
                    type="text"
                    required
                    value={pmTitle}
                    onChange={e => setPmTitle(e.target.value)}
                    placeholder="مثلاً: تعویض فیلتر هیدرولیک و پایش ارتعاش بلبرینگ"
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  />
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">سالن یا بخش استقرار:</label>
                  <select
                    value={pmHall}
                    onChange={e => setPmHall(e.target.value)}
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  >
                    {FACTORY_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* دسته تخصصی، دوره تناوب و اولویت */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-blue-200 font-semibold mb-1">دسته‌بندی تخصصی:</label>
                  <select
                    value={pmCategory}
                    onChange={e => setPmCategory(e.target.value as PmCategory)}
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  >
                    <option value="مکانیک">مکانیک</option>
                    <option value="برق">برق</option>
                    <option value="هیدرولیک">هیدرولیک</option>
                    <option value="روانکاری">روانکاری</option>
                    <option value="تاسیسات">تاسیسات</option>
                  </select>
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">دوره تناوب زمانی:</label>
                  <select
                    value={pmPeriodicity}
                    onChange={e => {
                      const val = e.target.value as PmPeriodicity;
                      setPmPeriodicity(val);
                      if (val === 'روزانه') setPmIntervalDays(1);
                      else if (val === 'هفتگی') setPmIntervalDays(7);
                      else if (val === 'دو هفته') setPmIntervalDays(14);
                      else if (val === 'ماهانه') setPmIntervalDays(30);
                      else if (val === 'سه ماهه') setPmIntervalDays(90);
                      else if (val === 'شش ماهه') setPmIntervalDays(180);
                      else if (val === 'سالانه') setPmIntervalDays(365);
                    }}
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  >
                    <option value="روزانه">روزانه (۱ روز)</option>
                    <option value="هفتگی">هفتگی (۷ روز)</option>
                    <option value="دو هفته">دو هفته (۱۴ روز)</option>
                    <option value="ماهانه">ماهانه (۳۰ روز)</option>
                    <option value="سه ماهه">سه ماهه / فصلی (۹۰ روز)</option>
                    <option value="شش ماهه">شش ماهه (۱۸۰ روز)</option>
                    <option value="سالانه">سالانه (۳۶۵ روز)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">سطح اولویت بازرسی:</label>
                  <select
                    value={pmPriority}
                    onChange={e => setPmPriority(e.target.value as PmPriority)}
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  >
                    <option value="بحرانی">بحرانی (توقف فوری تولید در صورت غفلت)</option>
                    <option value="مهم">مهم (سرویس ادواری اصلی)</option>
                    <option value="عادی">عادی (پایش عمومی)</option>
                  </select>
                </div>
              </div>

              {/* تکنسین مسئول، کارکرد ساعتی و مدت زمان */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-blue-200 font-semibold mb-1">تکنسین مسئول انجام:</label>
                  <select
                    value={pmTech}
                    onChange={e => setPmTech(e.target.value)}
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400"
                  >
                    {technicians.map((t, i) => (
                      <option key={i} value={t}>{t}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">کارکرد ساعتی (اختیاری):</label>
                  <input
                    type="number"
                    value={pmIntervalHours}
                    onChange={e => setPmIntervalHours(Number(e.target.value) || 0)}
                    placeholder="مثلاً: 500 ساعت"
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400 font-mono text-center"
                  />
                </div>

                <div>
                  <label className="block text-blue-200 font-semibold mb-1">مدت زمان تقریبی (دقیقه):</label>
                  <input
                    type="number"
                    value={pmEstMinutes}
                    onChange={e => setPmEstMinutes(Number(e.target.value) || 30)}
                    placeholder="مثلاً: 60"
                    className="w-full bg-slate-950 border border-blue-900/60 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-400 font-mono text-center"
                  />
                </div>
              </div>

              {/* دستورالعمل اجرایی و نکات ایمنی */}
              <div>
                <label className="block text-blue-200 font-semibold mb-1">دستورالعمل اجرایی بازرسی و نکات ایمنی (LOTO):</label>
                <textarea
                  rows={2}
                  value={pmInstructions}
                  onChange={e => setPmInstructions(e.target.value)}
                  placeholder="اقدامات ایمنی قبل از شروع، روش تست، استانداردهای تلرانس و نکات لازم..."
                  className="w-full bg-slate-950 border border-blue-900/60 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-400 text-xs leading-relaxed"
                ></textarea>
              </div>

              {/* مراحل چک‌لیست */}
              <div>
                <label className="block text-blue-200 font-semibold mb-1">
                  مراحل چک‌لیست بازرسی (هر مورد در یک سطر):
                </label>
                <textarea
                  rows={3}
                  value={pmChecklistInput}
                  onChange={e => setPmChecklistInput(e.target.value)}
                  placeholder="مثال:&#10;چک فشار پمپ روغن و سلامت گیج&#10;تمیزکاری توری مکش و تله آب&#10;تست عدم لرزش یا نویز غیرعادی محور"
                  className="w-full bg-slate-950 border border-blue-900/60 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-400 text-xs leading-relaxed font-mono"
                ></textarea>
              </div>

              {/* قطعات و ملزومات مصرفی */}
              <div>
                <label className="block text-blue-200 font-semibold mb-1">
                  قطعات و روانکارهای مورد نیاز (هر مورد در یک سطر):
                </label>
                <textarea
                  rows={2}
                  value={pmPartsInput}
                  onChange={e => setPmPartsInput(e.target.value)}
                  placeholder="مثال:&#10;روغن هیدرولیک ۴۶ (۱۰ لیتر)&#10;المنت فیلتر خطی&#10;اورینگ تفلونی ۲۵"
                  className="w-full bg-slate-950 border border-blue-900/60 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-400 text-xs leading-relaxed font-mono"
                ></textarea>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-indigo-500/30">
                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="px-4 py-2.5 rounded-xl border border-blue-800/40 text-blue-300 hover:text-white transition-colors"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-black text-xs shadow-lg shadow-indigo-950/60 transition-all cursor-pointer"
                >
                  ثبت و زمان‌بندی برنامه PM
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: مشاهده چک‌لیست و جزئیات PM (View PM Details)      */}
      {/* ======================================================== */}
      {modalType === 'viewPmDetails' && selectedPmSchedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="glass-panel-navy border border-indigo-500/50 p-6 rounded-3xl max-w-2xl w-full space-y-5 shadow-2xl animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto scrollbar-thin">
            
            <div className="flex items-center justify-between pb-3 border-b border-indigo-500/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600/30 border border-indigo-500/50 text-indigo-300 flex items-center justify-center font-bold">
                  <ClipboardCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">{selectedPmSchedule.title}</h3>
                  <p className="text-xs text-blue-300/70">
                    شناسه: <span className="font-mono">{selectedPmSchedule.id}</span> • تجهیز: <strong>{selectedPmSchedule.equipmentName}</strong>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-slate-800 text-blue-300 hover:text-white flex items-center justify-center transition-colors border border-blue-800/40"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              
              {/* Quick Info Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-blue-900/40 text-center">
                  <span className="text-[10px] text-blue-300 block mb-1">کد تجهیز</span>
                  <strong className="text-sm font-mono text-indigo-300">{selectedPmSchedule.equipmentCode}</strong>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/80 border border-blue-900/40 text-center">
                  <span className="text-[10px] text-blue-300 block mb-1">دوره تناوب</span>
                  <strong className="text-sm text-white font-bold">{selectedPmSchedule.periodicity}</strong>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/80 border border-blue-900/40 text-center">
                  <span className="text-[10px] text-blue-300 block mb-1">تکنسین مسئول</span>
                  <strong className="text-sm text-cyan-300 font-bold">{selectedPmSchedule.assignedTechnician}</strong>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/80 border border-blue-900/40 text-center">
                  <span className="text-[10px] text-blue-300 block mb-1">موعد بعدی سررسید</span>
                  <strong className={`text-sm font-mono font-bold ${
                    selectedPmSchedule.status === 'سررسید شده' ? 'text-rose-400' : 'text-emerald-400'
                  }`}>
                    {selectedPmSchedule.nextDueDate}
                  </strong>
                </div>
              </div>

              {/* Instructions */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-blue-900/50 space-y-1.5">
                <h4 className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>دستورالعمل و نکات ایمنی بازرسی:</span>
                </h4>
                <p className="text-xs text-blue-200/90 leading-relaxed">
                  {selectedPmSchedule.instructions}
                </p>
              </div>

              {/* Checklist Items Interactive List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-white">
                  <span>مراحل چک‌لیست بازرسی (روی هر مرحله کلیک کنید تا تایید شود):</span>
                  <span className="text-indigo-300 font-mono">
                    {toFaDigits(selectedPmSchedule.checklist.filter(c => c.completed).length)} / {toFaDigits(selectedPmSchedule.checklist.length)}
                  </span>
                </div>

                <div className="space-y-2">
                  {selectedPmSchedule.checklist.map(chk => (
                    <div
                      key={chk.id}
                      onClick={() => {
                        // Toggle checklist completed in state and in selectedPmSchedule
                        setPmSchedules(prev => prev.map(p => {
                          if (p.id !== selectedPmSchedule.id) return p;
                          return {
                            ...p,
                            checklist: p.checklist.map(c => c.id === chk.id ? { ...c, completed: !c.completed } : c)
                          };
                        }));
                        setSelectedPmSchedule(prev => prev ? {
                          ...prev,
                          checklist: prev.checklist.map(c => c.id === chk.id ? { ...c, completed: !c.completed } : c)
                        } : null);
                      }}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                        chk.completed
                          ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                          : 'bg-slate-950/80 border-blue-900/50 text-blue-100 hover:border-indigo-400'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                          chk.completed
                            ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-bold'
                            : 'border-blue-700 bg-slate-900 text-transparent'
                        }`}>
                          ✓
                        </div>
                        <span className={`text-xs ${chk.completed ? 'line-through opacity-80' : 'font-medium'}`}>
                          {chk.title}
                        </span>
                      </div>
                      <span className="text-[10px] text-blue-300/60 font-mono">
                        {chk.completed ? 'تکمیل شد ✓' : 'در انتظار تایید'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Required parts if any */}
              {selectedPmSchedule.requiredParts && selectedPmSchedule.requiredParts.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-indigo-950/50 border border-indigo-500/30 space-y-1.5">
                  <span className="text-xs font-bold text-indigo-300 block">قطعات، فیلترها و روانکارهای مورد نیاز:</span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {selectedPmSchedule.requiredParts.map((p, idx) => (
                      <span key={idx} className="px-2.5 py-1 rounded-xl bg-slate-950 text-indigo-200 border border-indigo-500/40 text-[11px] font-semibold">
                        ⚙️ {p}
                      </span>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Modal Bottom Actions */}
            <div className="pt-4 border-t border-indigo-500/30 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    handleMarkPmDone(selectedPmSchedule.id);
                    setModalType('none');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-950/50 transition-all cursor-pointer"
                >
                  ثبت اتمام بازرسی و تمدید دوره
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleConvertPmToWorkOrder(selectedPmSchedule);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md shadow-blue-950/50 transition-all cursor-pointer"
                >
                  انتقال به دستور کار ⚡
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-2.5 rounded-xl border border-blue-800/40 text-blue-300 hover:text-white flex items-center gap-1 text-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>چاپ چک‌لیست</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModalType('none')}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer border border-blue-800/40"
                >
                  بستن
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: INSTALL DESKTOP APP & DOWNLOAD STANDALONE FILE   */}
      {/* ======================================================== */}
      {modalType === 'installDesktop' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border-2 border-cyan-500/50 shadow-2xl p-6 sm:p-8 space-y-6 my-8">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-blue-900/50">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 text-white flex items-center justify-center shadow-lg shadow-cyan-950/60 ring-2 ring-cyan-400/40">
                  <Monitor className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">نصب و دریافت نسخه دسکتاپ (Windows / PC)</h3>
                  <p className="text-xs text-blue-300/80">اجرا در پنجره مستقل نرم‌افزار، دسترسی آفلاین و ذخیره همیشگی روی کامپیوتر</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="p-2 rounded-xl text-blue-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-5">
              
              {/* روش اول: نصب رسمی دسکتاپ PWA */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-950/70 via-slate-950 to-cyan-950/60 border-2 border-cyan-500/40 shadow-xl space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center text-xl shrink-0">
                    💻
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-white flex items-center gap-2">
                      <span>روش اول: نصب مستقیم به عنوان نرم‌افزار کامپیوتر (PWA)</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">پیشنهادی</span>
                    </h4>
                    <p className="text-xs text-blue-200/90 leading-relaxed">
                      با نصب این حالت، آیکون برنامه مستقیماً روی <strong>صفحه دسکتاپ (Desktop)</strong>، <strong>منوی استارت</strong> و <strong>نوار وظیفه (Taskbar)</strong> ویندوز قرار می‌گیرد و مانند یک نرم‌افزار اختصاصی ویندوز در پنجره مستقل باز می‌شود.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-blue-900/60 space-y-2 text-xs text-blue-200">
                  <div className="flex items-center gap-2 font-bold text-cyan-300">
                    <span>راهنمای نصب در مرورگر Chrome یا Edge:</span>
                  </div>
                  <ul className="space-y-1.5 list-disc list-inside text-[11px] text-blue-200/90 pr-2 leading-relaxed">
                    <li>اگر دکمه نصب زیر فعال است، روی آن کلیک کنید و در پنجره مرورگر گزینه <strong>Install</strong> را تایید نمایید.</li>
                    <li>در صورت عدم نمایش دکمه، در بالای صفحه و انتهای سمت راست <strong>نوار آدرس مرورگر</strong>، روی آیکون <strong>کامپیوتر کوچک یا فلش نصب (Install App)</strong> کلیک نمایید.</li>
                    <li>همچنین می‌توانید از منوی سه نقطه مرورگر (⋮) گزینه <strong>Save and share</strong> ➔ <strong>Install CMMS</strong> را انتخاب نمایید.</li>
                  </ul>
                </div>

                {isInstallable ? (
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await pwaInstall();
                      if (res) setModalType('none');
                    }}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-black text-xs shadow-lg shadow-cyan-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <Monitor className="w-4 h-4" />
                    <span>نصب مستقیم آخرین نسخه روی دسکتاپ با ۱ کلیک 🚀</span>
                  </button>
                ) : isInstalled ? (
                  <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center flex items-center justify-between">
                    <span>✓ این برنامه با موفقیت به عنوان نرم‌افزار دسکتاپ روی سیستم شما نصب است.</span>
                    <button
                      type="button"
                      onClick={updateServiceWorker}
                      className="px-2.5 py-1 rounded-lg bg-emerald-800/60 hover:bg-emerald-700 text-white text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>دریافت آخرین آپدیت</span>
                    </button>
                  </div>
                ) : (
                  <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-500/30 text-blue-200 text-xs flex items-center justify-between">
                    <span>💡 برای نصب آخرین نسخه، از آیکون نصب در نوار آدرس مرورگر (Install App) استفاده نمایید.</span>
                    <button
                      type="button"
                      onClick={updateServiceWorker}
                      className="px-2.5 py-1 rounded-lg bg-cyan-900/60 hover:bg-cyan-800 text-cyan-200 text-[11px] flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>بروزرسانی کش</span>
                    </button>
                  </div>
                )}
              </div>

              {/* روش دوم: دانلود فایل مستقل دسکتاپ */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/70 via-slate-950 to-teal-950/60 border-2 border-emerald-500/40 shadow-xl space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center text-xl shrink-0">
                    📥
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-white flex items-center gap-2">
                      <span>روش دوم: دانلود فایل مستقل دسکتاپ (تک‌فایلی بدون نیاز به سرور)</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">اجرا با دوبار کلیک</span>
                    </h4>
                    <p className="text-xs text-blue-200/90 leading-relaxed">
                      یک فایل سبک HTML به نام <code className="text-emerald-300 font-mono font-bold">CMMS-Factory-Desktop.html</code> که می‌توانید آن را دانلود کرده و مستقیماً روی <strong>صفحه دسکتاپ (Desktop)</strong> سیستم خود قرار دهید. با ۲ بار کلیک باز می‌شود، تمام درخواست‌ها را در حافظه سیستم ذخیره می‌کند و در صورت اتصال به اینترنت با دیتابیس ابری همگام می‌شود.
                    </p>
                  </div>
                </div>

                {/* پیام وضعیت دانلود */}
                {desktopDownloadMsg && (
                  <div className={`p-3.5 rounded-xl border text-xs leading-relaxed flex items-center gap-2.5 animate-in fade-in duration-200 ${
                    desktopDownloadStatus === 'success'
                      ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                      : desktopDownloadStatus === 'error'
                      ? 'bg-rose-950/80 border-rose-500/50 text-rose-200'
                      : 'bg-cyan-950/80 border-cyan-500/50 text-cyan-200'
                  }`}>
                    {desktopDownloadStatus === 'downloading' ? (
                      <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin shrink-0" />
                    ) : desktopDownloadStatus === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{desktopDownloadMsg}</span>
                  </div>
                )}

                <div className="space-y-2.5">
                  <button
                    type="button"
                    disabled={desktopDownloadStatus === 'downloading'}
                    onClick={downloadDesktopHtmlFile}
                    className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-xs shadow-lg shadow-emerald-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all text-center disabled:opacity-60"
                  >
                    {desktopDownloadStatus === 'downloading' ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin ml-1" />
                        <span>در حال دریافت فایل از دیتاسنتر...</span>
                      </>
                    ) : desktopDownloadStatus === 'success' ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-200 ml-1" />
                        <span>دانلود شد! برای دریافت مجدد کلیک کنید</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4 inline-block ml-1" />
                        <span>دانلود فایل مستقل دسکتاپ (CMMS-Factory-Desktop.html)</span>
                      </>
                    )}
                  </button>

                  {/* گزینه‌های کمکی برای دانلود در صورت مسدود بودن دانلود داخل آی‌فریم مرورگر */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    <a
                      href={getApiUrl('/api/portal/download-desktop')}
                      download="CMMS-Factory-Desktop.html"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-500/40 text-emerald-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>لینک دانلود مستقیم (تب جدید)</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => {
                        const link = getApiUrl('/api/portal/download-desktop');
                        navigator.clipboard.writeText(link);
                        setDesktopLinkCopied(true);
                        setTimeout(() => setDesktopLinkCopied(false), 3500);
                      }}
                      className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
                    >
                      {desktopLinkCopied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{desktopLinkCopied ? 'لینک دانلود کپی شد! ✓' : 'کپی آدرس لینک دانلود'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* روش سوم: پشتیبان‌گیری جامع و انتقال کلیه داده‌های کارخانه (Full System Backup & Restore) */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-950 to-purple-950/70 border-2 border-indigo-500/50 shadow-2xl space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center justify-center text-xl shrink-0">
                      💾
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-black text-white flex items-center gap-2">
                        <span>روش سوم: پشتیبان‌گیری جامع و بازگردانی کل اطلاعات سامانه (Full Backup & Restore)</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold">۱۰۰٪ اطلاعات سامانه</span>
                      </h4>
                      <p className="text-xs text-indigo-200/90 leading-relaxed">
                        شامل تمام بخش‌ها: <strong>تمامی تراکنش‌های انبار روغن</strong>، <strong>موجودی و سطوح مخازن</strong>، <strong>دستورکارها و درخواست‌های فنی</strong>، <strong>تجهیزات</strong>، <strong>سوابق PM</strong> و <strong>تکنسین‌ها</strong> در یک فایل استاندارد JSON.
                      </p>
                    </div>
                  </div>
                </div>

                {/* خلاصه آماری رکوردهای آماده پشتیبان */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-indigo-500/30 shadow-inner">
                    <span className="text-[10px] text-indigo-300 block">تراکنش‌های روغن</span>
                    <strong className="text-sm font-black text-amber-400">{toFaDigits(oilTransactions.length)} عدد</strong>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-indigo-500/30 shadow-inner">
                    <span className="text-[10px] text-indigo-300 block">مخازن فعال</span>
                    <strong className="text-sm font-black text-cyan-400">{toFaDigits(oilTanks.length)} مخزن</strong>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-indigo-500/30 shadow-inner">
                    <span className="text-[10px] text-indigo-300 block">پرونده‌های فنی</span>
                    <strong className="text-sm font-black text-emerald-400">{toFaDigits(workRequests.length)} کار</strong>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-indigo-500/30 shadow-inner">
                    <span className="text-[10px] text-indigo-300 block">تجهیزات و PM</span>
                    <strong className="text-sm font-black text-purple-400">{toFaDigits(equipments.length + pmSchedules.length)} مورد</strong>
                  </div>
                </div>

                {/* پیام بازخورد دانلود یا بازگردانی */}
                {backupStatusMsg && (
                  <div className={`p-3.5 rounded-xl border text-xs leading-relaxed flex items-center gap-2.5 animate-in fade-in duration-200 ${
                    backupStatusMsg.type === 'success'
                      ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                      : backupStatusMsg.type === 'error'
                      ? 'bg-rose-950/80 border-rose-500/50 text-rose-200'
                      : 'bg-indigo-950/80 border-indigo-500/50 text-indigo-200'
                  }`}>
                    {backupStatusMsg.type === 'info' ? (
                      <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin shrink-0" />
                    ) : backupStatusMsg.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{backupStatusMsg.text}</span>
                  </div>
                )}

                {/* دکمه‌های اقدام پشتیبان */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* دکمه دانلود فایل کامل JSON */}
                  <button
                    type="button"
                    onClick={downloadFullSystemBackupJson}
                    className="py-3 px-3.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-bold text-xs shadow-lg shadow-indigo-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all text-center"
                    title="دانلود فایل پشتیبان متنی کامل قابل خوانش برای هوش مصنوعی و انسان"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    <span>دانلود فایل پشتیبان جامع (JSON هوشمند سامانه)</span>
                  </button>

                  {/* دکمه بازگردانی از فایل JSON */}
                  <button
                    type="button"
                    onClick={() => backupFileInputRef.current?.click()}
                    className="py-3 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border-2 border-indigo-500/50 text-indigo-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
                    title="انتخاب فایل بکاپ قبلی و بارگذاری روی دیتاسنتر و مرورگر"
                  >
                    <Upload className="w-4 h-4 shrink-0 text-indigo-400" />
                    <span>بازگردانی اطلاعات از فایل پشتیبان (Restore Backup)</span>
                  </button>

                  {/* اینپوت مخفی فایل */}
                  <input
                    ref={backupFileInputRef}
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        restoreFullSystemBackupJson(file);
                        e.target.value = '';
                      }
                    }}
                  />
                </div>

                {/* بخش ویژه: دانلود گزارش‌های جامع و تفکیک‌شده اکسل (Excel Master & Individual Reports) */}
                <div className="pt-2 p-4 rounded-2xl bg-gradient-to-br from-slate-900/90 via-[#0d1627] to-slate-900 border border-emerald-500/30 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 shadow-md">
                        <FileSpreadsheet className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-emerald-200">گزارش اکسل جامع سامانه (چند برگه‌ای — ۸ شیت کامل)</div>
                        <div className="text-[11px] text-slate-400">حاوی خلاصه کل + تفکیک کامل: خدمات فنی، تجهیزات، PM، قطعات و روغن</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={downloadFullSystemBackupExcel}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 border border-emerald-400 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 transition-all cursor-pointer shrink-0"
                    >
                      <Download className="w-4 h-4 text-emerald-100" />
                      <span>دانلود فایل اکسل جامع سامانه (۸ شیت)</span>
                    </button>
                  </div>

                  {/* دکمه‌های مستقیم دانلود تک‌شیت اختصاصی هر بخش */}
                  <div className="pt-2 border-t border-slate-800/80">
                    <div className="text-[11px] text-slate-300 font-bold mb-2 flex items-center gap-1.5">
                      <span>📥 دانلود مستقیم فایل اکسل مخصوص یک بخش خاص:</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                      <button
                        type="button"
                        onClick={exportTechnicalOrdersToCsv}
                        className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-bold text-center flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="دانلود فایل اکسل فقط دستورکارها و پرونده‌های خدمات فنی"
                      >
                        <span>🛠️ فقط خدمات فنی</span>
                      </button>
                      <button
                        type="button"
                        onClick={exportEquipmentsToExcel}
                        className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-bold text-center flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="دانلود فایل اکسل تجهیزات و ماشین‌آلات"
                      >
                        <span>⚙️ فقط تجهیزات</span>
                      </button>
                      <button
                        type="button"
                        onClick={exportPmToCsv}
                        className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-bold text-center flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="دانلود فایل اکسل برنامه‌های نگهداری PM"
                      >
                        <span>📋 فقط نگهداری PM</span>
                      </button>
                      <button
                        type="button"
                        onClick={exportSparePartsToCsv}
                        className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-bold text-center flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="دانلود فایل اکسل انبار قطعات یدکی"
                      >
                        <span>🔩 فقط انبار قطعات</span>
                      </button>
                      <button
                        type="button"
                        onClick={exportOilReportCsv}
                        className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-bold text-center flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="دانلود فایل اکسل مخازن و تراکنش‌های روغن"
                      >
                        <span>🛢️ فقط انبار روغن</span>
                      </button>
                    </div>
                  </div>

                  {/* راهنمای بسیار کاربردی زبانه‌های اکسل */}
                  <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/20 text-[11px] text-emerald-200/90 leading-relaxed flex items-start gap-2">
                    <span className="text-base shrink-0">💡</span>
                    <span>
                      <strong>نکته مهم نحوه نمایش در اکسل:</strong> فایل جامع در ۸ برگه تفکیک شده است. برگه اول «خلاصه کل سامانه» است و برای مشاهده جدول کامل هر بخش (خدمات فنی، تجهیزات، PM، قطعات و روغن)، کافی است روی <strong>زبانه‌های پایین نرم‌افزار اکسل (Sheets در نوار پایین صفحه)</strong> کلیک فرمایید.
                    </span>
                  </div>
                </div>

                {/* راهنمای ویژه ارسال فایل به هوش مصنوعی */}
                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-[11px] text-indigo-200/90 leading-relaxed flex items-start gap-2">
                  <span className="text-base shrink-0">🤖</span>
                  <span>
                    <strong>قابلیت هوشمند ارسال فایل به پشتیبانی / هوش مصنوعی:</strong> فایل JSON دانلود شده کاملاً استاندارد و خوانا ساخته شده است. هر زمان که بخواهید، می‌توانید همین فایل را در چت برای هوش مصنوعی بفرستید؛ سیستم تمام اطلاعات و تراکنش‌های شما را خط به خط بازخوانی کرده و هر تغییری که بخواهید روی آن اعمال خواهد کرد.
                  </span>
                </div>
              </div>


            </div>

            {/* Footer */}
            <div className="pt-4 border-t border-blue-900/50 flex items-center justify-between">
              <span className="text-xs text-blue-300/70">
                شما می‌توانید کارهای خدمات فنی را هم‌اکنون در سیستم ثبت کنید و کارهایتان عقب نیفتد.
              </span>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
              >
                بستن
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: CINEMATIC LOGO REVEAL VIDEO PREVIEW (4K)          */}
      {/* ======================================================== */}
      {modalType === 'videoPreview' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl rounded-3xl bg-slate-950 border-2 border-cyan-500/50 shadow-2xl overflow-hidden p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></div>
                <h3 className="text-sm font-black text-white">معرفی و نمای رسمی سامانه ({BRAND_CONFIG.SYSTEM_SHORT_NAME})</h3>
              </div>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-900/90 shadow-2xl border border-slate-800 flex flex-col items-center justify-center p-8 text-center space-y-4">
              <img src={COMPANY_LOGO} alt={BRAND_CONFIG.COMPANY_NAME} className="h-20 w-auto object-contain" />
              <h4 className="text-xl font-black text-white">{BRAND_CONFIG.SYSTEM_NAME}</h4>
              <p className="text-xs text-slate-300 max-w-md">{BRAND_CONFIG.COMPANY_FULL_NAME}</p>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <span>کیفیت بهینه‌سازی‌شده اختصاصی، انیمیشن ۵ ثانیه‌ای پیوسته متالیک نقره‌ای</span>
              <button
                type="button"
                onClick={() => setModalType('none')}
                className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition-all cursor-pointer shadow-lg"
              >
                بازگشت به پورتال
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ثبت برداشت از مخزن (Oil Withdrawal Dialog)        */}
      {/* ======================================================== */}
      {oilModalMode === 'withdraw' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#171c24] to-[#0d1117] border border-[#303844] shadow-2xl p-6 space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#303844]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-700 text-white flex items-center justify-center shadow-md text-base">
                  💧
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">ثبت برداشت از مخزن</h3>
                  <p className="text-[11px] text-[#9aa4b0]">کسر خودکار از موجودی مخزن و ثبت تراکنش</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => { setOilModalMode('none'); setOilOpError(null); }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handlePerformOilWithdraw} className="space-y-4 text-xs">
              {/* Select Tank */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">انتخاب مخزن روغن *:</label>
                <select
                  value={oilTargetTankId}
                  onChange={e => setOilTargetTankId(Number(e.target.value))}
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-[#a9141b]"
                >
                  {oilTanks.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} (موجودی فعلی: {fa(t.currentLiters)} از {fa(t.capacityLiters)} لیتر)
                    </option>
                  ))}
                </select>
              </div>

              {/* Operator */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">نام اپراتور تحویل‌گیرنده *:</label>
                <input
                  type="text"
                  required
                  list="oil-operators-datalist"
                  value={oilOpOperator}
                  onChange={e => setOilOpOperator(e.target.value)}
                  placeholder="نام اپراتور یا مسئول برداشت..."
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#a9141b]"
                />
                <datalist id="oil-operators-datalist">
                  {productionOperators.map((op, i) => (
                    <option key={op.id || i} value={op.name}>
                      {op.name} {op.personnelCode ? `(کد: ${op.personnelCode})` : ''}
                    </option>
                  ))}
                </datalist>
                {/* دکمه‌های سریع برای انتخاب اپراتورهای پرکاربرد */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
                  <span className="text-[10px] text-slate-400">پیشنهاد سریع:</span>
                  {productionOperators.slice(0, 5).map(op => op.name).map(name => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setOilOpOperator(name)}
                      className="px-2 py-0.5 rounded-lg bg-[#242a33] hover:bg-[#323b47] text-slate-200 hover:text-white text-[10px] font-bold border border-[#3a424d] cursor-pointer"
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Equipment Code */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">کد یا نام دستگاه / تجهیز مقصد:</label>
                <input
                  type="text"
                  value={oilOpEquipment}
                  onChange={e => setOilOpEquipment(e.target.value)}
                  placeholder="مثلاً: برش 11 یا تورنوس ۰۸ یا فرز CNC"
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#a9141b]"
                />
              </div>

              {/* Amount in Liters - Supports both Persian and English numbers */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">مقدار برداشت (لیتر) *:</label>
                <input
                  type="text"
                  inputMode="decimal"
                  dir="ltr"
                  required
                  value={oilOpAmount}
                  onChange={e => setOilOpAmount(e.target.value)}
                  placeholder="مثلاً: ۲۰ یا 20"
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-amber-300 font-mono font-bold text-sm focus:outline-none focus:border-[#a9141b] text-center"
                />
                <div className="flex items-center gap-1.5 pt-1.5 justify-center">
                  {[5, 10, 20, 50, 100].map(v => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setOilOpAmount(String(v))}
                      className="px-2.5 py-1 rounded-lg bg-[#242a33] hover:bg-[#323b47] text-amber-300 font-mono text-xs font-bold border border-[#3a424d] cursor-pointer"
                    >
                      {toFaDigits(v)} ل
                    </button>
                  ))}
                </div>
              </div>

              {/* Error Notice */}
              {oilOpError && (
                <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-bold text-center">
                  ⚠️ {oilOpError}
                </div>
              )}

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => { setOilModalMode('none'); setOilOpError(null); }}
                  className="px-4 py-2.5 rounded-xl bg-[#242a33] hover:bg-[#2e3642] text-slate-300 text-xs font-bold transition-all cursor-pointer border border-[#3a424d]"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingOilOp}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#d71920] to-[#a70f16] hover:from-[#e3242b] hover:to-[#b71118] text-white text-xs font-black shadow-lg shadow-red-950/60 transition-all cursor-pointer border border-[#d71920] disabled:opacity-60 flex items-center gap-1.5"
                >
                  {isSubmittingOilOp ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>در حال ثبت در دیتابیس ابری...</span>
                    </>
                  ) : (
                    <span>✓ ثبت برداشت</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ورود روغن به مخزن (Oil Entry Dialog)             */}
      {/* ======================================================== */}
      {oilModalMode === 'entry' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#171c24] to-[#0d1117] border border-[#303844] shadow-2xl p-6 space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#303844]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-md text-base">
                  ＋
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">ورود روغن به مخزن</h3>
                  <p className="text-[11px] text-[#9aa4b0]">افزایش موجودی مخزن با دریافت محموله جدید</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => { setOilModalMode('none'); setOilOpError(null); }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handlePerformOilEntry} className="space-y-4 text-xs">
              {/* Select Tank */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">انتخاب مخزن روغن *:</label>
                <select
                  value={oilTargetTankId}
                  onChange={e => setOilTargetTankId(Number(e.target.value))}
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-emerald-500"
                >
                  {oilTanks.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} (موجودی فعلی: {fa(t.currentLiters)} از {fa(t.capacityLiters)} لیتر)
                    </option>
                  ))}
                </select>
              </div>

              {/* Amount in Liters */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">مقدار روغن ورودی (لیتر) *:</label>
                <input
                  type="text"
                  inputMode="decimal"
                  dir="ltr"
                  required
                  value={oilOpAmount}
                  onChange={e => setOilOpAmount(e.target.value)}
                  placeholder="مثلاً: ۲۰۰ یا 200"
                  className="w-full bg-[#11161d] border border-[#303844] rounded-xl px-3.5 py-2.5 text-emerald-400 font-mono font-bold text-sm focus:outline-none focus:border-emerald-500 text-center"
                />
                <div className="flex items-center gap-1.5 pt-1.5 justify-center">
                  {[50, 100, 200, 400, 1000].map(v => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setOilOpAmount(String(v))}
                      className="px-2.5 py-1 rounded-lg bg-[#242a33] hover:bg-[#323b47] text-emerald-300 font-mono text-xs font-bold border border-[#3a424d] cursor-pointer"
                    >
                      {toFaDigits(v)} ل
                    </button>
                  ))}
                </div>
              </div>

              {/* Error Notice */}
              {oilOpError && (
                <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-bold text-center">
                  ⚠️ {oilOpError}
                </div>
              )}

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => { setOilModalMode('none'); setOilOpError(null); }}
                  className="px-4 py-2.5 rounded-xl bg-[#242a33] hover:bg-[#2e3642] text-slate-300 text-xs font-bold transition-all cursor-pointer border border-[#3a424d]"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingOilOp}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-950/60 transition-all cursor-pointer border border-emerald-500 disabled:opacity-60 flex items-center gap-1.5"
                >
                  {isSubmittingOilOp ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>در حال شارژ و ذخیره ابری...</span>
                    </>
                  ) : (
                    <span>✓ ثبت ورود روغن</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: گزارش‌ها و چاپ (Oil Reports Dialog)                */}
      {/* ======================================================== */}
      {isOilReportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl rounded-3xl bg-gradient-to-b from-[#171c24] to-[#0d1117] border border-[#303844] shadow-2xl p-6 sm:p-8 space-y-6 my-auto max-h-[92vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#303844]">
              <div className="flex items-center gap-3">
                <img
                  src={COMPANY_LOGO}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-11 w-auto object-contain rounded-xl p-1 bg-black/60 border border-[#303844] shadow-md shrink-0"
                />
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-700 text-white flex items-center justify-center shadow-md text-lg">
                  📊
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">گزارش جامع تراکنش‌های انبار روغن</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-cyan-500/30">{BRAND_CONFIG.COMPANY_NAME}</span>
                  </div>
                  <p className="text-xs text-[#9aa4b0]">{BRAND_CONFIG.COMPANY_NAME} • پایش و چاپ رسمی مخازن روغن</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOilReportModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter Tools & Exact Date Range */}
            <div className="p-4 sm:p-5 rounded-2xl bg-[#11161d] border border-[#303844] space-y-4">
              
              {/* Row 1: Tanks, Operation Type, and Primary Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  {/* Tank Filter */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#9aa4b0] font-bold">مخزن:</span>
                    <select
                      value={oilReportFilterTank}
                      onChange={e => setOilReportFilterTank(e.target.value)}
                      className="bg-[#0d1117] border border-[#303844] rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#a9141b]"
                    >
                      <option value="all">همه مخزن‌ها (۴ مخزن)</option>
                      {oilTanks.map(t => (
                        <option key={t.id} value={String(t.id)}>{t.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Operation Type Tabs */}
                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0d1117] border border-[#303844] text-xs">
                    <button
                      type="button"
                      onClick={() => setOilReportTab('out')}
                      className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                        oilReportTab === 'out'
                          ? 'bg-gradient-to-r from-[#751118] to-[#3b0d12] text-white border border-[#a9141b]'
                          : 'text-[#9aa4b0] hover:text-white'
                      }`}
                    >
                      برداشت‌ها (خروجی)
                    </button>
                    <button
                      type="button"
                      onClick={() => setOilReportTab('in')}
                      className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                        oilReportTab === 'in'
                          ? 'bg-gradient-to-r from-emerald-800 to-teal-900 text-white border border-emerald-500'
                          : 'text-[#9aa4b0] hover:text-white'
                      }`}
                    >
                      ورود روغن (شارژ)
                    </button>
                  </div>
                </div>

                {/* Print & Export Action Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleForceUploadAllToServer}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-800 to-emerald-800 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-bold border border-teal-500 shadow-sm cursor-pointer transition-all active:scale-95"
                    title="ارسال و ذخیره دائمی کلیه داده‌های انبار روغن در سرور ابری جهت نمایش لحظه‌ای در گوشی"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-cyan-200 ${centralSyncState === 'syncing' ? 'animate-spin' : ''}`} />
                    <span>همگام‌سازی با گوشی و سرور</span>
                  </button>

                  <button
                    type="button"
                    onClick={exportOilReportCsv}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 shadow-sm cursor-pointer transition-all"
                    title="دانلود فایل اکسل تراکنش‌های فیلترشده"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>خروجی اکسل (CSV)</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePrintOilReport}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black shadow-lg shadow-blue-950/60 cursor-pointer transition-all border border-blue-400/40"
                    title="چاپ رسمی برگ گزارش در اندازه A4 یا ذخیره به صورت PDF"
                  >
                    <Printer className="w-4 h-4 text-cyan-200" />
                    <span>🖨️ چاپ رسمی گزارش (A4 / PDF)</span>
                  </button>
                </div>
              </div>

              {/* Row 2: Exact Date Range Filtering (بازه تاریخ دقیق) */}
              <div className="pt-3 border-t border-[#303844]/60 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1.5 text-xs text-[#9aa4b0] font-bold">
                    <Calendar className="w-4 h-4 text-amber-400" />
                    <span>بازه دقیق تاریخ:</span>
                  </div>

                  {/* Start Date */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-400 font-bold">از تاریخ:</span>
                    <JalaliDatePicker
                      value={oilReportStartDate}
                      onChange={setOilReportStartDate}
                      placeholder="انتخاب از تقویم..."
                    />
                  </div>

                  {/* End Date */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-400 font-bold">تا تاریخ:</span>
                    <JalaliDatePicker
                      value={oilReportEndDate}
                      onChange={setOilReportEndDate}
                      placeholder="انتخاب از تقویم..."
                    />
                  </div>

                  {/* Search Filter */}
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={oilReportSearch}
                      onChange={e => setOilReportSearch(e.target.value)}
                      placeholder="جستجوی کد دستگاه / اپراتور..."
                      className="w-44 bg-[#0d1117] border border-[#303844] rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                {/* Reset Filters */}
                {(oilReportStartDate || oilReportEndDate || oilReportSearch || oilReportFilterTank !== 'all') && (
                  <button
                    type="button"
                    onClick={() => {
                      setOilReportStartDate('');
                      setOilReportEndDate('');
                      setOilReportSearch('');
                      setOilReportFilterTank('all');
                    }}
                    className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 px-2.5 py-1 rounded-lg bg-rose-950/40 border border-rose-800/40 cursor-pointer transition-all"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>پاکسازی تمام فیلترها</span>
                  </button>
                )}
              </div>

              {/* Row 3: Quick Date Presets */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                <span className="text-[#9aa4b0] ml-1">انتخاب سریع:</span>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate(''); setOilReportEndDate(''); }}
                  className={`px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                    !oilReportStartDate && !oilReportEndDate
                      ? 'bg-blue-900/60 text-cyan-300 border-blue-500/60 font-bold'
                      : 'bg-[#0d1117] text-slate-400 border-[#303844] hover:text-white'
                  }`}
                >
                  همه تاریخ‌ها
                </button>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate('1405/08/02'); setOilReportEndDate('1405/08/02'); }}
                  className="px-2.5 py-1 rounded-lg bg-[#0d1117] text-slate-400 border border-[#303844] hover:text-white transition-all cursor-pointer"
                >
                  امروز (۲ آبان)
                </button>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate('1405/07/25'); setOilReportEndDate('1405/08/02'); }}
                  className="px-2.5 py-1 rounded-lg bg-[#0d1117] text-slate-400 border border-[#303844] hover:text-white transition-all cursor-pointer"
                >
                  هفته اخیر
                </button>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate('1405/08/01'); setOilReportEndDate('1405/08/30'); }}
                  className="px-2.5 py-1 rounded-lg bg-[#0d1117] text-slate-400 border border-[#303844] hover:text-white transition-all cursor-pointer"
                >
                  ماه آبان ۱۴۰۵
                </button>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate('1405/07/01'); setOilReportEndDate('1405/07/30'); }}
                  className="px-2.5 py-1 rounded-lg bg-[#0d1117] text-slate-400 border border-[#303844] hover:text-white transition-all cursor-pointer"
                >
                  ماه مهر ۱۴۰۵
                </button>
                <button
                  type="button"
                  onClick={() => { setOilReportStartDate('1405/07/01'); setOilReportEndDate('1405/09/30'); }}
                  className="px-2.5 py-1 rounded-lg bg-[#0d1117] text-slate-400 border border-[#303844] hover:text-white transition-all cursor-pointer"
                >
                  فصل پاییز ۱۴۰۵
                </button>
              </div>

            </div>

            {/* Printable Report Section */}
            {(() => {
              const filtered = getFilteredOilTransactions();
              const totalLit = filtered.reduce((sum, tx) => sum + tx.amount_l, 0);
              const targetTankObj = oilTanks.find(t => String(t.id) === String(oilReportFilterTank));

              return (
                <div id="printArea" className="space-y-4">
                  {/* Report Header Info */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#303844]">
                    <div>
                      <h2 className="text-base font-black text-white flex items-center gap-2">
                        <span>{oilReportTab === 'out' ? '📋 گزارش برداشت روغن از مخازن' : '📋 گزارش ورود و شارژ روغن'}</span>
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-950 text-cyan-300 border border-blue-800/60">
                          {targetTankObj ? targetTankObj.name : 'تمامی مخازن ۴‌گانه'}
                        </span>
                      </h2>
                      <p className="text-xs text-[#9aa4b0] mt-1">
                        بازه گزارش: {(oilReportStartDate || oilReportEndDate) ? `از ${oilReportStartDate || 'ابتدا'} تا ${oilReportEndDate || 'اکنون'}` : 'کلیه تاریخ‌های ثبت‌شده'} — تاریخ گزارش‌گیری: {persianClock}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handlePrintOilReport}
                      className="px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-cyan-300 border border-blue-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>ارسال به چاپگر</span>
                    </button>
                  </div>

                  {/* Summary Metric Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-2xl bg-[#11161d] border border-[#303844] text-center space-y-1">
                      <div className="text-xs text-[#9aa4b0]">مجموع حجم فیلترشده</div>
                      <div className="text-xl font-black text-amber-300 font-mono">{fa(totalLit)} لیتر</div>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-[#11161d] border border-[#303844] text-center space-y-1">
                      <div className="text-xs text-[#9aa4b0]">تعداد کل تراکنش‌ها</div>
                      <div className="text-xl font-black text-white font-mono">{fa(filtered.length)} عملیات</div>
                    </div>
                    <div className="p-3.5 rounded-2xl bg-[#11161d] border border-[#303844] text-center space-y-1">
                      <div className="text-xs text-[#9aa4b0]">میانگین برداشت هر تراکنش</div>
                      <div className="text-xl font-black text-cyan-300 font-mono">
                        {fa(filtered.length > 0 ? (totalLit / filtered.length).toFixed(1) : 0)} لیتر
                      </div>
                    </div>
                  </div>

                  {/* Transactions Table */}
                  <div className="overflow-x-auto rounded-2xl border border-[#303844]">
                    <table className="w-full text-right text-xs">
                      <thead>
                        <tr className="bg-[#11161d] border-b border-[#303844] text-[#9aa4b0]">
                          <th className="py-3 px-3 text-center w-12">ردیف</th>
                          <th className="py-3 px-3">مخزن</th>
                          <th className="py-3 px-3 text-center">مقدار</th>
                          <th className="py-3 px-3">{oilReportTab === 'out' ? 'اپراتور تحویل‌گیرنده' : 'ثبت‌کننده'}</th>
                          <th className="py-3 px-3 text-center">{oilReportTab === 'out' ? 'کد تجهیز مقصد' : 'منبع تأمین'}</th>
                          <th className="py-3 px-3 text-center">تاریخ و زمان دقیق ثبت</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#303844]/50 bg-[#0d1117]/60">
                        {filtered.map((tx, idx) => (
                          <tr key={tx.id || idx} className="hover:bg-[#171c24] transition-colors">
                            <td className="py-3 px-3 text-center text-slate-400 font-mono">{fa(idx + 1)}</td>
                            <td className="py-3 px-3 text-white font-bold">{tx.tank_name || '—'}</td>
                            <td className="py-3 px-3 text-center font-mono font-black text-amber-300">{fa(tx.amount_l)} لیتر</td>
                            <td className="py-3 px-3 text-slate-200">{tx.operator || '—'}</td>
                            <td className="py-3 px-3 text-center font-mono font-bold text-cyan-300">{tx.equipment || '—'}</td>
                            <td className="py-3 px-3 text-center font-mono text-[11px] text-[#9aa4b0]">{tx.created_at}</td>
                          </tr>
                        ))}
                        {filtered.length === 0 && (
                          <tr>
                            <td colSpan={6} className="py-12 text-center text-[#9aa4b0] text-xs">
                              هیچ تراکنشی مطابق با تاریخ و فیلترهای انتخابی یافت نشد.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })()}

            {/* Footer */}
            <div className="pt-3 border-t border-[#303844] flex items-center justify-between">
              <span className="text-xs text-[#9aa4b0]">
                برای چاپ مستقیم، بر روی دکمه «چاپ رسمی گزارش» در بالای صفحه کلیک فرمایید.
              </span>
              <button
                type="button"
                onClick={() => setIsOilReportModalOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
              >
                بستن پنجره گزارش
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 1: فرم بازرسی تجهیز (مطابق عکس ۴ کاربر)   */}
      {/* ======================================================== */}
      {inspectingEquipment && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl rounded-3xl bg-gradient-to-b from-[#141b24] to-[#0c1219] border border-cyan-500/50 shadow-2xl p-6 sm:p-7 space-y-5 text-right animate-in zoom-in-95 my-6">
            
            {/* Header: کد و نام تجهیز + نام اپراتور و بازرس */}
            <div className="flex items-center justify-between pb-4 border-b border-blue-900/40">
              <div className="space-y-1">
                <h3 className="text-xl font-black text-white flex items-center gap-2">
                  <span className="text-cyan-400">🔍</span>
                  <span>بازرسی تجهیز {inspectingEquipment.code}</span>
                  <span className="text-xs font-normal text-blue-300/80">({inspectingEquipment.name})</span>
                </h3>
                <p className="text-xs text-blue-300/70">
                  اپراتور: <strong className="text-white">{inspectingOperator}</strong> — ثبت توسط بازرس: <strong className="text-cyan-300">بازرس فنی</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectingEquipment(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* اپراتور جاری */}
            <div className="flex items-center gap-3">
              <label className="text-xs text-blue-300 font-bold whitespace-nowrap">انتخاب اپراتور دستگاه:</label>
              <select
                value={inspectingOperator}
                onChange={e => setInspectingOperator(e.target.value)}
                className="flex-1 bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                {(productionOperators && productionOperators.length > 0 ? productionOperators : (activeOperatorLeaderboard.length > 0 ? activeOperatorLeaderboard : [])).map(op => (
                  <option key={op.id} value={op.name}>
                    {op.name} {('personnelCode' in op && op.personnelCode) ? `(${op.personnelCode})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* نتیجه بازرسی: دو دکمه «بدون مشکل» و «دارای عدم انطباق» مطابق عکس ۴ */}
            <div className="space-y-2">
              <label className="text-xs text-slate-300 font-bold block">نتیجه بازرسی:</label>
              <div className="grid grid-cols-2 gap-3">
                {/* دکمه بدون مشکل (سبز) */}
                <button
                  type="button"
                  onClick={() => setInspectionResult('conforming')}
                  className={`py-3 px-4 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    inspectionResult === 'conforming'
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950/70 ring-2 ring-emerald-400 border border-emerald-400'
                      : 'bg-slate-900/80 text-emerald-300 hover:bg-slate-800 border border-emerald-500/30'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-300" />
                  <span>بدون مشکل</span>
                </button>

                {/* دکمه دارای عدم انطباق (قرمز) */}
                <button
                  type="button"
                  onClick={() => setInspectionResult('non_conforming')}
                  className={`py-3 px-4 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    inspectionResult === 'non_conforming'
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-950/70 ring-2 ring-rose-400 border border-rose-400'
                      : 'bg-slate-900/80 text-rose-300 hover:bg-slate-800 border border-rose-500/30'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4 text-rose-300" />
                  <span>دارای عدم انطباق</span>
                </button>
              </div>
            </div>

            {/* در صورت انتخاب «بدون مشکل» */}
            {inspectionResult === 'conforming' && (
              <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400 shrink-0" />
                <div>
                  <strong className="block text-white text-sm mb-0.5">وضعیت تجهیز در شرایط ایده‌آل است</strong>
                  <span>نظافت، روانکاری، و کارکرد قطعات منطبق بر استاندارد بوده و نیاز به اقدام اصلاحی ندارد.</span>
                </div>
              </div>
            )}

            {/* در صورت انتخاب «دارای عدم انطباق»: ۸ گزینه چک‌لیست مطابق عکس ۴ */}
            {inspectionResult === 'non_conforming' && (
              <div className="space-y-4 animate-in fade-in duration-200">
                <div className="space-y-2">
                  <label className="text-xs text-rose-300 font-bold block flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                    <span>نوع عدم انطباق (مواردی که دارای اشکال هستند را علامت بزنید):</span>
                  </label>

                  {/* گرید ۲ ستونه از ۸ مورد مشخص شده در عکس ۴ */}
                  <div className="grid grid-cols-2 gap-2.5">
                    {INSPECTION_DEFECT_OPTIONS.map((defect) => {
                      const isChecked = inspectionDefects.includes(defect);
                      return (
                        <button
                          key={defect}
                          type="button"
                          onClick={() => {
                            if (isChecked) {
                              setInspectionDefects(prev => prev.filter(d => d !== defect));
                            } else {
                              setInspectionDefects(prev => [...prev, defect]);
                            }
                          }}
                          className={`p-3 rounded-2xl border transition-all text-xs font-bold flex items-center justify-between cursor-pointer ${
                            isChecked
                              ? 'bg-rose-950/90 border-rose-500 text-white shadow-md shadow-rose-950/50 ring-1 ring-rose-400'
                              : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-600 hover:text-white'
                          }`}
                        >
                          <span>{defect}</span>
                          <span className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold ${
                            isChecked ? 'bg-rose-500 text-white' : 'border border-slate-600 bg-slate-900'
                          }`}>
                            {isChecked ? '✓' : ''}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* فیلد توضیحات بازرس */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-bold block">توضیحات بازرس:</label>
              <textarea
                value={inspectionNotes}
                onChange={e => setInspectionNotes(e.target.value)}
                rows={2}
                placeholder="توضیحات..."
                className="w-full bg-slate-950 border border-blue-900/60 rounded-2xl p-3 text-xs text-white focus:outline-none focus:border-cyan-400 placeholder-slate-500"
              />
            </div>

            {/* عکس عدم انطباق (عکس‌برداری با دوربین یا آپلود فایل - مطابق عکس ۴) */}
            <div className="space-y-2">
              <label className="text-xs text-slate-300 font-bold block flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-cyan-400" />
                <span>عکس عدم انطباق (عکس‌برداری مستقیم یا انتخاب فایل):</span>
              </label>

              {inspectionPhoto ? (
                <div className="p-3 rounded-2xl bg-slate-950 border border-blue-900/50 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={inspectionPhoto}
                      alt="عکس عدم انطباق"
                      className="w-16 h-16 object-cover rounded-xl border border-rose-500/40 shadow-md cursor-pointer hover:scale-105 transition-transform"
                      onClick={() => setSelectedPhotoLightbox(inspectionPhoto)}
                      title="کلیک برای بزرگنمایی"
                    />
                    <div>
                      <span className="text-xs font-bold text-white block">عکس عدم انطباق ضمیمه شد ✓</span>
                      <span className="text-[10px] text-slate-400">عکس با کیفیت بالا در پرونده ذخیره می‌شود</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedPhotoLightbox(inspectionPhoto)}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold"
                    >
                      بزرگنمایی
                    </button>
                    <button
                      type="button"
                      onClick={() => setInspectionPhoto(null)}
                      className="px-2.5 py-1.5 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-xs font-bold"
                    >
                      حذف عکس
                    </button>
                  </div>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-blue-800/60 hover:border-cyan-400 bg-slate-950/80 hover:bg-slate-900 rounded-2xl cursor-pointer transition-all group">
                  <Camera className="w-7 h-7 text-cyan-400 group-hover:scale-110 transition-transform mb-1.5" />
                  <span className="text-xs font-bold text-white">عکس عدم انطباق 📷</span>
                  <span className="text-[10px] text-blue-300/60 mt-0.5">از محل ایراد یا نشتی با گوشی عکس بگیرید یا فایل انتخاب کنید</span>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleInspectionPhotoChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {/* دکمه‌های انصراف و ثبت بازرسی (مطابق عکس ۴) */}
            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-blue-900/40">
              <button
                type="button"
                onClick={() => setInspectingEquipment(null)}
                className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                انصراف
              </button>

              <button
                type="button"
                onClick={handleSubmitInspection}
                className={`py-3 px-4 rounded-2xl text-white text-xs font-black transition-all cursor-pointer shadow-xl flex items-center justify-center gap-1.5 ${
                  inspectionResult === 'conforming'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-950/60'
                    : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 shadow-rose-950/60'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>✓ ثبت بازرسی</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL: تجهیزات و چک‌لیست دسته انتخابی (مورد ۲ کاربر) */}
      {/* ======================================================== */}
      {selectedCategoryForModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-5xl rounded-3xl bg-slate-950/95 backdrop-blur-md border border-slate-800 shadow-2xl p-3 sm:p-7 space-y-4 sm:space-y-5 my-auto max-h-[95vh] flex flex-col text-right text-slate-300">
            
            {/* Header: لوگو + نام دسته + تعداد تجهیزات و دکمه بستن */}
            <div className="flex flex-wrap items-center justify-between gap-3 sm:gap-4 pb-3 sm:pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={COMPANY_LOGO}
                  alt={BRAND_CONFIG.COMPANY_NAME}
                  className="h-11 w-auto object-contain rounded-xl p-1 bg-black/60 border border-slate-800 shadow-md shrink-0"
                />
                <div>
                  <div className="flex items-center gap-2.5">
                    <h3 className="text-lg sm:text-xl font-bold text-slate-100 flex items-center gap-2">
                      <span className="text-slate-400">
                        {selectedCategoryForModal.name.includes('تورنوس') ? '⚙️' : selectedCategoryForModal.name.includes('فرز') ? '🔩' : selectedCategoryForModal.name.includes('تراش') ? '📐' : selectedCategoryForModal.name.includes('سینتک') ? '🏭' : selectedCategoryForModal.name.includes('مایر') ? '⚡' : selectedCategoryForModal.name.includes('استار') ? '⭐' : '📦'}
                      </span>
                      <span>تجهیزات و چک‌لیست دسته: {selectedCategoryForModal.name}</span>
                    </h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-900 text-slate-300 font-mono font-bold border border-slate-800">
                      تعداد: {toFaDigits(equipments.filter(eq => eq.category === selectedCategoryForModal.name).length)} دستگاه
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    کد دستگاه، نام اپراتور و ثبت مستقیم چک‌لیست سلامت یا عدم انطباق در واحد فنی
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsEquipmentExcelModalOpen(true)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-slate-700 transition-all flex items-center justify-center cursor-pointer shadow-md"
                  title="ورود تجهیزات از فایل اکسل"
                >
                  <Upload className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPmPickerTargetCategory(selectedCategoryForModal.name);
                    const catName = selectedCategoryForModal.name;
                    if (catName === 'تراش') setPmPickerGroupFilter('TULT');
                    else if (catName === 'تورنوس') setPmPickerGroupFilter('TUTN');
                    else if (catName === 'فرز') setPmPickerGroupFilter('MICN');
                    else if (catName === 'مایر') setPmPickerGroupFilter('TUMA');
                    else if (catName === 'سینتک') setPmPickerGroupFilter('SY');
                    else if (catName === 'پرس') setPmPickerGroupFilter('PR');
                    else if (catName === 'تجهیزات دستی') setPmPickerGroupFilter('MANUAL');
                    else setPmPickerGroupFilter('all');
                    setIsPmEquipmentPickerOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-950/50"
                  title="افزودن و تخصیص همزمان چند تجهیز از دیتابیس ماشین‌آلات (PM) با سرچ و تیک گروهی"
                >
                  <CheckSquare className="w-4 h-4" />
                  <span>+ افزودن چندتایی از دیتابیس PM</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setNewEqCategory(selectedCategoryForModal.name);
                    setIsAddEquipmentModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-400" />
                  <span>+ افزودن دستی</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsAssignPanelOpen(!isAssignPanelOpen)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md ${
                    isAssignPanelOpen
                      ? 'bg-cyan-600 text-white border border-cyan-400 shadow-cyan-950/50'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                  }`}
                  title="جستجو در تجهیزات فایل اکسل یا انبار و افزودن به این دسته همراه با تعیین اپراتور"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{isAssignPanelOpen ? 'بستن پنل تخصیص' : '+ تخصیص تجهیز از اکسل / انبار'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategoryForModal(null);
                    setCategoryModalSearch('');
                    setInlineExpandedDefectsEqId(null);
                    setIsAssignPanelOpen(false);
                  }}
                  className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 border border-transparent hover:border-rose-900/40 transition-colors cursor-pointer"
                  title="بستن"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* اعلان پیام موفقیت ثبت درجا */}
            {categoryQuickSuccessToast && (
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-slate-900 to-teal-950/90 border border-emerald-500/60 text-emerald-200 text-xs font-bold flex items-center justify-between gap-3 shadow-lg animate-in fade-in slide-in-from-top-1">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>{categoryQuickSuccessToast}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setCategoryQuickSuccessToast(null)}
                  className="text-emerald-400 hover:text-white px-2 py-0.5"
                >
                  ✕
                </button>
              </div>
            )}

            {/* پنل تخصیص تجهیزات فایل اکسل یا انبار به این دسته (درخواست کاربر: سرچ نام یا کد تجهیز و تعیین اپراتور) */}
            {isAssignPanelOpen && (
              <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-[#0e1726] via-[#09111c] to-[#050b12] border-2 border-cyan-500/60 shadow-2xl space-y-4 animate-in fade-in slide-in-from-top-2">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-cyan-500/30">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-bold">
                      📥
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white flex items-center gap-2">
                        <span>ورود و تخصیص تجهیز به دسته: {selectedCategoryForModal.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">
                          {toFaDigits(equipments.filter(e => !e.category || e.category !== selectedCategoryForModal.name).length)} دستگاه قابل تخصیص
                        </span>
                      </h4>
                      <p className="text-[11px] text-blue-300/80 mt-0.5">
                        با سرچ کد یا نام تجهیز (اضافه‌شده از فایل اکسل یا انبار سیستم)، آن را وارد این دسته کرده و اپراتور مسئول را مشخص نمایید.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* فیلتر دامنه جستجو */}
                    <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-blue-900/50 text-xs">
                      <button
                        type="button"
                        onClick={() => setAssignFilterPool('all')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          assignFilterPool === 'all'
                            ? 'bg-cyan-600 text-white'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        همه تجهیزات سیستم
                      </button>
                      <button
                        type="button"
                        onClick={() => setAssignFilterPool('unassigned')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                          assignFilterPool === 'unassigned'
                            ? 'bg-cyan-600 text-white'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        فقط بدون دسته (آزاد)
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsAssignPanelOpen(false)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* ردیف جستجو و انتخاب اپراتور */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2 relative">
                    <Search className="w-4 h-4 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={assignSearchQuery}
                      onChange={e => setAssignSearchQuery(e.target.value)}
                      placeholder="سرچ کد تجهیز (مانند TU-01، 102) یا عنوان تجهیز از اکسل..."
                      className="w-full bg-slate-950 border border-cyan-500/50 rounded-xl pr-9 pl-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 shadow-inner"
                    />
                  </div>

                  <div className="sm:col-span-1">
                    <select
                      value={assignTargetOperator}
                      onChange={e => setAssignTargetOperator(e.target.value)}
                      className="w-full bg-slate-950 border border-blue-800/60 rounded-xl px-3 py-2.5 text-xs text-cyan-200 font-bold focus:outline-none focus:border-cyan-400 cursor-pointer"
                      title="انتخاب اپراتور پیش‌فرض"
                    >
                      <option value="" className="bg-slate-900 text-slate-400">--- انتخاب اپراتور (۱۲۸ نفر) ---</option>
                      {productionOperators.map(op => (
                        <option key={op.id} value={op.name} className="bg-slate-900 text-white">
                          {op.name} {op.personnelCode ? `(کد: ${toFaDigits(op.personnelCode)})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* لیست تجهیزات یافته شده برای تخصیص به دسته */}
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {(() => {
                    const pool = equipments.filter(eq => {
                      if (assignFilterPool === 'unassigned') {
                        return !eq.category || eq.category === 'متفرقه';
                      }
                      return eq.category !== selectedCategoryForModal.name;
                    });

                    const matched = pool.filter(eq => {
                      if (!assignSearchQuery.trim()) return true;
                      const q = assignSearchQuery.toLowerCase();
                      return (
                        eq.code.toLowerCase().includes(q) ||
                        eq.name.toLowerCase().includes(q) ||
                        (eq.category && eq.category.toLowerCase().includes(q)) ||
                        (eq.hall && eq.hall.toLowerCase().includes(q))
                      );
                    });

                    if (matched.length === 0) {
                      return (
                        <div className="p-4 text-center rounded-2xl bg-slate-950/70 border border-dashed border-blue-900/40 text-xs text-slate-400 space-y-1">
                          <span>هیچ تجهیزی با این عنوان/کد پیدا نشد.</span>
                          <span className="block text-[11px] text-cyan-300">
                            می‌توانید فایل اکسل را بارگذاری کنید یا با کادر زیر کد تجهیز را مستقیماً ثبت نمایید.
                          </span>
                        </div>
                      );
                    }

                    return matched.slice(0, 15).map(eq => (
                      <div
                        key={eq.id}
                        className="p-3 rounded-2xl bg-slate-950/90 border border-blue-900/50 hover:border-cyan-500/50 flex flex-wrap items-center justify-between gap-3 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="font-mono text-xs font-black px-2.5 py-1 rounded-xl bg-blue-950 text-cyan-300 border border-cyan-500/40">
                            {eq.code}
                          </span>
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-white block truncate">{eq.name}</span>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                              <span>دسته فعلی: {eq.category || 'بدون دسته (آزاد)'}</span>
                              <span>•</span>
                              <span>{eq.hall}</span>
                              {eq.inspector && (
                                <>
                                  <span>•</span>
                                  <span className="text-emerald-300">اپراتور: {eq.inspector}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleAssignEquipmentToCategory(eq.id, selectedCategoryForModal.name, assignTargetOperator || eq.inspector || undefined)}
                            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-cyan-950/60"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>ورود به دسته {selectedCategoryForModal.name}</span>
                          </button>
                        </div>
                      </div>
                    ));
                  })()}
                </div>

                {/* فرم تعریف مستقیم سریع کد تجهیز */}
                <div className="pt-3 border-t border-cyan-500/20 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="text-[11px] text-blue-300 font-bold">تعریف مستقیم و ورود درجا به این دسته:</span>
                  <div className="flex items-center gap-2 flex-1 max-w-lg">
                    <input
                      type="text"
                      value={assignFastCode}
                      onChange={e => setAssignFastCode(e.target.value)}
                      placeholder="کد تجهیز (مثلاً TUTN-01)..."
                      className="w-36 bg-slate-950 border border-blue-800 rounded-xl px-2.5 py-1.5 text-xs text-cyan-300 font-mono uppercase"
                    />
                    <input
                      type="text"
                      value={assignFastName}
                      onChange={e => setAssignFastName(e.target.value)}
                      placeholder="عنوان دستگاه..."
                      className="flex-1 bg-slate-950 border border-blue-800 rounded-xl px-2.5 py-1.5 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={() => handleFastAddAndAssign(selectedCategoryForModal.name)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 cursor-pointer shadow-md shadow-emerald-950/40"
                    >
                      + ثبت و ورود درجا
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* نوار جستجوی کد تجهیز یا اپراتور در این دسته */}
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-emerald-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={categoryModalSearch}
                  onChange={e => setCategoryModalSearch(e.target.value)}
                  placeholder={`جستجوی کد تجهیز (مثل TUTN01 یا EQ-T101) یا نام اپراتور در دسته ${selectedCategoryForModal.name}...`}
                  className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pr-10 pl-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* لیست کارت‌های تجهیزات این دسته با کد تجهیز، نام اپراتور و دکمه‌های ثبت چک‌لیست درجا */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1 overscroll-contain touch-pan-y">
              {(() => {
                const catEquipments = equipments
                  .filter(eq => eq.category === selectedCategoryForModal.name)
                  .filter(eq => {
                    if (categoryModalFilterStatus === 'healthy') return eq.status === 'سالم';
                    if (categoryModalFilterStatus === 'issue') return eq.status !== 'سالم';
                    return true;
                  })
                  .filter(eq => {
                    if (!categoryModalSearch.trim()) return true;
                    const q = categoryModalSearch.toLowerCase();
                    return (
                      eq.code.toLowerCase().includes(q) ||
                      eq.name.toLowerCase().includes(q) ||
                      (eq.inspector && eq.inspector.toLowerCase().includes(q)) ||
                      eq.hall.toLowerCase().includes(q)
                    );
                  })
                  .sort((a, b) => {
                    // مرتب‌سازی عددی بر اساس کد تجهیز (TUTN01 اولین باشد، بعد TUTN02 و تا آخر)
                    const extractNum = (code: string) => {
                      const match = code.match(/(\d+)/);
                      return match ? parseInt(match[1], 10) : 999999;
                    };
                    const numA = extractNum(a.code);
                    const numB = extractNum(b.code);
                    if (numA !== numB) {
                      return numA - numB;
                    }
                    return a.code.localeCompare(b.code, undefined, { numeric: true, sensitivity: 'base' });
                  });

                if (catEquipments.length === 0) {
                  return (
                    <div className="py-12 text-center rounded-2xl bg-slate-950/60 border border-dashed border-blue-900/40 space-y-2">
                      <span className="text-3xl block">🔍</span>
                      <h4 className="text-sm font-bold text-white">تجهیزی با این مشخصات یافت نشد</h4>
                      <p className="text-xs text-slate-400">می‌توانید عبارت جستجو را پاک کنید یا تجهیز جدید اضافه کنید.</p>
                    </div>
                  );
                }

                // ۱. نمایش آکاردئونی تجهیزات (دقیقاً مطابق عکس نمونه کاربر با ترتیب صعودی کدها و بازشونده با کلیک)
                if (categoryViewMode === 'accordion') {
                  return (
                    <div className="space-y-3.5 py-1">
                      {catEquipments.map((eq) => {
                        const isHealthy = eq.status === 'سالم';
                        const isIssue = eq.status === 'نیازمند_سرویس' || eq.status === 'تعمیر_اضطراری';
                        const isAccordionOpen = expandedAccordionEqId === eq.id;
                        const isDefectExpanded = inlineExpandedDefectsEqId === eq.id;
                        const currentDefects = inlineInspectionDefectsMap[eq.id] || [];
                        const currentNotes = inlineInspectionNotesMap[eq.id] || '';
                        const currentPhoto = inlineInspectionPhotosMap[eq.id] || null;
                        const currentAutoWo = inlineInspectionAutoWoMap[eq.id] ?? true;
                        const eqCodeKey = (eq.code || '').trim().toUpperCase();
                        const eqRecentLogs =
                          (eqCodeKey ? recentInspectionsByEquipmentKey.get(`CODE:${eqCodeKey}`) : undefined) ||
                          (eq.id ? recentInspectionsByEquipmentKey.get(`ID:${eq.id}`) : undefined) ||
                          [];

                        return (
                          <div
                            key={eq.id}
                            className={`rounded-2xl border transition-all duration-300 overflow-hidden shadow-lg ${
                              isAccordionOpen
                                ? 'bg-[#09111f] border-emerald-500/60 shadow-[0_0_20px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/40'
                                : isIssue
                                ? 'bg-[#0b101a]/95 border-rose-950/80 hover:border-rose-700/60'
                                : 'bg-[#080e19]/90 border-slate-800/80 hover:border-slate-700'
                            }`}
                          >
                            {/* نوار اصلی هدر آکاردئون */}
                            <div
                              onClick={() => {
                                setExpandedAccordionEqId(prev => prev === eq.id ? null : eq.id);
                              }}
                              className="w-full px-4 sm:px-5 py-3.5 sm:py-4 flex items-center justify-between cursor-pointer select-none gap-3 hover:bg-slate-800/25 transition-colors"
                            >
                              {/* سمت راست (در جهت راست به چپ): نقطه نئونی وضعیت + کد تجهیز + | + نام تجهیز + ۵ دایره بازرسی قبلی */}
                              <div className="flex items-center gap-3 min-w-0">
                                {/* نقطه نئونی وضعیت */}
                                <span
                                  className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                                    isIssue
                                      ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.95)] animate-pulse'
                                      : isHealthy
                                      ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.95)]'
                                      : 'bg-slate-500'
                                  }`}
                                />

                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="font-mono text-sm sm:text-base font-black text-white tracking-wide shrink-0">
                                    {eq.code}
                                  </span>
                                  <span className="text-slate-600 font-light text-sm select-none shrink-0">|</span>
                                  <span className="text-xs sm:text-sm text-slate-300 font-medium truncate">
                                    {eq.name}
                                  </span>
                                  {eqRecentLogs.length > 0 && (
                                    <span className="inline-flex items-center gap-1 shrink-0 mr-1">
                                      {eqRecentLogs.slice(0, 5).map((log, dotIdx) => (
                                        <span
                                          key={log.id || dotIdx}
                                          className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                                            log.result === 'conforming'
                                              ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.7)]'
                                              : 'bg-rose-500 shadow-[0_0_6px_rgba(244,63,94,0.85)]'
                                          }`}
                                        />
                                      ))}
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* سمت چپ (در جهت راست به چپ): نام اپراتور (در صورت ثبت) + آیکون مثلث پایین */}
                              <div className="flex items-center gap-3 shrink-0 text-left">
                                {eq.inspector && (
                                  <span className="text-xs sm:text-sm text-slate-400">
                                    اپراتور: {eq.inspector}
                                  </span>
                                )}

                                {/* آیکون مثلث رو به پایین */}
                                <svg
                                  className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-300 shrink-0 ${
                                    isAccordionOpen ? 'rotate-180 text-emerald-400' : ''
                                  }`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                                </svg>
                              </div>
                            </div>

                            {/* بدنه بازشونده آکاردئون */}
                            {isAccordionOpen && (
                              <div className="px-4 sm:px-5 pb-5 pt-3 border-t border-slate-800/80 bg-slate-950/80 space-y-4 animate-in slide-in-from-top-2 duration-200">
                                {/* ردیف مشخصات تکمیلی، سالن و ویرایش کد */}
                                <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="text-slate-400">کد دستگاه:</span>
                                    {editingEquipmentCodeId === eq.id ? (
                                      <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-cyan-400">
                                        <input
                                          type="text"
                                          value={editingEquipmentCodeValue}
                                          onChange={e => setEditingEquipmentCodeValue(e.target.value)}
                                          autoFocus
                                          onKeyDown={e => {
                                            if (e.key === 'Enter') handleSaveEquipmentCode(eq.id);
                                            if (e.key === 'Escape') setEditingEquipmentCodeId(null);
                                          }}
                                          className="w-24 bg-slate-900 border border-cyan-500/70 rounded px-2 py-0.5 text-xs text-cyan-200 font-mono font-bold uppercase outline-none"
                                        />
                                        <button
                                          type="button"
                                          onClick={() => handleSaveEquipmentCode(eq.id)}
                                          className="p-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                                        >
                                          <Check className="w-3.5 h-3.5" />
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setEditingEquipmentCodeId(null)}
                                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                                        >
                                          <X className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-mono font-black text-cyan-300 bg-blue-950/80 px-2.5 py-0.5 rounded-lg border border-cyan-500/30">
                                          {eq.code}
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setEditingEquipmentCodeId(eq.id);
                                            setEditingEquipmentCodeValue(eq.code);
                                          }}
                                          className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                                          title="ویرایش کد تجهیز"
                                        >
                                          <Edit3 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    )}

                                    <span className="text-slate-600">|</span>
                                    <span className="text-slate-400">مکان استقرار:</span>
                                    <span className="text-slate-200 font-bold">{eq.hall}</span>
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => handleRemoveEquipmentFromCategory(eq.id)}
                                    className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-500/40 text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                                  >
                                    <X className="w-3 h-3" />
                                    <span>خروج از این دسته</span>
                                  </button>
                                </div>

                                {/* انتخاب و تخصیص اپراتور با قابلیت سرچ زنده و سریع */}
                                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2.5 text-xs">
                                  <div className="flex flex-wrap items-center justify-between gap-2">
                                    <div className="flex items-center gap-2 text-slate-300">
                                      <User className="w-4 h-4 text-emerald-400" />
                                      <span className="font-bold">اپراتور مسئول این دستگاه:</span>
                                    </div>

                                    {eq.inspector ? (
                                      <div className="flex items-center gap-2 bg-emerald-950/80 border border-emerald-500/50 px-3 py-1 rounded-xl shadow-sm">
                                        <span className="text-emerald-300 font-bold">{eq.inspector}</span>
                                        <button
                                          type="button"
                                          onClick={() => handleUpdateEquipmentOperator(eq.id, '')}
                                          className="text-slate-400 hover:text-rose-400 cursor-pointer p-0.5 rounded-md hover:bg-rose-950/50 transition-colors"
                                          title="حذف اپراتور این دستگاه"
                                        >
                                          <X className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    ) : (
                                      <span className="text-slate-500 text-[11px] font-medium bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                                        هنوز اپراتوری تعیین نشده
                                      </span>
                                    )}
                                  </div>

                                  {/* فیلد جستجوی زنده اپراتور */}
                                  <div className="relative">
                                    <div className="relative flex items-center">
                                      <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 pointer-events-none" />
                                      <input
                                        type="text"
                                        value={operatorSearchMap[eq.id] || ''}
                                        onChange={e => {
                                          const val = e.target.value;
                                          setOperatorSearchMap(prev => ({ ...prev, [eq.id]: val }));
                                          setOperatorPickerOpenId(eq.id);
                                        }}
                                        onFocus={() => setOperatorPickerOpenId(eq.id)}
                                        placeholder="جستجوی سریع اپراتور با نام یا کد پرسنلی..."
                                        className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl pr-9 pl-8 py-2 text-xs text-white placeholder-slate-500 outline-none transition-colors"
                                      />
                                      {operatorSearchMap[eq.id] && (
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setOperatorSearchMap(prev => ({ ...prev, [eq.id]: '' }));
                                          }}
                                          className="absolute left-2.5 text-slate-400 hover:text-white cursor-pointer"
                                        >
                                          <X className="w-3.5 h-3.5" />
                                        </button>
                                      )}
                                    </div>

                                    {/* لیست نتایج فیلتر شده */}
                                    {operatorPickerOpenId === eq.id && (
                                      <div className="mt-2 max-h-48 overflow-y-auto rounded-2xl bg-slate-950 border border-slate-700 shadow-2xl p-1.5 space-y-1 z-30">
                                        <div className="flex items-center justify-between px-2 py-1 border-b border-slate-800/80 text-[10px] text-slate-500">
                                          <span>انتخاب از لیست اپراتورها:</span>
                                          <button
                                            type="button"
                                            onClick={() => setOperatorPickerOpenId(null)}
                                            className="text-slate-400 hover:text-white cursor-pointer"
                                          >
                                            بستن ✕
                                          </button>
                                        </div>

                                        {(() => {
                                          const q = (operatorSearchMap[eq.id] || '').trim().toLowerCase();
                                          const filtered = productionOperators.filter(op =>
                                            !q ||
                                            op.name.toLowerCase().includes(q) ||
                                            (op.personnelCode && op.personnelCode.toLowerCase().includes(q))
                                          );

                                          if (filtered.length === 0) {
                                            return (
                                              <div className="p-3 text-center text-xs text-slate-500">
                                                اپراتوری با نام یا کد «{q}» یافت نشد
                                              </div>
                                            );
                                          }

                                          return (
                                            <div className="space-y-0.5">
                                              {filtered.slice(0, 25).map(op => {
                                                const isCurrent = eq.inspector === op.name;
                                                return (
                                                  <button
                                                    key={op.id}
                                                    type="button"
                                                    onClick={() => {
                                                      handleUpdateEquipmentOperator(eq.id, op.name);
                                                      setOperatorSearchMap(prev => ({ ...prev, [eq.id]: '' }));
                                                      setOperatorPickerOpenId(null);
                                                      setCategoryQuickSuccessToast(`✓ اپراتور دستگاه ${eq.code} به «${op.name}» تغییر یافت.`);
                                                      setTimeout(() => setCategoryQuickSuccessToast(null), 3500);
                                                    }}
                                                    className={`w-full px-3 py-2 rounded-xl text-right flex items-center justify-between text-xs transition-colors cursor-pointer ${
                                                      isCurrent
                                                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold'
                                                        : 'hover:bg-slate-900 text-slate-200'
                                                    }`}
                                                  >
                                                    <span className="font-bold">{op.name}</span>
                                                    {op.personnelCode && (
                                                      <span className="text-[10px] text-slate-400 font-mono bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800">
                                                        کد: {toFaDigits(op.personnelCode)}
                                                      </span>
                                                    )}
                                                  </button>
                                                );
                                              })}
                                            </div>
                                          );
                                        })()}
                                      </div>
                                    )}
                                  </div>
                                </div>

                                {/* دکمه‌های عملیات سریع چک‌لیست */}
                                <div className="grid grid-cols-2 gap-3 pt-1">
                                  {/* دکمه تأیید سلامت کامل */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleQuickConfirmConforming(eq);
                                      setCategoryQuickSuccessToast(`✓ سلامت تجهیز ${eq.code} با موفقیت تأیید شد.`);
                                      setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
                                    }}
                                    className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-950/60 transition-all flex items-center justify-center gap-2 cursor-pointer border border-emerald-400/40"
                                  >
                                    <Check className="w-4 h-4" />
                                    <span>✓ تأیید سلامت دستگاه</span>
                                  </button>

                                  {/* دکمه ثبت عدم انطباق */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setInlineExpandedDefectsEqId(isDefectExpanded ? null : eq.id);
                                    }}
                                    className={`py-2.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer border ${
                                      isDefectExpanded
                                        ? 'bg-rose-700 text-white border-rose-400 shadow-lg shadow-rose-950/60'
                                        : 'bg-rose-950/70 hover:bg-rose-900 text-rose-300 hover:text-white border-rose-500/50'
                                    }`}
                                  >
                                    <AlertTriangle className="w-4 h-4" />
                                    <span>{isDefectExpanded ? 'بستن فرم عیوب' : '⚠️ ثبت عدم انطباق / ایراد'}</span>
                                  </button>
                                </div>

                                {/* فرم کشویی موارد عدم انطباق */}
                                {isDefectExpanded && (
                                  <div className="p-4 rounded-2xl bg-slate-950 border border-rose-500/60 space-y-3 animate-in fade-in duration-200">
                                    <span className="text-xs font-bold text-rose-300 block flex items-center gap-2">
                                      <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                                      <span>انتخاب ایرادات و چک‌لیست عدم انطباق {eq.code}:</span>
                                    </span>

                                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                      {INSPECTION_DEFECT_OPTIONS.map((defect) => {
                                        const isChecked = currentDefects.includes(defect);
                                        return (
                                          <button
                                            key={defect}
                                            type="button"
                                            onClick={() => {
                                              setInlineInspectionDefectsMap(prev => {
                                                const list = prev[eq.id] || [];
                                                return {
                                                  ...prev,
                                                  [eq.id]: isChecked ? list.filter(d => d !== defect) : [...list, defect]
                                                };
                                              });
                                            }}
                                            className={`p-2 rounded-xl text-[11px] font-bold text-right transition-all flex items-center gap-2 cursor-pointer border ${
                                              isChecked
                                                ? 'bg-rose-950 text-white border-rose-500 shadow-sm ring-1 ring-rose-500'
                                                : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:border-slate-700'
                                            }`}
                                          >
                                            <span className={`w-3.5 h-3.5 rounded flex items-center justify-center text-[10px] shrink-0 border ${
                                              isChecked ? 'bg-rose-600 border-rose-400 text-white' : 'border-slate-700'
                                            }`}>
                                              {isChecked ? '✓' : ''}
                                            </span>
                                            <span className="truncate">{defect}</span>
                                          </button>
                                        );
                                      })}
                                    </div>

                                    <div className="space-y-1.5">
                                      <label className="text-[11px] text-slate-400 font-bold block">شرح ایراد و توضیحات تکمیلی:</label>
                                      <textarea
                                        rows={2}
                                        value={currentNotes}
                                        onChange={e => {
                                          const val = e.target.value;
                                          setInlineInspectionNotesMap(prev => ({ ...prev, [eq.id]: val }));
                                        }}
                                        placeholder="توضیحات نقص مشاهده شده جهت ارجاع به تکنسین فنی..."
                                        className="w-full bg-slate-900 border border-slate-700 focus:border-rose-500 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 outline-none"
                                      />
                                    </div>

                                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                                      <div className="flex items-center gap-2">
                                        <label className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer">
                                          <Camera className="w-3.5 h-3.5 text-rose-400" />
                                          <span>{currentPhoto ? 'تغییر عکس پیوست' : 'عکس از قطعه معیوب'}</span>
                                          <input
                                            type="file"
                                            accept="image/*"
                                            capture="environment"
                                            onChange={e => handleInlinePhotoChange(eq.id, e)}
                                            className="hidden"
                                          />
                                        </label>

                                        {currentPhoto && (
                                          <button
                                            type="button"
                                            onClick={() => setSelectedPhotoLightbox(currentPhoto)}
                                            className="p-1 rounded-lg border border-slate-700 hover:border-rose-500 overflow-hidden cursor-pointer"
                                            title="مشاهده عکس"
                                          >
                                            <img src={currentPhoto} alt="نقص" className="w-8 h-8 object-cover rounded" />
                                          </button>
                                        )}
                                      </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                                      <button
                                        type="button"
                                        onClick={() => setInlineExpandedDefectsEqId(null)}
                                        className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                                      >
                                        انصراف
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleInlineSubmitNonConforming(eq)}
                                        className="py-2 px-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white text-xs font-black shadow-md shadow-rose-950/60 cursor-pointer"
                                      >
                                        ✓ ثبت عدم انطباق
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                }

                // ۲. نمایش رول ۳ بعدی استوانه‌ای چرخشی (مطابق درخواست کاربر: مثل درخواست خدمات فنی بچرخه مثل یک رول بالا پایین بشه با قابلیت لمس انگشت روی موبایل)
                if (categoryViewMode === '3dRoll') {
                  return (
                    <EquipmentVerticalCarousel3D
                      equipments={catEquipments}
                      productionOperators={productionOperators}
                      categoryName={selectedCategoryForModal.name}
                      onQuickConfirmConforming={(eq) => {
                        handleQuickConfirmConforming(eq);
                        setCategoryQuickSuccessToast(`✓ سلامت تجهیز ${eq.code} با موفقیت تأیید شد.`);
                        setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
                      }}
                      onInlineSubmitNonConforming={handleInlineSubmitNonConforming}
                      onUpdateEquipmentOperator={handleUpdateEquipmentOperator}
                      onSaveEquipmentCode={handleSaveEquipmentCode}
                      onRemoveFromCategory={handleRemoveEquipmentFromCategory}
                      editingEquipmentCodeId={editingEquipmentCodeId}
                      editingEquipmentCodeValue={editingEquipmentCodeValue}
                      setEditingEquipmentCodeId={setEditingEquipmentCodeId}
                      setEditingEquipmentCodeValue={setEditingEquipmentCodeValue}
                      inlineExpandedDefectsEqId={inlineExpandedDefectsEqId}
                      setInlineExpandedDefectsEqId={setInlineExpandedDefectsEqId}
                      inlineInspectionDefectsMap={inlineInspectionDefectsMap}
                      setInlineInspectionDefectsMap={setInlineInspectionDefectsMap}
                      inlineInspectionNotesMap={inlineInspectionNotesMap}
                      setInlineInspectionNotesMap={setInlineInspectionNotesMap}
                      inlineInspectionPhotosMap={inlineInspectionPhotosMap}
                      setInlineInspectionPhotosMap={setInlineInspectionPhotosMap}
                      inlineInspectionAutoWoMap={inlineInspectionAutoWoMap}
                      setInlineInspectionAutoWoMap={setInlineInspectionAutoWoMap}
                      onPhotoChange={handleInlinePhotoChange}
                      onPhotoLightbox={setSelectedPhotoLightbox}
                      toFaDigits={toFaDigits}
                    />
                  );
                }

                // ۳. نمایش شبکه‌ای معمولی (Grid)
                return (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {catEquipments.map((eq) => {
                      const isHealthy = eq.status === 'سالم';
                      const isWarning = eq.status === 'نیازمند_سرویس';
                      const isExpanded = inlineExpandedDefectsEqId === eq.id;
                      const currentDefects = inlineInspectionDefectsMap[eq.id] || [];
                      const currentNotes = inlineInspectionNotesMap[eq.id] || '';
                      const currentPhoto = inlineInspectionPhotosMap[eq.id] || null;
                      const currentAutoWo = inlineInspectionAutoWoMap[eq.id] ?? true;

                      return (
                        <div
                          key={eq.id}
                          className={`p-3.5 sm:p-4 rounded-3xl border transition-all duration-300 flex flex-col justify-between space-y-3 shadow-lg ${
                            isExpanded
                              ? 'bg-slate-950/95 border-rose-500/80 shadow-rose-950/40 ring-1 ring-rose-500/50'
                              : 'bg-gradient-to-b from-[#0e1620] to-[#080d14] border-blue-900/50 hover:border-cyan-500/50'
                          }`}
                        >
                          <div className="space-y-2.5">
                            {/* کد تجهیز برجسته با مداد کوچک برای تغییر کد (مورد اول کاربر) */}
                            <div className="flex items-center justify-between">
                              {editingEquipmentCodeId === eq.id ? (
                                <div className="flex items-center gap-1.5 bg-slate-900/95 p-1.5 rounded-xl border border-cyan-400 shadow-md">
                                  <span className="text-[11px] font-bold text-cyan-300">کد:</span>
                                  <input
                                    type="text"
                                    value={editingEquipmentCodeValue}
                                    onChange={e => setEditingEquipmentCodeValue(e.target.value)}
                                    autoFocus
                                    onKeyDown={e => {
                                      if (e.key === 'Enter') handleSaveEquipmentCode(eq.id);
                                      if (e.key === 'Escape') setEditingEquipmentCodeId(null);
                                    }}
                                    className="w-24 sm:w-28 bg-slate-950 border border-cyan-500/70 rounded-lg px-2 py-1 text-xs text-cyan-200 font-mono font-bold focus:outline-none uppercase"
                                    placeholder="کد جدید..."
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleSaveEquipmentCode(eq.id)}
                                    className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer transition-colors"
                                    title="ذخیره کد تجهیز"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEquipmentCodeId(null)}
                                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors"
                                    title="انصراف"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-between w-full gap-2">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <span className="font-mono text-xs sm:text-sm font-black text-cyan-300 bg-blue-950/90 px-3.5 py-1.5 rounded-xl border border-cyan-500/50 shadow-inner shrink-0">
                                      کد: {eq.code}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setEditingEquipmentCodeId(eq.id);
                                        setEditingEquipmentCodeValue(eq.code);
                                      }}
                                      className="p-1.5 rounded-xl bg-blue-950/80 hover:bg-cyan-600/30 text-cyan-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400 transition-all cursor-pointer shadow-sm group shrink-0"
                                      title="ویرایش کد تجهیز (تغییر کد)"
                                    >
                                      <Edit3 className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                                    </button>
                                    <span className="text-xs font-bold text-white truncate max-w-[150px] sm:max-w-[200px]" title={eq.name}>
                                      {eq.name}
                                    </span>
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => handleRemoveEquipmentFromCategory(eq.id)}
                                    className="px-2 py-1 rounded-xl bg-slate-900/90 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-500/40 text-[10px] flex items-center gap-1 cursor-pointer transition-colors shrink-0"
                                    title="خروج این تجهیز از دسته"
                                  >
                                    <X className="w-3 h-3" />
                                    <span>خروج از دسته</span>
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* نام اپراتور */}
                            <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-blue-900/40 flex items-center justify-between gap-2 text-xs">
                              <div className="flex items-center gap-1.5 text-blue-200">
                                <User className="w-3.5 h-3.5 text-cyan-400" />
                                <span className="font-bold text-[11px]">نام اپراتور:</span>
                              </div>
                              <select
                                value={eq.inspector || ''}
                                onChange={e => handleUpdateEquipmentOperator(eq.id, e.target.value)}
                                className="bg-[#0b1219] border border-blue-800/60 rounded-xl px-2.5 py-1 text-xs text-white font-bold focus:outline-none focus:border-cyan-400 cursor-pointer"
                                title="انتخاب یا تغییر اپراتور این دستگاه"
                              >
                                <option value="" className="bg-slate-900 text-slate-400"></option>
                                {productionOperators.map(op => (
                                  <option key={op.id} value={op.name} className="bg-slate-900 text-white">
                                    {op.name} {op.personnelCode ? `(${toFaDigits(op.personnelCode)})` : ''}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          {/* دکمه‌های اقدام چک‌لیست همونجا (مورد ۲ کاربر) */}
                          <div className="pt-1.5 border-t border-blue-900/40 space-y-2.5">
                            <div className="grid grid-cols-2 gap-2">
                              {/* دکمه ۱: تایید سلامت بدون مشکل (یک کلیک) */}
                              <button
                                type="button"
                                onClick={() => {
                                  handleQuickConfirmConforming(eq);
                                  setCategoryQuickSuccessToast(`✓ سلامت تجهیز ${eq.code} با موفقیت تأیید و ثبت شد.`);
                                  setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
                                }}
                                className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-950/60 transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-400/50"
                                title="تأیید فوری سلامت این تجهیز بدون مشکل"
                              >
                                <Check className="w-4 h-4 text-emerald-200" />
                                <span>✓ تأیید سلامت</span>
                              </button>

                              {/* دکمه ۲: دارای عدم انطباق (باز کردن چک‌لیست عیوب) */}
                              <button
                                type="button"
                                onClick={() => {
                                  setInlineExpandedDefectsEqId(isExpanded ? null : eq.id);
                                }}
                                className={`py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                                  isExpanded
                                    ? 'bg-rose-700 text-white border-rose-400 shadow-md shadow-rose-950/60'
                                    : 'bg-rose-950/70 hover:bg-rose-900/80 text-rose-300 hover:text-white border-rose-500/50'
                                }`}
                                title="ثبت نقص فنی، عکس‌برداری و موارد عدم انطباق"
                              >
                                <AlertTriangle className="w-4 h-4 text-rose-300" />
                                <span>{isExpanded ? 'بستن فرم' : '⚠️ عدم انطباق'}</span>
                              </button>
                            </div>

                            {/* فرم کشویی عدم انطباق درست زیر کارت تجهیز (همونجا) */}
                            {isExpanded && (
                              <div className="p-4 rounded-2xl bg-slate-950 border border-rose-500/50 space-y-3 animate-in fade-in duration-200">
                                <span className="text-[11px] font-bold text-rose-300 block flex items-center gap-1.5">
                                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                                  <span>انتخاب موارد عدم انطباق تجهیز {eq.code}:</span>
                                </span>

                                {/* ۸ مورد عدم انطباق مطابق عکس ۴ */}
                                <div className="grid grid-cols-2 gap-1.5">
                                  {INSPECTION_DEFECT_OPTIONS.map((defect) => {
                                    const isChecked = currentDefects.includes(defect);
                                    return (
                                      <button
                                        key={defect}
                                        type="button"
                                        onClick={() => {
                                          const next = isChecked
                                            ? currentDefects.filter(d => d !== defect)
                                            : [...currentDefects, defect];
                                          setInlineInspectionDefectsMap(prev => ({
                                            ...prev,
                                            [eq.id]: next
                                          }));
                                        }}
                                        className={`p-2 rounded-xl text-[11px] font-bold flex items-center justify-between border transition-all cursor-pointer ${
                                          isChecked
                                            ? 'bg-rose-950 text-white border-rose-500 ring-1 ring-rose-400'
                                            : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:text-white'
                                        }`}
                                      >
                                        <span>{defect}</span>
                                        <span className={`w-4 h-4 rounded text-[10px] flex items-center justify-center font-bold ${
                                          isChecked ? 'bg-rose-500 text-white' : 'border border-slate-700'
                                        }`}>
                                          {isChecked ? '✓' : ''}
                                        </span>
                                      </button>
                                    );
                                  })}
                                </div>

                                {/* توضیحات بازرس */}
                                <div>
                                  <textarea
                                    value={currentNotes}
                                    onChange={e => {
                                      const val = e.target.value;
                                      setInlineInspectionNotesMap(prev => ({ ...prev, [eq.id]: val }));
                                    }}
                                    rows={2}
                                    placeholder="شرح دقیق اشکال مشاهده‌شده..."
                                    className="w-full bg-[#0b1219] border border-blue-900/60 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-400"
                                  />
                                </div>

                                {/* عکس‌برداری عدم انطباق با دوربین یا بارگذاری فایل */}
                                <div>
                                  {currentPhoto ? (
                                    <div className="p-2.5 rounded-xl bg-[#0b1219] border border-rose-500/40 flex items-center justify-between gap-2">
                                      <div className="flex items-center gap-2">
                                        <img
                                          src={currentPhoto}
                                          alt="عکس عدم انطباق"
                                          className="w-12 h-12 object-cover rounded-lg border border-rose-500/50 cursor-pointer"
                                          onClick={() => setSelectedPhotoLightbox(currentPhoto)}
                                        />
                                        <span className="text-[11px] font-bold text-white">عکس ضمیمه شد ✓</span>
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <button
                                          type="button"
                                          onClick={() => setSelectedPhotoLightbox(currentPhoto)}
                                          className="px-2 py-1 rounded bg-slate-800 text-cyan-300 text-[10px]"
                                        >
                                          بزرگنمایی
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setInlineInspectionPhotosMap(prev => ({ ...prev, [eq.id]: null }));
                                          }}
                                          className="px-2 py-1 rounded bg-rose-950 text-rose-300 text-[10px]"
                                        >
                                          حذف
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <label className="flex items-center justify-center gap-2 p-2.5 rounded-xl border border-dashed border-rose-500/40 bg-[#0b1219] hover:bg-slate-900 text-xs font-bold text-rose-300 cursor-pointer transition-colors">
                                      <Camera className="w-4 h-4 text-rose-400" />
                                      <span>عکس عدم انطباق 📷 (عکس با دوربین یا انتخاب فایل)</span>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        capture="environment"
                                        onChange={e => handleInlinePhotoChange(eq.id, e)}
                                        className="hidden"
                                      />
                                    </label>
                                  )}
                                </div>

                                {/* صدور خودکار دستور کار */}
                                <div className="flex items-center justify-between p-2 rounded-xl bg-blue-950/40 border border-blue-900/40 text-xs text-blue-200">
                                  <span>صدور خودکار دستور کار در واحد خدمات فنی:</span>
                                  <input
                                    type="checkbox"
                                    checked={currentAutoWo}
                                    onChange={e => {
                                      const checked = e.target.checked;
                                      setInlineInspectionAutoWoMap(prev => ({ ...prev, [eq.id]: checked }));
                                    }}
                                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                                  />
                                </div>

                                {/* ثبت نهایی عدم انطباق و انصراف */}
                                <div className="grid grid-cols-2 gap-2 pt-1">
                                  <button
                                    type="button"
                                    onClick={() => setInlineExpandedDefectsEqId(null)}
                                    className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold"
                                  >
                                    انصراف
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleInlineSubmitNonConforming(eq)}
                                    className="py-2 px-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white text-xs font-black shadow-md shadow-rose-950/60"
                                  >
                                    ✓ ثبت عدم انطباق
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            {/* Footer Modal: دکمه بستن */}
            <div className="pt-3 border-t border-blue-900/40 flex items-center justify-between text-xs text-slate-400">
              <span>{BRAND_CONFIG.COMPANY_FULL_NAME} • بازرسی فنی تجهیزات</span>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategoryForModal(null);
                  setCategoryModalSearch('');
                  setInlineExpandedDefectsEqId(null);
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
              >
                بستن پنجره
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DEDICATED MODAL: فقط و فقط ویرایش نام و عکس پس‌زمینه دسته (بدون هیچ مورد دیگر) */}
      {/* ======================================================== */}
      {categoryToQuickEdit && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-5 text-right text-slate-200 animate-in zoom-in-95">
            {/* Header: فقط نام و عکس پس‌زمینه */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center text-sm font-bold shadow-inner">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">تنظیم نام و عکس پس‌زمینه</h3>
                  <span className="text-xs text-slate-500">دسته‌بندی: {categoryToQuickEdit.name}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCategoryToQuickEdit(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* بخش ۱: ویرایش نام دسته‌بندی */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">نام دسته‌بندی:</label>
              <input
                type="text"
                value={quickEditCatName}
                onChange={e => setQuickEditCatName(e.target.value)}
                placeholder="نام دسته (مثلاً تورنوس، فرز، تراش...)"
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white font-bold outline-none transition-colors"
                autoFocus
              />
            </div>

            {/* بخش ۲: عکس پس‌زمینه کارت */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">عکس پس‌زمینه کارت:</label>
              
              {/* پیش‌نمایش تصویر در صورت انتخاب بودن */}
              {quickEditCatImage ? (
                <div className="relative w-full h-36 rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 shadow-inner group">
                  <img
                    src={quickEditCatImage}
                    alt="پیش‌نمایش پس‌زمینه"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-3">
                    <span className="text-xl font-bold text-white drop-shadow-md">
                      {quickEditCatName || categoryToQuickEdit.name}
                    </span>
                  </div>

                  {/* دکمه تنظیم مجدد کادر و اندازه */}
                  <button
                    type="button"
                    onClick={() => setRawImageForFraming(quickEditCatImage)}
                    className="absolute top-2 right-2 px-2.5 py-1 rounded-xl bg-slate-950/90 hover:bg-slate-800 text-emerald-300 border border-emerald-500/40 text-xs flex items-center gap-1 transition-colors cursor-pointer shadow-lg"
                    title="تنظیم مجدد کادر و بزرگ‌نمایی/کوچک‌نمایی"
                  >
                    <Crop className="w-3.5 h-3.5" />
                    <span>تنظیم کادر</span>
                  </button>

                  {/* دکمه حذف عکس */}
                  <button
                    type="button"
                    onClick={() => setQuickEditCatImage('')}
                    className="absolute top-2 left-2 px-2.5 py-1 rounded-xl bg-rose-950/90 hover:bg-rose-900 text-rose-300 border border-rose-600/50 text-xs flex items-center gap-1 transition-colors cursor-pointer shadow-lg"
                    title="حذف تصویر"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف عکس</span>
                  </button>
                </div>
              ) : (
                <div className="w-full h-24 rounded-2xl border border-dashed border-slate-700/80 bg-slate-950/60 flex flex-col items-center justify-center text-slate-500 text-xs gap-1.5 p-3">
                  <ImageIcon className="w-6 h-6 text-slate-600" />
                  <span>عکسی برای پس‌زمینه این دسته قرار داده نشده است</span>
                </div>
              )}

              {/* دکمه انتخاب / بارگذاری فایل عکس */}
              <div className="pt-1">
                <label className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-700 shadow-sm">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <span>{quickEditCatImage ? 'تغییر عکس پس‌زمینه (با کادر و مقیاس)' : 'انتخاب عکس پس‌زمینه (با کادر و مقیاس)'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (ev) => {
                          if (typeof ev.target?.result === 'string') {
                            const raw = ev.target.result;
                            compressImageDataUrl(raw, 960, 0.82).then(compressed => {
                              setRawImageForFraming(compressed);
                            });
                          }
                        };
                        reader.readAsDataURL(file);
                        e.target.value = '';
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* دکمه‌های اقدام: ذخیره و انصراف */}
            <div className="flex items-center gap-2.5 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={handleSaveCategoryQuickEdit}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-lg shadow-emerald-950/60 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>ذخیره تغییرات</span>
              </button>

              <button
                type="button"
                onClick={() => setCategoryToQuickEdit(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: تنظیم کادر و بزرگ‌نمایی/کوچک‌نمایی عکس پس‌زمینه */}
      {/* ======================================================== */}
      <ImageFramingModal
        isOpen={!!rawImageForFraming}
        imageSrc={rawImageForFraming || ''}
        categoryName={quickEditCatName || categoryToQuickEdit?.name}
        onConfirm={async (croppedUrl) => {
          const compressed = await compressImageDataUrl(croppedUrl, 480, 0.75);
          setQuickEditCatImage(compressed);
          setRawImageForFraming(null);
        }}
        onCancel={() => setRawImageForFraming(null)}
        aspectRatio={1.7}
      />

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 2: مدیریت دسته‌بندی تجهیزات (عکس ۳ کاربر) */}
      {/* ======================================================== */}
      {isCategoryManageModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-3xl bg-gradient-to-b from-[#141b24] to-[#0c1219] border border-cyan-500/50 shadow-2xl p-6 sm:p-7 space-y-5 text-right animate-in zoom-in-95 my-6">
            
            {/* Header: مدیریت دسته‌بندی تجهیزات */}
            <div className="pb-4 border-b border-blue-900/40 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <span>🗂</span>
                  <span>مدیریت دسته‌بندی تجهیزات</span>
                </h3>
                <p className="text-xs text-blue-300/70 mt-1">
                  این دسته‌ها کاملاً قابل تغییر هستند؛ دسته جدید اضافه کن یا دسته موجود را ویرایش/غیرفعال کن.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCategoryManageModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* لیست دسته‌ها با ویرایش و حذف مطابق عکس ۳ */}
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {checklistCategories.map((cat) => {
                const isEditing = editingCatId === cat.id;
                return (
                  <div
                    key={cat.id}
                    className="p-3.5 rounded-2xl bg-slate-950/80 border border-blue-900/40 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors"
                  >
                    {isEditing ? (
                      <div className="flex-1 flex items-center gap-2">
                        <input
                          type="text"
                          value={editingCatName}
                          onChange={e => setEditingCatName(e.target.value)}
                          placeholder="نام دسته..."
                          className="flex-1 bg-slate-900 border border-cyan-500/60 rounded-xl px-2.5 py-1 text-xs text-white"
                        />
                        <input
                          type="number"
                          value={editingCatCount}
                          onChange={e => setEditingCatCount(Number(e.target.value))}
                          placeholder="تعداد..."
                          className="w-16 bg-slate-900 border border-cyan-500/60 rounded-xl px-2 py-1 text-xs text-white font-mono text-center"
                        />
                        <button
                          type="button"
                          onClick={handleCategorySaveEdit}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                        >
                          ذخیره
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCatId(null)}
                          className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs"
                        >
                          انصراف
                        </button>
                      </div>
                    ) : (
                      <>
                        <div>
                          <strong className="text-sm font-black text-white block">{cat.name}</strong>
                          <span className="text-xs text-slate-400 font-mono">{toFaDigits(cat.equipmentCount)} تجهیز</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCatId(cat.id);
                              setEditingCatName(cat.name);
                              setEditingCatCount(cat.equipmentCount);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-blue-300 hover:text-white border border-blue-800/40 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>ویرایش</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCategoryDelete(cat.id)}
                            className="px-3 py-1.5 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* فرم افزودن دسته جدید */}
            {isAddingNewCategory && (
              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-3 animate-in fade-in">
                <span className="text-xs font-bold text-cyan-300 block">افزودن دسته‌بندی جدید:</span>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={e => setNewCatName(e.target.value)}
                    placeholder="نام دسته (مثال: پرس، وایرکات...)"
                    className="col-span-2 bg-slate-950 border border-cyan-500/60 rounded-xl px-3 py-2 text-xs text-white"
                  />
                  <input
                    type="number"
                    value={newCatCount}
                    onChange={e => setNewCatCount(Number(e.target.value))}
                    placeholder="تعداد دستگاه"
                    className="col-span-1 bg-slate-950 border border-cyan-500/60 rounded-xl px-3 py-2 text-xs text-white font-mono text-center"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingNewCategory(false)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                  >
                    انصراف
                  </button>
                  <button
                    type="button"
                    onClick={handleCategoryAddNew}
                    className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                  >
                    ثبت دسته‌بندی
                  </button>
                </div>
              </div>
            )}

            {/* دکمه‌های بازگشت، بازنشانی به ۹ دسته اصلی و افزودن دسته مطابق عکس ۳ */}
            <div className="space-y-2 pt-3 border-t border-blue-900/40">
              <button
                type="button"
                onClick={() => {
                  setChecklistCategories(EXACT_9_MAIN_CATEGORIES);
                  setCategoryQuickSuccessToast('✓ لیست دسته‌بندی‌ها بازنشانی شد.');
                  setTimeout(() => setCategoryQuickSuccessToast(null), 4000);
                }}
                className="w-full py-2 px-3 rounded-xl bg-blue-950/70 hover:bg-blue-900 border border-cyan-500/30 text-cyan-300 text-xs font-bold transition-all cursor-pointer text-center flex items-center justify-center gap-1.5"
              >
                <span>🔄 بازنشانی لیست دسته‌بندی‌ها</span>
              </button>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setIsCategoryManageModalOpen(false)}
                  className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition-all cursor-pointer"
                >
                  بازگشت
                </button>

                <button
                  type="button"
                  onClick={() => setIsAddingNewCategory(true)}
                  className="py-3 px-4 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white text-xs font-black shadow-lg shadow-red-950/60 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ افزودن دسته</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 3: نوار کشویی ابزارهای چک‌لیست (عکس ۲)   */}
      {/* ======================================================== */}
      {isChecklistDrawerOpen && (
        <>
          <div
            onClick={() => setIsChecklistDrawerOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 transition-opacity"
          />
          <aside className="fixed top-0 right-0 h-full w-84 max-w-[88vw] z-50 bg-[#0c1322]/95 backdrop-blur-2xl border-l border-slate-800 p-5 flex flex-col justify-between shadow-2xl text-right animate-in slide-in-from-right duration-300 overflow-y-auto">
            <div className="space-y-5">
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-800/80">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-emerald-400">
                    <ClipboardCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">نوار ابزار چک‌لیست</h3>
                    <p className="text-[10px] text-slate-400">سامانه بازرسی دوره‌ای خط تولید</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsChecklistDrawerOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* خلاصه شاخص‌های کلیدی بازرسی (کارت یک‌دست و مرتب) */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-2.5 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <BarChart2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-xs font-bold">شاخص‌های آماری</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setIsChecklistDrawerOpen(false); setIsInspectionHistoryModalOpen(true); }}
                    className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-bold cursor-pointer transition-colors"
                  >
                    <span>سوابق کامل</span>
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">کل تجهیزات</span>
                    <strong className="text-sm font-bold text-white font-mono">{toFaDigits(totalEquipmentsCount)}</strong>
                    <span className="text-[9px] text-slate-500 block">دستگاه</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">بازرسی امروز</span>
                    <strong className="text-sm font-bold text-emerald-400 font-mono">{toFaDigits(todayInspectionsCount)}</strong>
                    <span className="text-[9px] text-slate-500 block">مورد</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">عدم انطباق</span>
                    <strong className="text-sm font-bold text-rose-400 font-mono">{toFaDigits(totalNonConformitiesCount)}</strong>
                    <span className="text-[9px] text-slate-500 block">مورد</span>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">درصد سلامت</span>
                    <strong className="text-sm font-bold text-slate-200 font-mono">{toFaDigits(conformingPercentage)}٪</strong>
                    <span className="text-[9px] text-slate-500 block">انطباق</span>
                  </div>
                </div>
              </div>

              {/* بخش ۱: مدیریت ماشین‌آلات و دسته‌ها */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 px-1 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-slate-500" />
                  مدیریت ماشین‌آلات و دسته‌ها
                </span>

                {/* تجهیزات چک‌لیست */}
                <button
                  type="button"
                  onClick={() => {
                    setIsChecklistDrawerOpen(false);
                    setSelectedCategoryForModal(checklistCategories[0] || null);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Sliders className="w-4 h-4 text-emerald-400" />
                    <span>تجهیزات و چک‌لیست ({toFaDigits(equipments.length)} دستگاه)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* دسته‌بندی تجهیزات */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setIsCategoryManageModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Layers className="w-4 h-4 text-slate-400" />
                    <span>دسته‌بندی تجهیزات (۹ دسته)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* تخصیص گروهی از دیتابیس PM */}
                <button
                  type="button"
                  onClick={() => {
                    setIsChecklistDrawerOpen(false);
                    setIsPmEquipmentPickerOpen(true);
                  }}
                  className="w-full p-2.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-950/60 border border-emerald-500/40 text-right flex items-center justify-between text-xs font-bold text-emerald-300 hover:text-emerald-200 transition-all cursor-pointer group shadow-sm"
                >
                  <div className="flex items-center gap-2.5">
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                    <span>تخصیص گروهی تجهیزات از دیتابیس PM</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* مکان‌ها و سالن‌های کارخانه */}
                <button
                  type="button"
                  onClick={() => {
                    setIsChecklistDrawerOpen(false);
                    setIsFactoryLocationsModalOpen(true);
                  }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    <span>مکان‌ها و سالن‌ها (S01 - S08)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* ورود تجهیزات با فایل اکسل */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setIsEquipmentExcelModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <FileSpreadsheet className="w-4 h-4 text-slate-400" />
                    <span>ورود تجهیزات با فایل اکسل</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>
              </div>

              {/* بخش ۲: ثبت و افزودن سریع */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 px-1 flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-slate-500" />
                  ثبت و افزودن سریع
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => { setIsChecklistDrawerOpen(false); setIsAddEquipmentModalOpen(true); }}
                    className="p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                  >
                    <span className="flex items-center gap-1.5">
                      <Plus className="w-3.5 h-3.5 text-emerald-400" />
                      تجهیز جدید
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setIsChecklistDrawerOpen(false); setIsAddOperatorModalOpen(true); }}
                    className="p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                  >
                    <span className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      اپراتور جدید
                    </span>
                  </button>
                </div>
              </div>

              {/* بخش ۳: سوابق و گزارش‌ها */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 px-1 flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-slate-500" />
                  سوابق و گزارش‌ها
                </span>

                {/* اپراتورها */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setIsOperatorsModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Users className="w-4 h-4 text-slate-400" />
                    <span>اپراتورها با کد پرسنلی ({toFaDigits(productionOperators.length)} نفر)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* تاریخچه بازرسی */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setIsInspectionHistoryModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <History className="w-4 h-4 text-slate-400" />
                    <span>تاریخچه کامل بازرسی‌ها</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* رتبه‌بندی اپراتورها */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setIsLeaderboardModalOpen(true); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-amber-400 text-sm">🏆</span>
                    <span>رتبه‌بندی و امتیاز اپراتورها</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>

                {/* متفرقه */}
                <button
                  type="button"
                  onClick={() => { setIsChecklistDrawerOpen(false); setChecklistCategoryFilter('متفرقه'); }}
                  className="w-full p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-right flex items-center justify-between text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Package className="w-4 h-4 text-slate-400" />
                    <span>تجهیزات بدون دسته (متفرقه)</span>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:-translate-x-0.5 transition-transform" />
                </button>
              </div>

            </div>

            <div className="pt-3.5 mt-3 border-t border-slate-800/80 text-[10px] text-slate-500 text-center">
              سامانه بازرسی دوره‌ای • {BRAND_CONFIG.COMPANY_FULL_NAME}
            </div>
          </aside>
        </>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 4: تاریخچه کامل بازرسی‌ها و گالری عکس     */}
      {/* ======================================================== */}
      {isInspectionHistoryModalOpen && (() => {
        const searchNorm = toEnDigits(historyEquipmentSearch).trim().toLowerCase();

        const matchedDirectory = searchNorm
          ? historyEquipmentDirectory.filter(item =>
              item.code.toLowerCase().includes(searchNorm) ||
              item.name.toLowerCase().includes(searchNorm) ||
              item.category.toLowerCase().includes(searchNorm)
            )
          : historyEquipmentDirectory;

        const selectedEquipmentStats = selectedHistoryEquipCode
          ? historyEquipmentDirectory.find(
              item => item.code.toUpperCase() === selectedHistoryEquipCode.trim().toUpperCase()
            ) || null
          : searchNorm && matchedDirectory.length === 1
          ? matchedDirectory[0]
          : null;

        const scopedLogs = inspectionLogs.filter(log => {
          if (historyDateFilter !== 'all') {
            const logDateNorm = normalizeShamsiDatePm(log.date) || toEnDigits(log.date || '').trim();
            if (logDateNorm !== historyDateFilter) return false;
          }
          if (selectedHistoryEquipCode) {
            return (log.equipmentCode || '').trim().toUpperCase() === selectedHistoryEquipCode.trim().toUpperCase();
          }
          if (searchNorm) {
            return (
              (log.equipmentCode || '').toLowerCase().includes(searchNorm) ||
              (log.equipmentName || '').toLowerCase().includes(searchNorm) ||
              (log.operator || '').toLowerCase().includes(searchNorm) ||
              (log.category || '').toLowerCase().includes(searchNorm)
            );
          }
          return true;
        });

        const scopedConformingCount = scopedLogs.filter(l => l.result === 'conforming').length;
        const scopedNonConformingCount = scopedLogs.filter(l => l.result === 'non_conforming').length;
        const visibleHistoryLogs = scopedLogs.filter(
          log => historyFilterResult === 'all' || log.result === historyFilterResult
        );

        return (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <div className="w-full max-w-4xl rounded-3xl bg-gradient-to-b from-[#141b24] to-[#0c1219] border border-cyan-500/50 shadow-2xl p-6 sm:p-7 space-y-5 text-right animate-in zoom-in-95 my-6">

              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-blue-900/40">
                <div>
                  <h3 className="text-lg font-black text-white flex items-center gap-2">
                    <History className="w-5 h-5 text-emerald-400" />
                    <span>تاریخچه کامل بازرسی‌های خط تولید</span>
                    <span className="text-xs font-mono font-bold text-cyan-300">
                      ({toFaDigits(inspectionLogs.length)} پرونده)
                    </span>
                  </h3>
                  <p className="text-xs text-blue-300/70 mt-1">جستجوی سریع تجهیز برای مشاهده آمار کامل عدم انطباق‌ها، سوابق سلامت و عکس‌های بازرسی</p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsInspectionHistoryModalOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* ۴ شاخص آماری کلیدی بازرسی در گزارش */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-cyan-500/40 text-center">
                  <span className="text-[11px] text-blue-300/80 block mb-0.5 font-bold">کل تجهیزات</span>
                  <strong className="text-xl font-black text-white font-mono">{toFaDigits(totalEquipmentsCount)}</strong>
                  <span className="text-[10px] text-blue-300/60 block">دستگاه</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setHistoryDateFilter(todayNormalizedDate);
                    setHistoryFilterResult('all');
                  }}
                  title="مشاهده لیست همه بازرسی‌های امروز"
                  className={`p-3 rounded-2xl border text-center cursor-pointer transition-all ${
                    historyDateFilter === todayNormalizedDate
                      ? 'bg-emerald-900/70 border-emerald-400 ring-1 ring-emerald-400/50'
                      : 'bg-emerald-950/60 hover:bg-emerald-900/50 border-emerald-500/40'
                  }`}
                >
                  <span className="text-[11px] text-emerald-300/80 block mb-0.5 font-bold">بازرسی‌های امروز</span>
                  <strong className="text-xl font-black text-emerald-400 font-mono">{toFaDigits(todayInspectionsCount)}</strong>
                  <span className="text-[10px] text-emerald-300/60 block">مورد ثبت‌شده (کلیک کنید)</span>
                </button>
                <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-500/40 text-center">
                  <span className="text-[11px] text-rose-300/90 block mb-0.5 font-bold">عدم انطباق‌ها</span>
                  <strong className="text-xl font-black text-rose-400 font-mono">{toFaDigits(totalNonConformitiesCount)}</strong>
                  <span className="text-[10px] text-rose-300/60 block">مورد ثبت‌شده</span>
                </div>
                <div className="p-3 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 text-center">
                  <span className="text-[11px] text-indigo-300/80 block mb-0.5 font-bold">بازرسی بدون مشکل</span>
                  <strong className="text-xl font-black text-indigo-300 font-mono">{toFaDigits(conformingPercentage)}٪</strong>
                  <span className="text-[10px] text-indigo-300/60 block">از کل بازرسی‌ها</span>
                </div>
              </div>

              {/* باکس جستجوی سریع تجهیز و انتخاب از لیست */}
              <div className="relative">
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-cyan-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={historyEquipmentSearch}
                      onFocus={() => setIsHistoryEquipDropdownOpen(true)}
                      onChange={(e) => {
                        setHistoryEquipmentSearch(e.target.value);
                        setSelectedHistoryEquipCode(null);
                        setIsHistoryEquipDropdownOpen(true);
                      }}
                      placeholder="جستجوی سریع کد یا نام تجهیز (مثال: TUTN01 یا تورنوس) جهت مشاهده آمار کامل و تعداد عدم انطباق..."
                      className="w-full pr-10 pl-9 py-2.5 rounded-xl bg-slate-950/90 border border-cyan-500/40 focus:border-cyan-400 focus:outline-none text-xs text-white placeholder:text-slate-500"
                    />
                    {(historyEquipmentSearch || selectedHistoryEquipCode) && (
                      <button
                        type="button"
                        onClick={() => {
                          setHistoryEquipmentSearch('');
                          setSelectedHistoryEquipCode(null);
                          setIsHistoryEquipDropdownOpen(false);
                        }}
                        title="پاک کردن جستجو"
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {selectedHistoryEquipCode && (
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryEquipmentSearch('');
                        setSelectedHistoryEquipCode(null);
                        setIsHistoryEquipDropdownOpen(false);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-bold shrink-0 cursor-pointer"
                    >
                      نمایش همه تجهیزات
                    </button>
                  )}
                </div>

                {/* لیست کشویی پیشنهادات جستجوی سریع */}
                {isHistoryEquipDropdownOpen && !selectedHistoryEquipCode && matchedDirectory.length > 0 && (
                  <div className="mt-1.5 w-full rounded-2xl bg-slate-950 border border-cyan-500/40 shadow-2xl max-h-56 overflow-y-auto divide-y divide-blue-900/30 z-20">
                    <div className="px-3 py-1.5 bg-slate-900/90 text-[10px] text-blue-300 font-bold flex items-center justify-between sticky top-0">
                      <span>تجهیزات یافت‌شده ({toFaDigits(matchedDirectory.length)}) — برای مشاهده آمار کامل کلیک کنید:</span>
                      <button
                        type="button"
                        onClick={() => setIsHistoryEquipDropdownOpen(false)}
                        className="text-slate-400 hover:text-white cursor-pointer"
                      >
                        بستن لیست
                      </button>
                    </div>
                    {matchedDirectory.slice(0, 12).map((item) => (
                      <button
                        key={item.code}
                        type="button"
                        onClick={() => {
                          setSelectedHistoryEquipCode(item.code);
                          setHistoryEquipmentSearch(`${item.code} — ${item.name}`);
                          setIsHistoryEquipDropdownOpen(false);
                        }}
                        className="w-full px-3.5 py-2.5 text-right flex items-center justify-between gap-2 hover:bg-blue-950/60 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="font-mono font-black text-xs text-cyan-300 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded-lg shrink-0">
                            {item.code}
                          </span>
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-white truncate block">{item.name}</span>
                            <span className="text-[10px] text-slate-400 block truncate">
                              دسته: {item.category} • کل بازرسی: {toFaDigits(item.totalInspections)}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.nonConformingCount > 0
                              ? 'bg-rose-950 text-rose-300 border border-rose-500/40'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                          }`}>
                            {item.nonConformingCount > 0
                              ? `${toFaDigits(item.nonConformingCount)} عدم انطباق`
                              : 'بدون عدم انطباق'}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* کارت آمار کامل تجهیز انتخاب‌شده / یافت‌شده */}
              {selectedEquipmentStats && (
                <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900/95 via-slate-950 to-[#091522] border border-cyan-500/40 shadow-lg space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-blue-900/40">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono font-black text-sm text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-2.5 py-1 rounded-xl">
                        {selectedEquipmentStats.code}
                      </span>
                      <div>
                        <h4 className="text-sm font-black text-white">{selectedEquipmentStats.name}</h4>
                        <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-2">
                          <span>دسته: <strong className="text-slate-200">{selectedEquipmentStats.category}</strong></span>
                          {selectedEquipmentStats.hall !== '—' && (
                            <span>• محل: <strong className="text-slate-200">{selectedEquipmentStats.hall}</strong></span>
                          )}
                          <span>• وضعیت فعلی: <strong className={selectedEquipmentStats.status === 'سالم' ? 'text-emerald-400' : 'text-rose-400'}>{selectedEquipmentStats.status.replace('_', ' ')}</strong></span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedHistoryEquipCode(null);
                        setHistoryEquipmentSearch('');
                      }}
                      className="text-[11px] font-bold text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 cursor-pointer"
                    >
                      بازگشت به همه تجهیزات
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="p-2.5 rounded-xl bg-slate-950/80 border border-blue-900/40 text-center">
                      <span className="text-[10px] text-blue-300/80 block">کل بازرسی‌های این تجهیز</span>
                      <strong className="text-lg font-black text-white font-mono">{toFaDigits(selectedEquipmentStats.totalInspections)}</strong>
                    </div>
                    <div className="p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-center">
                      <span className="text-[10px] text-rose-300 block">تعداد کل عدم انطباق</span>
                      <strong className="text-lg font-black text-rose-400 font-mono">{toFaDigits(selectedEquipmentStats.nonConformingCount)}</strong>
                    </div>
                    <div className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-center">
                      <span className="text-[10px] text-emerald-300 block">بازرسی سالم / شاخص سلامت</span>
                      <strong className="text-lg font-black text-emerald-400 font-mono">
                        {toFaDigits(selectedEquipmentStats.conformingCount)} ({toFaDigits(selectedEquipmentStats.healthPct)}٪)
                      </strong>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-950/80 border border-cyan-500/30 text-center">
                      <span className="text-[10px] text-cyan-300 block">آخرین بازرسی / اپراتور</span>
                      <strong className="text-xs font-bold text-white font-mono block mt-0.5">
                        {toFaDigits(selectedEquipmentStats.lastDate)}
                      </strong>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {selectedEquipmentStats.lastOperator}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px]">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-slate-400 font-bold">ریز ایرادات ثبت‌شده:</span>
                      {selectedEquipmentStats.defectCounts.length > 0 ? (
                        selectedEquipmentStats.defectCounts.map((d) => (
                          <span
                            key={d.name}
                            className="px-2 py-0.5 rounded-lg bg-rose-950/80 border border-rose-500/40 text-rose-200 font-bold"
                          >
                            {d.name} <span className="font-mono text-rose-400">×{toFaDigits(d.count)}</span>
                          </span>
                        ))
                      ) : (
                        <span className="text-emerald-400 font-bold">هیچ مورد عدم انطباقی برای این تجهیز ثبت نشده است ✓</span>
                      )}
                    </div>
                    {selectedEquipmentStats.linkedWorkOrdersCount > 0 && (
                      <span className="px-2 py-0.5 rounded-lg bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 font-mono font-bold">
                        دستورکارهای صادرشده: {toFaDigits(selectedEquipmentStats.linkedWorkOrdersCount)}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* فیلتر تاریخ و وضعیت با آیکون پرینت روی گزینه فعال */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-blue-300 font-bold ml-1">فیلتر وضعیت:</span>

                  <div
                    className={`inline-flex items-center rounded-xl transition-all ${
                      historyFilterResult === 'all'
                        ? 'bg-cyan-500 text-slate-950 font-black shadow'
                        : 'bg-slate-900 text-slate-300 border border-slate-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setHistoryFilterResult('all')}
                      className="px-3 py-1.5 text-xs cursor-pointer"
                    >
                      همه موارد ({toFaDigits(scopedLogs.length)})
                    </button>
                    {historyFilterResult === 'all' && (
                      <button
                        type="button"
                        onClick={() => setChecklistPrintMode('all')}
                        title="چاپ همه موارد"
                        aria-label="چاپ همه موارد"
                        className="pl-2.5 pr-1.5 py-1.5 border-r border-slate-950/20 hover:bg-cyan-400/60 rounded-l-xl flex items-center justify-center cursor-pointer transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div
                    className={`inline-flex items-center rounded-xl transition-all ${
                      historyFilterResult === 'conforming'
                        ? 'bg-emerald-600 text-white font-black shadow'
                        : 'bg-slate-900 text-slate-300 border border-slate-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setHistoryFilterResult('conforming')}
                      className="px-3 py-1.5 text-xs cursor-pointer"
                    >
                      بدون مشکل ({toFaDigits(scopedConformingCount)})
                    </button>
                    {historyFilterResult === 'conforming' && (
                      <button
                        type="button"
                        onClick={() => setChecklistPrintMode('conforming')}
                        title="چاپ موارد بدون مشکل"
                        aria-label="چاپ موارد بدون مشکل"
                        className="pl-2.5 pr-1.5 py-1.5 border-r border-white/25 hover:bg-emerald-500 rounded-l-xl flex items-center justify-center cursor-pointer transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div
                    className={`inline-flex items-center rounded-xl transition-all ${
                      historyFilterResult === 'non_conforming'
                        ? 'bg-rose-600 text-white font-black shadow'
                        : 'bg-slate-900 text-slate-300 border border-slate-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setHistoryFilterResult('non_conforming')}
                      className="px-3 py-1.5 text-xs cursor-pointer"
                    >
                      عدم انطباق‌ها ({toFaDigits(scopedNonConformingCount)})
                    </button>
                    {historyFilterResult === 'non_conforming' && (
                      <button
                        type="button"
                        onClick={() => setChecklistPrintMode('non_conforming')}
                        title="چاپ عدم انطباق‌ها"
                        aria-label="چاپ عدم انطباق‌ها"
                        className="pl-2.5 pr-1.5 py-1.5 border-r border-white/25 hover:bg-rose-500 rounded-l-xl flex items-center justify-center cursor-pointer transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* سوئیچ سریع تاریخ امروز / همه تاریخ‌ها */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setHistoryDateFilter(todayNormalizedDate)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold cursor-pointer transition-colors ${
                      historyDateFilter === todayNormalizedDate
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                        : 'bg-slate-900 text-slate-300 border border-slate-700 hover:text-white'
                    }`}
                  >
                    فقط امروز ({toFaDigits(todayInspectionsCount)})
                  </button>
                  {historyDateFilter !== 'all' && (
                    <button
                      type="button"
                      onClick={() => setHistoryDateFilter('all')}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>همه تاریخ‌ها</span>
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* جدول تاریخچه */}
              <div className="overflow-x-auto rounded-2xl border border-blue-900/40 max-h-[420px]">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-950/90 text-blue-300 border-b border-blue-900/40">
                      <th className="py-2.5 px-3">کد و دستگاه</th>
                      <th className="py-2.5 px-3 text-center">وضعیت</th>
                      <th className="py-2.5 px-3">اپراتور</th>
                      <th className="py-2.5 px-3">موارد عدم انطباق</th>
                      <th className="py-2.5 px-3">توضیحات</th>
                      <th className="py-2.5 px-3 text-center">عکس</th>
                      <th className="py-2.5 px-3 text-center">تاریخ و زمان</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blue-900/30 bg-slate-950/60">
                    {visibleHistoryLogs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500 text-xs">
                          هیچ سابقه بازرسی مطابق جستجو و فیلتر فعلی یافت نشد.
                        </td>
                      </tr>
                    ) : (
                      visibleHistoryLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-blue-950/40 transition-colors">
                          <td className="py-3 px-3">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedHistoryEquipCode(log.equipmentCode);
                                setHistoryEquipmentSearch(`${log.equipmentCode} — ${log.equipmentName}`);
                                setIsHistoryEquipDropdownOpen(false);
                              }}
                              title="مشاهده آمار کامل این تجهیز"
                              className="text-right hover:opacity-80 cursor-pointer"
                            >
                              <span className="font-mono font-bold text-cyan-300 block">{log.equipmentCode}</span>
                              <span className="text-[11px] text-white">{log.equipmentName}</span>
                            </button>
                          </td>

                          <td className="py-3 px-3 text-center whitespace-nowrap">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              log.result === 'conforming'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                            }`}>
                              {log.result === 'conforming' ? 'بدون مشکل ✓' : 'دارای عدم انطباق ⚠️'}
                            </span>
                          </td>

                          <td className="py-3 px-3 text-slate-200 whitespace-nowrap font-bold">
                            {log.operator}
                          </td>

                          <td className="py-3 px-3">
                            {log.defects && log.defects.length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {log.defects.map((d, i) => (
                                  <span key={i} className="px-1.5 py-0.5 rounded-md bg-rose-950/80 text-rose-300 border border-rose-500/40 text-[10px]">
                                    {d}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <span className="text-slate-500 text-[11px]">—</span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-slate-300 max-w-xs text-[11px]">
                            {log.notes || '—'}
                            {log.workOrderCode && (
                              <span className="block text-cyan-400 font-mono text-[10px] mt-0.5">
                                دستور کار مرتبط: {log.workOrderCode}
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-center">
                            {log.photoUrl ? (
                              <img
                                src={log.photoUrl}
                                alt="عکس عدم انطباق"
                                className="w-10 h-10 object-cover rounded-lg border border-red-500/50 mx-auto cursor-pointer hover:scale-110 transition-transform"
                                onClick={() => setSelectedPhotoLightbox(log.photoUrl || null)}
                                title="کلیک برای بزرگنمایی"
                              />
                            ) : (
                              <span className="text-slate-600 text-[11px]">—</span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-center font-mono text-[11px] text-slate-400 whitespace-nowrap">
                            <div>{toFaDigits(log.date)}</div>
                            <div className="text-[10px] text-slate-500">{toFaDigits(log.time)}</div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="flex justify-end pt-3 border-t border-blue-900/40">
                <button
                  type="button"
                  onClick={() => setIsInspectionHistoryModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer"
                >
                  بستن پنجره
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 4B: پیش‌نمایش و چاپ تفکیکی بازرسی‌ها      */}
      {/* ======================================================== */}
      {checklistPrintMode && (() => {
        const chkCfg = printSettings.checklistInspectionReport;
        const meta = getChecklistPrintModeMeta(checklistPrintMode);
        const printRows = getChecklistLogsForPrintMode(checklistPrintMode);
        return (
          <div className="fixed inset-0 z-[60] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
            <div className="w-full max-w-5xl rounded-3xl bg-white text-slate-900 shadow-2xl border border-slate-300 overflow-hidden my-auto max-h-[93vh] flex flex-col">
              {/* نوار ابزار بالا */}
              <div className="bg-slate-900 text-white px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 border-b border-slate-700 no-print">
                <div className="flex flex-wrap items-center gap-2">
                  <Printer className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm font-black">پیش‌نمایش چاپ چک‌لیست ({chkCfg.docCode})</span>
                  <div className="flex items-center gap-1 mr-2">
                    <button
                      type="button"
                      onClick={() => setChecklistPrintMode('all')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                        checklistPrintMode === 'all'
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      همه موارد ({toFaDigits(inspectionLogs.length)})
                    </button>
                    <button
                      type="button"
                      onClick={() => setChecklistPrintMode('conforming')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                        checklistPrintMode === 'conforming'
                          ? 'bg-emerald-500 text-white font-black'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      بدون مشکل ({toFaDigits(conformingInspectionsCount)})
                    </button>
                    <button
                      type="button"
                      onClick={() => setChecklistPrintMode('non_conforming')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                        checklistPrintMode === 'non_conforming'
                          ? 'bg-rose-500 text-white font-black'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      عدم انطباق‌ها ({toFaDigits(totalNonConformitiesCount)})
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => downloadChecklistInspectionHtml(checklistPrintMode)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 text-xs font-bold cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-cyan-400" />
                    <span>دانلود فایل چاپی</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => triggerChecklistInspectionPrint(checklistPrintMode)}
                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>ارسال به چاپگر / PDF</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setChecklistPrintMode(null)}
                    className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* محتوای قابل چاپ A4 */}
              <div className="p-5 sm:p-7 overflow-y-auto space-y-4 bg-white text-slate-900">
                <div className="flex flex-wrap items-center justify-between gap-4 border-2 border-slate-900 rounded-2xl p-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={COMPANY_LOGO_WHITEBG}
                      alt={BRAND_CONFIG.COMPANY_NAME}
                      className="h-14 w-auto object-contain"
                    />
                    <div>
                      <div className="text-xs font-bold text-slate-500">{BRAND_CONFIG.COMPANY_FULL_NAME}</div>
                      <h2 className="text-base sm:text-lg font-black text-slate-950 mt-0.5">{chkCfg.docTitle}</h2>
                      <span
                        className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-[11px] font-black border"
                        style={{
                          backgroundColor: meta.bgSoft,
                          color: meta.accent,
                          borderColor: meta.borderSoft
                        }}
                      >
                        {meta.badge}
                      </span>
                    </div>
                  </div>
                  <div className="text-left font-mono text-xs space-y-1 text-slate-800">
                    <div>کد سند: <strong className="font-black text-slate-950">{chkCfg.docCode}</strong></div>
                    <div>تعداد پرونده: <strong>{toFaDigits(printRows.length)}</strong> مورد</div>
                    <div>تاریخ چاپ: <strong>{toFaDigits(getEnDateNow())}</strong> — <strong>{toFaDigits(getEnTimeNow())}</strong></div>
                  </div>
                </div>

                {/* آمار خلاصه */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="border border-slate-300 rounded-xl p-2.5 bg-slate-50">
                    <div className="text-[11px] text-slate-500 font-bold">کل تجهیزات خط</div>
                    <div className="text-base font-black font-mono text-slate-900 mt-0.5">{toFaDigits(totalEquipmentsCount)} دستگاه</div>
                  </div>
                  <div className="border border-slate-300 rounded-xl p-2.5 bg-slate-50">
                    <div className="text-[11px] text-slate-500 font-bold">ردیف‌های این گزارش</div>
                    <div className="text-base font-black font-mono mt-0.5" style={{ color: meta.accent }}>{toFaDigits(printRows.length)} پرونده</div>
                  </div>
                  <div className="border border-emerald-200 rounded-xl p-2.5 bg-emerald-50/70">
                    <div className="text-[11px] text-emerald-700 font-bold">بازرسی‌های بدون مشکل</div>
                    <div className="text-base font-black font-mono text-emerald-700 mt-0.5">{toFaDigits(conformingInspectionsCount)} مورد</div>
                  </div>
                  <div className="border border-rose-200 rounded-xl p-2.5 bg-rose-50/70">
                    <div className="text-[11px] text-rose-700 font-bold">موارد عدم انطباق</div>
                    <div className="text-base font-black font-mono text-rose-700 mt-0.5">{toFaDigits(totalNonConformitiesCount)} مورد</div>
                  </div>
                </div>

                {/* جدول چاپی */}
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-right text-xs">
                    <thead>
                      <tr className="bg-slate-200 text-slate-950 font-black">
                        <th className="border border-slate-500 p-2 w-10 text-center">ردیف</th>
                        <th className="border border-slate-500 p-2 min-w-[125px]">کد و نام تجهیز</th>
                        <th className="border border-slate-500 p-2 text-center">دسته / خط</th>
                        <th className="border border-slate-500 p-2 text-center">وضعیت</th>
                        <th className="border border-slate-500 p-2">اپراتور</th>
                        <th className="border border-slate-500 p-2">موارد عدم انطباق</th>
                        <th className="border border-slate-500 p-2">توضیحات و دستور کار</th>
                        <th className="border border-slate-500 p-2 text-center w-16">عکس</th>
                        <th className="border border-slate-500 p-2 text-center">تاریخ و زمان</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printRows.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="border border-slate-400 p-6 text-center text-slate-500 font-bold">
                            هیچ سابقه‌ای در دسته «{meta.badge}» ثبت نشده است.
                          </td>
                        </tr>
                      ) : (
                        printRows.map((log, idx) => {
                          const isOk = log.result === 'conforming';
                          return (
                            <tr key={log.id} className="even:bg-slate-50/70">
                              <td className="border border-slate-400 p-2 text-center font-mono font-bold">{toFaDigits(idx + 1)}</td>
                              <td className="border border-slate-400 p-2">
                                <div className="font-mono font-black text-slate-900">{log.equipmentCode}</div>
                                <div className="text-[11px] text-slate-700">{log.equipmentName}</div>
                              </td>
                              <td className="border border-slate-400 p-2 text-center font-bold">{log.category || '—'}</td>
                              <td className="border border-slate-400 p-2 text-center whitespace-nowrap">
                                <span
                                  className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black border ${
                                    isOk
                                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                      : 'bg-rose-100 text-rose-800 border-rose-300'
                                  }`}
                                >
                                  {isOk ? 'بدون مشکل ✓' : 'عدم انطباق ⚠️'}
                                </span>
                              </td>
                              <td className="border border-slate-400 p-2 font-bold">{log.operator || '—'}</td>
                              <td className="border border-slate-400 p-2">
                                {log.defects && log.defects.length > 0 ? (
                                  <div className="flex flex-wrap gap-1">
                                    {log.defects.map((d, i) => (
                                      <span key={i} className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-900 border border-rose-300 text-[10px] font-bold">
                                        {d}
                                      </span>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-slate-400">—</span>
                                )}
                              </td>
                              <td className="border border-slate-400 p-2 text-[11px]">
                                <div>{log.notes || '—'}</div>
                                {log.workOrderCode && (
                                  <div className="font-mono text-[10px] font-bold text-sky-700 mt-0.5">
                                    دستور کار مرتبط: {log.workOrderCode}
                                  </div>
                                )}
                              </td>
                              <td className="border border-slate-400 p-1.5 text-center">
                                {log.photoUrl ? (
                                  <img
                                    src={log.photoUrl}
                                    alt="عکس عدم انطباق"
                                    className="w-10 h-10 object-cover rounded border border-slate-300 mx-auto"
                                  />
                                ) : (
                                  <span className="text-slate-400">—</span>
                                )}
                              </td>
                              <td className="border border-slate-400 p-2 text-center font-mono text-[11px] whitespace-nowrap">
                                <div>{toFaDigits(log.date)}</div>
                                <div className="text-[10px] text-slate-500">{toFaDigits(log.time)}</div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {/* امضاهای انتهای برگه */}
                <div className="grid grid-cols-3 gap-3 pt-2 text-center text-xs">
                  <div className="border border-dashed border-slate-400 rounded-xl p-3 min-h-[64px] flex flex-col justify-between">
                    <span className="font-bold text-slate-800">بازرس کنترل و چک‌لیست</span>
                    <span className="text-[10px] text-slate-400">نام، امضا و تاریخ</span>
                  </div>
                  <div className="border border-dashed border-slate-400 rounded-xl p-3 min-h-[64px] flex flex-col justify-between">
                    <span className="font-bold text-slate-800">سرپرست سالن تولید</span>
                    <span className="text-[10px] text-slate-400">نام، امضا و تاریخ</span>
                  </div>
                  <div className="border border-dashed border-slate-400 rounded-xl p-3 min-h-[64px] flex flex-col justify-between">
                    <span className="font-bold text-slate-800">واحد نگهداری و تعمیرات (نت)</span>
                    <span className="text-[10px] text-slate-400">نام، امضا و تاریخ</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 5: بزرگنمایی عکس عدم انطباق (Lightbox)    */}
      {/* ======================================================== */}
      {selectedPhotoLightbox && (
        <div
          onClick={() => setSelectedPhotoLightbox(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out"
        >
          <div className="relative max-w-3xl max-h-[85vh] rounded-3xl overflow-hidden border-2 border-cyan-500/60 shadow-2xl p-2 bg-black">
            <button
              onClick={() => setSelectedPhotoLightbox(null)}
              className="absolute top-4 left-4 z-10 w-9 h-9 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={selectedPhotoLightbox}
              alt="عکس عدم انطباق با کیفیت بالا"
              className="max-h-[80vh] w-auto object-contain rounded-2xl mx-auto"
            />
            <div className="p-3 text-center text-xs text-white bg-black/60">
              تصویر مستندسازی شده عدم انطباق در محل تجهیز
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 6: افزودن اپراتور جدید                    */}
      {/* ======================================================== */}
      {isAddOperatorModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-cyan-500/50 shadow-2xl p-6 space-y-4 text-right animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>افزودن اپراتور جدید به خط تولید</span>
              </h3>
              <button onClick={() => setIsAddOperatorModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-bold block">نام و نام خانوادگی اپراتور *:</label>
              <input
                type="text"
                value={newOperatorName}
                onChange={e => setNewOperatorName(e.target.value)}
                placeholder="نام و نام خانوادگی اپراتور..."
                className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-bold block">کد پرسنلی اپراتور *:</label>
              <input
                type="text"
                value={newOperatorPersonnelCode}
                onChange={e => setNewOperatorPersonnelCode(e.target.value)}
                placeholder="کد پرسنلی یا کد نت..."
                className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddOperatorModalOpen(false)}
                className="py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleAddNewOperator}
                className="py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                ثبت اپراتور
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 7: افزودن تجهیز جدید                     */}
      {/* ======================================================== */}
      {isAddEquipmentModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-emerald-500/50 shadow-2xl p-6 space-y-4 text-right animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>افزودن ماشین‌آلات جدید به چک‌لیست</span>
              </h3>
              <button onClick={() => setIsAddEquipmentModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* میانبر بارگذاری اکسل */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-teal-950/60 to-slate-900 border border-emerald-500/40 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-emerald-300">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>لیست تجهیزات را در اکسل دارید؟</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddEquipmentModalOpen(false);
                  setIsEquipmentExcelModalOpen(true);
                }}
                title="ورود از اکسل"
                className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors cursor-pointer flex items-center justify-center"
              >
                <Upload className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-bold block">کد دستگاه:</label>
                  <input
                    type="text"
                    value={newEqCode}
                    onChange={e => {
                      const val = e.target.value;
                      setNewEqCode(val);
                      const up = val.trim().toUpperCase();
                      // اگر کاربر از داخل دسته خاصی مودال را باز کرده باشد، دسته را تغییر نده
                      if (selectedCategoryForModal) return;

                      if (
                        up.startsWith('TUMN') ||
                        up.startsWith('MIDR') ||
                        up.startsWith('MIMN') ||
                        up.startsWith('SBMU') ||
                        up.startsWith('WBMN') ||
                        up.includes('MN') ||
                        up.includes('MANUAL') ||
                        up.includes('DRILL') ||
                        up.includes('دریل')
                      ) {
                        setNewEqCategory('تجهیزات دستی');
                      } else if (up.startsWith('TULT') || up.startsWith('TUTL')) {
                        setNewEqCategory('تراش');
                      } else if (up.startsWith('TUTN')) {
                        setNewEqCategory('تورنوس');
                      } else if ((up.startsWith('MICN') || up.startsWith('FR')) && !up.startsWith('MIDR')) {
                        setNewEqCategory('فرز');
                      } else if (up.startsWith('TUMA')) {
                        setNewEqCategory('مایر');
                      } else if (up.startsWith('SY')) {
                        setNewEqCategory('سینتک');
                      } else if (up.startsWith('ST')) {
                        setNewEqCategory('استار');
                      } else if (up.startsWith('PR')) {
                        setNewEqCategory('پرس');
                      }
                    }}
                    placeholder="مثال: TULT01 یا TUTN01 یا FR03"
                    className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-bold block">دسته‌بندی:</label>
                  <select
                    value={newEqCategory}
                    onChange={e => setNewEqCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    {checklistCategories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-bold block">نام کامل دستگاه:</label>
                <input
                  type="text"
                  value={newEqName}
                  onChange={e => setNewEqName(e.target.value)}
                  placeholder="مثال: تراش CNC مدل B1000..."
                  className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-bold block">سالن / محل استقرار:</label>
                <select
                  value={newEqHall}
                  onChange={e => setNewEqHall(e.target.value)}
                  className="w-full bg-slate-950 border border-blue-800 rounded-xl px-3 py-2 text-xs text-white"
                >
                  {FACTORY_LOCATIONS.map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddEquipmentModalOpen(false)}
                className="py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleAddNewEquipment}
                className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
              >
                ثبت تجهیز
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL: تخصیص و افزودن گروهی تجهیزات از دیتابیس PM */}
      {/* ======================================================== */}
      {isPmEquipmentPickerOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 animate-in fade-in duration-200">
          <div className="w-full max-w-5xl rounded-3xl bg-slate-950 border border-slate-700 shadow-2xl p-4 sm:p-6 space-y-4 text-right flex flex-col max-h-[92vh] text-slate-200">
            {/* Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                  <CheckSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    <span>افزودن و تخصیص گروهی تجهیزات از دیتابیس PM</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-emerald-300 font-mono font-bold">
                      {toFaDigits(allPmEquipments.length)} تجهیز فعال
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    انتخاب همزمان و چندتایی ماشین‌آلات با تیک، سرچ سریع بر اساس کد/نام و تخصیص قطعی به دسته‌بندی چک‌لیست
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPmEquipmentPickerOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* نوار انتخاب دسته مقصد و سرچ */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 shrink-0 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="sm:col-span-4 space-y-1">
                <label className="text-[11px] font-bold text-slate-300 block">
                  دسته مقصد در چک‌لیست:
                </label>
                <select
                  value={pmPickerTargetCategory}
                  onChange={e => setPmPickerTargetCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-emerald-500/50 rounded-xl px-3 py-2 text-xs text-emerald-300 font-bold outline-none focus:border-emerald-400"
                >
                  {checklistCategories.map(c => (
                    <option key={c.id || c.name} value={c.name}>
                      دسته {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-8 space-y-1">
                <label className="text-[11px] font-bold text-slate-300 block">
                  جستجوی سریع در دیتابیس PM:
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={pmPickerSearch}
                    onChange={e => setPmPickerSearch(e.target.value)}
                    placeholder="جستجوی کد دستگاه (مثلاً TULT، TUTN، MICN، 01)، نام، خانواده یا سالن..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-8 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
                  />
                  {pmPickerSearch && (
                    <button
                      type="button"
                      onClick={() => setPmPickerSearch('')}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* فیلترهای سریع پیش‌کد تجهیزات */}
            <div className="flex flex-wrap items-center gap-1.5 shrink-0">
              <span className="text-[11px] text-slate-400 font-bold ml-1 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5 text-emerald-400" />
                فیلتر سریع نوع تجهیز:
              </span>
              {[
                { id: 'all', label: `همه (${toFaDigits(allPmEquipments.length)})` },
                { id: 'TULT', label: 'تراش (TULT - ۳۷ دستگاه)', highlight: true },
                { id: 'TUTN', label: 'تورنوس (TUTN - ۱۹ دستگاه)' },
                { id: 'MICN', label: 'فرز CNC (MICN - ۲۸ دستگاه)' },
                { id: 'MANUAL', label: 'تجهیزات دستی (TUMN, MIDR - ۱۶ دستگاه)', highlight: true },
                { id: 'TUMA', label: 'تراش مایر (TUMA)' },
                { id: 'SY', label: 'سینتک (SY)' },
                { id: 'PR', label: 'پرس (PR)' },
                { id: 'other', label: 'سایر ماشین‌آلات' }
              ].map(f => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setPmPickerGroupFilter(f.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    pmPickerGroupFilter === f.id
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                      : f.highlight
                      ? 'bg-slate-900 text-emerald-300 border border-emerald-500/40 hover:bg-slate-800'
                      : 'bg-slate-900/90 text-slate-300 border border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* ردیف عملیات انتخاب همگانی و آمار */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-1 py-1 shrink-0 text-xs">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllFilteredPm}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  <span>تیک زدن همه موارد این لیست ({toFaDigits(filteredPmEquipments.length)} دستگاه)</span>
                </button>
                {pmPickerSelectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setPmPickerSelectedIds([])}
                    className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 text-xs font-bold transition-colors cursor-pointer"
                  >
                    لغو همه انتخاب‌ها
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 font-bold">
                <span className="text-slate-400 text-xs">تعداد انتخاب‌شده:</span>
                <span className="px-3 py-1 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-mono text-sm">
                  {toFaDigits(pmPickerSelectedIds.length)} دستگاه
                </span>
              </div>
            </div>

            {/* لیست اسکرول‌خور تجهیزات با چک‌باکس */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[220px]">
              {filteredPmEquipments.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-900/40 rounded-2xl border border-dashed border-slate-800">
                  موردی با فیلتر یا جستجوی جاری یافت نشد.
                </div>
              ) : (
                filteredPmEquipments.map((item: any) => {
                  const isChecked = pmPickerSelectedIds.includes(item.id);
                  const existingInChecklist = equipments.find(e => (e.code || '').toUpperCase() === (item.id || '').toUpperCase());
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        setPmPickerSelectedIds(prev => 
                          prev.includes(item.id) 
                            ? prev.filter(id => id !== item.id) 
                            : [...prev, item.id]
                        );
                      }}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-wrap items-center justify-between gap-3 ${
                        isChecked
                          ? 'bg-emerald-950/40 border-emerald-500/70 shadow-sm'
                          : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/80'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Checkbox */}
                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                            isChecked
                              ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black'
                              : 'border-slate-600 bg-slate-950'
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>

                        {/* Machine Code */}
                        <span className="font-mono text-xs font-black px-2.5 py-1 rounded-xl bg-slate-950 text-emerald-400 border border-slate-700 shrink-0">
                          {item.id}
                        </span>

                        {/* Machine details */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs sm:text-sm font-bold text-white truncate">
                              {item.name}
                            </span>
                            {item.family && item.family !== item.name && (
                              <span className="text-[11px] text-slate-400 truncate">
                                ({item.family})
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-slate-500" />
                              {item.location || 'سالن مشخص‌نشده'}
                            </span>
                            {item.priority && (
                              <>
                                <span>•</span>
                                <span className="text-amber-400/90">{item.priority}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* وضعیت فعلی در چک‌لیست */}
                      <div className="flex items-center gap-2 shrink-0">
                        {existingInChecklist ? (
                          <span className={`text-[11px] px-2.5 py-1 rounded-xl font-bold border ${
                            existingInChecklist.category === pmPickerTargetCategory
                              ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300'
                              : 'bg-slate-950 border-slate-700 text-amber-300'
                          }`}>
                            دسته فعلی: {existingInChecklist.category || 'بدون دسته'}
                          </span>
                        ) : (
                          <span className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-slate-400">
                            هنوز در چک‌لیست نیست
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 shrink-0">
              <button
                type="button"
                onClick={() => setIsPmEquipmentPickerOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                انصراف
              </button>

              <button
                type="button"
                disabled={pmPickerSelectedIds.length === 0}
                onClick={handleBatchAddFromPm}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black text-xs sm:text-sm transition-all shadow-lg shadow-emerald-950/60 cursor-pointer flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>
                  افزودن و تخصیص {toFaDigits(pmPickerSelectedIds.length)} تجهیز انتخاب‌شده به دسته «{pmPickerTargetCategory}»
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* FACTORY LOCATIONS MODAL (S01 الی S08)                    */}
      {/* قابل دسترسی مستقیم از نوار خدمات فنی و سامانه چک‌لیست‌ها */}
      {/* ======================================================== */}
      {isFactoryLocationsModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-3xl rounded-3xl bg-gradient-to-br from-[#0c1824] via-[#09131d] to-[#050a10] border-2 border-emerald-500/50 shadow-2xl p-5 sm:p-6 space-y-4 text-right animate-in zoom-in-95 max-h-[92vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-emerald-500/30 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/20">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                    <span>مکان‌ها و سالن‌ها</span>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono font-bold">
                      {toFaDigits(activeFactoryLocations.length)} محدوده اصلی (S01 - S08)
                    </span>
                  </h3>
                  <p className="text-xs text-blue-300/80 mt-0.5">
                    تعریف ساختار سالن‌ها و زیرسیستم‌های متصل به خدمات فنی، چک‌لیست‌ها و نگهداری پیشگیرانه
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFactoryLocationsModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* جستجوی سریع مکان‌ها */}
            <div className="relative shrink-0">
              <Search className="w-4 h-4 text-emerald-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={appLocationSearch}
                onChange={e => setAppLocationSearch(e.target.value)}
                placeholder="جستجوی نام سالن، کد مکان (مثل S01، S04) یا زیرسیستم (مثل نیم طبقه، پلاسما)..."
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pr-10 pl-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* لیست سالن‌ها به صورت آکاردئونی (پیش‌فرض بسته؛ با کلیک زیرمجموعه باز می‌شود) */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {activeFactoryLocations
                .filter(loc => {
                  if (!appLocationSearch.trim()) return true;
                  const q = appLocationSearch.toLowerCase();
                  const matchCode = loc.code.toLowerCase().includes(q);
                  const matchName = loc.name.toLowerCase().includes(q);
                  const matchSub = (loc.subLocations || []).some((s: any) => s.name.toLowerCase().includes(q));
                  return matchCode || matchName || matchSub;
                })
                .map(loc => {
                  const isExpanded = !!modalExpandedLocations[loc.id];
                  const subList = loc.subLocations || [];
                  const assignedCount = equipments.filter(eq => eq.hall && (eq.hall.includes(loc.name) || eq.hall.includes(loc.code))).length;

                  return (
                    <div
                      key={loc.id}
                      className="rounded-2xl border border-slate-800 bg-slate-900/70 hover:border-emerald-500/30 transition-all overflow-hidden"
                    >
                      {/* هدر آکاردئون (با کلیک باز/بسته می‌شود) */}
                      <div
                        onClick={() => toggleModalLocationExpand(loc.id)}
                        className="p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none bg-slate-950/50 hover:bg-slate-800/40 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center border border-slate-700"
                          >
                            {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                          </button>

                          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 font-mono font-bold text-xs text-emerald-400">
                            {loc.code}
                          </span>

                          <div>
                            <div className="text-sm font-bold text-white flex items-center gap-2">
                              <span>{loc.name}</span>
                              <span className="text-[10px] font-normal px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                                {toFaDigits(subList.length)} زیرسیستم
                              </span>
                              {assignedCount > 0 && (
                                <span className="text-[10px] font-normal px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                                  {toFaDigits(assignedCount)} دستگاه
                                </span>
                              )}
                            </div>
                            {loc.description && (
                              <p className="text-[11px] text-slate-400 mt-0.5">{loc.description}</p>
                            )}
                          </div>
                        </div>

                        {/* دکمه اعمال فیلتر سریع برای چک‌لیست */}
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setChecklistHallFilter(loc.code);
                              setIsFactoryLocationsModalOpen(false);
                              setCurrentView('checklist');
                            }}
                            className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/40 transition-colors font-bold cursor-pointer"
                            title="فیلتر تجهیزات این مکان در سامانه چک‌لیست"
                          >
                            فیلتر چک‌لیست
                          </button>
                        </div>
                      </div>

                      {/* بدنه آکاردئون (فقط زمانی که کاربر کلیک کند باز می‌شود) */}
                      {isExpanded && (
                        <div className="p-4 border-t border-slate-800/80 bg-slate-950/80 space-y-3 animate-in slide-in-from-top-2 duration-200">
                          <div>
                            <label className="text-[11px] font-bold text-slate-400 mb-1.5 block">
                              زیرسیستم‌ها و بخش‌های تعریف‌شده در {loc.name}:
                            </label>
                            {subList.length === 0 ? (
                              <p className="text-xs text-slate-500 italic">هنوز زیرسیستمی ثبت نشده است.</p>
                            ) : (
                              <div className="flex flex-wrap gap-1.5">
                                {subList.map((sub: any) => (
                                  <span
                                    key={sub.id}
                                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200"
                                  >
                                    <span>{sub.name}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSubLocationFromModal(loc.id, sub.id)}
                                      className="text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                                      title="حذف این زیرسیستم"
                                    >
                                      <X size={12} />
                                    </button>
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* فرم افزودن زیرسیستم جدید (مثلا افزودن نیم طبقه به سالن یک) */}
                          <div className="pt-2 border-t border-slate-800/60 flex items-center gap-2">
                            <input
                              type="text"
                              value={newSubLocInputsInApp[loc.id] || ''}
                              onChange={e => setNewSubLocInputsInApp({ ...newSubLocInputsInApp, [loc.id]: e.target.value })}
                              onKeyDown={e => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddSubLocationFromModal(loc.id);
                                }
                              }}
                              placeholder={`افزودن زیرسیستم به ${loc.name} (مثال: نیم طبقه، اتاق ابزار)...`}
                              className="flex-1 bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                            />
                            <button
                              type="button"
                              onClick={() => handleAddSubLocationFromModal(loc.id)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                            >
                              <Plus size={13} />
                              <span>افزودن</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>

            {/* Modal Footer */}
            <div className="pt-3 border-t border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsFactoryLocationsModalOpen(false);
                  setCurrentView('pm');
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>ورود به مدیریت جامع مکان‌ها در نگهداری پیشگیرانه (PM)</span>
              </button>

              <button
                type="button"
                onClick={() => setIsFactoryLocationsModalOpen(false)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                بستن پنجره
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 8: جدول کامل رتبه‌بندی اپراتورها            */}
      {/* ======================================================== */}
      {isLeaderboardModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-3xl bg-slate-900 border border-cyan-500/50 shadow-2xl p-6 space-y-4 text-right animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span className="text-amber-400">🏆</span>
                <span>رتبه‌بندی جامع و شاخص عملکرد اپراتورها</span>
              </h3>
              <button onClick={() => setIsLeaderboardModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-blue-900/30">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-950 text-blue-300 border-b border-blue-900/40">
                    <th className="py-2.5 px-3 text-center w-10">رتبه</th>
                    <th className="py-2.5 px-3">اپراتور</th>
                    <th className="py-2.5 px-3 text-center">تعداد بازرسی</th>
                    <th className="py-2.5 px-3 text-center">وضعیت کیفی</th>
                    <th className="py-2.5 px-3 text-center">درصد عملکرد</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-blue-900/30 bg-slate-950/60">
                  {activeOperatorLeaderboard.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                        هنوز بازرسی توسط اپراتورها ثبت نشده است.
                      </td>
                    </tr>
                  ) : (
                    activeOperatorLeaderboard.map((op, idx) => (
                      <tr key={op.id} className="hover:bg-blue-950/40 transition-colors">
                        <td className="py-3 px-3 text-center font-bold text-amber-400">#{toFaDigits(idx + 1)}</td>
                        <td className="py-3 px-3 font-bold text-white">{op.name}</td>
                        <td className="py-3 px-3 text-center font-mono text-cyan-300">{toFaDigits(op.inspectionsCount)}</td>
                        <td className="py-3 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] border font-bold ${
                            op.status === 'بدون مشکل'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                              : 'bg-rose-950 text-rose-300 border-rose-500/40'
                          }`}>
                            {op.status}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-emerald-400">
                          {toFaDigits(op.performancePct)}٪
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setIsLeaderboardModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 9: لیست مدیریت اپراتورها (با کد پرسنلی)     */}
      {/* ======================================================== */}
      {isOperatorsModalOpen && (() => {
        const query = operatorSearchQuery.trim().toLowerCase();
        const filteredOps = productionOperators.filter(op => {
          if (!query) return true;
          const matchName = op.name.toLowerCase().includes(query);
          const matchCode = op.personnelCode ? op.personnelCode.includes(query) : false;
          const matchNet = op.netCode ? op.netCode.toLowerCase().includes(query) : false;
          return matchName || matchCode || matchNet;
        });

        return (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
            <div className="w-full max-w-2xl rounded-3xl bg-gradient-to-br from-[#0c1824] via-[#08121c] to-[#04090f] border-2 border-cyan-500/50 shadow-2xl p-5 sm:p-6 space-y-4 text-right animate-in zoom-in-95 max-h-[90vh] flex flex-col">
              
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-cyan-500/30 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shadow-md">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                      <span>فهرست اپراتورهای خط تولید</span>
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono font-bold">
                        {toFaDigits(productionOperators.length)} اپراتور
                      </span>
                    </h3>
                    <p className="text-xs text-blue-300/80 mt-0.5">ثبت و پایش عملکرد همراه با کد پرسنلی معتبر پرسنل</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsOperatorsModalOpen(false)} 
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Bar & Quick Stats */}
              <div className="shrink-0 space-y-2">
                <div className="relative">
                  <input
                    type="text"
                    value={operatorSearchQuery}
                    onChange={e => setOperatorSearchQuery(e.target.value)}
                    placeholder="جستجوی نام اپراتور یا کد پرسنلی..."
                    className="w-full bg-slate-950/90 border border-cyan-500/40 rounded-2xl px-10 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 shadow-inner"
                  />
                  <Search className="w-4 h-4 text-cyan-400 absolute right-3.5 top-3 pointer-events-none" />
                  {operatorSearchQuery && (
                    <button
                      onClick={() => setOperatorSearchQuery('')}
                      className="absolute left-3.5 top-2.5 text-slate-400 hover:text-white text-xs bg-slate-800 px-2 py-0.5 rounded-lg"
                    >
                      پاک کردن
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between text-[11px] text-blue-300/75 px-1">
                  <span>نمایش {toFaDigits(filteredOps.length)} نفر از مجموع {toFaDigits(productionOperators.length)} اپراتور خط تولید</span>
                  <span className="text-cyan-400 font-bold">واحد: تولید و ماشین‌کاری CNC</span>
                </div>
              </div>

              {/* Operators List (Scrollable) */}
              <div className="space-y-2 flex-1 overflow-y-auto pr-1 min-h-[220px] max-h-[52vh]">
                {filteredOps.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs">
                    موردی با مشخصات «{operatorSearchQuery}» یافت نشد.
                  </div>
                ) : (
                  filteredOps.map((op, idx) => (
                    <div 
                      key={op.id || idx} 
                      className="p-3 sm:p-3.5 rounded-2xl bg-slate-950/80 border border-blue-900/40 hover:border-cyan-500/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all hover:bg-blue-950/40 group"
                    >
                      {/* Name & Personnel Code */}
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-900/60 to-blue-900/60 border border-cyan-500/30 flex items-center justify-center text-cyan-300 font-black text-xs shrink-0 group-hover:scale-105 transition-transform">
                          {op.name.slice(0, 1)}
                        </div>
                        <div>
                          <strong className="text-sm font-bold text-white block group-hover:text-cyan-300 transition-colors">
                            {op.name}
                          </strong>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <span className="px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 text-[10px] font-mono font-bold border border-cyan-500/40">
                              کد پرسنلی: {toFaDigits(op.personnelCode || '-')}
                            </span>
                            {op.netCode && (
                              <span className="px-2 py-0.5 rounded-md bg-blue-950 text-blue-300 text-[10px] font-mono border border-blue-600/30">
                                نت‌کد: {op.netCode}
                              </span>
                            )}
                            <span className="text-[10px] text-slate-400">
                              واحد {op.department || 'تولید'}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Stats & Quick Actions */}
                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        <span className="px-2.5 py-1 rounded-xl bg-slate-900 text-cyan-300 text-xs font-mono font-bold border border-cyan-500/30">
                          {toFaDigits(op.inspectionsCount)} بازرسی
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setInspectingOperator(op.name);
                            setIsOperatorsModalOpen(false);
                            setChecklistNotice(`✓ اپراتور «${op.name}» (کد: ${toFaDigits(op.personnelCode || '')}) برای ثبت بازرسی انتخاب شد.`);
                            setTimeout(() => setChecklistNotice(null), 3500);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-cyan-600/80 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1"
                          title="انتخاب این اپراتور به عنوان اپراتور پیش‌فرض بازرسی"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>انتخاب جهت بازرسی</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-cyan-500/30 shrink-0">
                <button
                  type="button"
                  onClick={() => { setIsOperatorsModalOpen(false); setIsAddOperatorModalOpen(true); }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-950/60 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>افزودن اپراتور جدید</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsOperatorsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer transition-colors"
                >
                  بستن
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {/* ======================================================== */}
      {/* CHECKLIST MODAL 10: بارگذاری و درون‌ریزی لیست تجهیزات از اکسل */}
      {/* ======================================================== */}
      {isEquipmentExcelModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-3xl rounded-3xl bg-gradient-to-b from-[#141d2c] via-[#0d1624] to-[#070d17] border border-emerald-500/50 shadow-2xl p-5 sm:p-7 space-y-5 my-auto max-h-[92vh] flex flex-col text-right">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-blue-900/50 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                    <span>درون‌ریزی تجهیزات با فایل اکسل</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 font-mono font-bold border border-emerald-500/40">
                      Excel / CSV
                    </span>
                  </h3>
                  <p className="text-xs text-blue-300/80 mt-0.5">
                    پشتیبانی مستقیم از فرمت‌های xlsx. و xls. و csv. با نگاشت خودکار ستون‌های فارسی
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsEquipmentExcelModalOpen(false);
                  setExcelParsedEquipments([]);
                  setExcelParseError(null);
                  setExcelFileName('');
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="بستن"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Template Download & Help Banner */}
            <div className="p-4 rounded-2xl bg-blue-950/40 border border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-white">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>ستون‌های فایل اکسل: «کد تجهیز» و «عنوان تجهیز» — فیلد اپراتور کاملاً خالی خواهد بود.</span>
                </div>
                <p className="text-[11px] text-blue-300/80">
                  شناسه «کد تجهیز» و «عنوان تجهیز» مستقیماً از فایل اکسل استخراج می‌شوند.
                </p>
              </div>
              <button
                type="button"
                onClick={handleDownloadEquipmentTemplate}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-950/60 whitespace-nowrap self-start sm:self-center"
              >
                <Download className="w-4 h-4" />
                <span>دانلود قالب استاندارد اکسل (.xlsx)</span>
              </button>
            </div>

            {/* File Upload Dropzone */}
            <div className="shrink-0">
              <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-emerald-500/40 hover:border-emerald-400 bg-slate-950/70 hover:bg-emerald-950/20 rounded-2xl cursor-pointer transition-all group">
                <Upload className="w-8 h-8 text-emerald-400 group-hover:scale-110 transition-transform mb-2" />
                <span className="text-sm font-bold text-white">
                  {excelFileName ? `فایل انتخاب‌شده: ${excelFileName}` : 'انتخاب یا رهاسازی فایل اکسل / CSV'}
                </span>
                <span className="text-xs text-blue-300/70 mt-1">
                  فایل‌های با پسوند xlsx. یا xls. یا csv. از تمامی نسخه‌های اکسل
                </span>
                <input
                  type="file"
                  accept=".xlsx, .xls, .csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, text/csv"
                  onChange={handleEquipmentExcelUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Loading / Spinner */}
            {isExcelParsing && (
              <div className="p-4 rounded-2xl bg-cyan-950/50 border border-cyan-500/30 text-center text-xs text-cyan-300 flex items-center justify-center gap-2 shrink-0 animate-pulse">
                <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                <span>در حال پردازش و استخراج اطلاعات تجهیزات از فایل اکسل...</span>
              </div>
            )}

            {/* Error Message Box */}
            {excelParseError && (
              <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-500/60 text-right space-y-2 shrink-0 animate-in fade-in">
                <div className="flex items-center gap-2 text-rose-300 text-xs font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>خطا در بررسی فایل اکسل:</span>
                </div>
                <p className="text-xs text-rose-200/90 leading-relaxed pr-6">
                  {excelParseError}
                </p>
                <div className="pr-6 pt-1 text-[11px] text-blue-200/80">
                  💡 راهنمای حل سریع: دکمه «دانلود قالب استاندارد اکسل» را زده و لیست خود را در آن کپی کرده و دوباره بارگذاری فرمایید.
                </div>
              </div>
            )}

            {/* Parsed Results & Preview */}
            {excelParsedEquipments.length > 0 && (
              <div className="flex-1 overflow-hidden flex flex-col space-y-3">
                {/* Mode Selector & Summary */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/40">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <strong className="text-sm font-black text-white">
                        {toFaDigits(excelParsedEquipments.length)} دستگاه با موفقیت شناسایی شدند
                      </strong>
                      <span className="text-[11px] text-emerald-300/80 block">
                        آماده ذخیره و اعمال در چک‌لیست‌های خط تولید
                      </span>
                    </div>
                  </div>

                  {/* Merge or Replace Toggle */}
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-blue-300 font-bold">حالت درون‌ریزی:</span>
                    <button
                      type="button"
                      onClick={() => setExcelImportMode('merge')}
                      className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                        excelImportMode === 'merge'
                          ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      افزودن و ادغام
                    </button>
                    <button
                      type="button"
                      onClick={() => setExcelImportMode('replace')}
                      className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                        excelImportMode === 'replace'
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                      title="پاک کردن لیست قبلی و جایگزینی با تجهیزات این فایل"
                    >
                      جایگزینی کامل
                    </button>
                  </div>
                </div>

                {/* Table Preview (Scrollable) */}
                <div className="flex-1 overflow-y-auto rounded-2xl border border-blue-900/40 max-h-56 bg-slate-950/70">
                  <table className="w-full text-right text-xs">
                    <thead className="sticky top-0 bg-slate-950 text-blue-300 border-b border-blue-900/50 shadow-sm">
                      <tr>
                        <th className="py-2.5 px-3 text-center w-12">#</th>
                        <th className="py-2.5 px-3">کد دستگاه</th>
                        <th className="py-2.5 px-3">نام تجهیز</th>
                        <th className="py-2.5 px-3">دسته‌بندی</th>
                        <th className="py-2.5 px-3">سالن استقرار</th>
                        <th className="py-2.5 px-3 text-center">اپراتور</th>
                        <th className="py-2.5 px-3 text-center">وضعیت</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-blue-900/30">
                      {excelParsedEquipments.map((eq, idx) => (
                        <tr key={eq.id || idx} className="hover:bg-blue-950/40 transition-colors">
                          <td className="py-2.5 px-3 text-center font-mono text-slate-400">{toFaDigits(idx + 1)}</td>
                          <td className="py-2.5 px-3 font-mono font-bold text-cyan-300">{eq.code}</td>
                          <td className="py-2.5 px-3 font-bold text-white">{eq.name}</td>
                          <td className="py-2.5 px-3">
                            <span className="px-2 py-0.5 rounded-md bg-blue-950 text-blue-300 text-[10px] font-bold border border-blue-600/30">
                              {eq.category}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-300 text-[11px]">{eq.hall}</td>
                          <td className="py-2.5 px-3 text-center text-slate-500 text-[11px]">
                            {eq.inspector || ''}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              eq.status === 'سالم' 
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' 
                                : 'bg-amber-950 text-amber-300 border border-amber-500/40'
                            }`}>
                              {eq.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-blue-900/50 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsEquipmentExcelModalOpen(false);
                  setExcelParsedEquipments([]);
                  setExcelParseError(null);
                  setExcelFileName('');
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
              >
                انصراف
              </button>

              <button
                type="button"
                disabled={excelParsedEquipments.length === 0}
                onClick={handleConfirmEquipmentImport}
                className={`px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
                  excelParsedEquipments.length > 0
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-950/60 scale-100 hover:scale-105'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-60'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>
                  {excelParsedEquipments.length > 0 
                    ? `تأیید و ذخیره (${toFaDigits(excelParsedEquipments.length)} دستگاه)` 
                    : 'فایل اکسل را انتخاب کنید'}
                </span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* مودال پیش‌نمایش و چاپ سند رسمی A4 انبار روغن */}
      <OilOfficialPrintModal

        isOpen={isOilOfficialPrintModalOpen}
        onClose={() => setIsOilOfficialPrintModalOpen(false)}
        transactions={getFilteredOilTransactions()}
        oilTanks={oilTanks}
        filterTankId={oilReportFilterTank}
        opType={oilReportTab}
        startDate={oilReportStartDate}
        endDate={oilReportEndDate}
        persianClock={persianClock}
      />

    </div>
  );
}
