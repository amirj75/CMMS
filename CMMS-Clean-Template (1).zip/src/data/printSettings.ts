import { useEffect, useState } from 'react';

export type PrintTemplateKey =
  | 'workRequestA5'
  | 'workOrderClosedA4'
  | 'paretoReport'
  | 'reliabilityReport'
  | 'workforceAllReport'
  | 'workforceIndividualReport'
  | 'workRequestsListReport'
  | 'workOrdersListReport'
  | 'pmFinalReport'
  | 'techServiceSheet'
  | 'techServiceWeekly'
  | 'consumablesReport'
  | 'oilOfficialReport'
  | 'checklistInspectionReport';

export interface PrintSettingValue {
  docCode: string;
  docTitle: string;
}

export interface PrintTemplateDefinition {
  key: PrintTemplateKey;
  label: string;
  section: 'درخواست کار و دستورکار' | 'گزارش‌های تحلیلی و پارتو' | 'خدمات فنی، PM و انبار';
  description: string;
  defaultDocCode: string;
  defaultDocTitle: string;
}

export const PRINT_SETTINGS_STORAGE_KEY = 'cmms_print_settings_v1';
export const PRINT_SETTINGS_UPDATED_EVENT = 'cmms_print_settings_updated';

export const PRINT_TEMPLATE_DEFINITIONS: PrintTemplateDefinition[] = [
  {
    key: 'workRequestA5',
    label: 'برگه درخواست کار (قطع A5)',
    section: 'درخواست کار و دستورکار',
    description: 'چاپ و پیش‌نمایش فرم ثبت درخواست کار تجهیز از کارتابل درخواست‌ها',
    defaultDocCode: 'F005PM',
    defaultDocTitle: 'درخواست کار'
  },
  {
    key: 'workOrderClosedA4',
    label: 'فرم کامل دستور کار بسته‌شده (قطع A4)',
    section: 'درخواست کار و دستورکار',
    description: 'چاپ و مشاهده فرم بایگانی‌شده دستور کار نگهداری و تعمیرات',
    defaultDocCode: 'FR069',
    defaultDocTitle: 'دستورکار نگهداری و تعمیرات'
  },
  {
    key: 'paretoReport',
    label: 'گزارش تحلیلی پارتو (۸۰/۲۰)',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ رسمی جدول و رتبه‌بندی پارتو خرابی، خانواده تجهیز، توقف و مکان',
    defaultDocCode: 'F008-PM',
    defaultDocTitle: 'گزارش تحلیلی پارتو (۸۰/۲۰)'
  },
  {
    key: 'reliabilityReport',
    label: 'گزارش قابلیت اطمینان تجهیز (MTBF / MTTR)',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ شناسنامه شاخص‌های قابلیت اطمینان و نمودار روند خرابی تجهیز',
    defaultDocCode: 'CMMS-REL-01',
    defaultDocTitle: 'شناسنامه و گزارش قابلیت اطمینان تجهیز'
  },
  {
    key: 'workforceAllReport',
    label: 'گزارش کلی عملکرد نیروی انسانی',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ گزارش تفکیکی عملکرد تمام تکنسین‌ها به همراه نمودار',
    defaultDocCode: 'CMMS-HR-03',
    defaultDocTitle: 'گزارش تفکیکی عملکرد نیروی انسانی'
  },
  {
    key: 'workforceIndividualReport',
    label: 'کارنامه عملکرد فردی تکنسین',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ کارنامه اختصاصی هر تکنسین (تفکیک EM / CM / PM / خدمات فنی)',
    defaultDocCode: 'CMMS-TECH-PERF-01',
    defaultDocTitle: 'کارنامه رسمی عملکرد فردی تکنسین'
  },
  {
    key: 'workRequestsListReport',
    label: 'گزارش لیست درخواست کارها',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ مستقیم جدول جامع درخواست کارها در تب گزارش‌ها',
    defaultDocCode: 'CMMS-WR-LIST-01',
    defaultDocTitle: 'گزارش جامع لیست درخواست کارها'
  },
  {
    key: 'workOrdersListReport',
    label: 'گزارش لیست دستور کارها',
    section: 'گزارش‌های تحلیلی و پارتو',
    description: 'چاپ مستقیم جدول جامع دستور کارها در تب گزارش‌ها',
    defaultDocCode: 'CMMS-WO-LIST-01',
    defaultDocTitle: 'گزارش جامع لیست دستور کارها'
  },
  {
    key: 'pmFinalReport',
    label: 'گزارش نهایی دستورکار پیشگیرانه (PM)',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ گزارش نهایی اتمام دستور کار نگهداری پیشگیرانه در استودیو PM',
    defaultDocCode: 'CMMS-PM-01',
    defaultDocTitle: 'گزارش نهایی دستورکار نگهداری پیشگیرانه'
  },
  {
    key: 'techServiceSheet',
    label: 'برگه شناسنامه دستور کار خدمات فنی',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ برگه رسمی شناسنامه و گزارش دستور کار واحد خدمات فنی',
    defaultDocCode: 'CMMS-TS-01',
    defaultDocTitle: 'برگه رسمی شناسنامه و گزارش دستور کار فنی'
  },
  {
    key: 'techServiceWeekly',
    label: 'گزارش تحلیلی هفتگی خدمات فنی',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ نمودار و گزارش کارکرد هفتگی دستورکارهای خدمات فنی',
    defaultDocCode: 'CMMS-TS-WK-01',
    defaultDocTitle: 'گزارش تحلیلی هفتگی کارکرد و دستورکارهای خدمات فنی'
  },
  {
    key: 'consumablesReport',
    label: 'گزارش جامع قطعات و لوازم مصرفی',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ گزارش آمار قطعات یدکی و اقلام مصرفی انبار',
    defaultDocCode: 'CMMS-SP-01',
    defaultDocTitle: 'گزارش جامع آمار قطعات و لوازم مصرفی'
  },
  {
    key: 'oilOfficialReport',
    label: 'گزارش رسمی پایش مخازن روغن',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ سند رسمی ورودی، خروجی و مصرف مخازن روغن و برشکاری',
    defaultDocCode: 'CMMS-OIL-01',
    defaultDocTitle: 'گزارش رسمی پایش مخازن روغن'
  },
  {
    key: 'checklistInspectionReport',
    label: 'گزارش تاریخچه بازرسی‌های چک‌لیست خط تولید',
    section: 'خدمات فنی، PM و انبار',
    description: 'چاپ تفکیکی سوابق بازرسی تجهیزات خط تولید (همه موارد، بدون مشکل، عدم انطباق)',
    defaultDocCode: 'CMMS-CHK-01',
    defaultDocTitle: 'گزارش جامع تاریخچه بازرسی‌های خط تولید'
  }
];

export type PrintSettingsMap = Record<PrintTemplateKey, PrintSettingValue>;

export function getDefaultPrintSettings(): PrintSettingsMap {
  const defaults = {} as PrintSettingsMap;
  PRINT_TEMPLATE_DEFINITIONS.forEach(def => {
    defaults[def.key] = {
      docCode: def.defaultDocCode,
      docTitle: def.defaultDocTitle
    };
  });
  return defaults;
}

export function loadPrintSettings(): PrintSettingsMap {
  const defaults = getDefaultPrintSettings();
  try {
    const raw = localStorage.getItem(PRINT_SETTINGS_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return defaults;

    PRINT_TEMPLATE_DEFINITIONS.forEach(def => {
      const entry = parsed[def.key];
      if (entry && typeof entry === 'object') {
        defaults[def.key] = {
          docCode: typeof entry.docCode === 'string' && entry.docCode.trim() ? entry.docCode : def.defaultDocCode,
          docTitle: typeof entry.docTitle === 'string' && entry.docTitle.trim() ? entry.docTitle : def.defaultDocTitle
        };
      }
    });
  } catch {
    // ignore storage errors
  }
  return defaults;
}

export function getPrintSetting(key: PrintTemplateKey): PrintSettingValue {
  const all = loadPrintSettings();
  return all[key];
}

export function savePrintSettings(next: PrintSettingsMap): void {
  try {
    localStorage.setItem(PRINT_SETTINGS_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // ignore storage errors
  }
  window.dispatchEvent(new CustomEvent(PRINT_SETTINGS_UPDATED_EVENT, { detail: next }));
}

export function resetPrintSettings(): PrintSettingsMap {
  const defaults = getDefaultPrintSettings();
  savePrintSettings(defaults);
  return defaults;
}

export function usePrintSettings(): PrintSettingsMap {
  const [settings, setSettings] = useState<PrintSettingsMap>(() => loadPrintSettings());

  useEffect(() => {
    const refresh = () => setSettings(loadPrintSettings());
    const handleStorage = (e: StorageEvent) => {
      if (!e.key || e.key === PRINT_SETTINGS_STORAGE_KEY) refresh();
    };
    window.addEventListener(PRINT_SETTINGS_UPDATED_EVENT, refresh);
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener(PRINT_SETTINGS_UPDATED_EVENT, refresh);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  return settings;
}
