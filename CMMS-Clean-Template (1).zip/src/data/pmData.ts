export interface PmChecklistItem {
  id: string;
  title: string;
  completed: boolean;
}

export type PmPeriodicity = 'روزانه' | 'هفتگی' | 'دو هفته' | 'ماهانه' | 'سه ماهه' | 'شش ماهه' | 'سالانه';
export type PmCategory = 'مکانیک' | 'برق' | 'هیدرولیک' | 'روانکاری' | 'تاسیسات';
export type PmPriority = 'عادی' | 'مهم' | 'بحرانی';
export type PmStatus = 'انجام‌شده' | 'در انتظار' | 'سررسید شده';

export interface PmSchedule {
  id: string;
  equipmentCode: string;
  equipmentName: string;
  hall: string;
  title: string;
  category: PmCategory;
  periodicity: PmPeriodicity;
  intervalDays: number;
  intervalHours?: number;
  lastPerformedDate: string;
  nextDueDate: string;
  assignedTechnician: string;
  priority: PmPriority;
  status: PmStatus;
  estimatedMinutes: number;
  instructions: string;
  checklist: PmChecklistItem[];
  requiredParts?: string[];
}

export const INITIAL_PM_SCHEDULES: PmSchedule[] = [];
