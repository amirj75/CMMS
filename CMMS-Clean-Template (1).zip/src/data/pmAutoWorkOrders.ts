import defaultPlantEquipment from './plantEquipment.json';
import defaultAssetFamilies from './assetFamilies.json';
import defaultFactoryLocations from './factoryLocations.json';

export const PM_AUTO_WORK_ORDERS_STORAGE_KEY = 'pm_studio_auto_work_orders_v1';

export interface PmScheduleGroupMeta {
  id: string;
  name: string;
  prefixes: string[];
  keywords: string[];
}

export const PM_AUTO_GROUP_META: PmScheduleGroupMeta[] = [
  { id: 'tornos', name: 'تورنوس', prefixes: ['TUTN'], keywords: ['تورنوس', 'tornos'] },
  { id: 'milling', name: 'فرز', prefixes: ['MICN', 'FR'], keywords: ['فرز', 'milling', 'feeler', 'hartford'] },
  { id: 'lathe', name: 'تراش', prefixes: ['TUTL', 'TULT', 'TUCT'], keywords: ['تراش', 'lathe', 'تبریز'] },
  { id: 'syntec', name: 'سینتک', prefixes: ['SY'], keywords: ['سینتک', 'syntec'] },
  { id: 'mayer', name: 'مایر', prefixes: ['TUMA'], keywords: ['مایر', 'mayer'] },
  { id: 'wirecut', name: 'وایرکات', prefixes: ['WICN'], keywords: ['وایرکات', 'wirecut', 'dk77'] },
  { id: 'lab', name: 'آزمایشگاه', prefixes: ['LAB', 'QC'], keywords: ['آزمایشگاه', 'تست', 'کوانتومتر', 'سختی', 'زبری', 'میکروسکوپ', 'lab'] },
  { id: 'press', name: 'پرس', prefixes: ['PR', 'PRHY'], keywords: ['پرس', 'press', 'هیدرولیک'] },
  { id: 'facilities', name: 'تاسیسات', prefixes: ['FAC', 'UT', 'CMP', 'CHL'], keywords: ['تاسیسات', 'کمپرسور', 'چیلر', 'دیزل', 'بویلر', 'ژنراتور', 'موتورخانه', 'هواساز', 'پمپ'] }
];

const PERIOD_LABELS: Record<string, string> = {
  monthly: 'ماهانه',
  bimonthly: 'دوماهه',
  quarterly: '۳ ماهه',
  biannual: '۶ ماهه',
  annual: 'سالانه',
  custom: 'سفارشی'
};

const PERIOD_MONTHS: Record<string, number> = {
  monthly: 1,
  bimonthly: 2,
  quarterly: 3,
  biannual: 6,
  annual: 12
};

export function toEnDigitsPm(str: string): string {
  return String(str || '')
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

export function isJalaliLeapYearPm(year: number): boolean {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  let jp = breaks[0];
  let jump = 0;
  for (let i = 1; i < breaks.length; i++) {
    const jm = breaks[i];
    jump = jm - jp;
    if (year < jm) break;
    jp = jm;
  }
  let n = year - jp;
  if (jump - n < 6) n = n - jump + Math.floor((jump + 4) / 33) * 33;
  let leap = (((n + 1) % 33) - 1) % 4;
  if (leap === -1) leap = 4;
  return leap === 0;
}

export function getDaysInJalaliMonthPm(year: number, month: number): number {
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  return isJalaliLeapYearPm(year) ? 30 : 29;
}

export function normalizeShamsiDatePm(raw?: string): string | null {
  if (!raw) return null;
  const cleaned = toEnDigitsPm(raw).trim().replace(/[-.]/g, '/');
  const m = cleaned.match(/(\d{4})\/(\d{1,2})\/(\d{1,2})/);
  if (!m) return null;
  const y = parseInt(m[1], 10);
  const mo = parseInt(m[2], 10);
  const d = parseInt(m[3], 10);
  if (isNaN(y) || isNaN(mo) || isNaN(d) || y < 1380 || y > 1450 || mo < 1 || mo > 12 || d < 1 || d > 31) {
    return null;
  }
  const maxD = getDaysInJalaliMonthPm(y, mo);
  const clampedD = Math.min(d, maxD);
  return `${y}/${String(mo).padStart(2, '0')}/${String(clampedD).padStart(2, '0')}`;
}

export function getTodayShamsiDateStringPm(): string {
  try {
    const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    const parts = fmt.formatToParts(new Date());
    const y = toEnDigitsPm(parts.find(p => p.type === 'year')?.value || '');
    const m = toEnDigitsPm(parts.find(p => p.type === 'month')?.value || '');
    const d = toEnDigitsPm(parts.find(p => p.type === 'day')?.value || '');
    const normalized = normalizeShamsiDatePm(`${y}/${m}/${d}`);
    if (normalized) return normalized;
  } catch {}
  try {
    const fa = toEnDigitsPm(
      new Intl.DateTimeFormat('fa-IR-u-nu-latn', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      }).format(new Date())
    );
    const normalized = normalizeShamsiDatePm(fa);
    if (normalized) return normalized;
  } catch {}
  return '1405/08/24';
}

export function compareShamsiDatesPm(a: string, b: string): number {
  const na = normalizeShamsiDatePm(a);
  const nb = normalizeShamsiDatePm(b);
  if (!na || !nb) return 0;
  const [ya, ma, da] = na.split('/').map(Number);
  const [yb, mb, db] = nb.split('/').map(Number);
  if (ya !== yb) return ya < yb ? -1 : 1;
  if (ma !== mb) return ma < mb ? -1 : 1;
  if (da !== db) return da < db ? -1 : 1;
  return 0;
}

function jalaliToDayNumberPm(shamsiDate: string): number | null {
  const norm = normalizeShamsiDatePm(shamsiDate);
  if (!norm) return null;
  const [jy, jm, jd] = norm.split('/').map(Number);
  let gy = jy <= 979 ? 621 : 1600;
  const jYear = jy - (jy <= 979 ? 0 : 979);
  let days =
    365 * jYear +
    Math.floor(jYear / 33) * 8 +
    Math.floor(((jYear % 33) + 3) / 4) +
    78 +
    jd +
    (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  gy += Math.floor((days - 1) / 365);
  if (days > 365) days = (days - 1) % 365;
  const gd = days + 1;
  const salA = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  let rem = gd;
  for (gm = 0; gm < 13; gm++) {
    const v = salA[gm];
    if (rem <= v) break;
    rem -= v;
  }
  return Math.floor(Date.UTC(gy, gm - 1, rem) / 86400000);
}

export function diffShamsiDaysPm(fromDate: string, toDate: string): number {
  const d1 = jalaliToDayNumberPm(fromDate);
  const d2 = jalaliToDayNumberPm(toDate);
  if (d1 === null || d2 === null) return 0;
  return d2 - d1;
}

function getPeriodCycleMinGapDays(periodKey: string, acts?: any[]): number {
  switch (periodKey) {
    case 'monthly':
      return 25;
    case 'bimonthly':
      return 50;
    case 'quarterly':
      return 75;
    case 'biannual':
      return 150;
    case 'annual':
      return 300;
    default: {
      const step = Math.max(1, Number(acts?.[0]?.customDays) || Number(acts?.[0]?.executionWindowDays) || 3);
      return Math.max(1, step - 1);
    }
  }
}

export function addShamsiDaysPm(shamsiDate: string, daysToAdd: number): string {
  const norm = normalizeShamsiDatePm(shamsiDate);
  if (!norm) return shamsiDate;
  let [year, month, day] = norm.split('/').map(Number);
  let remaining = Math.max(0, Math.floor(daysToAdd || 0));
  while (remaining > 0) {
    const daysInMonth = getDaysInJalaliMonthPm(year, month);
    if (day + remaining <= daysInMonth) {
      day += remaining;
      remaining = 0;
    } else {
      remaining -= (daysInMonth - day + 1);
      day = 1;
      month += 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
    }
  }
  return `${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
}

function addShamsiMonthsClampPm(shamsiDate: string, monthsToAdd: number, anchorDay: number): string {
  const norm = normalizeShamsiDatePm(shamsiDate);
  if (!norm) return shamsiDate;
  const [sYear, sMonth] = norm.split('/').map(Number);
  const totalMonths = sYear * 12 + (sMonth - 1) + monthsToAdd;
  const year = Math.floor(totalMonths / 12);
  const month = (totalMonths % 12) + 1;
  const maxDay = getDaysInJalaliMonthPm(year, month);
  const day = Math.min(Math.max(1, anchorDay), maxDay);
  return `${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
}

export function resolveLatestDuePmOccurrence(act: any, todayStr: string): string | null {
  if (!act || act.isActive === false || !act.isScheduled || !act.startDate) return null;
  const startNorm = normalizeShamsiDatePm(act.startDate);
  if (!startNorm) return null;

  if (compareShamsiDatesPm(startNorm, todayStr) > 0) {
    return null;
  }

  const freqType = String(act.frequencyType || 'monthly');
  const stepMonths = PERIOD_MONTHS[freqType];

  if (stepMonths) {
    const anchorDay = Number(startNorm.split('/')[2]) || 1;
    let latest = startNorm;
    for (let k = 1; k <= 120; k++) {
      const candidate = addShamsiMonthsClampPm(startNorm, k * stepMonths, anchorDay);
      if (compareShamsiDatesPm(candidate, todayStr) <= 0) {
        latest = candidate;
      } else {
        break;
      }
    }
    return latest;
  }

  const stepDays = Math.max(1, Number(act.customDays) || Number(act.executionWindowDays) || 3);
  let latest = startNorm;
  for (let k = 1; k <= 365; k++) {
    const candidate = addShamsiDaysPm(startNorm, k * stepDays);
    if (compareShamsiDatesPm(candidate, todayStr) <= 0) {
      latest = candidate;
    } else {
      break;
    }
  }
  return latest;
}

/**
 * استخراج طول استاندارد کدهای درخواست/دستور کار سیستم (پیش‌فرض ۸ کاراکتر مثل WR000001 و WO000001)
 * و تولید کدهای هم‌طول برای نگهداری پیشگیرانه:
 * - کد درخواست: PMWR0001 (۸ کاراکتر)
 * - کد دستور کار: PMWO0001 (۸ کاراکتر)
 */
export function resolveStandardWorkOrderCodeLength(allItems: any[]): number {
  const lengthCounts = new Map<number, number>();
  const registerLen = (raw?: string) => {
    const code = String(raw || '').trim().toUpperCase();
    if (/^(WO|WR)\d+$/.test(code)) {
      lengthCounts.set(code.length, (lengthCounts.get(code.length) || 0) + 1);
    }
  };

  allItems.forEach(item => {
    if (!item) return;
    registerLen(item.woCode);
    registerLen(item.workOrderCode);
    registerLen(item.code);
  });

  if (lengthCounts.size === 0) return 8;
  let bestLen = 8;
  let bestCount = -1;
  lengthCounts.forEach((cnt, len) => {
    if (cnt > bestCount) {
      bestCount = cnt;
      bestLen = len;
    }
  });
  return Math.max(6, bestLen);
}

export function getNextPmReqAndWoCodes(
  allPmOrders: any[],
  targetLen?: number
): { reqCode: string; woCode: string } {
  const resolvedLen = targetLen || 8;
  const digitLen = Math.max(2, resolvedLen - 4);
  let maxNum = 0;

  const checkCode = (raw?: string) => {
    const code = String(raw || '').trim().toUpperCase();
    const m = code.match(/^PM(?:WR|WO)(\d+)$/);
    if (m) {
      const n = parseInt(m[1], 10);
      if (!isNaN(n) && n > maxNum) {
        maxNum = n;
      }
    }
  };

  allPmOrders.forEach(item => {
    if (!item) return;
    checkCode(item.code);
    checkCode(item.woCode);
    checkCode(item.workOrderCode);
  });

  const numStr = String(maxNum + 1).padStart(digitLen, '0');
  return {
    reqCode: `PMWR${numStr}`,
    woCode: `PMWO${numStr}`
  };
}

function loadJsonFromStorage<T>(keys: string[], fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed !== null && parsed !== undefined) return parsed as T;
      }
    } catch {}
  }
  return fallback;
}

export function loadAutoPmWorkOrders(): any[] {
  const list = loadJsonFromStorage<any[]>([PM_AUTO_WORK_ORDERS_STORAGE_KEY], []);
  return Array.isArray(list) ? list : [];
}

export function saveAutoPmWorkOrders(list: any[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PM_AUTO_WORK_ORDERS_STORAGE_KEY, JSON.stringify(list));
  } catch {}
  try {
    fetch('/api/portal/sync-state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pmAutoWorkOrders: list })
    }).catch(() => {});
  } catch {}
}

/**
 * پاکسازی کامل آیتم‌های PM زمان‌بندی‌شده خودکار از کارتابل «درخواست کار» تا منحصراً در بخش نگهداری پیشگیرانه باشند
 */
function purgeAutoPmFromWorkRequestsStorage(): void {
  if (typeof window === 'undefined') return;
  const isAutoPmEntry = (r: any) =>
    Boolean(r?.isScheduledPM) ||
    Boolean(r?.pmSourceKey) ||
    /^PM(?:WR|WO)?\d+$/i.test(String(r?.code || '').trim());

  let removedFromWr = false;
  try {
    const rawWr = localStorage.getItem('portal_pm_work_requests_v3');
    if (rawWr) {
      const parsed = JSON.parse(rawWr);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter(r => !isAutoPmEntry(r));
        if (cleaned.length !== parsed.length) {
          removedFromWr = true;
          localStorage.setItem('portal_pm_work_requests_v3', JSON.stringify(cleaned));
        }
      }
    }
  } catch {}

  let removedFromTs = false;
  try {
    const rawTs = localStorage.getItem('technicalServiceWorkRequests');
    if (rawTs) {
      const parsed = JSON.parse(rawTs);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter(r => !isAutoPmEntry(r));
        if (cleaned.length !== parsed.length) {
          removedFromTs = true;
          localStorage.setItem('technicalServiceWorkRequests', JSON.stringify(cleaned));
          fetch('/api/portal/sync-state', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ workRequests: cleaned })
          }).catch(() => {});
        }
      }
    }
  } catch {}

  if (removedFromWr || removedFromTs) {
    try {
      window.dispatchEvent(new CustomEvent('pm_work_requests_updated'));
    } catch {}
  }
}

export function resolveGroupEquipmentsList(
  groupId: string,
  allEquipments: any[],
  groupAssignedMap: Record<string, string[]>
): any[] {
  const grp = PM_AUTO_GROUP_META.find(g => g.id === groupId);
  if (!grp) return [];

  const matched = allEquipments.filter(eq => {
    const idUpper = String(eq?.id || '').toUpperCase();
    const nameLower = String(eq?.name || '').toLowerCase();
    const famLower = String(eq?.family || '').toLowerCase();
    const locLower = String(eq?.location || '').toLowerCase();
    const matchPrefix = grp.prefixes.some(p => idUpper.startsWith(p));
    const matchKeyword = grp.keywords.some(k => nameLower.includes(k) || famLower.includes(k) || locLower.includes(k));
    return matchPrefix || matchKeyword;
  });

  const assignedIds = groupAssignedMap?.[groupId];
  if (!Array.isArray(assignedIds)) {
    return matched;
  }

  return assignedIds.map(id => {
    const foundAll = allEquipments.find(e => e.id === id);
    if (foundAll) return foundAll;
    const foundDef = matched.find(e => e.id === id);
    if (foundDef) return foundDef;
    return { id, name: `تجهیز ${id}`, location: 'سالن تولید', family: grp.name };
  });
}

export interface AutoPmWoLookupEntry {
  code: string;     // PMWR0001
  woCode: string;   // PMWO0001
  status: string;
  isArchived: boolean;
  sourceKey: string;
  dueDate: string;
}

export interface SyncDuePmWorkOrdersResult {
  createdItems: any[];
  allPmOrders: any[];
  statusBySourceKey: Record<string, AutoPmWoLookupEntry>;
  statusByGroupPeriod: Record<string, AutoPmWoLookupEntry>;
}

export function isItemArchivedCheck(item: any): boolean {
  return (
    Boolean(item?.isArchivedWorkOrder) ||
    item?.status === 'انجام شد' ||
    item?.status === 'انجام شده' ||
    item?.status === 'لغو' ||
    item?.status === 'لغو شده'
  );
}

export function buildAutoPmLookupMaps(orders: any[]): {
  statusBySourceKey: Record<string, AutoPmWoLookupEntry>;
  statusByGroupPeriod: Record<string, AutoPmWoLookupEntry>;
} {
  const statusBySourceKey: Record<string, AutoPmWoLookupEntry> = {};
  const statusByGroupPeriod: Record<string, AutoPmWoLookupEntry> = {};

  (Array.isArray(orders) ? orders : []).forEach(item => {
    if (!item || !item.pmSourceKey) return;
    const reqCode = String(item.code || '');
    const woCode = String(item.woCode || item.workOrderCode || reqCode);
    const entry: AutoPmWoLookupEntry = {
      code: reqCode,
      woCode,
      status: String(item.status || 'در انتظار دستور برنامه ریزی'),
      isArchived: isItemArchivedCheck(item),
      sourceKey: String(item.pmSourceKey),
      dueDate: String(item.pmDueDate || item.woStartDate || '')
    };
    statusBySourceKey[entry.sourceKey] = entry;
    if (item.pmGroupId && item.pmPeriodKey) {
      const gpKey = `${item.pmGroupId}::${item.pmPeriodKey}`;
      const existing = statusByGroupPeriod[gpKey];
      if (!existing || compareShamsiDatesPm(entry.dueDate, existing.dueDate) >= 0) {
        statusByGroupPeriod[gpKey] = entry;
      }
    }
  });

  return { statusBySourceKey, statusByGroupPeriod };
}

export function syncDuePmWorkOrders(options?: {
  groupActivities?: Record<string, any[]>;
  equipments?: any[];
  groupAssignedEquipMap?: Record<string, string[]>;
  periodSchedules?: Record<string, { startDate: string; endDate: string; executionWindowDays: number; isScheduled: boolean; updatedByUser?: boolean }>;
  silent?: boolean;
}): SyncDuePmWorkOrdersResult {
  if (typeof window === 'undefined') {
    return {
      createdItems: [],
      allPmOrders: [],
      statusBySourceKey: {},
      statusByGroupPeriod: {}
    };
  }

  // حذف هرگونه رکورد اشتباهی که قبلاً به کارتابل «درخواست کار» اضافه شده بود
  purgeAutoPmFromWorkRequestsStorage();

  const groupActivities =
    options?.groupActivities ||
    loadJsonFromStorage<Record<string, any[]>>(
      [
        'pm_studio_group_acts_v6',
        'pm_studio_group_acts_v5',
        'pm_studio_group_acts_v4',
        'pm_studio_group_acts_v3',
        'pm_studio_group_acts_v2',
        'pm_studio_group_acts_v1'
      ],
      {}
    );

  const periodSchedulesMap =
    options?.periodSchedules ||
    loadJsonFromStorage<Record<string, { startDate: string; endDate: string; executionWindowDays: number; isScheduled: boolean; updatedByUser?: boolean }>>(
      ['pm_studio_period_schedules_v1'],
      {}
    );

  // فقط دستورکارهای PM ذخیره شده در بخش نگهداری پیشگیرانه خوانده می‌شوند
  const existingPmOrders = loadAutoPmWorkOrders();
  const referenceWorkRequests = loadJsonFromStorage<any[]>(['portal_pm_work_requests_v3'], []);
  const referenceTechRequests = loadJsonFromStorage<any[]>(['technicalServiceWorkRequests'], []);

  const todayStr = getTodayShamsiDateStringPm();

  // پاکسازی دستورکارهای تکراری بازشده در تاریخ امروز که در همان بازه/دوره قبلاً دستور کار باز داشته‌اند
  let hasDeduplicatedOrders = false;
  const openOrdersByGroupPeriod = new Map<string, any[]>();
  existingPmOrders.forEach(item => {
    if (!item || isItemArchivedCheck(item) || !item.pmGroupId || !item.pmPeriodKey) return;
    const gpKey = `${item.pmGroupId}::${item.pmPeriodKey}`;
    if (!openOrdersByGroupPeriod.has(gpKey)) openOrdersByGroupPeriod.set(gpKey, []);
    openOrdersByGroupPeriod.get(gpKey)!.push(item);
  });

  const duplicateOrderIdsToDrop = new Set<string>();
  openOrdersByGroupPeriod.forEach((orders, gpKey) => {
    if (orders.length <= 1) return;
    const periodKey = gpKey.split('::')[1] || 'monthly';
    const minGap = getPeriodCycleMinGapDays(periodKey);
    const sorted = [...orders].sort((a, b) =>
      compareShamsiDatesPm(String(a.pmDueDate || a.woStartDate || ''), String(b.pmDueDate || b.woStartDate || ''))
    );
    const anchor = sorted[0];
    const anchorDate = String(anchor.pmDueDate || anchor.woStartDate || '');
    for (let i = 1; i < sorted.length; i++) {
      const cand = sorted[i];
      const candDate = String(cand.pmDueDate || cand.woStartDate || '');
      const hasTechLogs = Array.isArray(cand.woTechnicians) && cand.woTechnicians.some((t: any) => (Number(t?.hours) || 0) > 0);
      const isUntouched = !hasTechLogs && cand.status === 'در انتظار دستور برنامه ریزی';
      const isSameCycle = anchorDate && candDate && Math.abs(diffShamsiDaysPm(anchorDate, candDate)) < minGap;
      if (isSameCycle && isUntouched && !periodSchedulesMap[gpKey]?.updatedByUser) {
        duplicateOrderIdsToDrop.add(String(cand.id || cand.code || ''));
      }
    }
  });

  let nextPmOrders = existingPmOrders.filter(item => {
    const key = String(item?.id || item?.code || '');
    if (key && duplicateOrderIdsToDrop.has(key)) {
      hasDeduplicatedOrders = true;
      return false;
    }
    return true;
  });

  if (!groupActivities || Object.keys(groupActivities).length === 0) {
    if (hasDeduplicatedOrders) {
      saveAutoPmWorkOrders(nextPmOrders);
    }
    const maps = buildAutoPmLookupMaps(nextPmOrders);
    return {
      createdItems: [],
      allPmOrders: nextPmOrders,
      ...maps
    };
  }

  const allEquipments =
    options?.equipments ||
    loadJsonFromStorage<any[]>(['pm_studio_equipments_v13', 'portal_equipments_v9'], defaultPlantEquipment as any[]);
  const familyList = loadJsonFromStorage<any[]>(['pm_studio_families_v9'], defaultAssetFamilies as any[]);
  const locationList = loadJsonFromStorage<any[]>(['pm_studio_locations_v9'], defaultFactoryLocations as any[]);
  const groupAssignedMap =
    options?.groupAssignedEquipMap ||
    loadJsonFromStorage<Record<string, string[]>>(['pm_studio_group_assigned_eq_v3'], {});

  const dueBucketsByGp = new Map<
    string,
    {
      groupId: string;
      periodKey: string;
      occurrenceDate: string;
      acts: any[];
    }
  >();

  Object.entries(groupActivities).forEach(([groupId, actList]) => {
    if (!Array.isArray(actList)) return;
    actList.forEach(act => {
      const periodKey = String(act.frequencyType || 'monthly');
      const gpKey = `${groupId}::${periodKey}`;
      const ps = periodSchedulesMap[gpKey];
      const effectiveAct = ps
        ? {
            ...act,
            startDate: ps.startDate,
            endDate: ps.endDate,
            executionWindowDays: ps.executionWindowDays,
            isScheduled: ps.isScheduled
          }
        : act;
      const occDate = resolveLatestDuePmOccurrence(effectiveAct, todayStr);
      if (!occDate) return;

      const existingBucket = dueBucketsByGp.get(gpKey);
      if (!existingBucket) {
        dueBucketsByGp.set(gpKey, {
          groupId,
          periodKey,
          occurrenceDate: occDate,
          acts: [effectiveAct]
        });
      } else {
        // یکپارچه‌سازی تاریخ وقوع روی تاریخ قدیمی‌تر یا تاریخ تنظیم‌شده دوره تا هرگز دو باکت جدا ساخته نشود
        if (!ps && compareShamsiDatesPm(occDate, existingBucket.occurrenceDate) < 0) {
          existingBucket.occurrenceDate = occDate;
        }
        if (!existingBucket.acts.some(a => a.id === effectiveAct.id || (a.title === effectiveAct.title && a.code === effectiveAct.code))) {
          existingBucket.acts.push(effectiveAct);
        }
      }
    });
  });

  if (dueBucketsByGp.size === 0) {
    if (hasDeduplicatedOrders) {
      saveAutoPmWorkOrders(nextPmOrders);
    }
    const maps = buildAutoPmLookupMaps(nextPmOrders);
    return {
      createdItems: [],
      allPmOrders: nextPmOrders,
      ...maps
    };
  }

  const targetCodeLen = resolveStandardWorkOrderCodeLength([
    ...referenceWorkRequests,
    ...referenceTechRequests,
    ...nextPmOrders
  ]);
  const existingSourceKeys = new Set<string>(
    nextPmOrders
      .map(r => String(r?.pmSourceKey || '').trim())
      .filter(Boolean)
  );

  const createdItems: any[] = [];
  let hasActivitySyncUpdates = hasDeduplicatedOrders;

  const sortedBuckets = Array.from(dueBucketsByGp.values()).sort((a, b) =>
    compareShamsiDatesPm(a.occurrenceDate, b.occurrenceDate)
  );

  sortedBuckets.forEach(bucket => {
    const { groupId, periodKey, occurrenceDate, acts } = bucket;
    const gpKey = `${groupId}::${periodKey}`;
    const sourceKey = `${gpKey}::${occurrenceDate}`;
    const grp = PM_AUTO_GROUP_META.find(g => g.id === groupId);
    const grpName = grp ? grp.name : groupId;
    const periodLabel = PERIOD_LABELS[periodKey] || 'دوره‌ای';
    const ps = periodSchedulesMap[gpKey];
    const maxWindowDays = Math.max(
      1,
      ps?.executionWindowDays || 0,
      ...acts.map(a => Number(a.executionWindowDays) || Number(a.customDays) || 3)
    );
    const occEndDate = ps?.endDate && ps?.startDate === occurrenceDate
      ? ps.endDate
      : addShamsiDaysPm(occurrenceDate, maxWindowDays);

    const minCycleGap = getPeriodCycleMinGapDays(periodKey, acts);
    const sameCycleOpenOrder = nextPmOrders.find(item => {
      if (!item || isItemArchivedCheck(item)) return false;
      if (item.pmSourceKey === sourceKey) return true;
      if (item.pmGroupId === groupId && item.pmPeriodKey === periodKey) {
        const itemDate = String(item.pmDueDate || item.woStartDate || '');
        if (!itemDate) return true;
        return Math.abs(diffShamsiDaysPm(itemDate, occurrenceDate)) < minCycleGap;
      }
      return false;
    });

    if (sameCycleOpenOrder || existingSourceKeys.has(sourceKey)) {
      if (sameCycleOpenOrder) {
        nextPmOrders = nextPmOrders.map(item => {
          if (item?.id !== sameCycleOpenOrder.id) return item;

          const curActs = Array.isArray(item.woActivities) ? item.woActivities : [];
          const keepUserDateOverride = Boolean(ps?.updatedByUser);
          const effectiveStart = keepUserDateOverride
            ? occurrenceDate
            : String(item.woStartDate || item.pmDueDate || occurrenceDate);
          const effectiveEnd = keepUserDateOverride
            ? occEndDate
            : String(item.woEndDate || addShamsiDaysPm(effectiveStart, maxWindowDays));
          const effectiveSourceKey = `${gpKey}::${effectiveStart}`;

          const nextWoActivities = acts.map((a, idx) => {
            const matchedExisting = curActs.find(
              (ca: any) =>
                (a.code && ca.code && String(ca.code).trim() === String(a.code).trim() && String(ca.title).trim() === String(a.title).trim()) ||
                String(ca.title || '').trim() === String(a.title || '').trim()
            );
            if (matchedExisting) {
              return {
                ...matchedExisting,
                code: a.code || matchedExisting.code || `PM-${String(idx + 1).padStart(2, '0')}`,
                title: a.title,
                startDate: effectiveStart,
                endDate: effectiveEnd
              };
            }
            return {
              id: `woa-pm-${Date.now()}-${idx + 1}`,
              code: a.code || `PM-${String(idx + 1).padStart(2, '0')}`,
              title: a.title,
              startDate: effectiveStart,
              startTime: item.woStartTimeOnly || '08:00',
              endDate: effectiveEnd,
              endTime: item.woEndTimeOnly || '16:00'
            };
          });

          const actsChanged =
            curActs.length !== nextWoActivities.length ||
            nextWoActivities.some(
              (na, i) =>
                !curActs[i] ||
                curActs[i].title !== na.title ||
                curActs[i].code !== na.code ||
                curActs[i].startDate !== na.startDate ||
                curActs[i].endDate !== na.endDate
            );
          const datesChanged =
            item.woStartDate !== effectiveStart ||
            item.woEndDate !== effectiveEnd ||
            item.pmSourceKey !== effectiveSourceKey;

          if (actsChanged || datesChanged) {
            hasActivitySyncUpdates = true;
            const summaryLine = `فعالیت‌های برنامه‌ریزی‌شده (${acts.length} مورد): ${acts.map((a, i) => `${i + 1}. ${a.code ? `[${a.code}] ` : ''}${a.title}`).join(' | ')}`;
            const descLines = String(item.description || '').split('\n');
            const updatedDescLines = descLines.map(line => {
              if (line.startsWith('فعالیت‌های برنامه‌ریزی‌شده')) return summaryLine;
              if (line.startsWith('گروه تجهیز:') && datesChanged) {
                return `گروه تجهیز: ${grpName} | دوره تناوب: ${periodLabel} | بازه اجرا: ${effectiveStart} تا ${effectiveEnd}`;
              }
              return line;
            });
            if (!descLines.some(l => l.startsWith('فعالیت‌های برنامه‌ریزی‌شده'))) {
              updatedDescLines.push(summaryLine);
            }

            return {
              ...item,
              requestTime: `${effectiveStart} - ${item.woStartTimeOnly || '08:00'}`,
              woStartDate: effectiveStart,
              woEndDate: effectiveEnd,
              woStartTime: `${effectiveStart} - ${item.woStartTimeOnly || '08:00'}`,
              woEndTime: `${effectiveEnd} - ${item.woEndTimeOnly || '16:00'}`,
              pmDueDate: effectiveStart,
              pmSourceKey: effectiveSourceKey,
              description: updatedDescLines.filter(Boolean).join('\n'),
              woActivities: nextWoActivities
            };
          }
          return item;
        });
      }
      return;
    }

    const { reqCode, woCode } = getNextPmReqAndWoCodes(nextPmOrders, targetCodeLen);

    const activeEqs = resolveGroupEquipmentsList(groupId, allEquipments, groupAssignedMap);
    const primaryEq = activeEqs[0];
    const eqCode = primaryEq?.id || grp?.prefixes[0] || groupId.toUpperCase();
    const eqName =
      activeEqs.length > 1
        ? `${grpName} (${activeEqs.length} تجهیز: ${activeEqs.slice(0, 3).map(e => e.id).join('، ')}${activeEqs.length > 3 ? ' ...' : ''})`
        : primaryEq?.name || `تجهیزات گروه ${grpName}`;

    const matchedFamily = familyList.find((f: any) => {
      const fId = String(f?.id || '').toUpperCase();
      const fName = String(f?.name || '').trim();
      const eqFam = String(primaryEq?.family || '').trim();
      return (
        (eqFam && fName === eqFam) ||
        (grp?.prefixes.some(p => fId.startsWith(p))) ||
        (grp?.keywords.some(k => fName.toLowerCase().includes(k)))
      );
    });

    const familyCode = matchedFamily?.id || grp?.prefixes[0] || '';
    const familyName = primaryEq?.family || matchedFamily?.name || `گروه ${grpName}`;

    const locName = primaryEq?.location || 'سالن تولید';
    const matchedLoc = locationList.find((l: any) => String(l?.name || '').trim() === locName);
    const locCode = primaryEq?.locationCode || matchedLoc?.id || '';

    const eqSummaryList =
      activeEqs.length > 0
        ? activeEqs.map(e => `${e.name || e.id} (${e.id})`).join('، ')
        : `تجهیزات گروه ${grpName}`;

    const woActivities = acts.map((a, idx) => ({
      id: `woa-pm-${Date.now()}-${idx + 1}`,
      code: a.code || `PM-${String(idx + 1).padStart(2, '0')}`,
      title: a.title,
      startDate: occurrenceDate,
      startTime: '08:00',
      endDate: occEndDate,
      endTime: '16:00'
    }));

    const partsNotes = acts
      .map(a => String(a.partsRequired || '').trim())
      .filter(Boolean);

    const newItem = {
      id: `pmwo-${woCode}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      code: reqCode,           // PMWR0001 (۸ کاراکتر)
      woCode: woCode,          // PMWO0001 (۸ کاراکتر)
      workOrderCode: woCode,   // PMWO0001 (۸ کاراکتر)
      equipmentName: eqName,
      equipmentCode: eqCode,
      locationName: locName,
      locationCode: locCode,
      requestTime: `${occurrenceDate} - 08:00`,
      equipmentFamilyName: familyName,
      equipmentFamilyCode: familyCode,
      failureTitle: `سرویس و نگهداری پیشگیرانه ${periodLabel} (${grpName})`,
      failureCode: 'PM-SCH',
      priority: 'عدم توقف تجهیز' as const,
      description: [
        `دستور کار پیشگیرانه زمان‌بندی شده (PM) — صادر شده در نگهداری پیشگیرانه در تاریخ سررسید ${occurrenceDate}`,
        `گروه تجهیز: ${grpName} | دوره تناوب: ${periodLabel} | بازه اجرا: ${occurrenceDate} تا ${occEndDate}`,
        `تجهیزات مشمول (${activeEqs.length || 1} دستگاه): ${eqSummaryList}`,
        `فعالیت‌های برنامه‌ریزی‌شده (${acts.length} مورد): ${acts.map((a, i) => `${i + 1}. ${a.code ? `[${a.code}] ` : ''}${a.title}`).join(' | ')}`,
        partsNotes.length > 0 ? `قطعات و اقلام پیشنهادی: ${partsNotes.join('، ')}` : ''
      ]
        .filter(Boolean)
        .join('\n'),
      requestType: 'پیشگیرانه' as const,
      status: 'در انتظار دستور برنامه ریزی',
      operatorName: 'سیستم زمان‌بندی خودکار PM',
      operatorPersonnelCode: 'SYS-PM',
      woStartDate: occurrenceDate,
      woStartTimeOnly: '08:00',
      woEndDate: occEndDate,
      woEndTimeOnly: '16:00',
      woStartTime: `${occurrenceDate} - 08:00`,
      woEndTime: `${occEndDate} - 16:00`,
      woActivities,
      isArchivedWorkOrder: false,
      isPM: true,
      isScheduledPM: true,
      pmGroupId: groupId,
      pmGroupName: grpName,
      pmPeriodKey: periodKey,
      pmPeriodLabel: periodLabel,
      pmDueDate: occurrenceDate,
      pmSourceKey: sourceKey,
      pmCandidateEquipments: activeEqs.map(e => ({
        id: String(e.id || ''),
        name: String(e.name || e.id || ''),
        location: String(e.location || ''),
        family: String(e.family || '')
      })),
      pmSelectedEquipmentIds: activeEqs.map(e => String(e.id || '')),
      timestamp: Date.now()
    };

    createdItems.push(newItem);
    nextPmOrders = [newItem, ...nextPmOrders];
    existingSourceKeys.add(sourceKey);
  });

  if (createdItems.length > 0 || hasActivitySyncUpdates) {
    saveAutoPmWorkOrders(nextPmOrders);

    if (!options?.silent) {
      try {
        window.dispatchEvent(
          new CustomEvent('pm_auto_work_orders_updated', {
            detail: { createdItems, allPmOrders: nextPmOrders }
          })
        );
      } catch {}
    }
  }

  const maps = buildAutoPmLookupMaps(nextPmOrders);
  return {
    createdItems,
    allPmOrders: nextPmOrders,
    ...maps
  };
}

export interface PmGroupFamilyActivityOption {
  id: string;
  code: string;
  title: string;
  familyId: string;
  familyName: string;
  frequency?: string;
  type?: string;
  role?: string;
}

interface PmGroupFamilyRule {
  prefixes: string[];
  keywords: string[];
  excludePrefixes?: string[];
  excludeKeywords?: string[];
}

const PM_GROUP_FAMILY_RULES: Record<string, PmGroupFamilyRule> = {
  tornos: {
    prefixes: ['TUTN', 'TUCT'],
    keywords: ['تورنوس', 'tornos']
  },
  milling: {
    prefixes: ['MICN', 'MINC', 'MIDR', 'FR'],
    keywords: ['فرز', 'milling', 'feeler', 'hartford']
  },
  lathe: {
    prefixes: ['TUTL', 'TULT', 'TUGM', 'TUHA', 'TUMN'],
    keywords: ['تراش cnc', 'تراش manual', 'گیلدمستر', 'هانووا', 'هانواو', 'تبریز', 'lathe'],
    excludePrefixes: ['TUTN', 'TUCT', 'TUSY', 'TUMA'],
    excludeKeywords: ['تورنوس', 'tornos', 'سینتک', 'syntec', 'مایر', 'mayer']
  },
  syntec: {
    prefixes: ['SY', 'TUSY'],
    keywords: ['سینتک', 'syntec']
  },
  mayer: {
    prefixes: ['TUMA'],
    keywords: ['مایر', 'mayer']
  },
  wirecut: {
    prefixes: ['WICN'],
    keywords: ['وایرکات', 'wirecut', 'dk77']
  },
  lab: {
    prefixes: ['LAB', 'QC', 'TLAX', 'TLRO', 'TLHT'],
    keywords: ['آزمایشگاه', 'تست خستگی', 'سختی سنج', 'سختیسنج', 'زبری', 'کوانتومتر', 'میکروسکوپ', 'lab']
  },
  press: {
    prefixes: ['PRHY', 'PRFO', 'PRST'],
    keywords: ['پرس'],
    excludePrefixes: ['PRTD', 'AUAC'],
    excludeKeywords: ['پرینتر', 'کمپرسور']
  },
  facilities: {
    prefixes: ['FAC', 'UT', 'CMP', 'CHL', 'CLCW', 'AUAC', 'GNDY', 'AREF', 'ARAU', 'BHBR'],
    keywords: ['تاسیسات', 'کمپرسور', 'چیلر', 'دیزل', 'ژنراتور', 'بویلر', 'موتورخانه', 'هواساز']
  }
};

function normFamilyFa(val: unknown): string {
  return String(val ?? '')
    .replace(/ي/g, 'ی')
    .replace(/ى/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\u200c/g, '')
    .trim()
    .toLowerCase();
}

function compactFamilyFa(val: unknown): string {
  return normFamilyFa(val).replace(/[\s_\-–—()（）/\\]+/g, '');
}

export function resolveGroupFamilyIds(
  groupId: string,
  familyList: any[],
  equipmentList: any[] = [],
  groupAssignedMap?: Record<string, string[]>
): Array<{ id: string; name: string }> {
  if (!groupId || typeof window === 'undefined') return [];
  const allFamilies = Array.isArray(familyList) && familyList.length > 0
    ? familyList
    : (defaultAssetFamilies as any[]);
  const rule = PM_GROUP_FAMILY_RULES[groupId];

  const matchedMap = new Map<string, { id: string; name: string }>();
  const addFam = (fam: any) => {
    const id = String(fam?.id || '').trim();
    if (!id || matchedMap.has(id)) return;
    matchedMap.set(id, { id, name: String(fam?.name || id).trim() });
  };

  const isExcluded = (fam: any): boolean => {
    if (!rule) return false;
    const fIdU = String(fam?.id || '').toUpperCase();
    const fTxt = normFamilyFa(`${fam?.name || ''} ${fam?.group || ''}`);
    if (rule.excludePrefixes?.some(p => fIdU.startsWith(p))) return true;
    if (rule.excludeKeywords?.some(k => fTxt.includes(normFamilyFa(k)))) return true;
    return false;
  };

  // ۱) تطبیق مستقیم با قوانین کد، نام و گروه خانواده برای جداسازی کامل (تورنوس فقط تورنوس، فرز فقط فرز و...)
  if (rule) {
    allFamilies.forEach(fam => {
      if (isExcluded(fam)) return;
      const fIdU = String(fam?.id || '').toUpperCase();
      const fTxt = normFamilyFa(`${fam?.name || ''} ${fam?.group || ''}`);
      const hitPrefix = rule.prefixes.some(p => fIdU.startsWith(p));
      const hitKeyword = rule.keywords.some(k => fTxt.includes(normFamilyFa(k)));
      if (hitPrefix || hitKeyword) {
        addFam(fam);
      }
    });
  }

  // ۲) بررسی خانواده‌های تجهیزات اختصاصی همین گروه (خصوصاً اگر کاربر تجهیز دلخواهی اضافه کرده باشد)
  const assignedIds = groupAssignedMap?.[groupId];
  const hasManualAssignment = Array.isArray(assignedIds);
  const groupEqs = hasManualAssignment
    ? assignedIds
        .map(id => (equipmentList || []).find(e => e?.id === id))
        .filter(Boolean)
    : resolveGroupEquipmentsList(groupId, equipmentList || [], {});

  const eqFamCompacts = new Set<string>();
  groupEqs.forEach((eq: any) => {
    const fc = compactFamilyFa(eq?.family);
    if (fc) eqFamCompacts.add(fc);
  });

  if (eqFamCompacts.size > 0) {
    allFamilies.forEach(fam => {
      if (!hasManualAssignment && isExcluded(fam)) return;
      const fc = compactFamilyFa(fam?.name);
      if (fc && eqFamCompacts.has(fc)) {
        addFam(fam);
      }
    });
  }

  // ۳) اضافه کردن خودکار زیرسیستم‌های هر خانواده تطبیق‌یافته (مانند TUTN01SU1 برق / TUTN01SU2 مکانیک)
  const parentIds = Array.from(matchedMap.keys());
  if (parentIds.length > 0) {
    allFamilies.forEach(fam => {
      const fId = String(fam?.id || '').trim();
      const fIdU = fId.toUpperCase();
      if (parentIds.some(pid => fIdU.startsWith(`${pid.toUpperCase()}SU`))) {
        addFam(fam);
      }
    });
  }

  return Array.from(matchedMap.values());
}

export function getGroupFamilyMaintenanceActivities(
  groupId: string,
  familyList: any[],
  equipmentList: any[] = [],
  groupAssignedMap?: Record<string, string[]>
): PmGroupFamilyActivityOption[] {
  if (!groupId || typeof window === 'undefined') return [];
  const matchedFamilies = resolveGroupFamilyIds(groupId, familyList, equipmentList, groupAssignedMap);
  const seen = new Set<string>();
  const results: PmGroupFamilyActivityOption[] = [];

  matchedFamilies.forEach(fam => {
    try {
      const raw = localStorage.getItem(`pmworks_asset_class_data_${fam.id}`);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed?.maintenance)) return;
      parsed.maintenance.forEach((m: any, idx: number) => {
        const title = String(m?.title || '').trim();
        const code = String(m?.code || '').trim();
        if (!title) return;
        const dedupKey = `${normFamilyFa(code)}||${normFamilyFa(title)}`;
        if (seen.has(dedupKey)) return;
        seen.add(dedupKey);
        results.push({
          id: String(m?.id || `${fam.id}-maint-${idx}`),
          code,
          title,
          familyId: fam.id,
          familyName: fam.name,
          frequency: String(m?.frequency || '').trim() || undefined,
          type: String(m?.type || '').trim() || undefined,
          role: String(m?.role || '').trim() || undefined
        });
      });
    } catch {}
  });

  return results;
}

export function isStrictPmRecord(item: any): boolean {
  if (!item || typeof item !== 'object') return false;
  const reqType = String(item.requestType || '').trim();
  const reqTypeUpper = reqType.toUpperCase();
  const opType = String(item.operationType || item.opType || '').trim();
  const code = String(item.code || item.id || '').trim().toUpperCase();
  const woCode = String(item.woCode || item.workOrderCode || item.woNumber || '').trim().toUpperCase();

  return (
    item.isPM === true ||
    item.isScheduledPM === true ||
    Boolean(item.pmGroupId) ||
    Boolean(item.pmPlanId) ||
    reqType === 'پیشگیرانه' ||
    reqTypeUpper === 'PM' ||
    opType.includes('(PM)') ||
    opType.includes('پیشگیرانه') ||
    code.startsWith('PMWR') ||
    code.startsWith('PMWO') ||
    code.startsWith('PM-') ||
    woCode.startsWith('PMWO') ||
    woCode.startsWith('PM-')
  );
}

export interface PmTechStatsSummary {
  hours: number;
  tasks: number;
  lastAction: string;
}

export interface PmReconcileSourcesOverride {
  autoPmOrders?: any[];
  pmWorkOrders?: any[];
  portalWorkRequests?: any[];
  techServiceRequests?: any[];
}

function readLocalJsonArray(key: string): any[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function computePmOnlyStatsByTechnician(
  overrides?: PmReconcileSourcesOverride
): Record<string, PmTechStatsSummary> {
  const stats: Record<string, PmTechStatsSummary> = {};
  const seenOrderKeys = new Set<string>();

  const creditTech = (nameRaw: any, hoursVal: number, actionLabel: string) => {
    const name = String(nameRaw || '').trim();
    if (!name || name === 'نامشخص' || name === 'در انتظار اعزام و ثبت مجریان') return;
    if (!stats[name]) {
      stats[name] = { hours: 0, tasks: 0, lastAction: actionLabel || 'فعالیت پیشگیرانه PM' };
    }
    stats[name].hours = Math.round((stats[name].hours + Math.max(0, hoursVal)) * 100) / 100;
    stats[name].tasks += 1;
    if (actionLabel && !stats[name].lastAction) {
      stats[name].lastAction = actionLabel;
    }
  };

  const registerSeenKeys = (item: any): boolean => {
    const keys = [item?.code, item?.woCode, item?.workOrderCode, item?.woNumber, item?.id]
      .map(k => String(k || '').trim().toUpperCase())
      .filter(Boolean);
    if (keys.some(k => seenOrderKeys.has(k))) return true;
    keys.forEach(k => seenOrderKeys.add(k));
    return false;
  };

  // ۱. دستورکارهای پیشگیرانه زمان‌بندی‌شده / سه‌تب (فقط PM)
  const autoPmOrders = overrides?.autoPmOrders ?? loadAutoPmWorkOrders();
  autoPmOrders.forEach((o: any) => {
    if (!o) return;
    if (registerSeenKeys(o)) return;
    const woLabel = String(o.woCode || o.workOrderCode || o.code || o.id || '').trim();
    const actionLabel = `دستور کار PM ${woLabel}${o.equipmentName ? ` (${o.equipmentName})` : ''}`.trim();

    if (Array.isArray(o.woTechnicians) && o.woTechnicians.length > 0) {
      const hoursByTech: Record<string, number> = {};
      o.woTechnicians.forEach((t: any) => {
        const n = String(t?.name || '').trim();
        if (!n) return;
        hoursByTech[n] = (hoursByTech[n] || 0) + (Number(t?.hours) || 0);
      });
      Object.entries(hoursByTech).forEach(([n, hrs]) => {
        if (hrs > 0) {
          creditTech(n, hrs, actionLabel);
        }
      });
    } else if (o.status === 'انجام شد' || o.status === 'completed') {
      const hrs = Math.round((Number(o.durationMinutes || 0) / 60) * 100) / 100;
      const names = new Set<string>();
      if (o.technician) names.add(String(o.technician).trim());
      if (Array.isArray(o.coTechnicians)) {
        o.coTechnicians.forEach((c: any) => {
          const cn = String(c || '').trim();
          if (cn) names.add(cn);
        });
      }
      names.forEach(n => creditTech(n, hrs, actionLabel));
    }
  });

  // ۲. دستورکارهای داخلی بسته شده در بخش PM Studio (فقط موارد انجام‌شده یا دارای ساعت واقعی)
  const pmWorkOrders = overrides?.pmWorkOrders ?? readLocalJsonArray('pm_studio_work_orders_v15');
  pmWorkOrders.forEach((o: any) => {
    if (!o) return;
    const isDone = o.status === 'انجام شد' || o.status === 'completed';
    const hasLoggedTechs =
      Array.isArray(o.woTechnicians) && o.woTechnicians.some((t: any) => (Number(t?.hours) || 0) > 0);
    if (!isDone && !hasLoggedTechs && !(Number(o.actualHours) > 0)) return;
    if (registerSeenKeys(o)) return;

    const woLabel = String(o.woCode || o.code || o.id || '').trim();
    const actionLabel = o.title ? `اتمام PM: ${o.title}` : `دستور کار PM ${woLabel}`;

    if (Array.isArray(o.woTechnicians) && o.woTechnicians.length > 0) {
      const hoursByTech: Record<string, number> = {};
      o.woTechnicians.forEach((t: any) => {
        const n = String(t?.name || '').trim();
        if (!n) return;
        hoursByTech[n] = (hoursByTech[n] || 0) + (Number(t?.hours) || 0);
      });
      Object.entries(hoursByTech).forEach(([n, hrs]) => {
        if (hrs > 0) creditTech(n, hrs, actionLabel);
      });
    } else {
      const hrs = Number(o.actualHours ?? o.estimatedHours ?? 0) || Math.round((Number(o.durationMinutes || 0) / 60) * 100) / 100;
      const names = new Set<string>();
      if (o.assignedTo) {
        String(o.assignedTo)
          .split(/\s+و\s+|[،,]+/)
          .map(s => s.trim())
          .filter(Boolean)
          .forEach(s => names.add(s));
      }
      if (o.technician) names.add(String(o.technician).trim());
      if (Array.isArray(o.coTechnicians)) {
        o.coTechnicians.forEach((c: any) => {
          const cn = String(c || '').trim();
          if (cn) names.add(cn);
        });
      }
      names.forEach(n => creditTech(n, hrs, actionLabel));
    }
  });

  // ۳. درخواست کارها و سوابق فنی که صریحاً از نوع پیشگیرانه (PM) هستند (موارد EM/CM مطلقاً لحاظ نمی‌شوند)
  const portalWrs = overrides?.portalWorkRequests ?? readLocalJsonArray('portal_pm_work_requests_v3');
  const techReqs = overrides?.techServiceRequests ?? readLocalJsonArray('technicalServiceWorkRequests');
  [...portalWrs, ...techReqs].forEach((r: any) => {
    if (!r || !isStrictPmRecord(r)) return;
    if (registerSeenKeys(r)) return;

    const woLabel = String(r.woCode || r.workOrderCode || r.code || r.id || '').trim();
    const actionLabel = `دستور کار PM ${woLabel}${r.equipmentName ? ` (${r.equipmentName})` : ''}`.trim();

    if (Array.isArray(r.woTechnicians) && r.woTechnicians.length > 0) {
      const hoursByTech: Record<string, number> = {};
      r.woTechnicians.forEach((t: any) => {
        const n = String(t?.name || '').trim();
        if (!n) return;
        hoursByTech[n] = (hoursByTech[n] || 0) + (Number(t?.hours) || 0);
      });
      Object.entries(hoursByTech).forEach(([n, hrs]) => {
        if (hrs > 0) creditTech(n, hrs, actionLabel);
      });
    } else if (r.status === 'انجام شد' || r.status === 'completed') {
      const hrs = Math.round((Number(r.durationMinutes || 0) / 60) * 100) / 100;
      const names = new Set<string>();
      if (r.technician) names.add(String(r.technician).trim());
      if (Array.isArray(r.coTechnicians)) {
        r.coTechnicians.forEach((c: any) => {
          const cn = String(c || '').trim();
          if (cn) names.add(cn);
        });
      }
      names.forEach(n => creditTech(n, hrs, actionLabel));
    }
  });

  return stats;
}

export function reconcilePmTechniciansList<T extends Record<string, any>>(
  techs: T[],
  overrides?: PmReconcileSourcesOverride
): T[] {
  if (!Array.isArray(techs)) return [];
  const pmStats = computePmOnlyStatsByTechnician(overrides);
  return techs.map(t => {
    const tName = String(t?.name || '').trim();
    const s = pmStats[tName];
    if (!s) {
      const prevLast = String(t?.lastAction || '');
      const cleanLast =
        !prevLast || prevLast.startsWith('دستور کار ')
          ? 'آماده ثبت فعالیت'
          : prevLast;
      return {
        ...t,
        completedTasks: 0,
        workHours: 0,
        lastAction: cleanLast
      };
    }
    return {
      ...t,
      completedTasks: s.tasks,
      workHours: s.hours,
      lastAction: s.lastAction || t.lastAction || 'فعالیت پیشگیرانه PM'
    };
  });
}

export function syncAndReconcilePmTechStorage(overrides?: PmReconcileSourcesOverride): any[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('pm_studio_techs_v5');
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const reconciled = reconcilePmTechniciansList(parsed, overrides);
    localStorage.setItem('pm_studio_techs_v5', JSON.stringify(reconciled));
    return reconciled;
  } catch {
    return [];
  }
}
