// ========================================================
// سامانه قطعات یدکی و اقلام مصرفی کارخانه
// رهگیری قطعات، کدگذاری و ثبت سوابق مصرف در خدمات فنی و نگهداری PM
// ========================================================

export type SparePartCategory = 
  | 'برقی' 
  | 'مکانیکی' 
  | 'هیدرولیک و پنوماتیک' 
  | 'ابزار دقیق' 
  | 'عمومی و سایر';

export type SparePartSource = 'all' | 'pm' | 'technical' | 'shared';
export type SparePartFilterSource = 'all' | 'pm' | 'technical' | 'shared';

// سابقه مصرف قطعه در یک کار (PM یا خدمات فنی)
export interface SparePartConsumptionRecord {
  id: string;
  partId: string;
  partCode?: string;
  partName: string;
  workType: 'pm' | 'technical'; // نوع کار: PM یا خدمات فنی
  workCode?: string;            // شماره دستورکار یا کد کار
  workTitle?: string;           // شرح و عنوان کار انجام‌شده
  equipment?: string;           // نام یا کد دستگاه / محل تجهیز
  count: number;                // تعداد یا مقدار مصرف
  unit?: string;                // واحد (عدد، متر، لیتر و...)
  date: string;                 // تاریخ مصرف
  technician?: string;          // تکنسین اقدام‌کننده
  notes?: string;               // توضیحات یا یادداشت اقدام
  timestamp: number;
}

export interface UnifiedSparePart {
  id: string;                    // شناسه یکتا
  code?: string;                 // کد قطعه (مانند PRT-01، BEARING-6204 و...)
  name: string;                  // نام کامل قطعه یدکی مصرفی
  category: SparePartCategory;   // گروه تخصصی (برقی، مکانیکی و...)
  unit?: string;                 // واحد شمارش (عدد، متر، لیتر، شاخه، بسته و...)
  price?: string;                // قیمت تخمینی (تومان)
  eqFamily?: string;             // دستگاه یا خانواده تجهیز مرتبط
  location?: string;             // محل فیزیکی در قفسه یا انبار
  notes?: string;                // مشخصات فنی، برند یا پارت نامبر سازنده
  lastUpdated?: string;          // تاریخ آخرین ویرایش
  // فیلدهای کمکی برای سازگاری عقب‌رو با گزارشات و کدهای قبلی
  stock: number;
  minStock: number;
  source?: string;
}

export function clearAllSparePartsReports(): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem('factory_spare_parts_consumptions_v1');
    } catch {}
  }
}

export const STORAGE_KEY_USER_CLEAN_SLATE = 'factory_spare_parts_clean_user_v16';
export const STORAGE_KEY_UNIFIED_SPARE_PARTS = 'factory_unified_spare_parts_v2';
export const STORAGE_KEY_CONSUMPTIONS = 'factory_spare_parts_consumptions_v1';
export const EVENT_SPARE_PARTS_UPDATED = 'factory-spare-parts-updated';

// لیست اولیه کاملاً خالی طبق درخواست مؤکد کاربر تا خودش موارد واقعی کارخانه را اضافه کند
export const INITIAL_UNIFIED_SPARE_PARTS: UnifiedSparePart[] = [];

// دریافت لیست قطعات یدکی از localStorage
export function getUnifiedSpareParts(): UnifiedSparePart[] {
  if (typeof window === 'undefined') return [];

  // اجرای پاکسازی یک‌باره اقلام ساختگی قبلی برای شروع تمیز کاربر
  try {
    const isCleaned = localStorage.getItem(STORAGE_KEY_USER_CLEAN_SLATE);
    if (!isCleaned) {
      localStorage.setItem(STORAGE_KEY_USER_CLEAN_SLATE, 'cleaned');
      localStorage.setItem(STORAGE_KEY_UNIFIED_SPARE_PARTS, JSON.stringify([]));
      return [];
    }
  } catch {}

  let currentList: UnifiedSparePart[] = [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_UNIFIED_SPARE_PARTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        currentList = parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading unified spare parts:', err);
  }

  return currentList;
}

// ذخیره قطعات در حافظه لوکال و انتشار رویداد برای همگام‌سازی آنی تمام کامپوننت‌ها
export function saveUnifiedSpareParts(parts: UnifiedSparePart[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_UNIFIED_SPARE_PARTS, JSON.stringify(parts));
    window.dispatchEvent(new CustomEvent(EVENT_SPARE_PARTS_UPDATED, { detail: parts }));
  } catch (err) {
    console.error('Failed to save unified spare parts:', err);
  }
}

// دریافت سوابق مصرف کلی یا فیلترشده برای یک قطعه مشخص (هم از ثبتهای دستی و هم از دستورکارهای خدمات فنی)
export function getSparePartConsumptions(partIdOrName?: string): SparePartConsumptionRecord[] {
  if (typeof window === 'undefined') return [];
  let allConsumptions: SparePartConsumptionRecord[] = [];

  // ۱. سوابق مصرف ثبت‌شده در انبار قطعات
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONSUMPTIONS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        allConsumptions = parsed;
      }
    }
  } catch {}

  // ۲. استخراج اقلام مصرفی ثبت‌شده در کارها و دستورکارهای خدمات فنی کارخانه
  try {
    const rawWR = localStorage.getItem('technicalServiceWorkRequests');
    if (rawWR) {
      const requests = JSON.parse(rawWR);
      if (Array.isArray(requests)) {
        requests.forEach((req: any) => {
          if (Array.isArray(req.consumables) && req.consumables.length > 0) {
            req.consumables.forEach((c: any, cIdx: number) => {
              const cName = (c.name || '').trim();
              if (!cName) return;
              const synId = `wr-cons-${req.code || req.id || 'wo'}-${cIdx}`;
              if (!allConsumptions.some(x => x.id === synId)) {
                allConsumptions.push({
                  id: synId,
                  partId: c.partId || cName,
                  partCode: c.code || '',
                  partName: cName,
                  workType: 'technical',
                  workCode: req.workOrderCode || req.code || 'دستورکار خدمات فنی',
                  workTitle: req.title || req.actionDetails || 'تعمیرات و خدمات فنی',
                  equipment: req.place || req.equipment || '',
                  count: Number(c.count || c.quantity || 1),
                  unit: c.unit || 'عدد',
                  date: req.woDate || req.created || req.completedAt || '۱۴۰۵/۰۸/۱۰',
                  technician: req.technician || (req.coTechnicians && req.coTechnicians[0]) || 'تکنسین فنی',
                  notes: req.actionDetails || req.description || '',
                  timestamp: Date.now() - 1000
                });
              }
            });
          }
        });
      }
    }
  } catch {}

  if (partIdOrName && partIdOrName.trim()) {
    const target = partIdOrName.trim().toLowerCase();
    return allConsumptions.filter(c => 
      (c.partId && c.partId.toLowerCase() === target) ||
      (c.partCode && c.partCode.toLowerCase() === target) ||
      (c.partName && c.partName.trim().toLowerCase() === target)
    );
  }

  // مرتب‌سازی از جدیدترین به قدیمی‌ترین
  return allConsumptions.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
}

// ثبت سابقه مصرف جدید برای یک قطعه
export function recordSparePartConsumption(
  recordInput: Omit<SparePartConsumptionRecord, 'id' | 'timestamp'>
): SparePartConsumptionRecord {
  const newRec: SparePartConsumptionRecord = {
    ...recordInput,
    id: `cons-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now()
  };

  let manualOnly: SparePartConsumptionRecord[] = [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONSUMPTIONS);
    if (raw) manualOnly = JSON.parse(raw);
  } catch {
    manualOnly = [];
  }

  const updatedManual = [newRec, ...manualOnly];
  try {
    localStorage.setItem(STORAGE_KEY_CONSUMPTIONS, JSON.stringify(updatedManual));
    window.dispatchEvent(new CustomEvent(EVENT_SPARE_PARTS_UPDATED, { detail: getUnifiedSpareParts() }));
  } catch {}

  return newRec;
}

// حذف یک رکورد مصرف قطعه
export function deleteSparePartConsumption(recordId: string): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONSUMPTIONS);
    if (!raw) return;
    const list: SparePartConsumptionRecord[] = JSON.parse(raw);
    const updated = list.filter(r => r.id !== recordId);
    localStorage.setItem(STORAGE_KEY_CONSUMPTIONS, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(EVENT_SPARE_PARTS_UPDATED, { detail: getUnifiedSpareParts() }));
  } catch {}
}

// افزودن یا بروزرسانی یک قطعه در انبار
export function addOrUpdateSparePart(partInput: Partial<UnifiedSparePart> & { name: string }): UnifiedSparePart {
  const current = getUnifiedSpareParts();
  const trimmedName = partInput.name.trim();

  const existingIndex = current.findIndex(
    p => (partInput.id && p.id === partInput.id) || 
         (partInput.code && p.code && p.code.toLowerCase() === (partInput.code || '').toLowerCase()) ||
         p.name.toLowerCase() === trimmedName.toLowerCase()
  );

  let updatedPart: UnifiedSparePart;

  if (existingIndex >= 0) {
    const existing = current[existingIndex];
    updatedPart = {
      ...existing,
      ...partInput,
      name: trimmedName,
      lastUpdated: new Date().toLocaleDateString('fa-IR')
    };
    current[existingIndex] = updatedPart;
  } else {
    const num = current.length + 1;
    const defaultCode = `PRT-${String(num).padStart(2, '0')}`;
    const partCode = (partInput.code && partInput.code.trim()) ? partInput.code.trim().toUpperCase() : defaultCode;
    const newId = partInput.id || `prt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    updatedPart = {
      id: newId,
      code: partCode,
      name: trimmedName,
      category: partInput.category || 'عمومی و سایر',
      unit: partInput.unit || 'عدد',
      price: partInput.price || '',
      eqFamily: partInput.eqFamily || '',
      location: partInput.location || '',
      notes: partInput.notes || '',
      stock: partInput.stock ?? 0,
      minStock: partInput.minStock ?? 0,
      source: partInput.source || 'shared',
      lastUpdated: new Date().toLocaleDateString('fa-IR')
    };
    current.unshift(updatedPart);
  }

  saveUnifiedSpareParts(current);
  return updatedPart;
}

// افزایش یا کاهش موجودی (جهت سازگاری کدهای قبلی)
export function adjustSparePartStock(id: string, delta: number): UnifiedSparePart[] {
  const current = getUnifiedSpareParts();
  const updated = current.map(item => {
    if (item.id === id) {
      const curStock = item.stock || 0;
      return { ...item, stock: Math.max(0, curStock + delta), lastUpdated: new Date().toLocaleDateString('fa-IR') };
    }
    return item;
  });
  saveUnifiedSpareParts(updated);
  return updated;
}

// حذف یک قطعه
export function deleteSparePart(id: string): UnifiedSparePart[] {
  const current = getUnifiedSpareParts();
  const updated = current.filter(item => item.id !== id);
  saveUnifiedSpareParts(updated);
  return updated;
}

// اشتراک در تغییرات جهت به‌روزرسانی آنی در کل سامانه
export function subscribeToSpareParts(callback: (parts: UnifiedSparePart[]) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handleUpdate = (e: any) => {
    if (e && e.detail) {
      callback(e.detail);
    } else {
      callback(getUnifiedSpareParts());
    }
  };

  const handleStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY_UNIFIED_SPARE_PARTS || e.key === STORAGE_KEY_CONSUMPTIONS) {
      callback(getUnifiedSpareParts());
    }
  };

  window.addEventListener(EVENT_SPARE_PARTS_UPDATED, handleUpdate);
  window.addEventListener('storage', handleStorage);

  return () => {
    window.removeEventListener(EVENT_SPARE_PARTS_UPDATED, handleUpdate);
    window.removeEventListener('storage', handleStorage);
  };
}

export interface WorkOrderConsumableItem {
  id: string;
  name: string;
  count: number;
  category: 'برقی' | 'مکانیکی' | 'سایر';
  unit?: string;
}

export const DEFAULT_PRESET_CONSUMABLES: Record<'برقی' | 'مکانیکی' | 'سایر', string[]> = {
  'برقی': [
    'فیوز مینیاتوری ۱۶ آمپر',
    'فیوز مینیاتوری ۲۵ آمپر',
    'کنتاکتور اشنایدر ۹ آمپر',
    'کنتاکتور اشنایدر ۱۸ آمپر',
    'کلید حرارتی ۲.۵ تا ۴ آمپر',
    'سنسور القایی نوری',
    'میکروسوئیچ غلطکی',
    'کابلشو و سرسیم سایز ۲.۵',
    'چسب برق نسوز',
    'ترمینال ریلی فونیکس'
  ],
  'مکانیکی': [
    'بلبرینگ شیار عمیق ۶۲۰۴',
    'بلبرینگ ۶۲۰۵ 2RS',
    'اورینگ NBR سایزهای مختلف',
    'کاسه نمد ضد روغن',
    'تسمه پروانه مقطع A',
    'تسمه دینام مقطع B',
    'پیچ آلن فولادی نمره ۸',
    'مهره کاسه نمدی و واشر فنری',
    'شیلنگ هیدرولیک فشار قوی',
    'کوپلینگ انعطاف‌پذیر لاستیکی'
  ],
  'سایر': [
    'اسپری زنگ‌بر و روانکار WD-40',
    'گریس نسوز بر پایه لیتیوم',
    'چسب قطره‌ای صنعتی لاکتایت',
    'نوار تفلون صنعتی گاز و مایع',
    'دستکش کار صنعتی مقاوم',
    'پارچه تنظیف صنعتی',
    'سیلیکون RTV و درزگیر حرارتی'
  ]
};

