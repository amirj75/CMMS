import { computeMinutesBetweenShamsiDateTimes } from './dateTimeUtils';

export interface TechTaskRecord {
  id: string;
  code: string;
  workOrderCode?: string;
  title: string;
  place: string;
  date: string;
  durationMinutes: number;
  status: 'انجام شد' | 'در حال اقدام';
  operationType: string;
  priority: 'ایمنی (اولویت بالا)' | 'عادی';
  details: string;
  partsUsed?: string;
  isLive?: boolean;
  technician?: string;
  coTechnicians?: string[];
  complexityLevel?: 'آسان' | 'معمولی' | 'دشوار';
}

// تمامی بایگانی‌ها و سوابق تستی صفر شدند تا کاربران از ابتدا دیتای واقعی خود را ثبت نمایند
export const TECH_FULL_HISTORICAL_TASKS: Record<string, TechTaskRecord[]> = {};

// بررسی انتساب تکنسین به کار (به عنوان تکنسین اصلی یا نفر کمکی/همکار)
function isTechAssigned(r: any, name: string): boolean {
  if (!r || !name) return false;
  if (r.technician === name || r.assignedTo === name) return true;
  if (r.assistant === name || r.helper === name || r.coTechnician === name || r.secondTechnician === name) return true;
  if (Array.isArray(r.technicians) && r.technicians.includes(name)) return true;
  if (Array.isArray(r.coTechnicians) && r.coTechnicians.includes(name)) return true;
  if (Array.isArray(r.woTechnicians) && r.woTechnicians.some((t: any) => String(t?.name || '').trim() === name)) return true;
  if (typeof r.coTechnicians === 'string' && r.coTechnicians.includes(name)) return true;
  if (typeof r.technicians === 'string' && r.technicians.includes(name)) return true;
  const text = `${r.actionDetails || ''} ${r.details || ''} ${r.description || ''} ${r.title || ''}`;
  if (text.includes(name)) return true;
  return false;
}

// استخراج همکاران و نفرات کمکی
function extractCoTechs(r: any, currentTechName: string): string[] {
  if (!r) return [];
  const list: string[] = [];
  if (Array.isArray(r.coTechnicians)) {
    list.push(...r.coTechnicians);
  } else if (typeof r.coTechnicians === 'string') {
    list.push(...r.coTechnicians.split(/[,،]+/).map((s: string) => s.trim()).filter(Boolean));
  }
  if (Array.isArray(r.technicians)) list.push(...r.technicians);
  if (Array.isArray(r.woTechnicians)) {
    r.woTechnicians.forEach((t: any) => {
      const n = String(t?.name || '').trim();
      if (n) list.push(n);
    });
  }
  if (r.assistant) list.push(r.assistant);
  if (r.helper) list.push(r.helper);
  if (r.coTechnician) list.push(r.coTechnician);
  if (r.secondTechnician) list.push(r.secondTechnician);

  // اگر تکنسین فعلی نفر کمکی بوده، تکنسین اصلی همکار او است
  if (r.technician && r.technician !== currentTechName) {
    list.push(r.technician);
  }

  const ALL_TECHS: string[] = [];
  const text = `${r.actionDetails || ''} ${r.details || ''} ${r.description || ''} ${r.title || ''}`;
  ALL_TECHS.forEach(t => {
    if (t !== currentTechName && !list.includes(t) && text.includes(t)) {
      list.push(t);
    }
  });

  return Array.from(new Set(list.filter(n => n && n !== currentTechName)));
}

// دریافت تمام کارهای مرتبط با یک تکنسین (تنها بر اساس درخواست‌ها و دستورکارهای واقعی ثبت‌شده)
export function getTechnicianAllTasks(name: string, workRequests: any[] = []): TechTaskRecord[] {
  // ۱. کارهای ثبت‌شده در جدول درخواست‌ها/دستورکارها
  const liveTasks: TechTaskRecord[] = (workRequests || [])
    .filter(r => isTechAssigned(r, name))
    .map((r, index) => {
      const matchedWoTechs = Array.isArray(r.woTechnicians)
        ? r.woTechnicians.filter((t: any) => String(t?.name || '').trim() === name)
        : [];
      let duration = matchedWoTechs.length > 0
        ? Math.round(matchedWoTechs.reduce((sum: number, t: any) => {
            if (t?.startDate && t?.startTime && t?.endDate && t?.endTime && !t?.customHours) {
              const mins = computeMinutesBetweenShamsiDateTimes(t.startDate, t.startTime, t.endDate, t.endTime);
              if (mins > 0) return sum + mins;
            }
            return sum + Math.round((Number(t?.hours) || 0) * 60);
          }, 0))
        : (Number(r.durationMinutes) || 0);
      if (!duration && r.woStartTime && r.woEndTime) {
        const [sh, sm] = r.woStartTime.split(':').map(Number);
        const [eh, em] = r.woEndTime.split(':').map(Number);
        if (!isNaN(sh) && !isNaN(sm) && !isNaN(eh) && !isNaN(em)) {
          const diff = (eh * 60 + em) - (sh * 60 + sm);
          if (diff > 0) duration = diff;
        }
      }

      // قطعات مصرفی
      let partsUsedText = '';
      if (Array.isArray(r.consumables) && r.consumables.length > 0) {
        partsUsedText = r.consumables.map((c: any) => `${c.name} (${c.quantity || c.count || 1} ${c.unit || 'عدد'} - ${c.category || 'قطعه'})`).join('، ');
      } else if (Array.isArray(r.partsUsed) && r.partsUsed.length > 0) {
        partsUsedText = r.partsUsed.map((p: any) => `${p.name || p.partName} (${p.count || p.quantity || 1} عدد)`).join('، ');
      } else if (typeof r.partsUsed === 'string') {
        partsUsedText = r.partsUsed;
      }

      const priorityVal = (r.priority?.includes('ایمنی') 
        ? 'ایمنی (اولویت بالا)' 
        : 'عادی') as 'ایمنی (اولویت بالا)' | 'عادی';

      const coTechs = extractCoTechs(r, name);
      const firstMatch = matchedWoTechs[0];
      const techStartLabel = firstMatch?.startDate
        ? `${firstMatch.startDate}${firstMatch.startTime ? ` (${firstMatch.startTime})` : ''}`
        : '';
      const techEndLabel = firstMatch?.endDate
        ? `${firstMatch.endDate}${firstMatch.endTime ? ` (${firstMatch.endTime})` : ''}`
        : '';
      const techSpecificDate = techStartLabel
        ? (techEndLabel && techEndLabel !== techStartLabel
            ? `${techStartLabel} تا ${techEndLabel}`
            : techStartLabel)
        : '';

      return {
        id: `live-${r.code || 'task'}-${index}`,
        code: r.code || `WR-${index + 1}`,
        workOrderCode: r.workOrderCode || (r.code ? r.code.replace('WR', 'WO') : undefined),
        title: r.title || 'اقدام فنی',
        place: r.place || 'سالن تولید',
        date: techSpecificDate || r.completedAt || r.woDate || r.created || 'ثبت جدید',
        durationMinutes: duration,
        status: (r.status === 'انجام شد' ? 'انجام شد' : 'در حال اقدام') as 'انجام شد' | 'در حال اقدام',
        operationType: r.operationType || 'تعمیرات و نگهداری',
        priority: priorityVal,
        details: r.actionDetails || r.description || 'اقدامات فنی طبق استاندارد صورت پذیرفت.',
        partsUsed: partsUsedText || undefined,
        isLive: true,
        technician: r.technician || name,
        coTechnicians: coTechs,
        complexityLevel: r.complexityLevel || 'معمولی'
      };
    });

  const historical = TECH_FULL_HISTORICAL_TASKS[name] || [];
  return [...liveTasks, ...historical];
}
