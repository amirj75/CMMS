export const DEFAULT_CATEGORY_IMAGES: Record<string, string> = {};
