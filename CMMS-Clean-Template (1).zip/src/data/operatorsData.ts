import { OperatorLeaderboardItem } from "./portalData";

export interface ProductionOperator extends OperatorLeaderboardItem {
  personnelCode: string;
  netCode: string;
  firstName?: string;
  lastName?: string;
  department: string;
}

export const PRODUCTION_OPERATORS_LIST: ProductionOperator[] = [];
