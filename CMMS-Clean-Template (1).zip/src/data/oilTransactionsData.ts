export interface OilOperation {
  id: string;
  tank_id: number;
  tank_name: string;
  type: 'in' | 'out';
  amount_l: number;
  operator: string;
  equipment?: string;
  created_at: string;
}

/**
 * استخراج و استانداردسازی تاریخ شمسی به فرمت YYYY/MM/DD برای فیلتر بازه تاریخی دقیق
 */
export function normalizeShamsiDateStr(raw: string): string {
  if (!raw) return '';
  const en = raw.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
  const match = en.match(/(1[34]\d{2})[\/\-\.](0?[1-9]|1[0-2])[\/\-\.](0?[1-9]|[12]\d|3[01])/);
  if (match) {
    const y = match[1];
    const m = match[2].padStart(2, '0');
    const d = match[3].padStart(2, '0');
    return `${y}/${m}/${d}`;
  }
  return '';
}

export const HISTORICAL_OIL_TRANSACTIONS: OilOperation[] = [];
