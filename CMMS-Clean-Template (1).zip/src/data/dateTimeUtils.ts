export const toEnDigits = (s: string): string => {
  return String(s || '')
    .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1728))
    .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1584));
};

export const isJalaliLeapYear = (year: number): boolean => {
  const mods = [1, 5, 9, 13, 17, 22, 26, 30];
  return mods.includes(((year % 33) + 33) % 33);
};

// تبدیل تاریخ شمسی (YYYY/MM/DD) به تعداد روزهای مطلق برای محاسبه دقیق تفاضل بین دو تاریخ
export const parseJalaliExactDays = (shamsiDate: string): number | null => {
  try {
    const clean = toEnDigits(shamsiDate || '').trim();
    const match = clean.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
    if (!match) return null;
    const y = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const d = parseInt(match[3], 10);
    if (isNaN(y) || isNaN(m) || isNaN(d) || m < 1 || m > 12 || d < 1 || d > 31) return null;

    let totalDays = 0;
    for (let yr = 1300; yr < y; yr++) {
      totalDays += isJalaliLeapYear(yr) ? 366 : 365;
    }
    if (y < 1300) {
      for (let yr = y; yr < 1300; yr++) {
        totalDays -= isJalaliLeapYear(yr) ? 366 : 365;
      }
    }
    if (m <= 6) {
      totalDays += (m - 1) * 31;
    } else {
      totalDays += 6 * 31 + (m - 7) * 30;
    }
    totalDays += d;
    return totalDays;
  } catch {
    return null;
  }
};

export const parseTimeMinutesOfDay = (timeStr: string): number | null => {
  try {
    const clean = toEnDigits(timeStr || '').trim();
    const match = clean.match(/(\d{1,2}):(\d{1,2})/);
    if (!match) return null;
    const h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) return null;
    return h * 60 + m;
  } catch {
    return null;
  }
};

// محاسبه دقیق مدت زمان به دقیقه بین (تاریخ شروع، ساعت شروع) و (تاریخ پایان، ساعت پایان)
export const computeMinutesBetweenShamsiDateTimes = (
  startDate: string,
  startTime: string,
  endDate: string,
  endTime: string
): number => {
  const sTime = parseTimeMinutesOfDay(startTime);
  const eTime = parseTimeMinutesOfDay(endTime);
  if (sTime === null || eTime === null) return 0;

  const sDays = parseJalaliExactDays(startDate);
  const eDays = parseJalaliExactDays(endDate || startDate);

  if (sDays !== null && eDays !== null) {
    const diff = (eDays - sDays) * 1440 + (eTime - sTime);
    return diff > 0 ? diff : 0;
  }

  const diffSameDay = eTime - sTime;
  return diffSameDay > 0 ? diffSameDay : 0;
};

// استخراج تاریخ (YYYY/MM/DD) و ساعت (HH:MM) از رشته‌های ترکیبی یا پیش‌فرض
export const extractShamsiDateAndTime = (
  rawStr: string | undefined,
  fallbackDate: string,
  fallbackTime: string
): { date: string; time: string } => {
  const clean = toEnDigits(String(rawStr || '')).trim();
  const dateMatch = clean.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  const timeMatch = clean.match(/(\d{1,2}):(\d{1,2})/);
  const date = dateMatch
    ? `${dateMatch[1]}/${dateMatch[2].padStart(2, '0')}/${dateMatch[3].padStart(2, '0')}`
    : fallbackDate;
  const time = timeMatch
    ? `${timeMatch[1].padStart(2, '0')}:${timeMatch[2].padStart(2, '0')}`
    : fallbackTime;
  return { date, time };
};

export const formatMinutesDurationFa = (minutes: number): string => {
  const mins = Math.max(0, Math.round(minutes || 0));
  const toFa = (n: number | string) => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  if (mins === 0) return '۰ دقیقه';
  const hrs = Math.floor(mins / 60);
  const rem = mins % 60;
  if (hrs > 0 && rem > 0) return `${toFa(hrs)} ساعت و ${toFa(rem)} دقیقه`;
  if (hrs > 0) return `${toFa(hrs)} ساعت`;
  return `${toFa(rem)} دقیقه`;
};
