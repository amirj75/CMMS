export interface OilTank {
  id: number;
  name: string;
  subName: string;
  type: string;
  capacityLiters: number;
  currentLiters: number;
  minAlertLiters: number;
  lastRefill: string;
  colorClass: string;
}

export const INITIAL_OIL_TANKS: OilTank[] = [
  {
    id: 1,
    name: 'مخزن ۱ (روغن برش)',
    subName: 'Cutting Oil',
    type: 'برشکاری و ماشین‌های تراش',
    capacityLiters: 2000,
    currentLiters: 0,
    minAlertLiters: 300,
    lastRefill: '',
    colorClass: '#9ec41b'
  },
  {
    id: 2,
    name: 'مخزن ۲ (آب صابون)',
    subName: 'Soluble Cooling Fluid',
    type: 'خنک‌کاری فرزکاری و سوراخ‌کاری',
    capacityLiters: 2000,
    currentLiters: 0,
    minAlertLiters: 300,
    lastRefill: '',
    colorClass: '#543220'
  },
  {
    id: 3,
    name: 'مخزن ۳ (روغن هیدرولیک)',
    subName: 'Hydraulic System ISO VG 46',
    type: 'جک‌ها، پرس‌ها و یونیت‌های هیدرولیک',
    capacityLiters: 1000,
    currentLiters: 0,
    minAlertLiters: 150,
    lastRefill: '',
    colorClass: '#c26e10'
  },
  {
    id: 4,
    name: 'مخزن ۴ (روغن روانکاری)',
    subName: 'Slideway Lubricant ISO VG 68',
    type: 'اسلایدوی، بال‌اسکرو و گیج‌های حرکتی',
    capacityLiters: 1000,
    currentLiters: 0,
    minAlertLiters: 150,
    lastRefill: '',
    colorClass: '#eab308'
  }
];

export interface EquipmentItem {
  id: string;
  code: string;
  name: string;
  category: string;
  hall: string;
  status: 'سالم' | 'نیازمند_سرویس' | 'تعمیر_اضطراری';
  lastInspectionDate: string;
  inspector: string;
  operatorName?: string;
  criticalChecks: string[];
  updatedAt?: number;
}

export const REPRESENTATIVE_EQUIPMENTS: EquipmentItem[] = [];

export interface ChecklistCategory {
  id: string;
  name: string;
  equipmentCount: number;
  image?: string;
  updatedAt?: number;
}

export const INITIAL_CHECKLIST_CATEGORIES: ChecklistCategory[] = [];

export const INSPECTION_DEFECT_OPTIONS = [
  'نظافت بدنه',
  'نظافت اطراف',
  'چک روغن',
  'عدم بررسی',
  'خرابی آب صابون',
  'نشتی',
  'خرابی تجهیز',
  'سایر'
] as const;

export type DefectOption = typeof INSPECTION_DEFECT_OPTIONS[number];

export interface InspectionRecord {
  id: string;
  equipmentId: string;
  equipmentCode: string;
  equipmentName: string;
  category: string;
  operator: string;
  inspector: string;
  date: string;
  time: string;
  result: 'conforming' | 'non_conforming';
  defects: string[];
  notes: string;
  photoUrl?: string;
  workOrderCode?: string;
}

export interface OperatorLeaderboardItem {
  id: string;
  name: string;
  personnelCode?: string;
  netCode?: string;
  department?: string;
  inspectionsCount: number;
  status: 'بدون مشکل' | 'دارای عدم انطباق';
  performancePct: number;
}

export const INITIAL_OPERATOR_LEADERBOARD: OperatorLeaderboardItem[] = [];

export const INITIAL_INSPECTIONS: InspectionRecord[] = [];
