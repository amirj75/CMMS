export const BRAND_CONFIG = {
  COMPANY_NAME: 'شرکت نمونه',
  COMPANY_FULL_NAME: 'شرکت صنعتی نمونه (سهامی خاص)',
  COMPANY_SHORT_EN: 'CMMS INDUSTRIAL',
  SYSTEM_NAME: 'سامانه یکپارچه نگهداری و تعمیرات (CMMS)',
  SYSTEM_SHORT_NAME: 'سامانه CMMS',
  TECHNICAL_DEPT_NAME: 'مدیریت فنی و مهندسی',
  DOC_PREFIX: 'CMMS',
};
