import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Central shared storage file path so PC, mobile and tablets share the exact same database
const DATA_DIR = path.resolve(__dirname, 'data');
const STORAGE_FILE = path.resolve(DATA_DIR, 'app-storage.json');

// Supabase Cloud Storage Client
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || '';
const supabase: SupabaseClient | null = (SUPABASE_URL && SUPABASE_ANON_KEY) ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.warn('Could not create data directory:', err);
  }
}

let centralStorage: Record<string, any> = {};
if (fs.existsSync(STORAGE_FILE)) {
  try {
    const raw = fs.readFileSync(STORAGE_FILE, 'utf-8');
    centralStorage = JSON.parse(raw);
    console.log('> Loaded central storage from disk.');
  } catch (err) {
    console.error('Error reading storage file:', err);
    centralStorage = {};
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));

  // CORS middleware for multi-device access (PC, mobile, standalone app, iframe)
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Parse port from CLI or env
  const args = process.argv.slice(2);
  let port = parseInt(process.env.PORT || '3000', 10);
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port' && args[i + 1]) {
      port = parseInt(args[i + 1], 10);
    }
  }

  // Gemini API setup
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Endpoint: Health Check
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      hasGeminiKey: Boolean(apiKey),
      timestamp: new Date().toISOString(),
    });
  });

  function jalaliToGregorian(jy: number, jm: number, jd: number): [number, number, number] {
    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + (Math.floor(((jy % 33) + 3) / 4)) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor(--days / 36524);
      days %= 36524;
      if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const sal_b = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    for (gm = 0; gm < 13 && gd > sal_b[gm]; gm++) gd -= sal_b[gm];
    return [gy, gm, gd];
  }

  function getTxSortKey(tx: any): number {
    if (!tx) return 0;
    if (tx.timestamp && typeof tx.timestamp === 'number' && tx.timestamp > 1000000000000) return tx.timestamp;
    if (tx.id && typeof tx.id === 'string' && tx.id.startsWith('tx-')) {
      const num = parseInt(tx.id.replace('tx-', ''), 10);
      if (!isNaN(num) && num > 1000000000000) return num;
    }
    const str = tx.created_at || '';
    const clean = String(str)
      .replace(/[۰-۹]/g, (d: string) => String.fromCharCode(d.charCodeAt(0) - 1728))
      .replace(/[٠-٩]/g, (d: string) => String.fromCharCode(d.charCodeAt(0) - 1584));
    const dateMatch = clean.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
    if (!dateMatch) return 0;
    const jy = parseInt(dateMatch[1], 10);
    const jm = parseInt(dateMatch[2], 10);
    const jd = parseInt(dateMatch[3], 10);
    let hour = 12;
    let minute = 0;
    let second = 0;
    const timeMatch = clean.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (timeMatch) {
      hour = parseInt(timeMatch[1], 10);
      minute = parseInt(timeMatch[2], 10);
      if (timeMatch[3]) second = parseInt(timeMatch[3], 10);
    }
    const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
    const d = new Date(gy, gm - 1, gd, hour, minute, second);
    return d.getTime();
  }

  function mergeOilTransactions(existing: any[], incoming: any[]): any[] {
    const map = new Map<string, any>();
    (existing || []).forEach(t => {
      if (t && t.id) map.set(t.id, t);
    });
    (incoming || []).forEach(t => {
      if (t && t.id) map.set(t.id, t);
    });
    return Array.from(map.values()).sort((a, b) => getTxSortKey(b) - getTxSortKey(a));
  }

  async function mirrorToSupabase(payload: any) {
    if (!supabase) return;
    try {
      const res = await Promise.resolve(supabase
        .from('work_requests')
        .upsert({
          code: 'SYSTEM_CENTRAL_STORAGE',
          place: 'دیتاسنتر ابری سامانه',
          created: '1405/08/06',
          title: 'مخزن ابری جامع کلیه اطلاعات انبار روغن، چک‌لیست‌ها و تجهیزات',
          priority: 'بحرانی',
          status: 'انجام شد',
          description: JSON.stringify(payload)
        }, { onConflict: 'code' }));
      if (res && res.error) {
        console.warn('> [SUPABASE] Mirror error:', res.error);
      } else {
        console.log('> [SUPABASE] Mirrored to Supabase cloud.');
      }

      // همگام‌سازی مستقیم و قطعی جدول اختصاصی مخازن در سوپابیس
      if (Array.isArray(payload.oilTanks) && payload.oilTanks.length > 0) {
        for (const t of payload.oilTanks) {
          await Promise.resolve(supabase
            .from('tanks')
            .upsert({
              id: Number(t.id),
              name: t.name,
              sub_name: t.subName || '',
              type: t.type || '',
              capacity_liters: Number(t.capacityLiters || 1000),
              current_liters: Number(t.currentLiters || 0),
              min_alert_liters: Number(t.minAlertLiters || 200),
              last_refill: t.lastRefill || '',
              color_class: t.colorClass || ''
            }, { onConflict: 'id' }));
        }
        console.log('> [SUPABASE] Tanks table updated successfully.');
      }
    } catch (e: any) {
      console.warn('> [SUPABASE] Mirror exception:', e);
    }
  }

  // Load from Supabase on boot if available
  (async () => {
    if (!supabase) return;
    try {
      const res = await Promise.resolve(supabase
        .from('work_requests')
        .select('description, created_at')
        .eq('code', 'SYSTEM_CENTRAL_STORAGE')
        .maybeSingle());

      if (res && !res.error && res.data && res.data.description) {
        try {
          const parsed = JSON.parse(res.data.description);
          if (parsed && typeof parsed === 'object') {
            centralStorage = {
              ...centralStorage,
              ...parsed
            };
            console.log(`> [SUPABASE] Loaded central state on server boot. Total tx: ${centralStorage.oilTransactions?.length || 0}`);
          }
        } catch {}
      }
    } catch (err: any) {
      console.warn('> [SUPABASE] Boot read error:', err);
    }
  })();

  // Endpoint: Shared Central State across all devices (PC, Phone, Tablet)
  app.get('/api/portal/sync-state', (_req, res) => {
    res.json({
      success: true,
      data: centralStorage,
      updatedAt: centralStorage._updatedAt || null,
      serverTime: new Date().toISOString()
    });
  });

  app.post('/api/portal/sync-state', (req, res) => {
    try {
      const incoming = req.body || {};

      // ۱. اگر تراکنش تکی جدید ارسال شده، مستقیماً اضافه و از موجودی مخزن کسر/شارژ شود
      if (incoming.newTransaction && incoming.newTransaction.id) {
        const tx = incoming.newTransaction;
        centralStorage.oilTransactions = mergeOilTransactions(
          centralStorage.oilTransactions || [],
          [tx]
        );
        if (Array.isArray(centralStorage.oilTanks)) {
          centralStorage.oilTanks = centralStorage.oilTanks.map((t: any) => {
            const matchesId = String(t.id) === String(tx.tank_id) || 
                              String(t.id).replace('tank-', '') === String(tx.tank_id).replace('tank-', '');
            const matchesName = Boolean(tx.tank_name && t.name && tx.tank_name.trim() === t.name.trim());
            if (matchesId || matchesName) {
              const amt = Number(tx.amount_l) || 0;
              const cur = Number(t.currentLiters) || 0;
              const next = tx.type === 'in' ? Math.min(t.capacityLiters, cur + amt) : Math.max(0, cur - amt);
              return { ...t, currentLiters: Math.round(next * 10) / 10, lastRefill: tx.created_at || t.lastRefill };
            }
            return t;
          });
        }
      }

      // ۲. ادغام امن لیست تراکنش‌های روغن بدون حذف دیتای قبلی
      if (Array.isArray(incoming.oilTransactions) && incoming.oilTransactions.length > 0) {
        centralStorage.oilTransactions = mergeOilTransactions(
          centralStorage.oilTransactions || [],
          incoming.oilTransactions
        );
      }

      // ۳. به‌روزرسانی وضعیت لحظه‌ای مخازن روغن در صورت ارسال لیست کامل جدید (با حفظ کاهش موجودی‌های جدید)
      if (Array.isArray(incoming.oilTanks) && incoming.oilTanks.length > 0) {
        if (!incoming.newTransaction) {
          centralStorage.oilTanks = incoming.oilTanks;
        } else {
          // اگر همزمان تراکنش ارسال شده، مطمئن شویم حجم تانک کسر شده حفظ می‌شود
          centralStorage.oilTanks = centralStorage.oilTanks.map((st: any) => {
            const inc = incoming.oilTanks.find((it: any) => String(it.id) === String(st.id) || (it.name && it.name === st.name));
            if (inc && typeof inc.currentLiters === 'number') {
              // موجودی کمتر اولویت دارد تا برداشت ناپدید نشود
              return { ...st, currentLiters: Math.min(st.currentLiters, inc.currentLiters) };
            }
            return st;
          });
        }
      }

      // ۴. ادغام اختصاصی و ماندگار عکس‌های پرسنلی تکنسین‌ها
      if (incoming.technicianPhotos && typeof incoming.technicianPhotos === 'object') {
        centralStorage.technicianPhotos = {
          ...(centralStorage.technicianPhotos || {}),
          ...incoming.technicianPhotos
        };
      }

      // ۵. ادغام سایر کلیدها
      Object.keys(incoming).forEach(k => {
        if (k !== 'oilTransactions' && k !== 'newTransaction' && k !== 'oilTanks' && k !== 'technicianPhotos') {
          centralStorage[k] = incoming[k];
        }
      });

      centralStorage._updatedAt = Date.now();

      // Save to file safely
      try {
        fs.writeFileSync(STORAGE_FILE, JSON.stringify(centralStorage, null, 2), 'utf-8');
      } catch (err) {
        console.error('Error saving storage file:', err);
      }

      // Mirror to Supabase cloud
      mirrorToSupabase(centralStorage);

      console.log(`> [SYNC SUCCESS] Device synced. Total oil tx: ${centralStorage.oilTransactions?.length || 0}, Tanks: ${centralStorage.oilTanks?.map((t: any) => t.name + ':' + t.currentLiters).join(' | ')}`);

      res.json({
        success: true,
        data: centralStorage,
        updatedAt: centralStorage._updatedAt
      });
    } catch (err: any) {
      console.error('Error updating central storage:', err);
      res.status(500).json({ success: false, error: err?.message || 'Server error' });
    }
  });

  // Force-upload master data from PC to server
  app.post('/api/portal/force-upload', (req, res) => {
    try {
      const payload = req.body || {};
      if (typeof payload !== 'object') {
        return res.status(400).json({ success: false, error: 'Invalid payload' });
      }

      // Merge transactions safely
      if (Array.isArray(payload.oilTransactions)) {
        payload.oilTransactions = mergeOilTransactions(
          centralStorage.oilTransactions || [],
          payload.oilTransactions
        );
      }

      // Merge payload into centralStorage
      centralStorage = {
        ...centralStorage,
        ...payload,
        _updatedAt: Date.now()
      };

      try {
        fs.writeFileSync(STORAGE_FILE, JSON.stringify(centralStorage, null, 2), 'utf-8');
      } catch (err) {
        console.error('Error writing force-upload file:', err);
      }

      // Mirror to Supabase cloud
      mirrorToSupabase(centralStorage);

      console.log(`> Force upload received and saved. Total keys: ${Object.keys(centralStorage).length}`);
      res.json({
        success: true,
        data: centralStorage,
        message: 'تمامی داده‌ها با موفقیت در سرور ذخیره شد.',
        updatedAt: centralStorage._updatedAt
      });
    } catch (err: any) {
      console.error('Error in /api/portal/force-upload:', err);
      res.status(500).json({ success: false, error: err?.message || 'Server error' });
    }
  });

  // Download full JSON backup
  app.get('/api/portal/download-backup', (_req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="cmms-backup-${Date.now()}.json"`);
    res.send(JSON.stringify(centralStorage, null, 2));
  });


  // Download standalone desktop HTML bundle with PRE-LOADED central storage
  app.get(['/api/portal/download-desktop', '/download-desktop', '/CMMS-Factory-Desktop.html'], (req, res, next) => {
    const isAttachment = req.path.includes('download') || req.query.download === '1' || req.query.attachment === '1';
    const publicPath = path.resolve(__dirname, 'public', 'CMMS-Factory-Desktop.html');
    const distPath = path.resolve(__dirname, 'dist', 'CMMS-Factory-Desktop.html');
    const targetPath = fs.existsSync(publicPath) ? publicPath : distPath;

    if (!fs.existsSync(targetPath)) {
      if (req.path.includes('download')) {
        return res.status(404).send('فایل دسکتاپ یافت نشد.');
      }
      return next();
    }

    try {
      let content = fs.readFileSync(targetPath, 'utf-8');
      // Inject the current central storage directly into the downloaded file
      const injection = `<script id="cmms-preloaded-data">window.__PRELOADED_CENTRAL_STORAGE__ = ${JSON.stringify(centralStorage)};</script>`;
      if (content.includes('</head>')) {
        content = content.replace('</head>', `${injection}\n</head>`);
      } else {
        content = `${injection}\n${content}`;
      }

      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      if (isAttachment) {
        res.setHeader('Content-Disposition', 'attachment; filename="CMMS-Factory-Desktop.html"');
      }
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      return res.send(content);
    } catch (err) {
      console.error('Error serving desktop file:', err);
      return res.sendFile(targetPath);
    }
  });

  // Endpoint: AI Technician Performance Analysis
  app.post('/api/technician-ai-analysis', async (req, res) => {
    try {
      const {
        technicianName,
        tasks = [],
        totalPlantTasks = 0,
        plantTotalMinutes = 0,
      } = req.body;

      if (!technicianName) {
        return res.status(400).json({ error: 'نام تکنسین الزامی است.' });
      }

      // محاسبه شاخص‌های پایه‌ای قبل از هوش مصنوعی
      const techTaskCount = tasks.length;
      const doneTasks = tasks.filter((t: any) => t.status === 'انجام شد');
      const activeTasks = tasks.filter((t: any) => t.status !== 'انجام شد');
      const totalMinutes = tasks.reduce((sum: number, t: any) => sum + (Number(t.durationMinutes) || 0), 0);
      const avgMinutes = techTaskCount > 0 ? Math.round(totalMinutes / techTaskCount) : 0;

      // سهم از کل کارهای خدمات فنی کارخانه
      const shareOfPlant = totalPlantTasks > 0 ? Math.round((techTaskCount / totalPlantTasks) * 100) : (techTaskCount > 0 ? 100 : 0);

      // تفکیک کارهای انفرادی (تکی) در برابر همراه با نیرو کمکی/شاگرد
      let soloTasksCount = 0;
      let teamTasksCount = 0;

      // بررسی نوع عملیات
      const opCountMap: Record<string, number> = {
        'برق صنعتی': 0,
        'مکانیک': 0,
        'تاسیسات': 0,
        'روشنایی': 0,
        'عمومی': 0,
      };

      tasks.forEach((t: any) => {
        const text = `${t.title || ''} ${t.description || ''} ${t.details || ''} ${t.actionDetails || ''}`;
        const hasHelpers = 
          (Array.isArray(t.coTechnicians) && t.coTechnicians.length > 0) ||
          (Array.isArray(t.technicians) && t.technicians.length > 1) ||
          Boolean(t.assistant || t.helper || t.assistantTechnician || t.coTechnician || t.secondTechnician) ||
          (t.technician && t.technician !== technicianName);
        const isTeam = hasHelpers || text.includes('کمکی') || text.includes('شاگرد') || text.includes('همراه') || text.includes('تیم') || text.includes('نفرات') || text.includes('دسته جمعی') || text.includes('با همکاری') || text.includes('دونفره') || text.includes('دو نفره') || text.includes('۲ نفره') || text.includes('تیمی');
        if (isTeam) {
          teamTasksCount++;
        } else {
          soloTasksCount++;
        }

        const op = t.operationType || 'عمومی';
        if (opCountMap[op] !== undefined) {
          opCountMap[op]++;
        } else if (op.includes('برق')) {
          opCountMap['برق صنعتی']++;
        } else if (op.includes('مکانیک')) {
          opCountMap['مکانیک']++;
        } else if (op.includes('تاسیسات')) {
          opCountMap['تاسیسات']++;
        } else {
          opCountMap['عمومی']++;
        }
      });

      const soloPercent = techTaskCount > 0 ? Math.round((soloTasksCount / techTaskCount) * 100) : 0;
      const teamPercent = techTaskCount > 0 ? Math.round((teamTasksCount / techTaskCount) * 100) : 0;
      const completionRate = techTaskCount > 0 ? Math.round((doneTasks.length / techTaskCount) * 100) : 0;

      // تشخیص رشته غالب
      let topOp = 'عمومی';
      let topOpCount = 0;
      Object.entries(opCountMap).forEach(([op, count]) => {
        if (count > topOpCount) {
          topOp = op;
          topOpCount = count;
        }
      });

      // آمار سطوح پیچیدگی کارها و سنجش انطباق با استانداردهای زمانی و نفرات
      // آسان: سقف ۲ ساعت (۱۲۰ دقیقه) و ۱ تکنسین
      // معمولی: سقف ۴ ساعت (۲۴۰ دقیقه) و تا ۲ تکنسین
      // دشوار: سقف ۸ ساعت (۴۸۰ دقیقه) و تا ۳ تکنسین
      let easyCount = 0;
      let normalCount = 0;
      let hardCount = 0;
      let onTimeComplianceCount = 0;
      let teamStandardConformCount = 0;

      tasks.forEach((t: any) => {
        const comp = t.complexityLevel || 'معمولی';
        const dur = Number(t.durationMinutes) || 45;
        const coList = Array.isArray(t.coTechnicians) ? t.coTechnicians : [];
        const teamSize = 1 + coList.length;

        let timeLimit = 240; // پیش‌فرض معمولی
        let maxTechs = 2;

        if (comp === 'آسان') {
          easyCount++;
          timeLimit = 120;
          maxTechs = 1;
        } else if (comp === 'دشوار') {
          hardCount++;
          timeLimit = 480;
          maxTechs = 3;
        } else {
          normalCount++;
          timeLimit = 240;
          maxTechs = 2;
        }

        if (dur <= timeLimit) {
          onTimeComplianceCount++;
        }
        if (teamSize <= maxTechs) {
          teamStandardConformCount++;
        }
      });

      const onTimePercent = techTaskCount > 0 ? Math.round((onTimeComplianceCount / techTaskCount) * 100) : 100;
      const teamConformPercent = techTaskCount > 0 ? Math.round((teamStandardConformCount / techTaskCount) * 100) : 100;

      // تشخیص سرعت تجربی بر اساس انطباق با سقف مجاز سطح پیچیدگی
      let speedLabel = 'منطبق بر سقف استاندارد زمانی';
      if (onTimePercent === 100 && avgMinutes <= 60) {
        speedLabel = 'سریع و چابک (زودتر از سقف استاندارد)';
      } else if (onTimePercent >= 85) {
        speedLabel = 'سریع و استاندارد در سطوح کار';
      } else if (onTimePercent >= 60) {
        speedLabel = 'متعادل (پروژه‌ای)';
      } else {
        speedLabel = 'طولانی‌تر از سقف زمانی استاندارد';
      }

      // محاسبه ستاره کیفیت عملکرد تکنسین (از ۱ تا ۵ ستاره) - مبتنی بر کیفیت اجرا، سرعت و تموم‌کنندگی در سطوح پیچیدگی کار
      let starRating = 5;
      let starRatingLabel = 'کیفیت عالی و بی‌نقص (۵ ستاره)';

      if (techTaskCount > 0) {
        // ۱. امتیاز تموم‌کنندگی و بستن کارها (کیفیت اصلی) - تا ۵۰ امتیاز
        const completionQuality = (completionRate / 100) * 50;

        // ۲. امتیاز چابکی و رعایت سقف زمانی پیچیدگی (۲ ساعت آسان، ۴ ساعت معمولی، ۸ ساعت دشوار) - تا ۳۰ امتیاز
        const speedQuality = (onTimePercent / 100) * 30;

        // ۳. امتیاز مدیریت نفرات و استقلال فنی (تا ۲۰ امتیاز)
        // تکنسین‌هایی که کارهای دشوار را با موفقیت جمع کرده‌اند امتیاز ویژه دریافت می‌کنند
        const teamScore = (teamConformPercent / 100) * 15;
        const hardBonus = Math.min(5, hardCount * 2.5);
        const autonomyQuality = Math.min(20, teamScore + (soloPercent >= 50 ? 5 : 3) + hardBonus);

        const totalQuality = completionQuality + speedQuality + autonomyQuality; // سقف ۱۰۰

        if (totalQuality >= 90) {
          starRating = 5;
          starRatingLabel = 'کیفیت عالی و بی‌نقص (۵ ستاره)';
        } else if (totalQuality >= 80) {
          starRating = 4.5;
          starRatingLabel = 'بسیار مطلوب و حرفه‌ای (۴.۵ ستاره)';
        } else if (totalQuality >= 70) {
          starRating = 4;
          starRatingLabel = 'کیفیت خوب و مورد تأیید (۴ ستاره)';
        } else if (totalQuality >= 60) {
          starRating = 3.5;
          starRatingLabel = 'کیفیت متوسط روبه‌بالا (۳.۵ ستاره)';
        } else if (totalQuality >= 50) {
          starRating = 3;
          starRatingLabel = 'کیفیت متوسط و قابل‌قبول (۳ ستاره)';
        } else {
          starRating = 2.5;
          starRatingLabel = 'نیازمند همراهی و نظارت کیفی (۲.۵ ستاره)';
        }
      }

      // در صورتی که تکنسین هنوز هیچ کاری ثبت نکرده باشد
      if (techTaskCount === 0) {
        return res.json({
          technicianName,
          taskCount: 0,
          doneCount: 0,
          activeCount: 0,
          totalMinutes: 0,
          avgMinutes: 0,
          shareOfPlantPercent: 0,
          soloPercent: 0,
          teamPercent: 0,
          completionRate: 0,
          topSpecialty: 'در انتظار ثبت اولین کار',
          speedLabel: 'بدون داده',
          easyCount: 0,
          normalCount: 0,
          hardCount: 0,
          onTimePercent: 100,
          starRating: 5,
          starRatingLabel: 'در انتظار ثبت اولین کار',
          analysisText: `چکیده تحلیلی عملکرد تکنسین ${technicianName}:
• سابقه کار: در حال حاضر هیچ دستورکاری برای این تکنسین در سامانه ثبت نشده است.
• وضعیت سنجش: پس از ثبت و خاتمه اولین فعالیت، کیفیت اجرا و گرایش تخصصی ارزیابی خواهد شد.
• استقلال و تموم‌کنندگی: داده‌ای جهت سنجش کار تکی یا کمکی وجود ندارد.
• توصیه: پیشنهاد می‌شود اولین کار تخصصی خط تولید به ایشان ارجاع گردد.`,
        });
      }

      // اگر کلید Gemini در دسترس است، از مدل gemini-2.5-flash با محدودیت زمانی سریع استفاده می‌کنیم
      let aiText = '';
      if (ai) {
        const taskBriefList = tasks.slice(0, 10).map((t: any, idx: number) => {
          const comp = t.complexityLevel || 'معمولی';
          const teamInfo = (Array.isArray(t.coTechnicians) && t.coTechnicians.length > 0)
            ? `تیم ${t.coTechnicians.length + 1} نفره (با ${t.coTechnicians.join('، ')})`
            : 'تک‌نفره';
          return `${idx + 1}. ${t.title} [${t.operationType || 'عمومی'}] - پیچیدگی: ${comp} (زمان: ${t.durationMinutes || 60} دقیقه، ${teamInfo}) - وضعیت: ${t.status}`;
        }).join('\n');

        const prompt = `شما ناظر ارشد و کارشناس خبره نت (نگهداری و تعمیرات) واحد فنی هستید.
اطلاعات عملکرد تکنسین:
نام: ${technicianName}
تعداد کارهای ثبت‌شده: ${techTaskCount} (${doneTasks.length} تمام‌شده، ${activeTasks.length} جاری)
تفکیک پیچیدگی کارها بر اساس استانداردهای واحد نگهداری:
• کارهای آسان (استاندارد حداکثر ۲ ساعت و ۱ تکنسین): ${easyCount} مورد
• کارهای معمولی (استاندارد حداکثر ۴ ساعت و بین ۱ تا ۲ تکنسین): ${normalCount} مورد
• کارهای دشوار (استاندارد تا ۸ ساعت کاری و تا ۳ تکنسین): ${hardCount} مورد
رعایت استاندارد سقف زمانی: ${onTimePercent}٪ کارها درون سقف مجاز استاندارد انجام شده‌اند.
میانگین زمان هر کار: ${avgMinutes} دقیقه (${speedLabel})
سهم از کل خدمات فنی: ${shareOfPlant}%
کارهای تکی: ${soloPercent}% | کارهای با نیروی کمکی/تیمی: ${teamPercent}%
تموم‌کنندگی فردی (درصد تحویل و بستن کارها): ${completionRate}%
گرایش فنی اصلی: ${topOp} (برق: ${opCountMap['برق صنعتی']}، مکانیک: ${opCountMap['مکانیک']}، تاسیسات: ${opCountMap['تاسیسات']}، عمومی: ${opCountMap['عمومی']})
نمونه کارها:
${taskBriefList}

دستور:
یک ارزیابی مدیریتی بسیار مفید و کاربردی در حداکثر ۵ الی ۶ خط بنویسید (بدون سلام، بدون مقدمه‌چینی، بدون حاشیه‌پردازی و بدون ذکر هرگونه نمره عددی از ۱۰۰).
در این متن حداکثر ۶ خطی صریحاً مشخص کنید:
۱. سرعت و ریتم انجام با توجه به سطح پیچیدگی: آیا کارها درون سقف مجاز استاندارد (آسان تا ۲ ساعت، معمولی تا ۴ ساعت، دشوار تا ۸ ساعت) سریع و به‌موقع جمع شده‌اند؟
۲. تناسب و توان فنی: عیار تکنسین در مواجهه با کارهای دشوار و معمولی چگونه است و بیشتر به درد کارهای برقی می‌خورد یا تاسیساتی، مکانیکی و خدماتی؟
۳. استقلال و هماهنگی تیمی: توانایی اجرای تکی کارهای آسان در برابر هماهنگی تیمی ۲ تا ۳ نفره در کارهای معمولی و دشوار، و قدرت تموم‌کنندگی و مسئولیت تحویل او.
۴. توصیه سرپرستی: چه نوع کارهایی (آسان، معمولی یا پروژه‌های دشوار) بهتر است در اولویت به او سپرده شود؟

تذکر حیاتی: تعداد کارها را ملاک منفی قرار ندهید (شاید نیروی جدید باشد)، بلکه صرفاً «کیفیت اجرا، رعایت استانداردهای زمانی و نفرات پیچیدگی کار، و تموم‌کنندگی» ملاک است. هیچ نمره‌ای از ۱۰۰ ننویسید.`;

        try {
          const timeoutPromise = new Promise<null>((_, reject) =>
            setTimeout(() => reject(new Error('Gemini API timeout')), 3500)
          );
          const geminiPromise = ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
          });
          const response: any = await Promise.race([geminiPromise, timeoutPromise]);
          aiText = response?.text?.trim() || '';
        } catch (geminiErr: any) {
          console.warn('Gemini 2.5 Flash unavailable or timed out, using intelligent analytical engine:', geminiErr?.message || geminiErr);
        }
      }

      // در صورتی که پاسخ هوش مصنوعی آماده نشد، نسخه چکیده استاندارد تولید می‌شود (نهایت ۵ خط صریح و تخصصی)
      if (!aiText) {
        aiText = `• بازده کلی: ${onTimePercent}٪ کارها طبق چارچوب استاندارد بوده است.
• تناسب و توان فنی: در بخش «${topOp}» به خصوص در اجرای کارهای سطح ${hardCount > 0 ? 'دشوار و پروژه‌ای' : 'معمولی و اضطراری'} تمرکز بالا و بازدهی اثبات‌شده دارد.
• استقلال و کار تیمی: منطبق بر استانداردهای فنی (اجرای مستقل کارهای آسان و هماهنگی ${teamPercent > 0 ? 'تیمی ۲ الی ۳ نفره در کارهای دشوارتر' : 'تک‌نفره با سرعت بالا'}).
• تموم‌کنندگی فردی: ضریب بستن و تحویل کامل کارها ${completionRate}٪ بوده که نشان‌دهنده دقت بالا و مسئولیت‌پذیری در تحویل نهایی است.
• توصیه سرپرستی: اولویت‌دهی به واگذاری دستورکارهای ${hardCount > 0 ? 'دشوار و حساس' : 'تخصصی'} حوزه ${topOp} متناسب با سرعت و ظرفیت کاری.`;
      }

      return res.json({
        technicianName,
        taskCount: techTaskCount,
        doneCount: doneTasks.length,
        activeCount: activeTasks.length,
        totalMinutes,
        avgMinutes,
        shareOfPlantPercent: shareOfPlant,
        soloPercent,
        teamPercent,
        completionRate,
        topSpecialty: topOp,
        speedLabel,
        starRating,
        starRatingLabel,
        analysisText: aiText,
      });
    } catch (err: any) {
      console.error('Error in /api/technician-ai-analysis:', err);
      return res.status(500).json({
        error: 'خطا در تحلیل هوش مصنوعی: ' + (err?.message || 'خطای ناشناخته سرور'),
      });
    }
  });

  // Create HTTP server
  const server = http.createServer(app);

  // Vite middleware in dev or static files in prod
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });

    // Prevent @vite/client from opening a failing WebSocket connection when HMR is disabled
    app.get('/@vite/client', async (_req, res, next) => {
      try {
        const result = await vite.transformRequest('/@vite/client');
        if (result?.code) {
          const patched = result.code
            .replace('transport.connect(createHMRHandler(handleMessage));', '/* HMR WebSocket disabled */')
            .replace('setupForwardConsoleHandler(transport, forwardConsole);', '/* ForwardConsole disabled */');
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store');
          return res.send(patched);
        }
      } catch {}
      next();
    });

    app.use(vite.middlewares);
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`> Full-stack server running at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
